#!/usr/bin/env python3
"""
wire.qa — Automated visual and interaction testing.

Runs against a built site to validate HTML quality, internal links,
SEO metadata, accessibility basics, and optionally captures screenshots
with layout regression detection.

Usage:
    python -m wire.qa --site /path/to/site
    python -m wire.qa --site /path/to/site --full
    python -m wire.qa --site /path/to/site --screenshots
    python -m wire.qa --site /path/to/site --update-reference
    python -m wire.qa --site /path/to/site --pages vendors/acme guides/setup
"""

import json
import logging
import re
from collections import defaultdict
from pathlib import Path

from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)


# ============================================================================
# Viewport definitions
# ============================================================================

VIEWPORTS = {
    "desktop": {"width": 1280, "height": 900},
    "mobile": {"width": 390, "height": 844},
}

MOBILE_USER_AGENT = (
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 "
    "Mobile/15E148 Safari/604.1"
)

# Layout regression threshold: >2% pixel change = regression
REGRESSION_THRESHOLD = 0.02


class QAResult:
    """A single QA check result."""

    __slots__ = ("page", "check", "severity", "message")

    SEVERITY_ERROR = "error"
    SEVERITY_WARNING = "warning"
    SEVERITY_INFO = "info"

    def __init__(self, page: str, check: str, severity: str, message: str):
        self.page = page
        self.check = check
        self.severity = severity
        self.message = message

    def __str__(self):
        icon = {"error": "X", "warning": "!", "info": "-"}[self.severity]
        return f"  [{icon}] {self.check}: {self.message} ({self.page})"


class ScreenshotResult:
    """Result of a screenshot capture + optional regression check."""

    __slots__ = ("page", "viewport", "screenshot_path", "is_regression",
                 "diff_pct", "diff_path", "reference_path")

    def __init__(self, page: str, viewport: str, screenshot_path: Path,
                 is_regression: bool = False, diff_pct: float = 0.0,
                 diff_path: Path = None, reference_path: Path = None):
        self.page = page
        self.viewport = viewport
        self.screenshot_path = screenshot_path
        self.is_regression = is_regression
        self.diff_pct = diff_pct
        self.diff_path = diff_path
        self.reference_path = reference_path


class QAReport:
    """Aggregated QA report for a site."""

    def __init__(self):
        self.results: list[QAResult] = []
        self.pages_checked = 0
        self.screenshots: list[ScreenshotResult] = []
        self.regressions: list[ScreenshotResult] = []

    @property
    def errors(self) -> list[QAResult]:
        return [r for r in self.results if r.severity == QAResult.SEVERITY_ERROR]

    @property
    def warnings(self) -> list[QAResult]:
        return [r for r in self.results if r.severity == QAResult.SEVERITY_WARNING]

    @property
    def has_critical_errors(self) -> bool:
        return len(self.errors) > 0 or len(self.regressions) > 0

    def summary(self) -> str:
        lines = []
        if not self.results and not self.regressions:
            parts = [f"QA: {self.pages_checked} pages checked. All passed."]
            if self.screenshots:
                parts.append(f" {len(self.screenshots)} screenshots captured.")
            lines.append("".join(parts))
            return "\n".join(lines)

        errors = len(self.errors)
        warns = len(self.warnings)
        reg_count = len(self.regressions)
        lines.append(
            f"QA: {self.pages_checked} pages checked. "
            f"{errors} error(s), {warns} warning(s).")

        if reg_count:
            lines.append(f"  {reg_count} layout regression(s) detected.")

        if self.errors:
            lines.append("\nErrors:")
            for r in self.errors:
                lines.append(str(r))

        if self.regressions:
            lines.append("\nLayout Regressions:")
            for s in self.regressions:
                lines.append(
                    f"  [X] {s.viewport}: {s.diff_pct:.1f}% changed ({s.page})")

        if self.warnings:
            lines.append("\nWarnings:")
            for r in self.warnings[:10]:
                lines.append(str(r))
            if len(self.warnings) > 10:
                lines.append(f"  ... and {len(self.warnings) - 10} more")

        return "\n".join(lines)


# ============================================================================
# HTML-based checks (no browser needed)
# ============================================================================

def check_seo(soup: BeautifulSoup, url: str) -> list[QAResult]:
    """Check SEO metadata on a single page."""
    results = []

    # Title
    title = soup.find("title")
    if not title or not title.get_text(strip=True):
        results.append(QAResult(url, "SEO", "error", "Missing <title> tag"))
    else:
        title_text = title.get_text(strip=True)
        if len(title_text) > 65:
            results.append(QAResult(url, "SEO", "warning",
                                    f"Title too long ({len(title_text)} chars)"))

    # Meta description
    desc = soup.find("meta", attrs={"name": "description"})
    if not desc or not desc.get("content"):
        results.append(QAResult(url, "SEO", "error", "Missing meta description"))
    elif len(desc["content"]) > 160:
        results.append(QAResult(url, "SEO", "warning",
                                f"Description too long ({len(desc['content'])} chars)"))

    # H1 (exclude code/pre blocks)
    h1s = [h for h in soup.find_all("h1")
           if not h.find_parent(["code", "pre"])]
    if not h1s:
        results.append(QAResult(url, "SEO", "error", "Missing H1"))
    elif len(h1s) > 1:
        results.append(QAResult(url, "SEO", "warning",
                                f"Multiple H1 tags ({len(h1s)})"))

    # Canonical
    canonical = soup.find("link", attrs={"rel": "canonical"})
    if not canonical:
        results.append(QAResult(url, "SEO", "warning", "Missing canonical tag"))

    # Viewport
    viewport = soup.find("meta", attrs={"name": "viewport"})
    if not viewport:
        results.append(QAResult(url, "SEO", "error", "Missing viewport meta tag"))

    return results


def _resolve_href(page_url: str, href: str) -> str:
    """Resolve a relative or absolute href against a page URL.

    Returns an absolute path (e.g. "/guides/setup/").
    """
    from posixpath import normpath

    if href.startswith("/"):
        return href

    base = page_url if page_url.endswith("/") else page_url + "/"
    combined = base + href
    result = normpath(combined)
    if not result.endswith("/"):
        result += "/"
    return result


def check_links(soup: BeautifulSoup, url: str,
                site_dir: Path, base_path: str = "") -> list[QAResult]:
    """Validate internal links on a page."""
    results = []

    for a in soup.find_all("a", href=True):
        href = a["href"]

        # Skip external, anchor, and special links
        if href.startswith(("http", "#", "javascript:", "mailto:")):
            # Check masked links have data-url
            if href == "javascript:void(0)":
                if not a.get("data-url"):
                    text = a.get_text(strip=True)[:30]
                    results.append(QAResult(url, "Links", "error",
                                            f"Masked link missing data-url: \"{text}\""))
            continue

        # Resolve relative links against the page URL
        resolved = _resolve_href(url, href)

        # Internal link — check target exists
        target = resolved.lstrip("/")
        if not target:
            continue

        target_path = site_dir / target
        if not target_path.exists():
            target_index = site_dir / target / "index.html"
            if not target_index.exists():
                text = a.get_text(strip=True)[:30]
                results.append(QAResult(url, "Links", "error",
                                        f"Broken: {href} (\"{text}\")"))

        # Check for empty anchor text
        text = a.get_text(strip=True)
        if not text and not a.find("img") and not a.get("aria-label"):
            results.append(QAResult(url, "Links", "warning",
                                    f"Empty anchor text: {href}"))

    return results


def check_accessibility(soup: BeautifulSoup, url: str) -> list[QAResult]:
    """Basic accessibility checks (no axe-core needed)."""
    results = []

    # Images without alt
    for img in soup.find_all("img"):
        if not img.has_attr("alt"):
            src = img.get("src", "unknown")
            results.append(QAResult(url, "A11y", "error",
                                    f"Image missing alt: {src}"))

    # Links that open in new tab without rel
    for a in soup.find_all("a", target="_blank"):
        rel = a.get("rel", [])
        if isinstance(rel, str):
            rel = rel.split()
        if "noopener" not in rel:
            results.append(QAResult(url, "A11y", "warning",
                                    f"target=_blank without rel=noopener: {a.get('href', '')}"))

    # Check for lang attribute on html
    html_tag = soup.find("html")
    if html_tag and not html_tag.get("lang"):
        results.append(QAResult(url, "A11y", "warning",
                                "Missing lang attribute on <html>"))

    # Check for skip-to-content link
    main = soup.find("main")
    if main and main.get("id"):
        skip_link = soup.find("a", href=f"#{main['id']}")
        # Don't flag — this is informational only

    return results


def check_html_quality(soup: BeautifulSoup, url: str) -> list[QAResult]:
    """Check HTML quality metrics."""
    results = []

    # DOM node count — 1500 accommodates nav, footer, sidebar, and real content
    all_tags = soup.find_all()
    if len(all_tags) > 1500:
        results.append(QAResult(url, "HTML", "warning",
                                f"Heavy DOM: {len(all_tags)} nodes (target: <1500)"))

    # Check for inline styles (bad practice)
    inline_styles = soup.find_all(style=True)
    # Exclude discovery layer hidden steps
    non_discovery = [t for t in inline_styles
                     if not t.get("data-step") and not t.get("data-discovery")
                     and "discovery" not in t.get("class", [])]
    if len(non_discovery) > 5:
        results.append(QAResult(url, "HTML", "warning",
                                f"{len(non_discovery)} elements with inline styles"))

    return results


# ============================================================================
# Nav interaction testing (requires Playwright)
# ============================================================================

def check_nav_links(site_dir: Path,
                    playwright_launch: callable = None) -> list[QAResult]:
    """Click every nav link and verify the target loads without errors.

    Uses Playwright to render the homepage, find all nav <a> elements,
    and verify each target page exists and loads. Catches broken nav
    items that static link checking misses (e.g., JS-rendered nav).

    Args:
        site_dir: Path to built site directory.
        playwright_launch: Optional callable returning a Playwright browser.

    Returns:
        List of QAResult objects for broken or erroring nav links.
    """
    results = []

    # Find homepage
    homepage = site_dir / "index.html"
    if not homepage.exists():
        results.append(QAResult("/", "Nav", "error", "No index.html found"))
        return results

    if playwright_launch:
        browser = playwright_launch()
    else:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            logger.error(
                "Playwright not installed. Run: pip install playwright && "
                "playwright install chromium")
            return results
        pw = sync_playwright().start()
        browser = pw.chromium.launch()

    try:
        ctx = browser.new_context(viewport=VIEWPORTS["desktop"])
        page = ctx.new_page()

        # Collect console errors
        console_errors = []
        page.on("console", lambda msg: console_errors.append(msg.text)
                if msg.type == "error" else None)

        file_url = homepage.resolve().as_uri()
        try:
            page.goto(file_url, wait_until="networkidle")
        except Exception:
            try:
                page.goto(file_url, wait_until="load")
            except Exception as e:
                results.append(QAResult("/", "Nav", "error",
                                        f"Failed to load homepage: {e}"))
                ctx.close()
                return results

        # Find all nav links
        nav_links = page.locator("nav a[href]").all()
        checked_hrefs = set()

        for link in nav_links:
            try:
                href = link.get_attribute("href")
            except Exception:
                continue

            if not href or href.startswith(("#", "javascript:", "mailto:")):
                continue
            if href.startswith("http"):
                continue  # Skip external links
            if href in checked_hrefs:
                continue
            checked_hrefs.add(href)

            # Check target file exists
            target = href.lstrip("/")
            if not target:
                target_path = site_dir / "index.html"
            else:
                target_path = site_dir / target
                if target_path.is_dir():
                    target_path = target_path / "index.html"
                elif not target_path.suffix:
                    target_path = site_dir / target / "index.html"

            if not target_path.exists():
                results.append(QAResult(
                    href, "Nav", "error",
                    f"Broken nav link: {href} (target not found)"))

        # Report console errors from homepage
        for err in console_errors:
            if "favicon" not in err.lower():  # Ignore favicon 404s
                results.append(QAResult(
                    "/", "Nav", "warning",
                    f"Console error: {err[:100]}"))

        ctx.close()
    finally:
        browser.close()
        if not playwright_launch:
            pw.stop()

    return results


# ============================================================================
# Smart sampling strategy
# ============================================================================

# Pages to always check regardless of sampling
CRITICAL_PAGES = ["/"]


def _smart_sample(html_files: list[tuple[Path, str]],
                  sample_size: int = 20) -> list[tuple[Path, str]]:
    """Select a representative sample of pages for QA.

    Strategy:
    1. Always include critical pages (homepage)
    2. Include one page per topic directory (representative coverage)
    3. Fill remaining slots with random pages

    Args:
        html_files: List of (path, url) tuples.
        sample_size: Target number of pages to check.

    Returns:
        Sampled list of (path, url) tuples.
    """
    import random

    if len(html_files) <= sample_size:
        return html_files

    selected = {}  # url -> (path, url)

    # 1. Always include critical pages
    for path, url in html_files:
        if url in CRITICAL_PAGES:
            selected[url] = (path, url)

    # 2. One page per topic directory for representative coverage
    topics_seen = set()
    for path, url in html_files:
        parts = url.strip("/").split("/")
        if len(parts) >= 2:
            topic = parts[0]
            if topic not in topics_seen and url not in selected:
                topics_seen.add(topic)
                selected[url] = (path, url)

    # 3. Fill remaining with random sample
    remaining = [(p, u) for p, u in html_files if u not in selected]
    slots_left = sample_size - len(selected)
    if slots_left > 0 and remaining:
        extras = random.sample(remaining, min(slots_left, len(remaining)))
        for p, u in extras:
            selected[u] = (p, u)

    return list(selected.values())


# ============================================================================
# Screenshot capture (requires Playwright)
# ============================================================================

def _page_slug(url: str) -> str:
    """Convert a page URL to a filesystem-safe slug.

    Examples:
        /                   -> index
        /guides/setup/      -> guides_setup
        /vendors/acme/      -> vendors_acme
    """
    clean = url.strip("/")
    if not clean:
        return "index"
    return clean.replace("/", "_")


def capture_screenshots(site_dir: Path, output_dir: Path,
                        pages: list[str] = None,
                        playwright_launch: callable = None) -> list[ScreenshotResult]:
    """Capture desktop and mobile screenshots using Playwright.

    Args:
        site_dir: Path to built site directory.
        output_dir: Directory to save screenshots (e.g. qa/screenshots/).
        pages: Specific page URLs to capture. None = all HTML files.
        playwright_launch: Optional callable returning a Playwright browser
                          (for dependency injection in tests).

    Returns:
        List of ScreenshotResult objects.
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    # Collect pages to screenshot
    html_files = _collect_html_files(site_dir, pages)
    if not html_files:
        logger.warning("No HTML files found for screenshot capture.")
        return []

    results = []

    if playwright_launch:
        browser = playwright_launch()
    else:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            logger.error(
                "Playwright not installed. Run: pip install playwright && "
                "playwright install chromium")
            return []
        pw = sync_playwright().start()
        browser = pw.chromium.launch()

    try:
        for html_path, url in html_files:
            slug = _page_slug(url)
            file_url = html_path.resolve().as_uri()

            for vp_name, vp_size in VIEWPORTS.items():
                user_agent = MOBILE_USER_AGENT if vp_name == "mobile" else None
                ctx_kwargs = {"viewport": vp_size}
                if user_agent:
                    ctx_kwargs["user_agent"] = user_agent

                ctx = browser.new_context(**ctx_kwargs)
                page = ctx.new_page()

                try:
                    page.goto(file_url, wait_until="networkidle")
                except Exception:
                    # Fall back to load event if networkidle times out
                    try:
                        page.goto(file_url, wait_until="load")
                    except Exception as e:
                        logger.warning(f"Failed to load {url}: {e}")
                        ctx.close()
                        continue

                screenshot_path = output_dir / f"{vp_name}_{slug}.png"
                page.screenshot(path=str(screenshot_path), full_page=True)

                results.append(ScreenshotResult(
                    page=url,
                    viewport=vp_name,
                    screenshot_path=screenshot_path,
                ))
                ctx.close()
    finally:
        browser.close()
        if not playwright_launch:
            pw.stop()

    logger.info(f"Captured {len(results)} screenshots to {output_dir}")
    return results


def _collect_html_files(site_dir: Path,
                        pages: list[str] = None) -> list[tuple[Path, str]]:
    """Collect HTML files to process, matching qa_site logic."""
    if pages:
        html_files = []
        for page_url in pages:
            page_url = page_url.strip("/")
            path = site_dir / page_url / "index.html"
            if path.exists():
                html_files.append((path, f"/{page_url}/"))
            elif (site_dir / f"{page_url}.html").exists():
                html_files.append(
                    (site_dir / f"{page_url}.html", f"/{page_url}"))
        return html_files

    html_files = []
    for f in sorted(site_dir.rglob("*.html")):
        rel = str(f.relative_to(site_dir)).replace("\\", "/")
        if rel == "index.html":
            url = "/"
        elif rel.endswith("/index.html"):
            url = "/" + rel[:-len("index.html")]
        else:
            url = "/" + rel
        html_files.append((f, url))
    return html_files


# ============================================================================
# Layout regression detection (requires Pillow)
# ============================================================================

def compare_screenshots(reference_path: Path, new_path: Path,
                        threshold: float = REGRESSION_THRESHOLD
                        ) -> tuple[bool, float]:
    """Compare two screenshots using pixel diff.

    Args:
        reference_path: Path to baseline screenshot.
        new_path: Path to new screenshot.
        threshold: Fraction of changed pixels to trigger regression (0.02 = 2%).

    Returns:
        Tuple of (is_regression, change_percentage).
    """
    try:
        from PIL import Image, ImageChops
    except ImportError:
        logger.error("Pillow not installed. Run: pip install Pillow")
        return False, 0.0

    ref = Image.open(reference_path).convert("RGB")
    new = Image.open(new_path).convert("RGB")

    # Size mismatch = definite regression
    if ref.size != new.size:
        return True, 100.0

    diff = ImageChops.difference(ref, new)

    # Count pixels that differ (any channel nonzero)
    # Count pixels that differ (any channel nonzero)
    # Use get_flattened_data (Pillow 11+) with fallback to getdata
    _get_data = getattr(diff, "get_flattened_data", None) or diff.getdata
    diff_data = _get_data()
    changed = sum(1 for pixel in diff_data if any(c > 0 for c in pixel))
    total = ref.size[0] * ref.size[1]

    if total == 0:
        return False, 0.0

    change_ratio = changed / total
    is_regression = change_ratio > threshold
    return is_regression, change_ratio * 100


def generate_diff_image(reference_path: Path, new_path: Path,
                        diff_output_path: Path) -> Path:
    """Generate a side-by-side diff image.

    Left = reference, right = new screenshot. Changed pixels highlighted in red
    on a third panel below.

    Args:
        reference_path: Path to baseline screenshot.
        new_path: Path to new screenshot.
        diff_output_path: Where to save the diff image.

    Returns:
        Path to the saved diff image.
    """
    try:
        from PIL import Image, ImageChops, ImageDraw
    except ImportError:
        logger.error("Pillow not installed. Run: pip install Pillow")
        return None

    diff_output_path.parent.mkdir(parents=True, exist_ok=True)

    ref = Image.open(reference_path).convert("RGB")
    new = Image.open(new_path).convert("RGB")

    # Handle size mismatch: resize new to reference size for comparison
    if ref.size != new.size:
        new = new.resize(ref.size, Image.LANCZOS)

    diff = ImageChops.difference(ref, new)

    # Create side-by-side: reference | new
    gap = 4
    total_width = ref.width * 2 + gap
    combined = Image.new("RGB", (total_width, ref.height), (200, 200, 200))
    combined.paste(ref, (0, 0))
    combined.paste(new, (ref.width + gap, 0))

    combined.save(str(diff_output_path))
    return diff_output_path


def detect_regressions(screenshots: list[ScreenshotResult],
                       reference_dir: Path,
                       regressions_dir: Path,
                       threshold: float = REGRESSION_THRESHOLD
                       ) -> list[ScreenshotResult]:
    """Compare screenshots against reference baselines.

    Args:
        screenshots: List of newly captured screenshots.
        reference_dir: Directory containing baseline screenshots.
        regressions_dir: Directory to save diff images.
        threshold: Pixel change threshold (default 2%).

    Returns:
        List of ScreenshotResult objects that are regressions.
    """
    regressions = []

    if not reference_dir.exists():
        logger.info(
            f"No reference directory at {reference_dir}. "
            "Run with --update-reference first.")
        return regressions

    for ss in screenshots:
        ref_path = reference_dir / ss.screenshot_path.name
        if not ref_path.exists():
            logger.debug(f"No reference for {ss.screenshot_path.name}, skipping.")
            continue

        is_reg, diff_pct = compare_screenshots(ref_path, ss.screenshot_path,
                                               threshold)
        ss.is_regression = is_reg
        ss.diff_pct = diff_pct
        ss.reference_path = ref_path

        if is_reg:
            regressions_dir.mkdir(parents=True, exist_ok=True)
            diff_path = regressions_dir / f"diff_{ss.screenshot_path.name}"
            generate_diff_image(ref_path, ss.screenshot_path, diff_path)
            ss.diff_path = diff_path
            regressions.append(ss)
            logger.warning(
                f"Regression: {ss.viewport} {ss.page} — "
                f"{diff_pct:.1f}% changed")

    return regressions


def update_reference(screenshots: list[ScreenshotResult],
                     reference_dir: Path) -> int:
    """Copy current screenshots to reference directory as new baselines.

    Args:
        screenshots: List of captured screenshots.
        reference_dir: Directory to save reference screenshots.

    Returns:
        Number of reference screenshots saved.
    """
    import shutil

    reference_dir.mkdir(parents=True, exist_ok=True)
    count = 0
    for ss in screenshots:
        dest = reference_dir / ss.screenshot_path.name
        shutil.copy2(str(ss.screenshot_path), str(dest))
        count += 1

    logger.info(f"Updated {count} reference screenshots in {reference_dir}")
    return count


# ============================================================================
# Site-level QA
# ============================================================================

def qa_page(html_path: Path, site_dir: Path, url: str,
            base_path: str = "") -> list[QAResult]:
    """Run all QA checks on a single page.

    Args:
        base_path: Deprecated, ignored. Kept for backward compatibility.
    """
    raw = html_path.read_text(encoding="utf-8")
    soup = BeautifulSoup(raw, "html.parser")

    results = []
    results.extend(check_seo(soup, url))
    results.extend(check_links(soup, url, site_dir))
    results.extend(check_accessibility(soup, url))
    results.extend(check_html_quality(soup, url))

    return results


def qa_site(site_dir: str | Path,
            pages: list[str] = None,
            full: bool = False,
            screenshots: bool = False,
            update_ref: bool = False,
            check_nav: bool = False,
            output_dir: str | Path = ".wire/qa",
            playwright_launch: callable = None,
            base_path: str = "") -> QAReport:
    """Run QA on a built site.

    Args:
        site_dir: Path to built site (e.g., site/).
        pages: Specific page URLs to check (e.g., ["guides/setup"]).
        full: If True, check all pages. Otherwise uses sampling.
        screenshots: If True, capture screenshots and run regression detection.
        update_ref: If True, save screenshots as new reference baselines.
        check_nav: If True, use Playwright to click every nav link and verify.
        output_dir: Base output directory for QA artifacts.
        playwright_launch: Optional callable for Playwright browser (testing).

    Returns:
        QAReport with all results.
    """
    site_dir = Path(site_dir)
    output_dir = Path(output_dir)
    report = QAReport()

    # Collect HTML files
    if pages:
        html_files = []
        for page_url in pages:
            page_url = page_url.strip("/")
            path = site_dir / page_url / "index.html"
            if path.exists():
                html_files.append((path, f"/{page_url}/"))
            elif (site_dir / f"{page_url}.html").exists():
                html_files.append((site_dir / f"{page_url}.html", f"/{page_url}"))
    else:
        html_files = []
        for f in sorted(site_dir.rglob("*.html")):
            rel = str(f.relative_to(site_dir)).replace("\\", "/")
            if rel == "index.html":
                url = "/"
            elif rel.endswith("/index.html"):
                url = "/" + rel[:-len("index.html")]
            else:
                url = "/" + rel
            html_files.append((f, url))

        # Smart sampling: representative coverage without checking everything
        if not full and len(html_files) > 30:
            html_files = _smart_sample(html_files)

    # Utility pages: auto-generated, not indexable content
    _UTILITY_URLS = {"/404.html", "/search/", "/news/"}

    # Run HTML checks — skip non-content pages
    for html_path, url in html_files:
        try:
            # Skip utility pages (404, search, news index)
            if url in _UTILITY_URLS:
                continue
            raw = html_path.read_text(encoding="utf-8")
            # Skip redirect stubs (meta refresh) and 410 Gone pages
            if 'http-equiv="refresh"' in raw.lower():
                continue
            if "<title>" in raw and "410" in raw.split("<title>")[1].split("</title>")[0]:
                continue
            results = qa_page(html_path, site_dir, url)
            report.results.extend(results)
            report.pages_checked += 1
        except Exception as e:
            report.results.append(QAResult(
                url, "QA", "error", f"Failed to check: {e}"))

    # Nav interaction testing (requires Playwright)
    if check_nav:
        nav_results = check_nav_links(site_dir, playwright_launch)
        report.results.extend(nav_results)

    # Screenshot capture + regression detection
    if screenshots or update_ref:
        page_urls = [url for _, url in html_files] if html_files else None
        screenshots_dir = output_dir / "screenshots"
        reference_dir = output_dir / "reference"
        regressions_dir = output_dir / "regressions"

        captured = capture_screenshots(
            site_dir, screenshots_dir,
            pages=pages,
            playwright_launch=playwright_launch,
        )
        report.screenshots = captured

        if update_ref and captured:
            update_reference(captured, reference_dir)
        elif captured:
            regressions = detect_regressions(
                captured, reference_dir, regressions_dir)
            report.regressions = regressions

    return report


# ============================================================================
# HTML report generation
# ============================================================================

def generate_report_html(report: QAReport, output_dir: Path) -> Path:
    """Generate an HTML QA report with screenshot gallery and regression flags.

    Returns path to report.html.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    report_path = output_dir / "report.html"

    errors = report.errors
    warnings = report.warnings
    has_regressions = len(report.regressions) > 0
    status_color = "#dc2626" if errors or has_regressions else "#059669"

    status_parts = []
    if errors:
        status_parts.append(f"{len(errors)} error(s)")
    if has_regressions:
        status_parts.append(f"{len(report.regressions)} regression(s)")
    status_text = ", ".join(status_parts) if status_parts else "All passed"

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>QA Report</title>
<style>
body {{ font-family: -apple-system, sans-serif; margin: 40px; color: #111827; }}
.status {{ padding: 20px; border-radius: 8px; color: #fff;
           background: {status_color}; font-size: 18px; font-weight: 700;
           margin-bottom: 24px; }}
.section {{ margin-bottom: 32px; }}
.section h2 {{ font-size: 16px; color: #6b7280; text-transform: uppercase;
               letter-spacing: 0.5px; margin-bottom: 12px; }}
.result {{ padding: 8px 12px; border-left: 3px solid; margin-bottom: 4px;
           font-size: 14px; }}
.result.error {{ border-color: #dc2626; background: #fef2f2; }}
.result.warning {{ border-color: #f59e0b; background: #fffbeb; }}
.meta {{ color: #6b7280; font-size: 12px; }}
.screenshots {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
                gap: 16px; }}
.screenshot-card {{ border: 2px solid #e5e7eb; border-radius: 8px; padding: 12px;
                    overflow: hidden; }}
.screenshot-card.regression {{ border-color: #dc2626; border-width: 3px; }}
.screenshot-card img {{ width: 100%; height: auto; border-radius: 4px; }}
.screenshot-card .label {{ font-size: 13px; font-weight: 600; margin-bottom: 8px; }}
.screenshot-card .diff-pct {{ color: #dc2626; font-weight: 700; font-size: 14px; }}
.screenshot-card .ok {{ color: #059669; font-size: 12px; }}
</style>
</head>
<body>
<h1>QA Report</h1>
<div class="status">{status_text} &mdash; {report.pages_checked} pages checked</div>
"""

    if errors:
        html += '<div class="section"><h2>Errors</h2>\n'
        for r in errors:
            html += (f'<div class="result error">'
                     f'<strong>{r.check}</strong>: {r.message} '
                     f'<span class="meta">{r.page}</span></div>\n')
        html += '</div>\n'

    # Regressions section
    if has_regressions:
        html += '<div class="section"><h2>Layout Regressions</h2>\n'
        html += '<div class="screenshots">\n'
        for s in report.regressions:
            diff_src = ""
            if s.diff_path and s.diff_path.exists():
                try:
                    diff_src = str(s.diff_path.relative_to(output_dir))
                except ValueError:
                    diff_src = str(s.diff_path)
            html += (f'<div class="screenshot-card regression">\n'
                     f'<div class="label">{s.viewport} &mdash; {s.page}</div>\n'
                     f'<div class="diff-pct">{s.diff_pct:.1f}% changed</div>\n')
            if diff_src:
                html += f'<img src="{diff_src}" alt="Diff: {s.page}">\n'
            html += '</div>\n'
        html += '</div></div>\n'

    if warnings:
        html += '<div class="section"><h2>Warnings</h2>\n'
        for r in warnings:
            html += (f'<div class="result warning">'
                     f'<strong>{r.check}</strong>: {r.message} '
                     f'<span class="meta">{r.page}</span></div>\n')
        html += '</div>\n'

    # Screenshots gallery
    if report.screenshots:
        html += '<div class="section"><h2>Screenshots</h2>\n'
        html += '<div class="screenshots">\n'
        for s in report.screenshots:
            is_reg = s.is_regression
            card_class = "screenshot-card regression" if is_reg else "screenshot-card"
            try:
                img_src = str(s.screenshot_path.relative_to(output_dir))
            except ValueError:
                img_src = str(s.screenshot_path)

            html += (f'<div class="{card_class}">\n'
                     f'<div class="label">{s.viewport} &mdash; {s.page}</div>\n')
            if is_reg:
                html += f'<div class="diff-pct">{s.diff_pct:.1f}% changed</div>\n'
            else:
                html += '<div class="ok">OK</div>\n'
            html += f'<img src="{img_src}" alt="{s.viewport}: {s.page}">\n'
            html += '</div>\n'
        html += '</div></div>\n'

    if not errors and not warnings and not has_regressions:
        html += '<p>No issues found. Ship it.</p>\n'

    html += '</body></html>'
    report_path.write_text(html, encoding="utf-8")

    return report_path


def main():
    """CLI entry point."""
    import argparse

    parser = argparse.ArgumentParser(
        description="wire.qa — automated site quality assurance")
    parser.add_argument("--site", required=True,
                        help="Path to built site directory")
    parser.add_argument("--pages", nargs="*",
                        help="Specific pages to check (e.g., guides/setup)")
    parser.add_argument("--full", action="store_true",
                        help="Check all pages (no sampling)")
    parser.add_argument("--screenshots", action="store_true",
                        help="Capture desktop and mobile screenshots")
    parser.add_argument("--update-reference", action="store_true",
                        help="Save current screenshots as new baselines")
    parser.add_argument("--check-nav", action="store_true",
                        help="Click every nav link to verify targets exist")
    parser.add_argument("--report", default=".wire/qa",
                        help="Output directory for QA report (default: .wire/qa/)")
    parser.add_argument("-v", "--verbose", action="store_true")

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(message)s",
    )

    do_screenshots = args.screenshots or args.update_reference
    report = qa_site(
        args.site, args.pages, args.full,
        screenshots=do_screenshots,
        update_ref=args.update_reference,
        check_nav=args.check_nav,
        output_dir=args.report,
    )
    print(report.summary())

    # Generate HTML report
    report_path = generate_report_html(report, Path(args.report))
    logger.info(f"\nReport: {report_path}")

    if report.has_critical_errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
