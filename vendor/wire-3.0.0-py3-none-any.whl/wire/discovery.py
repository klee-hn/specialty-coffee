#!/usr/bin/env python3
"""
wire.discovery — Discovery reading system.

Converts :::hook / :::step / :::choices markdown blocks into a guided
reading layer rendered above the full article. The full article is always
in the DOM — the discovery layer is a progressive enhancement overlay.

Syntax:
    :::hook
    Hook text shown above the fold.
    :::

    :::step id="start"
    Step body text (60-120 words).
    :::choices
    - Choice label -> next_step_id
    - Another choice -> other_step_id
    :::

No JS: discovery layer is hidden via CSS, full article renders normally.
With JS: layer becomes visible, user gets guided experience.
"""

import json
import re
from html import escape as html_escape
from pathlib import Path

import frontmatter


def parse_steps(text: str) -> dict | None:
    """Parse :::step markdown syntax into a discovery structure.

    Args:
        text: Raw markdown content of a .steps.md file.

    Returns:
        Dict with {hook, steps} or None if no valid blocks found.
        Steps dict maps step_id -> {text, choices: [{label, next}]}.
    """
    if ":::hook" not in text and ":::step" not in text:
        return None

    result = {"hook": "", "steps": {}}

    # Extract hook block
    hook_match = re.search(
        r':::hook\s*\n(.*?)^:::$', text, re.DOTALL | re.MULTILINE)
    if hook_match:
        result["hook"] = hook_match.group(1).strip()

    # Extract step blocks — match from :::step to a standalone ::: on its own line
    step_pattern = re.compile(
        r':::step\s+id="([^"]+)"\s*\n(.*?)^:::$', re.DOTALL | re.MULTILINE)

    for match in step_pattern.finditer(text):
        step_id = match.group(1)
        block = match.group(2)

        # Split on :::choices
        if ":::choices" in block:
            parts = block.split(":::choices", 1)
            step_text = parts[0].strip()
            choices_text = parts[1].strip()
        else:
            step_text = block.strip()
            choices_text = ""

        # Parse choices
        choices = []
        if choices_text:
            for line in choices_text.splitlines():
                line = line.strip()
                if line.startswith("- ") and "->" in line:
                    label_part, next_part = line[2:].rsplit("->", 1)
                    choices.append({
                        "label": label_part.strip(),
                        "next": next_part.strip(),
                    })

        result["steps"][step_id] = {
            "text": step_text,
            "choices": choices,
        }

    if not result["hook"] and not result["steps"]:
        return None

    return result


def find_steps_file(page_path: Path) -> Path | None:
    """Find the .steps.md file for a given page.

    Looks for:
        {page_dir}/{stem}.steps.md
        {page_dir}/steps.md (for index.md pages)
    """
    if page_path.name == "index.md":
        steps_path = page_path.parent / "steps.md"
    else:
        steps_path = page_path.with_suffix(".steps.md")

    return steps_path if steps_path.exists() else None


def extract_h2_ids(markdown_text: str) -> set[str]:
    """Extract H2 heading anchor IDs from markdown text.

    Uses the same slugification as WireRenderer.heading() in build.py.
    """
    post = frontmatter.loads(markdown_text)
    h2_lines = re.findall(r'^## (.+)$', post.content, re.MULTILINE)
    ids = set()
    for h2 in h2_lines:
        slug = re.sub(r'[^\w\s-]', '', h2.lower())
        slug = re.sub(r'[-\s]+', '-', slug).strip('-')
        ids.add(slug)
    return ids


def render_discovery_html(data: dict, labels: dict = None) -> str:
    """Render discovery data as HTML for the guided reading layer.

    Design principles:
    - All content in DOM on page load (no fetch, no lazy injection)
    - Hidden by default via CSS (.discovery-layer { display: none })
    - JS adds .discovery-active to <body>, which reveals the layer
    - Without JS: layer stays hidden, full article renders normally
    - Steps use opacity/visibility transitions, not display toggling
    - Zero CLS: layer has fixed dimensions before JS runs

    Returns:
        Complete HTML string with discovery layer, embedded JSON data,
        inline <style> block, and inline <script> block.
        Empty string if data is None or empty.
    """
    if not data:
        return ""

    if labels is None:
        labels = {}

    step_ids = list(data.get("steps", {}).keys())
    step_count = len(step_ids)

    start_label = labels.get("discovery_start", "Guide me through this")
    read_label = labels.get("discovery_read", "Read the full article")

    lines = ['<div class="discovery-layer" data-discovery>']

    # Hook section — visible when discovery layer first appears
    if data.get("hook"):
        hook_text = html_escape(data["hook"], quote=False)
        lines.append('  <div class="discovery-hook" data-hook>')
        lines.append(f'    <p>{hook_text}</p>')
        lines.append('    <div class="discovery-cta">')
        lines.append('      <button class="btn btn-primary" '
                     'data-start-discovery>'
                     f'{html_escape(start_label, quote=False)}</button>')
        lines.append('      <button class="btn btn-secondary" '
                     'data-skip-discovery>'
                     f'{html_escape(read_label, quote=False)}</button>')
        lines.append('    </div>')
        lines.append('  </div>')

    # Step cards — all in DOM, hidden via CSS opacity/visibility
    for step_id, step in data.get("steps", {}).items():
        escaped_id = html_escape(step_id, quote=True)
        lines.append(f'  <div class="discovery-step" data-step="{escaped_id}">')
        lines.append('    <div class="step-text">')
        # Convert step text to paragraphs
        for para in step["text"].split("\n\n"):
            para = para.strip()
            if para:
                lines.append(f'      <p>{html_escape(para, quote=False)}</p>')
        lines.append('    </div>')

        if step.get("choices"):
            lines.append('    <div class="step-choices">')
            for choice in step["choices"]:
                escaped_next = html_escape(choice["next"], quote=True)
                # "end" choices use the configurable discovery_read label
                # so non-English sites get the translated text
                label = (read_label if choice["next"] == "end"
                         else choice["label"])
                escaped_label = html_escape(label, quote=False)
                lines.append(
                    f'      <button class="btn" '
                    f'data-next="{escaped_next}">'
                    f'{escaped_label}</button>')
            lines.append('    </div>')

        lines.append('  </div>')

    # Progress dots
    if step_count > 0:
        lines.append('  <div class="discovery-progress">')
        for i in range(step_count):
            lines.append(f'    <span class="progress-dot" data-dot="{i}"></span>')
        lines.append('  </div>')

    lines.append('</div>')

    # Embed step data as JSON for the JS component
    # CSS and JS are loaded globally via base.html (discovery.css, discovery.js)
    lines.append('<script type="application/json" data-discovery-data>')
    lines.append(json.dumps(data, indent=None))
    lines.append('</script>')

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# DISCOVERY_CSS — Full styling for the discovery reading system
#
# Key design decisions:
#   1. .discovery-layer is display:none by default — no JS means no layer,
#      no broken layout, no empty containers, zero CLS.
#   2. JS adds .discovery-active to <body>, which flips the layer to block.
#   3. Step cards use opacity + visibility transitions (not display toggle)
#      for smooth fade effects without triggering layout reflow.
#   4. Mobile-first: single column, touch-friendly button sizing.
# ---------------------------------------------------------------------------
DISCOVERY_CSS = """
/* === Discovery Reading System === */

/* Hidden by default. JS adds .discovery-active to <body> to reveal. */
.discovery-layer {
  display: none;
  max-width: 640px;
  margin: 0 auto 48px;
  padding: 48px 24px;
  position: relative;
}

/* JS has activated the discovery experience */
.discovery-active .discovery-layer {
  display: block;
}

/* --- Hook --- */
.discovery-hook {
  text-align: center;
  transition: opacity 0.3s ease-out;
}
.discovery-hook.hidden {
  opacity: 0;
  visibility: hidden;
  height: 0;
  overflow: hidden;
  margin: 0;
  padding: 0;
}
.discovery-hook p {
  font-size: 1.25em;
  line-height: 1.6;
  color: var(--text, #1a1a1a);
  margin-bottom: 24px;
}
.discovery-cta {
  display: flex;
  gap: 12px;
  justify-content: center;
  flex-wrap: wrap;
}

/* --- Step cards --- */
.discovery-step {
  opacity: 0;
  visibility: hidden;
  height: 0;
  overflow: hidden;
  transition: opacity 0.4s ease-out;
}
.discovery-step.active {
  opacity: 1;
  visibility: visible;
  height: auto;
  overflow: visible;
  animation: discoveryFadeIn 0.4s ease-out;
}

.step-text {
  font-size: 1.05em;
  line-height: 1.7;
  margin-bottom: 24px;
}
.step-text p {
  margin-bottom: 12px;
}
.step-text p:last-child {
  margin-bottom: 0;
}

/* --- Choice buttons (styled by wire.css .step-choices .btn) --- */

/* --- Progress dots --- */
.discovery-progress {
  display: none;
  justify-content: center;
  gap: 8px;
  margin-top: 24px;
}
.discovery-progress.visible {
  display: flex;
}
.progress-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--border, #ddd);
  transition: background 0.25s, transform 0.25s;
}
.progress-dot.active {
  background: var(--primary, #1a73e8);
  transform: scale(1.25);
}

/* --- Section highlight --- */
.discovery-highlight {
  border-left: 3px solid var(--primary, #1a73e8);
  padding-left: 12px;
  transition: border-color 0.5s ease-out, padding-left 0.5s ease-out;
}
.discovery-highlight.fade-out {
  border-left-color: transparent;
  padding-left: 0;
}

/* --- Fade-in animation --- */
@keyframes discoveryFadeIn {
  from {
    opacity: 0;
    transform: translateY(8px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* --- Collapsed state (after user exits discovery) --- */
.discovery-layer.collapsed {
  display: none;
}

/* --- Mobile responsive --- */
@media (max-width: 640px) {
  .discovery-layer {
    padding: 32px 16px;
    margin-bottom: 32px;
  }
  .discovery-hook p {
    font-size: 1.1em;
  }
  .discovery-cta {
    flex-direction: column;
    gap: 10px;
  }
  .discovery-cta .btn {
    width: 100%;
    text-align: center;
  }
}
"""

# ---------------------------------------------------------------------------
# DISCOVERY_JS — Minimal vanilla JS, no external dependencies
#
# Behavior:
#   1. On load: adds .discovery-active to <body> to reveal the layer
#   2. "Guide me through this" -> hides hook, shows first step + progress
#   3. Choice button click -> transitions to next step (no page reload)
#   4. "Read the full article on this" -> collapses layer, scrolls to
#      the matching section anchor with a 3-second highlight
#   5. "Read the full article" (from hook) -> collapses layer, scrolls
#      to article content
#   6. Progress dots update as user moves between steps
# ---------------------------------------------------------------------------
DISCOVERY_JS = """
(function() {
  var layer = document.querySelector('[data-discovery]');
  if (!layer) return;

  var dataEl = document.querySelector('[data-discovery-data]');
  if (!dataEl) return;

  var data;
  try {
    data = JSON.parse(dataEl.textContent);
  } catch (e) {
    return;
  }

  var stepIds = Object.keys(data.steps);
  if (!stepIds.length && !data.hook) return;

  /* Activate the discovery layer (CSS: .discovery-active .discovery-layer) */
  document.body.classList.add('discovery-active');

  var hook = layer.querySelector('[data-hook]');
  var progress = layer.querySelector('.discovery-progress');
  var dots = layer.querySelectorAll('.progress-dot');
  var allSteps = layer.querySelectorAll('[data-step]');

  /* --- "Guide me through this" --- */
  var startBtn = layer.querySelector('[data-start-discovery]');
  if (startBtn) {
    startBtn.addEventListener('click', function() {
      if (hook) hook.classList.add('hidden');
      if (progress) progress.classList.add('visible');
      showStep(stepIds[0]);
    });
  }

  /* --- "Read the full article" from hook --- */
  var skipBtn = layer.querySelector('[data-skip-discovery]');
  if (skipBtn) {
    skipBtn.addEventListener('click', function() {
      collapseLayer();
      var article = document.querySelector('article') ||
                    document.querySelector('.md-content') ||
                    document.querySelector('main');
      if (article) {
        article.scrollIntoView({ behavior: 'smooth' });
      }
    });
  }

  /* --- Delegated click handler for choice + read-more buttons --- */
  layer.addEventListener('click', function(e) {
    var nextBtn = e.target.closest('[data-next]');
    if (nextBtn) {
      showStep(nextBtn.getAttribute('data-next'));
      return;
    }

    var readBtn = e.target.closest('[data-read-section]');
    if (readBtn) {
      var sectionId = readBtn.getAttribute('data-read-section');
      collapseLayer();
      scrollToSection(sectionId);
    }
  });

  /* --- Show a step by ID, or exit if step doesn't exist --- */
  function showStep(id) {
    var target = layer.querySelector('[data-step="' + id + '"]');
    if (!target) {
      collapseLayer();
      var article = document.querySelector('article') ||
                    document.querySelector('.md-content') ||
                    document.querySelector('main');
      if (article) article.scrollIntoView({ behavior: 'smooth' });
      return;
    }
    for (var i = 0; i < allSteps.length; i++) {
      allSteps[i].classList.remove('active');
    }
    /* Small delay so the browser processes the removal first */
    requestAnimationFrame(function() {
      target.classList.add('active');
    });
    /* Update progress dots */
    var idx = stepIds.indexOf(id);
    for (var j = 0; j < dots.length; j++) {
      if (j <= idx) {
        dots[j].classList.add('active');
      } else {
        dots[j].classList.remove('active');
      }
    }
  }

  /* --- Collapse the discovery layer --- */
  function collapseLayer() {
    layer.classList.add('collapsed');
    document.body.classList.remove('discovery-active');
  }

  /* --- Scroll to a section and highlight it for 3 seconds --- */
  function scrollToSection(id) {
    var target = document.getElementById(id);
    if (!target) return;

    target.scrollIntoView({ behavior: 'smooth' });
    target.classList.add('discovery-highlight');

    setTimeout(function() {
      target.classList.add('fade-out');
    }, 2500);

    setTimeout(function() {
      target.classList.remove('discovery-highlight', 'fade-out');
    }, 3000);
  }
})();
"""
