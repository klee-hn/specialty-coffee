"""wire.notify — Telegram escalation for the Wire autonomous operator.

Send messages to a human operator via Telegram and optionally wait for
a reply. Used by the VPS operator when it needs a decision or can't fix
a failure after 2 attempts.

Setup:
    TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in .env
"""

import json
import logging
import os
import time
import urllib.request
import urllib.error

from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger("wire.notify")

TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")
_API_BASE = "https://api.telegram.org/bot{token}"


def _api_url(method: str) -> str:
    """Build Telegram Bot API URL."""
    return f"{_API_BASE.format(token=TELEGRAM_BOT_TOKEN)}/{method}"


def send(message: str) -> int | None:
    """Send a Telegram message. Returns message_id on success, None on failure.

    Messages longer than 4096 chars are truncated with a warning.
    """
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        logger.warning("Telegram credentials not configured — skipping notification")
        return None

    if len(message) > 4096:
        message = message[:4090] + "\n[...]"

    payload = json.dumps({
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message,
        "parse_mode": "Markdown",
    }).encode()

    req = urllib.request.Request(
        _api_url("sendMessage"),
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
            msg_id = data.get("result", {}).get("message_id")
            logger.info("Telegram message sent (id=%s)", msg_id)
            return msg_id
    except (urllib.error.URLError, json.JSONDecodeError, OSError) as e:
        logger.error("Failed to send Telegram message: %s", e)
        return None


def poll_response(after_message_id: int,
                  timeout_minutes: int = 60,
                  poll_interval: int = 30) -> str | None:
    """Poll for a reply newer than after_message_id.

    Checks every poll_interval seconds for up to timeout_minutes.
    Returns the reply text, or None on timeout.
    """
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        return None

    deadline = time.time() + (timeout_minutes * 60)
    offset = 0

    while time.time() < deadline:
        try:
            url = _api_url("getUpdates") + f"?offset={offset}&timeout=10"
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read())

            for update in data.get("result", []):
                offset = update["update_id"] + 1
                msg = update.get("message", {})
                # Must be from the same chat, after our sent message
                if (str(msg.get("chat", {}).get("id")) == str(TELEGRAM_CHAT_ID)
                        and msg.get("message_id", 0) > after_message_id
                        and msg.get("text")):
                    logger.info("Received reply: %s", msg["text"][:80])
                    return msg["text"]

        except (urllib.error.URLError, json.JSONDecodeError, OSError) as e:
            logger.warning("Poll error (retrying): %s", e)

        time.sleep(poll_interval)

    logger.warning("No reply received within %d minutes", timeout_minutes)
    return None


def ask(question: str, timeout_minutes: int = 60) -> str | None:
    """Send a question and wait for a reply. Convenience wrapper.

    Returns the reply text, or None if no response within timeout.
    """
    msg_id = send(question)
    if msg_id is None:
        return None
    return poll_response(msg_id, timeout_minutes=timeout_minutes)
