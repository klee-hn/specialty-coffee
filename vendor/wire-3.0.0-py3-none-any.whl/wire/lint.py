#!/usr/bin/env python3
"""
wire.lint — Build-time HTML content linter.

Runs against rendered HTML after wire.build completes.
Every rule is a hard failure with a specific, actionable message.

Usage:
    python -m wire.lint --site /path/to/site
    python -m wire.lint --site /path/to/site --rules RULE-01,RULE-05
"""

import json
import logging
import re
from pathlib import Path
from posixpath import normpath
from collections import defaultdict

from bs4 import BeautifulSoup, NavigableString

logger = logging.getLogger(__name__)


def _resolve_href(page_url: str, href: str) -> str:
    """Resolve a relative or absolute href against a page URL.

    Returns an absolute path (e.g. "/guides/setup/").
    Handles both old absolute links and new relative links.
    """
    # Already absolute
    if href.startswith("/"):
        return href

    # Relative: resolve against the page's directory
    # page_url is like "/guides/setup/" — the "directory" is the URL itself
    # since pages are served as /guides/setup/index.html
    base = page_url if page_url.endswith("/") else page_url + "/"
    combined = base + href
    # Normalize .. and . segments
    result = normpath(combined)
    # normpath strips trailing slash, re-add it
    if not result.endswith("/"):
        result += "/"
    return result


class LintResult:
    """A single lint rule result."""

    __slots__ = ("rule_id", "url", "message", "group", "severity", "overruled")

    def __init__(self, rule_id: str, url: str, message: str, group: str = ""):
        self.rule_id = rule_id
        self.url = url
        self.message = message
        self.group = group
        self.severity = "error" if rule_id in LINT_ERRORS else "warning"
        self.overruled = False

    def __str__(self):
        return f"LINT_FAIL [{self.rule_id}]: {self.message}\n  URL: {self.url}"


# Rules that are ERRORS (block deployment) — broken functionality, not quality hints.
# Everything else is a WARNING (printed but does not block).
LINT_ERRORS = {
    "RULE-22",   # Internal link 404 (fragment)
    "RULE-33",   # Internal link target missing
    "RULE-36",   # Link to redirect (should use final URL)
    "RULE-37",   # Mixed content (HTTP on HTTPS site)
    "RULE-41",   # Broken image (src file missing)
    "RULE-48",   # Broken JSON-LD URL
    "RULE-51",   # Raw YouTube iframe (GDPR violation)
}


# ============================================================================
# GROUP A: Metadata
# ============================================================================

def _real_tags(soup, tag_name):
    """Find tags that are not inside <code> or <pre> elements."""
    return [t for t in soup.find_all(tag_name)
            if not t.find_parent(["code", "pre"])]


def rule_01_h1_present(soup, url, **_):
    """H1 present and non-empty."""
    h1s = _real_tags(soup, "h1")
    if not h1s:
        return LintResult("RULE-01", url,
                          "No H1 found. Add exactly one H1 containing your target query.",
                          "Metadata")
    if not h1s[0].get_text(strip=True):
        return LintResult("RULE-01", url,
                          "H1 tag is empty. Add text to your H1.",
                          "Metadata")
    return None


def rule_02_single_h1(soup, url, **_):
    """Exactly one H1 per page."""
    h1s = _real_tags(soup, "h1")
    if len(h1s) > 1:
        texts = [h.get_text(strip=True) for h in h1s]
        return LintResult("RULE-02", url,
                          f"Multiple H1 tags found ({len(h1s)}): "
                          f"{', '.join(repr(t) for t in texts[:3])}. "
                          f"Keep exactly one H1, demote others to H2.",
                          "Metadata")
    return None


def rule_03_heading_hierarchy(soup, url, **_):
    """Heading hierarchy is not skipped."""
    headings = [h for h in soup.find_all(re.compile(r'^h[1-6]$'))
                if not h.find_parent(["code", "pre"])]
    prev_level = 0
    for h in headings:
        level = int(h.name[1])
        if prev_level > 0 and level > prev_level + 1:
            return LintResult("RULE-03", url,
                              f"Heading hierarchy skip: H{prev_level} followed by "
                              f"H{level} at \"{h.get_text(strip=True)[:60]}\". "
                              f"Use sequential heading levels.",
                              "Metadata")
        prev_level = level
    return None


def rule_04_target_query(soup, url, **_):
    """Target query appears in H1 or title."""
    meta = soup.find("meta", attrs={"name": "target-query"})
    if not meta or not meta.get("content", "").strip():
        return None  # no target query defined — skip

    query = meta["content"].strip().lower()

    # Check title
    title_tag = soup.find("title")
    if title_tag:
        title_text = title_tag.get_text(strip=True).lower()
        if query in title_text:
            return None

    # Check H1
    h1s = _real_tags(soup, "h1")
    if h1s:
        h1_text = h1s[0].get_text(strip=True).lower()
        if query in h1_text:
            return None

    current_h1 = h1s[0].get_text(strip=True) if h1s else "(none)"
    current_title = title_tag.get_text(strip=True) if title_tag else "(none)"

    return LintResult(
        "RULE-04", url,
        f'Target query "{meta["content"].strip()}" not found in H1 or title. '
        f'Current H1: "{current_h1}". '
        f'Current title: "{current_title}".',
        "Metadata")


def rule_05_title(soup, url, all_titles=None, **_):
    """Title tag present, unique, correct length."""
    head = soup.find("head")
    titles = head.find_all("title") if head else []
    if not titles:
        return LintResult("RULE-05", url,
                          "Missing <title> tag.", "Metadata")

    title_text = titles[0].get_text(strip=True)
    if not title_text:
        return LintResult("RULE-05", url,
                          "Empty <title> tag.", "Metadata")

    if len(title_text) > 65:
        return LintResult("RULE-05", url,
                          f"Title too long ({len(title_text)} chars, limit 65): "
                          f"\"{title_text[:70]}...\"",
                          "Metadata")

    if len(title_text) < 20:
        return LintResult("RULE-05", url,
                          f"Title too short ({len(title_text)} chars, min 20): "
                          f"\"{title_text}\"",
                          "Metadata")

    # Duplicate check
    if all_titles is not None:
        if title_text in all_titles and all_titles[title_text] != url:
            return LintResult("RULE-05", url,
                              f"Duplicate title \"{title_text}\" — "
                              f"also used by {all_titles[title_text]}",
                              "Metadata")
        all_titles[title_text] = url

    return None


def rule_06_single_title(soup, url, **_):
    """Exactly one title tag."""
    head = soup.find("head")
    titles = head.find_all("title") if head else []
    if len(titles) > 1:
        return LintResult("RULE-06", url,
                          f"Multiple <title> tags found ({len(titles)}). "
                          f"Remove all but one.",
                          "Metadata")
    return None


def rule_07_meta_description(soup, url, **_):
    """Meta description present and correct length."""
    desc = soup.find("meta", attrs={"name": "description"})
    if not desc or not desc.get("content"):
        return LintResult("RULE-07", url,
                          "Missing meta description.", "Metadata")

    content = desc["content"]
    if len(content) > 158:
        return LintResult("RULE-07", url,
                          f"Meta description too long ({len(content)} chars, "
                          f"limit 158): \"{content[:80]}...\"",
                          "Metadata")
    return None


def rule_09_og_tags(soup, url, **_):
    """Open Graph tags present."""
    required_og = ["og:title", "og:description"]
    missing = []
    for prop in required_og:
        tag = soup.find("meta", attrs={"property": prop})
        if not tag or not tag.get("content"):
            missing.append(prop)

    if missing:
        return LintResult("RULE-09", url,
                          f"Missing Open Graph tags: {', '.join(missing)}",
                          "Metadata")
    return None


def rule_10_viewport(soup, url, **_):
    """Viewport meta tag present."""
    viewport = soup.find("meta", attrs={"name": "viewport"})
    if not viewport:
        return LintResult("RULE-10", url,
                          "Missing viewport meta tag. Add: "
                          '<meta name="viewport" content="width=device-width, initial-scale=1">',
                          "Metadata")
    return None


def rule_11_charset(soup, url, raw_html="", **_):
    """Charset declared in first 1024 bytes."""
    head = raw_html[:1024] if raw_html else str(soup.head)[:1024] if soup.head else ""
    if "charset" not in head.lower():
        return LintResult("RULE-11", url,
                          "No charset declaration in first 1024 bytes. "
                          'Add: <meta charset="utf-8">',
                          "Metadata")
    return None


# ============================================================================
# GROUP B: Canonicalization
# ============================================================================

def rule_12_canonical(soup, url, **_):
    """Canonical tag present."""
    canonical = soup.find("link", attrs={"rel": "canonical"})
    if not canonical or not canonical.get("href"):
        return LintResult("RULE-12", url,
                          "Missing canonical tag. Add: "
                          '<link rel="canonical" href="{full_url}">',
                          "Canonical")
    return None


def rule_13_single_canonical(soup, url, **_):
    """Exactly one canonical tag."""
    canonicals = soup.find_all("link", attrs={"rel": "canonical"})
    if len(canonicals) > 1:
        hrefs = [c.get("href", "") for c in canonicals]
        return LintResult("RULE-13", url,
                          f"Multiple canonical tags ({len(canonicals)}): "
                          f"{', '.join(hrefs[:3])}. Google ignores both.",
                          "Canonical")
    return None


def rule_15_canonical_in_sitemap(soup, url, site_dir=None, **_):
    """Canonical URL appears in sitemap."""
    if not site_dir:
        return None
    canonical = soup.find("link", attrs={"rel": "canonical"})
    if not canonical or not canonical.get("href"):
        return None  # rule_12 handles missing canonical

    sitemap_path = Path(site_dir) / "sitemap.xml"
    if not sitemap_path.exists():
        return None  # rule_23 handles missing sitemap

    canonical_href = canonical["href"]
    sitemap_text = sitemap_path.read_text(encoding="utf-8")
    if canonical_href not in sitemap_text:
        return LintResult("RULE-15", url,
                          f"Canonical URL not in sitemap: {canonical_href}. "
                          f"Add it to sitemap.xml or fix the canonical tag.",
                          "Canonical")
    return None


def rule_16_duplicate_h1(soup, url, all_h1s=None, **_):
    """No duplicate H1 across domain."""
    real_h1s = _real_tags(soup, "h1")
    h1 = real_h1s[0] if real_h1s else None
    if not h1:
        return None
    h1_text = h1.get_text(strip=True)
    if all_h1s is not None:
        if h1_text in all_h1s and all_h1s[h1_text] != url:
            return LintResult("RULE-16", url,
                              f"Duplicate H1 \"{h1_text}\" — "
                              f"also used by {all_h1s[h1_text]}. "
                              f"Differentiate or consolidate.",
                              "Canonical")
        all_h1s[h1_text] = url
    return None


# ============================================================================
# GROUP C: URL Structure
# ============================================================================

def rule_17_lowercase_url(url, **_):
    """No uppercase characters in URL path."""
    from urllib.parse import urlparse
    parsed = urlparse(url)
    path = parsed.path
    if path != path.lower():
        return LintResult("RULE-17", url,
                          f"Uppercase in URL path: \"{path}\". "
                          f"Use lowercase: \"{path.lower()}\"",
                          "URL")
    return None


def rule_18_url_characters(url, **_):
    """No spaces or special characters in URL path."""
    from urllib.parse import urlparse
    path = urlparse(url).path
    invalid = re.findall(r'[^a-z0-9\-/._]', path)
    if invalid:
        chars = ", ".join(repr(c) for c in set(invalid))
        return LintResult("RULE-18", url,
                          f"Invalid characters in URL path: {chars}. "
                          f"Use only: a-z, 0-9, hyphens, forward slashes.",
                          "URL")
    return None


def rule_19_no_underscores(url, **_):
    """No underscores in URL path."""
    from urllib.parse import urlparse
    path = urlparse(url).path
    if "_" in path:
        return LintResult("RULE-19", url,
                          f"Underscores in URL path: \"{path}\". "
                          f"Replace with hyphens: \"{path.replace('_', '-')}\"",
                          "URL")
    return None


def rule_20_url_length(url, **_):
    """URL length within limit (115 characters)."""
    if len(url) > 115:
        return LintResult("RULE-20", url,
                          f"URL too long ({len(url)} chars, limit 115). "
                          f"Shorten the path.",
                          "URL")
    return None


# ============================================================================
# GROUP D: Sitemap
# ============================================================================

def rule_23_sitemap_exists(site_dir, **_):
    """sitemap.xml or sitemap-index.xml exists at site root."""
    p = Path(site_dir)
    if not (p / "sitemap.xml").exists() and not (p / "sitemap-index.xml").exists():
        return LintResult("RULE-23", "/",
                          "sitemap.xml not found. Generate it during build.",
                          "Sitemap")
    return None


def rule_24_pages_in_sitemap(site_dir, page_urls=None, **_):
    """All indexable pages should appear in sitemap.xml."""
    if page_urls is None:
        return []  # returns list, not single result

    sitemap_path = Path(site_dir) / "sitemap.xml"
    if not sitemap_path.exists():
        return []  # rule_23 covers this

    sitemap_content = sitemap_path.read_text(encoding="utf-8")
    results = []
    for url in page_urls:
        # Check if URL appears in sitemap (look for the path)
        if url not in sitemap_content and url.rstrip("/") not in sitemap_content:
            results.append(LintResult("RULE-24", url,
                                      f"Page not found in sitemap.xml.",
                                      "Sitemap"))
    return results


# ============================================================================
# GROUP E: robots.txt
# ============================================================================

def rule_28_robots_exists(site_dir, **_):
    """robots.txt exists at site root."""
    if not (Path(site_dir) / "robots.txt").exists():
        return LintResult("RULE-28", "/",
                          "robots.txt not found. Create it with: "
                          "User-agent: * / Allow: / / Sitemap: ...",
                          "robots.txt")
    return None


def rule_29_robots_css_js(site_dir, **_):
    """robots.txt does not block CSS or JS."""
    robots_path = Path(site_dir) / "robots.txt"
    if not robots_path.exists():
        return None

    content = robots_path.read_text(encoding="utf-8")
    for line in content.splitlines():
        line_lower = line.strip().lower()
        if line_lower.startswith("disallow:"):
            path = line_lower.replace("disallow:", "").strip()
            if any(ext in path for ext in [".css", ".js", "/css", "/js"]):
                return LintResult("RULE-29", "/robots.txt",
                                  f"robots.txt blocks CSS or JS: \"{line.strip()}\". "
                                  f"Google needs these to render pages.",
                                  "robots.txt")
    return None


def rule_30_robots_sitemap(site_dir, **_):
    """robots.txt contains Sitemap directive."""
    robots_path = Path(site_dir) / "robots.txt"
    if not robots_path.exists():
        return None  # rule_28 covers this

    content = robots_path.read_text(encoding="utf-8")
    if "sitemap:" not in content.lower():
        return LintResult("RULE-30", "/robots.txt",
                          "robots.txt missing Sitemap directive.",
                          "robots.txt")
    return None


def rule_31_robots_block_all(site_dir, **_):
    """robots.txt does not block all crawlers."""
    robots_path = Path(site_dir) / "robots.txt"
    if not robots_path.exists():
        return None

    content = robots_path.read_text(encoding="utf-8")
    for line in content.splitlines():
        line_lower = line.strip().lower()
        if line_lower.startswith("disallow:"):
            path = line_lower.replace("disallow:", "").strip()
            if path == "/":
                return LintResult("RULE-31", "/robots.txt",
                                  "robots.txt blocks all crawlers with Disallow: /",
                                  "robots.txt")
    return None


def rule_32_legal_links(site_dir, **_):
    """Site has imprint and privacy links (required in EU/Germany)."""
    index = Path(site_dir) / "index.html"
    if not index.exists():
        return None

    html = index.read_text(encoding="utf-8").lower()
    # Skip redirect stubs — root page on multi-lang sites is just a meta refresh (#225)
    if 'http-equiv="refresh"' in html or "http-equiv='refresh'" in html:
        return None
    footer_start = html.find("<footer")
    if footer_start == -1:
        # No footer — check whole page
        text = html
    else:
        text = html[footer_start:]

    imprint_terms = ("impressum", "imprint", "legal notice")
    privacy_terms = ("datenschutz", "privacy", "privacy policy")

    has_imprint = any(t in text for t in imprint_terms)
    has_privacy = any(t in text for t in privacy_terms)

    missing = []
    if not has_imprint:
        missing.append("Impressum/Imprint")
    if not has_privacy:
        missing.append("Datenschutz/Privacy Policy")

    if missing:
        return LintResult("RULE-32", "/",
                          f"Missing legal link(s): {', '.join(missing)}. "
                          f"Required by EU/German law. Add to footer in wire.yml.",
                          "Legal")
    return None


# ============================================================================
# GROUP F: Internal Links
# ============================================================================

def rule_33_internal_links(soup, url, site_dir=None, **_):
    """No internal links returning 4xx (target file missing)."""
    if not site_dir:
        return None

    site_path = Path(site_dir)
    errors = []

    for a in soup.find_all("a", href=True):
        href = a["href"]
        if not href or href.startswith(("http", "#", "javascript:", "mailto:")):
            continue

        # Resolve relative links against the page URL
        resolved = _resolve_href(url, href)

        # Resolve internal link
        target = resolved.lstrip("/")
        if not target:
            continue

        target_path = site_path / target
        if not target_path.exists():
            # Try with index.html
            target_index = site_path / target / "index.html"
            if not target_index.exists():
                anchor = a.get_text(strip=True)[:40]
                errors.append(f"Broken internal link: {href} "
                              f"(anchor: \"{anchor}\")")

    if errors:
        shown = "; ".join(errors[:5])
        more = f" (+{len(errors) - 5} more)" if len(errors) > 5 else ""
        return LintResult("RULE-33", url,
                          f"{len(errors)} broken internal link(s): "
                          + shown + more
                          + ". Fix: create the missing page, correct the URL, "
                          "or add a redirect in wire.yml.",
                          "Links")
    return None


def rule_34_empty_anchor(soup, url, **_):
    """No internal links with empty anchor text."""
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if href.startswith(("http", "#", "javascript:", "mailto:")):
            continue
        text = a.get_text(strip=True)
        if not text and not a.get("aria-label"):
            # Check for <img alt="..."> inside the link (logo pattern)
            img = a.find("img", alt=True)
            if img and img.get("alt", "").strip():
                continue
            return LintResult("RULE-34", url,
                              f"Empty anchor text on internal link: {href}",
                              "Links")
    return None


def rule_35_orphan_pages(url, inbound_links=None, **_):
    """At least one inbound internal link per page."""
    if inbound_links is None:
        return None
    if url not in inbound_links or inbound_links[url] == 0:
        if url == "/":  # homepage is always accessible
            return None
        # News articles are linked from the auto-generated listing page
        if "/news/" in url and url != "/news/":
            return None
        return LintResult("RULE-35", url,
                          "No inbound internal links. This page is an orphan. "
                          "Add a link from at least one relevant page.",
                          "Links")
    return None


def rule_36_redirect_links(soup, url, redirect_map=None, **_):
    """Internal links must not point to redirect stubs — update to real URL."""
    if not redirect_map:
        return None

    errors = []

    for a in soup.find_all("a", href=True):
        href = a["href"]
        if not href or href.startswith(("http", "#", "javascript:", "mailto:")):
            continue

        resolved = _resolve_href(url, href)
        # Strip anchor fragment before lookup
        clean = resolved.split("#")[0]
        # Normalize trailing slash
        if clean and not clean.endswith("/"):
            clean += "/"

        if clean in redirect_map:
            target = redirect_map[clean]
            # Skip language-prefix redirects: /path/ → /en/path/ is expected
            if target and re.match(r'^/[a-z]{2}' + re.escape(clean) + r'$', target):
                continue
            errors.append(
                f"{href} → redirect to {target}"
                if target else f"{href} → redirect stub")

    if errors:
        return LintResult("RULE-36", url,
                          f"{len(errors)} link(s) point to redirects instead of "
                          f"real pages — update href to target: "
                          + "; ".join(errors[:5]),
                          "Links")
    return None


# ============================================================================
# GROUP H: Images
# ============================================================================

def rule_40_img_alt(soup, url, **_):
    """All images have alt text."""
    images = soup.find_all("img")
    missing = []
    for img in images:
        if img.find_parent(["code", "pre"]):
            continue
        if not img.has_attr("alt"):
            src = img.get("src", "(no src)")
            missing.append(src)

    if missing:
        return LintResult("RULE-40", url,
                          f"{len(missing)} image(s) missing alt text: "
                          + ", ".join(missing[:3]),
                          "Images")
    return None


# ============================================================================
# GROUP K: Indexability
# ============================================================================

def rule_49_noindex_with_links(soup, url, inbound_links=None, **_):
    """Important pages are not accidentally noindexed."""
    robots = soup.find("meta", attrs={"name": "robots"})
    if not robots:
        return None

    content = robots.get("content", "").lower()
    if "noindex" not in content:
        return None

    # Check if other pages link to this one
    if inbound_links and url in inbound_links and inbound_links[url] > 0:
        return LintResult("RULE-49", url,
                          f"noindex on page with {inbound_links[url]} inbound link(s). "
                          f"Likely accidental — remove noindex or remove links.",
                          "Indexability")
    return None


def rule_50_nofollow_internal(soup, url, **_):
    """No nofollow on internal links."""
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if href.startswith(("http", "#", "javascript:", "mailto:")):
            continue
        rel = a.get("rel", [])
        if isinstance(rel, str):
            rel = rel.split()
        if "nofollow" in rel:
            return LintResult("RULE-50", url,
                              f"nofollow on internal link: {href}. "
                              f"Remove rel=\"nofollow\" from internal links.",
                              "Indexability")
    return None


# ============================================================================
# GROUP L: Privacy / GDPR
# ============================================================================

def rule_51_no_video_iframes(soup, url, **_):
    """No raw YouTube/Vimeo iframes — use !yt[VIDEO_ID] shortcode instead."""
    for iframe in soup.find_all("iframe", src=True):
        if iframe.find_parent(["code", "pre"]):
            continue
        src = iframe["src"].lower()
        if any(d in src for d in ("youtube.com", "youtu.be", "youtube-nocookie.com",
                                   "vimeo.com", "player.vimeo.com")):
            return LintResult("RULE-51", url,
                              f"Raw video iframe: {iframe['src'][:80]}. "
                              f"Use !yt[VIDEO_ID] shortcode for GDPR-safe embeds.",
                              "Privacy")
    return None


def rule_52_no_em_dashes(soup, url, **_):
    """No em dashes (—) or double hyphens (--) in body text.

    Em dashes are the #1 tell of AI-generated content. Use commas, periods,
    semicolons, or rewrite the sentence. Double hyphens (--) are the lazy
    ascii replacement — equally bad.

    Skips code blocks, pre, and navigation elements.
    """
    content = soup.find("article") or soup.find("main")
    if not content:
        return None
    # Collect text nodes, skipping code/pre/nav/script
    # Skip code, nav, and link/citation text — dashes in proper nouns and titles are legitimate (#219)
    skip_tags = {"code", "pre", "samp", "script", "style", "nav", "header", "footer", "a", "cite"}
    hits = []
    for element in content.descendants:
        if not isinstance(element, NavigableString):
            continue
        # Skip if inside a code/pre/nav/script/style ancestor
        if element.find_parent(skip_tags):
            continue
        text = str(element)
        # Check for em dash (U+2014), double hyphen (--), or spaced hyphen ( - )
        # Skip CLI flags like --dry-run, --force (word follows immediately)
        has_em_dash = "\u2014" in text
        has_double_hyphen = re.search(r'(?<!\w)--(?!\w)', text) is not None
        # Spaced hyphen: word + spaces + hyphen + spaces + word (#98)
        has_spaced_hyphen = re.search(r'\w\s{1,2}-\s{1,2}\w', text) is not None
        if has_em_dash or has_double_hyphen or has_spaced_hyphen:
            # Get a short context snippet
            for pattern in ["\u2014", "--", " - "]:
                idx = text.find(pattern)
                if idx >= 0:
                    start = max(0, idx - 20)
                    end = min(len(text), idx + len(pattern) + 20)
                    snippet = text[start:end].strip()
                    if snippet:
                        hits.append(snippet)
    if hits:
        # Show first occurrence
        sample = hits[0].replace("\n", " ")
        count = len(hits)
        plural = "es" if count > 1 else ""
        return LintResult(
            "RULE-52", url,
            f"{count} em dash{plural} found. First: \u2018{sample}\u2019. "
            f"Dashes look AI generated. Try to rewrite sentence as one or two. Try to sound more human. Like 'SEO Reference - Thresholds'"
            f" -> 'Research about Thresholds in SEO' ",
            "Content quality")
    return None


def rule_53_discovery_step_ids(soup, url, **_):
    """Discovery step IDs must match article H2 anchors."""
    steps = soup.select('[data-step]')
    if not steps:
        return None
    step_ids = {s.get('data-step', '') for s in steps} - {"start"}
    h2_ids = {h2.get('id', '') for h2 in _real_tags(soup, 'h2')} - {''}
    orphans = step_ids - h2_ids
    if orphans:
        return LintResult("RULE-53", url,
            f"Discovery step IDs not matching any H2: {', '.join(sorted(orphans))}",
            "Discovery")
    return None


# ============================================================================
# GROUP A extended: Content quality
# ============================================================================

def rule_08_word_count(soup, url, **_):
    """Body content has meaningful length (not a stub page)."""
    # Look for main content container first, fall back to body
    content = soup.find("article") or soup.find("main") or soup.find("body")
    if not content:
        return None
    # Get text, skipping nav/header/footer/script elements
    text_parts = []
    for element in content.descendants:
        if hasattr(element, "name") and element.name in (
                "nav", "header", "footer", "script", "style"):
            continue
        if isinstance(element, str) and element.parent.name not in (
                "nav", "header", "footer", "script", "style"):
            text_parts.append(element)
    text = " ".join(text_parts)
    word_count = len(text.split())
    if word_count < 200:
        return LintResult("RULE-08", url,
                          f"Thin content: {word_count} words. "
                          f"Pages with fewer than 200 words risk being ignored by search engines.",
                          "Metadata")
    return None


# ============================================================================
# GROUP C extended: URL consistency
# ============================================================================

def rule_22_trailing_slash(soup, url, **_):
    """Internal links use consistent trailing slash."""
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if href.startswith(("http", "#", "javascript:", "mailto:")):
            continue
        if "." in href.split("/")[-1]:
            continue  # File link (e.g., /style.css)
        if href and not href.endswith("/") and href != "/":
            return LintResult("RULE-22", url,
                              f"Internal link without trailing slash: {href}. "
                              f"Add trailing slash for consistent URLs.",
                              "URL Structure")
    return None


# ============================================================================
# GROUP D extended: Sitemap integrity
# ============================================================================

def rule_25_noindex_in_sitemap(site_dir, **_):
    """No noindex pages listed in sitemap."""
    site_dir = Path(site_dir)
    sitemap = site_dir / "sitemap.xml"
    if not sitemap.exists():
        return None
    sitemap_text = sitemap.read_text(encoding="utf-8")
    # Extract URLs from sitemap
    sitemap_urls = re.findall(r"<loc>([^<]+)</loc>", sitemap_text)
    noindex_in_sitemap = []
    for html_file in site_dir.rglob("*.html"):
        raw = html_file.read_text(encoding="utf-8")
        if 'name="robots"' in raw and "noindex" in raw.lower():
            rel = str(html_file.relative_to(site_dir)).replace("\\", "/")
            page_url = "/" + rel.replace("index.html", "").rstrip("/") + "/"
            if page_url == "//":
                page_url = "/"
            # Check if any sitemap URL matches
            for surl in sitemap_urls:
                if surl.endswith(page_url) or surl.endswith(page_url.rstrip("/")):
                    noindex_in_sitemap.append(page_url)
                    break
    if noindex_in_sitemap:
        pages = ", ".join(noindex_in_sitemap[:5])
        return LintResult("RULE-25", "sitemap.xml",
                          f"noindex page(s) in sitemap: {pages}. "
                          f"Remove from sitemap or remove noindex.",
                          "Sitemap")
    return None


# ============================================================================
# GROUP C extended: Query parameters
# ============================================================================

def rule_21_no_query_params(url, **_):
    """No query parameters on canonical page URLs."""
    from urllib.parse import urlparse
    parsed = urlparse(url)
    if parsed.query:
        return LintResult("RULE-21", url,
                          f"Query parameters on page URL: ?{parsed.query}. "
                          f"Strip parameters for clean canonical URLs.",
                          "URL Structure")
    return None


# ============================================================================
# GROUP D extended: Sitemap blocked pages
# ============================================================================

def rule_26_robots_blocked_in_sitemap(site_dir, **_):
    """No robots.txt-blocked pages in sitemap."""
    site_dir = Path(site_dir)
    robots_path = site_dir / "robots.txt"
    sitemap_path = site_dir / "sitemap.xml"
    if not robots_path.exists() or not sitemap_path.exists():
        return None

    # Parse disallow rules
    disallow_paths = []
    robots_text = robots_path.read_text(encoding="utf-8")
    for line in robots_text.splitlines():
        line_lower = line.strip().lower()
        if line_lower.startswith("disallow:"):
            path = line.strip().split(":", 1)[1].strip()
            if path and path != "/":
                disallow_paths.append(path)

    if not disallow_paths:
        return None

    sitemap_text = sitemap_path.read_text(encoding="utf-8")
    sitemap_urls = re.findall(r"<loc>([^<]+)</loc>", sitemap_text)

    blocked = []
    for surl in sitemap_urls:
        from urllib.parse import urlparse
        path = urlparse(surl).path
        for dp in disallow_paths:
            if path.startswith(dp):
                blocked.append(path)
                break

    if blocked:
        pages = ", ".join(blocked[:5])
        return LintResult("RULE-26", "sitemap.xml",
                          f"robots.txt-blocked page(s) in sitemap: {pages}. "
                          f"Remove from sitemap or update robots.txt.",
                          "Sitemap")
    return None


# ============================================================================
# GROUP G: Security (build-time checkable)
# ============================================================================

def rule_37_mixed_content(soup, url, **_):
    """No HTTP resources on HTTPS pages."""
    mixed = []
    for tag in soup.find_all(["img", "script", "link", "source", "video", "audio"]):
        src = tag.get("src") or tag.get("href") or ""
        if src.startswith("http://"):
            mixed.append(src)

    if mixed:
        return LintResult("RULE-37", url,
                          f"{len(mixed)} mixed content resource(s) loading over HTTP: "
                          + ", ".join(mixed[:3]),
                          "Security")
    return None


# ============================================================================
# GROUP H extended: Image attributes
# ============================================================================

def rule_41_broken_images(soup, url, site_dir=None, **_):
    """No broken local image sources."""
    if not site_dir:
        return None

    site_path = Path(site_dir)
    # Resolve page directory for relative paths
    page_dir = site_path
    if url and url != "/":
        page_dir = site_path / url.strip("/")
    broken = []
    for img in soup.find_all("img", src=True):
        src = img["src"]
        if src.startswith(("http://", "https://", "data:", "//")):
            continue  # External or data URI — can't check at build time
        if src.startswith("/"):
            target = src.lstrip("/")
            resolved = site_path / target
        else:
            resolved = (page_dir / src).resolve()
        if not resolved.exists():
            broken.append(src)

    if broken:
        return LintResult("RULE-41", url,
                          f"{len(broken)} broken image source(s): "
                          + ", ".join(broken[:3]),
                          "Images")
    return None

def rule_42_img_dimensions(soup, url, **_):
    """Images have explicit width and height to prevent layout shift."""
    for img in soup.find_all("img"):
        # Shortcode/component images are CSS-sized — not content layout (#214, #216, #224)
        if img.find_parent(class_=("author-byline", "sidebar-card", "logo-cloud")):
            continue
        if not img.get("width") or not img.get("height"):
            src = img.get("src", "(no src)")
            return LintResult("RULE-42", url,
                              f"Image missing width/height: {src}. "
                              f"Use ![alt](src) in markdown — Wire auto-injects dimensions. "
                              f"Raw <img> tags bypass this.",
                              "Images")
    return None


# ============================================================================
# GROUP J: Structured Data
# ============================================================================

def rule_45_jsonld_present(soup, url, **_):
    """Page must have at least one JSON-LD block."""
    scripts = soup.find_all("script", type="application/ld+json")
    if not scripts:
        return LintResult("RULE-45", url,
                          "No JSON-LD structured data found. "
                          "Add a <script type=\"application/ld+json\"> block.",
                          "Structured Data")
    return None


def rule_46_jsonld_valid(soup, url, **_):
    """JSON-LD scripts contain valid JSON."""
    for script in soup.find_all("script", type="application/ld+json"):
        text = script.string
        if not text:
            continue
        try:
            json.loads(text)
        except (json.JSONDecodeError, TypeError) as e:
            return LintResult("RULE-46", url,
                              f"Invalid JSON-LD: {e}. Fix the structured data.",
                              "Structured Data")
    return None


def rule_47_jsonld_type(soup, url, **_):
    """JSON-LD @type is a recognized schema.org type."""
    valid_types = {
        "Article", "BlogPosting", "NewsArticle", "WebPage", "WebSite",
        "Organization", "Person", "Product", "SoftwareApplication",
        "FAQPage", "HowTo", "BreadcrumbList", "ItemList", "Event",
        "LocalBusiness", "Service", "Review", "Course", "CollectionPage",
        "ProfilePage", "TechArticle",
    }
    for script in soup.find_all("script", type="application/ld+json"):
        text = script.string
        if not text:
            continue
        try:
            data = json.loads(text)
        except (json.JSONDecodeError, TypeError):
            continue  # rule_46 handles this
        items = data if isinstance(data, list) else [data]
        for item in items:
            if not isinstance(item, dict):
                continue
            at_type = item.get("@type", "")
            if at_type and at_type not in valid_types:
                return LintResult("RULE-47", url,
                                  f"Unknown JSON-LD @type: \"{at_type}\". "
                                  f"Use a recognized schema.org type.",
                                  "Structured Data")
    return None


def rule_48_jsonld_urls(soup, url, site_dir=None, **_):
    """No broken local URLs in structured data fields."""
    if not site_dir:
        return None
    site_path = Path(site_dir)
    url_fields = {"url", "mainEntityOfPage", "image", "logo", "sameAs"}

    for script in soup.find_all("script", type="application/ld+json"):
        text = script.string
        if not text:
            continue
        try:
            data = json.loads(text)
        except (json.JSONDecodeError, TypeError):
            continue
        items = data if isinstance(data, list) else [data]
        for item in items:
            if not isinstance(item, dict):
                continue
            for field in url_fields:
                val = item.get(field, "")
                if isinstance(val, str) and val.startswith("/"):
                    target = val.lstrip("/")
                    if target and not (site_path / target).exists():
                        target_index = site_path / target / "index.html"
                        if not target_index.exists():
                            return LintResult("RULE-48", url,
                                              f"Broken URL in JSON-LD field \"{field}\": "
                                              f"{val}",
                                              "Structured Data")
    return None


# Google-recommended fields per schema.org @type.
# Missing these won't break anything, but costs rich result features and CTR.
_JSONLD_RECOMMENDED = {
    "Article":      {"headline", "datePublished", "author"},
    "BlogPosting":  {"headline", "datePublished", "author"},
    "TechArticle":  {"headline", "datePublished", "author"},
    "NewsArticle":  {"headline", "datePublished", "author", "publisher"},
    "WebSite":      {"name", "url"},
    "Organization": {"name", "url"},
    "ProfilePage":  {"mainEntity"},
}


def rule_55_jsonld_recommended_fields(soup, url, **_):
    """JSON-LD includes Google-recommended fields for its @type."""
    for script in soup.find_all("script", type="application/ld+json"):
        text = script.string
        if not text:
            continue
        try:
            data = json.loads(text)
        except (json.JSONDecodeError, TypeError):
            continue
        items = data if isinstance(data, list) else [data]
        for item in items:
            if not isinstance(item, dict):
                continue
            at_type = item.get("@type", "")
            required = _JSONLD_RECOMMENDED.get(at_type)
            if not required:
                continue
            missing = [f for f in sorted(required) if not item.get(f)]
            if missing:
                fields = ", ".join(missing)
                return LintResult("RULE-55", url,
                    f"JSON-LD @type \"{at_type}\" missing recommended "
                    f"field(s): {fields}. Google uses these for rich "
                    f"results and E-E-A-T signals.",
                    "Structured Data")
    return None


# ============================================================================
# GROUP I: Hreflang (active only when pages have hreflang tags)
# ============================================================================

def rule_43_hreflang_valid(soup, url, **_):
    """Hreflang tags use valid BCP 47 language codes."""
    valid_prefixes = {
        "en", "de", "fr", "es", "it", "pt", "nl", "pl", "ru", "ja",
        "zh", "ko", "ar", "tr", "sv", "da", "no", "fi", "cs", "hu",
        "ro", "bg", "hr", "sk", "sl", "el", "he", "th", "vi", "id",
        "ms", "uk", "x-default",
    }
    hreflangs = soup.find_all("link", attrs={"rel": "alternate", "hreflang": True})
    if not hreflangs:
        return None  # No hreflang tags — skip
    for link in hreflangs:
        lang = link.get("hreflang", "")
        # x-default is a special hreflang value, not a BCP 47 code (#246)
        if lang.lower() == "x-default":
            continue
        prefix = lang.split("-")[0].lower()
        if prefix not in valid_prefixes:
            return LintResult("RULE-43", url,
                              f"Invalid hreflang code: \"{lang}\". "
                              f"Use a valid BCP 47 language tag.",
                              "Hreflang")
    return None


def rule_44_hreflang_xdefault(soup, url, **_):
    """Hreflang includes x-default when other hreflang tags exist."""
    hreflangs = soup.find_all("link", attrs={"rel": "alternate", "hreflang": True})
    if len(hreflangs) < 2:
        return None  # Not a multilingual page
    codes = [link.get("hreflang", "").lower() for link in hreflangs]
    if "x-default" not in codes:
        return LintResult("RULE-44", url,
                          "Hreflang tags present but missing x-default. "
                          "Add x-default as the fallback for unmatched regions.",
                          "Hreflang")
    return None


def rule_45_hreflang_reciprocal(soup, url, hreflang_map=None, **_):
    """Every hreflang alternate has a reciprocal link back."""
    if not hreflang_map:
        return None
    hreflangs = soup.find_all("link", attrs={"rel": "alternate", "hreflang": True})
    if not hreflangs:
        return None
    for link in hreflangs:
        href = link.get("href", "")
        lang = link.get("hreflang", "")
        if lang.lower() == "x-default":
            continue
        # Check if target page links back to us
        target_langs = hreflang_map.get(href, {})
        # Look for any hreflang in target that points back to our canonical URL
        page_canonical = None
        canonical_tag = soup.find("link", attrs={"rel": "canonical"})
        if canonical_tag:
            page_canonical = canonical_tag.get("href", "")
        if not page_canonical:
            continue
        if page_canonical not in target_langs.values():
            return LintResult("RULE-45", url,
                              f"Hreflang \"{lang}\" points to {href} but "
                              f"that page does not link back. Add reciprocal "
                              f"hreflang to the target page.",
                              "Hreflang")
    return None


# ============================================================================
# GROUP O: Shortcodes / Components
# ============================================================================


def rule_63_stats_bar_count(soup, url, **_):
    """Stats bar must have exactly 4 items. Mobile grid is 2-col, so odd counts orphan."""
    bars = soup.find_all("div", class_="stats-bar")
    for bar in bars:
        stats = bar.find_all("div", class_="stat", recursive=False)
        count = len(stats)
        if count != 4:
            return LintResult(
                "RULE-63", url,
                f"Stats bar has {count} item(s) (need exactly 4). "
                f"Desktop renders 4 across, mobile renders 2+2. "
                f"Other counts create orphan rows.",
                "Components")
    return None


def rule_64_custom_hero_section(soup, url, **_):
    """Landing page custom <section> in hero must declare section-hero class."""
    landing = soup.find("article", class_="landing-content")
    if not landing:
        return None
    # Find the hero wrapper — Wire's section-hero div
    hero_div = landing.find("div", class_="section-hero")
    if not hero_div:
        # No Wire hero wrapper — check if there's a passthrough custom section
        # (customer provided section-hero, build skipped the wrapper)
        # That's fine — they declared ownership
        return None
    # Hero wrapper exists — check if it contains a <section> without section-hero
    for section in hero_div.find_all("section", recursive=True):
        classes = section.get("class", [])
        if "section-hero" not in classes:
            return LintResult(
                "RULE-64", url,
                f"Custom <section class=\"{' '.join(classes)}\"> inside hero "
                f"but missing section-hero class. Wire wraps the hero with "
                f"padding and background — your custom section fights it. "
                f"Add section-hero to your <section> class list so Wire "
                f"passes it through without wrapping.",
                "Components")
    return None


def rule_65_og_image(soup, url, **_):
    """Open Graph image tag present for social sharing previews."""
    tag = soup.find("meta", attrs={"property": "og:image"})
    if not tag or not tag.get("content"):
        return LintResult(
            "RULE-65", url,
            "Missing og:image — social shares will show a blank preview. "
            "Add image: to frontmatter, or set theme.og_image in wire.yml "
            "as a site-wide fallback.",
            "Metadata")
    return None


def rule_66_form_without_handler(soup, url, **_):
    """Form element must have a submission handler."""
    form = soup.find("form")
    if not form:
        return None
    # Customer form with own action= is fine
    if form.get("action"):
        return None
    # Wire-managed form (forms.js loaded via __wire_form) is fine
    if soup.find("script", string=lambda s: s and "__wire_form" in s):
        return None
    return LintResult(
        "RULE-66", url,
        "Page has a <form> without action= and no form_id configured. "
        "The form renders but submit does nothing. Add form_id to "
        "wire.yml under extra.wire, or add an action= attribute to "
        "the <form> tag.",
        "Links")


def rule_67_numbered_headings(soup, url, **_):
    """Headings should not start with numbered prefixes.

    Only fires when the majority of H2/H3 headings are numbered — that
    indicates a mechanically numbered document (migration artifact).
    A single numbered heading in an otherwise normal page is fine.
    """
    _numbered = re.compile(r'^\d+[\.\)]\s+')
    headings = _real_tags(soup, 'h2') + _real_tags(soup, 'h3')
    if len(headings) < 2:
        return None
    numbered = [h for h in headings if _numbered.match(h.get_text(strip=True))]
    if len(numbered) < len(headings) * 0.5:
        return None
    first = numbered[0].get_text(strip=True)
    return LintResult(
        "RULE-67", url,
        f"Heading starts with numbered prefix: \"{first[:60]}\". "
                f"Use descriptive headings without manual numbering.",
                "Content Quality")


def rule_68_progress_bar_values(soup, url, **_):
    """Progress bar fill width must be 0-100%. Values > 100% break layout."""
    fills = soup.find_all("div", class_="progress-fill")
    for fill in fills:
        style = fill.get("style", "")
        m = re.search(r'width:\s*([\d.]+)%', style)
        if m:
            val = float(m.group(1))
            if val > 100:
                return LintResult(
                    "RULE-68", url,
                    f"Progress bar fill is {val}% (max 100%). "
                    f"Values over 100% overflow the track.",
                    "Components")
    return None


def rule_69_cross_language_links(soup, url, lang_prefixes=None, **_):
    """Internal links must stay in the same language directory.

    On multi-language sites, a page at /de/services/ must not link to
    /en/about/. Customers copy markdown between languages and forget to
    update links. Excludes language switcher links and external URLs.
    """
    if not lang_prefixes or len(lang_prefixes) < 2:
        return None

    # Determine this page's language from URL prefix
    page_lang = None
    for prefix in lang_prefixes:
        if url.startswith(f"/{prefix}/"):
            page_lang = prefix
            break
    if not page_lang:
        return None  # Root page, not in a lang dir

    # Check <a> tags only (not <link> hreflang tags)
    violations = []
    for a in soup.find_all("a", href=True):
        href = a["href"]
        # Skip external links
        if href.startswith(("http://", "https://", "mailto:", "tel:", "#",
                            "javascript:")):
            continue
        # Skip links inside .lang-switcher
        if a.find_parent(class_="lang-switcher"):
            continue
        # Check if link goes to a different language prefix
        for prefix in lang_prefixes:
            if prefix != page_lang and href.startswith(f"/{prefix}/"):
                violations.append(href)
                break

    if violations:
        examples = ", ".join(violations[:3])
        extra = f" (+{len(violations) - 3} more)" if len(violations) > 3 else ""
        return LintResult(
            "RULE-69", url,
            f"Cross-language internal link(s): {examples}{extra}. "
            f"Page is in /{page_lang}/ but links to another language. "
            f"Update links to stay in /{page_lang}/ or use the language switcher.",
            "Links")
    return None


def rule_70_absolute_self_links(soup, url, site_url=None, **_):
    """No absolute URLs pointing to own domain — use relative paths instead.

    Absolute self-links bypass redirect checks and break when the domain
    changes. Wire can only validate internal links when they are relative.
    """
    if not site_url:
        return None

    domain = site_url.rstrip("/").lower()
    # Also match www/non-www variants
    if domain.startswith("https://www."):
        alt_domain = domain.replace("https://www.", "https://")
    elif domain.startswith("https://"):
        alt_domain = domain.replace("https://", "https://www.")
    else:
        alt_domain = None

    domains = [domain]
    if alt_domain:
        domains.append(alt_domain)
    # Also check http variants
    domains.extend([d.replace("https://", "http://") for d in domains])

    errors = []
    for a in soup.find_all("a", href=True):
        href = a["href"].lower()
        for d in domains:
            if href.startswith(d + "/") or href == d:
                anchor = a.get_text(strip=True)[:40]
                errors.append(
                    f"{a['href']} (anchor: \"{anchor}\")")
                break

    if errors:
        return LintResult(
            "RULE-70", url,
            f"{len(errors)} absolute self-link(s) — use relative paths instead: "
            + "; ".join(errors[:5]),
            "Links")
    return None


def _parse_topic_slug(url: str, lang_prefixes: set = None) -> tuple:
    """Extract (topic, slug) from a page URL.

    Articles live at /topic/slug/ (or /lang/topic/slug/ on multi-language sites).
    Topic index pages are /topic/ (or /lang/topic/), where slug is empty.

    Returns:
        (topic, slug) tuple. Both empty if the URL is not a topic page.
    """
    parts = [p for p in url.strip("/").split("/") if p]
    # Strip language prefix if present
    if lang_prefixes and parts and parts[0] in lang_prefixes:
        parts = parts[1:]
    if len(parts) >= 2:
        return parts[0], parts[-1]
    elif len(parts) == 1:
        return parts[0], ""
    return "", ""


def rule_71_article_link_minimum(soup, url, lang_prefixes=None,
                                  all_titles=None, **_):
    """Articles must have minimum internal + external links (reverse SEO silo).

    Every article page (topic + slug) must contain:
      - At least 2 internal links to sibling pages in the same topic
      - At least 1 internal link to the topic index or a parent page
      - At least 1 external link for source credibility

    Skips the sibling check when the topic has fewer than 3 sibling pages
    (not enough siblings to link to). Skips the topic index check when no
    topic index page exists in the site.

    Links are counted from the article body only (not navigation, sidebar, or
    template chrome) to enforce genuine content interlinking.
    """
    topic, slug = _parse_topic_slug(url, lang_prefixes)
    # Only applies to article pages (has both topic and slug)
    if not topic or not slug:
        return None

    # Skip news articles — they are auto-generated
    if topic == "news":
        return None

    # Find article body — only count links in actual content
    body = soup.find("div", class_="article-body")
    if not body:
        # Fallback: try <article> or <main> for non-standard templates
        body = soup.find("article") or soup.find("main")
    if not body:
        return None

    # Determine lang prefix for URL matching
    lang_prefix = ""
    if lang_prefixes:
        parts = url.strip("/").split("/")
        if parts and parts[0] in lang_prefixes:
            lang_prefix = parts[0]

    # Build the topic path prefix for sibling detection
    if lang_prefix:
        topic_prefix = f"/{lang_prefix}/{topic}/"
    else:
        topic_prefix = f"/{topic}/"
    topic_index = topic_prefix  # e.g. /guides/ or /en/guides/

    sibling_count = 0
    topic_index_count = 0
    external_count = 0

    for a in body.find_all("a", href=True):
        href = a["href"]

        # External link
        if href.startswith(("http://", "https://")):
            external_count += 1
            continue

        # Skip anchors, javascript, mailto
        if href.startswith(("#", "javascript:", "mailto:", "tel:")):
            continue

        # Resolve relative links to absolute paths
        resolved = _resolve_href(url, href)

        # Check if it points to the topic index
        if resolved.rstrip("/") + "/" == topic_index:
            topic_index_count += 1
            continue

        # Check if it points to a sibling page in the same topic
        if resolved.startswith(topic_prefix) and resolved != topic_index:
            sibling_count += 1

    # Count total sibling article pages in this topic (excluding self)
    # to skip checks when there aren't enough siblings to link to.
    total_siblings = 0
    topic_index_exists = False
    if all_titles:
        for page_url in all_titles.values():
            norm = page_url.rstrip("/") + "/"
            if norm == topic_index:
                topic_index_exists = True
            elif norm.startswith(topic_prefix) and norm != url.rstrip("/") + "/":
                total_siblings += 1

    issues = []
    # Skip sibling check when fewer than 3 sibling pages exist
    if total_siblings >= 2 and sibling_count < 2:
        need = 2 - sibling_count
        issues.append(
            f"needs {need} more internal link(s) to sibling pages "
            f"in /{topic}/")
    # Skip topic index check when no topic index page exists
    if topic_index_exists and topic_index_count < 1:
        issues.append(
            f"needs 1 link to the topic index page ({topic_index})")
    if external_count < 1:
        issues.append("needs 1 external link for source credibility")

    if issues:
        # Has/missing summary for context
        has_parts = []
        if sibling_count:
            has_parts.append(f"{sibling_count} sibling link(s)")
        if topic_index_count:
            has_parts.append(f"topic index link")
        if external_count:
            has_parts.append(f"{external_count} external link(s)")
        has_str = f" Has: {', '.join(has_parts)}." if has_parts else ""
        return LintResult(
            "RULE-71", url,
            f"Article link minimum not met: {'; '.join(issues)}.{has_str} "
            f"Link on first mention of the concept (2-5 word anchor). "
            f"Do NOT append links at the bottom.",
            "Content quality")
    return None


def rule_72_generic_anchor_text(soup, url, **_):
    """No generic anchor text ('click here', 'here', 'read more') (#111).

    Generic anchors waste link equity. Google uses anchor text to understand
    what the target page is about. 'Click here' tells Google nothing.
    Only checks article body — nav/header/footer links are excluded.
    """
    # Generic patterns (English + German)
    _GENERIC = {
        "click here", "here", "read more", "learn more", "more info",
        "this page", "this article", "this link", "find out more",
        "see more", "view more", "go here",
        # German
        "hier", "hier klicken", "mehr erfahren", "weiterlesen",
        "mehr dazu", "mehr lesen",
    }

    content = soup.find(class_="article-body") or soup.find("article") or soup.find("main")
    if not content:
        return None

    hits = []
    for a in content.find_all("a", href=True):
        text = a.get_text(strip=True).lower()
        if text in _GENERIC:
            hits.append(f'"{a.get_text(strip=True)}" → {a["href"]}')

    if hits:
        sample = hits[0]
        count = len(hits)
        return LintResult(
            "RULE-72", url,
            f"{count} generic anchor(s) found. First: {sample}. "
            f"Use descriptive 2-5 word anchors that describe the target page.",
            "Content quality")
    return None


def rule_101_tel_format(soup, url, **_):
    """tel: links should use E.164 format (+49...) (#153)."""
    content = soup.find("article") or soup.find("main") or soup
    for a in content.find_all("a", href=True):
        href = a["href"]
        if href.startswith("tel:") and not href.startswith("tel:+"):
            return LintResult(
                "RULE-101", url,
                f"tel: link not in E.164 format: {href}. "
                f"Use +{'{country code}'} prefix for mobile compatibility.",
                "Links")
    return None


def rule_102_pdf_link(soup, url, **_):
    """Links to .pdf should indicate file type (#154).

    Visitors expect page navigation — PDFs are downloads.
    Google indexes PDFs separately, competing with HTML pages.
    """
    content = soup.find("article") or soup.find("main") or soup
    for a in content.find_all("a", href=True):
        href = a["href"].lower()
        if href.endswith(".pdf"):
            text = a.get_text(strip=True).lower()
            if "pdf" not in text and "download" not in text:
                return LintResult(
                    "RULE-102", url,
                    f"Link to PDF without indicator: '{a.get_text(strip=True)}'. "
                    f"Add (PDF) or 'Download' to set visitor expectations.",
                    "Links")
    return None


def rule_100_title_h1_misaligned(soup, url, **_):
    """Title and H1 have <30% word overlap = misaligned intent (#152).

    SearchPilot A/B: aligning H1 with title intent → +28% traffic.
    Title targets search queries, H1 targets readers — but they should
    be about the same topic.
    """
    stripped = url.strip("/")
    if not stripped or "/" not in stripped:
        return None
    title_tag = soup.find("title")
    h1_tag = soup.find("h1")
    if not title_tag or not h1_tag:
        return None
    _stops = {"the", "a", "an", "and", "or", "for", "to", "in", "of", "on",
              "is", "are", "was", "with", "by", "at", "from", "your", "how",
              "der", "die", "das", "und", "oder", "für", "mit", "von", "ein"}
    title_words = {w.lower() for w in title_tag.get_text(strip=True).split()
                   if w.lower() not in _stops and len(w) > 2}
    h1_words = {w.lower() for w in h1_tag.get_text(strip=True).split()
                if w.lower() not in _stops and len(w) > 2}
    if not title_words or not h1_words:
        return None
    overlap = len(title_words & h1_words) / max(len(title_words), len(h1_words))
    if overlap < 0.3:
        return LintResult(
            "RULE-100", url,
            f"Title and H1 share only {overlap:.0%} of keywords. "
            f"Align intent — both should be about the same topic.",
            "Metadata")
    return None


# RULE-98 REMOVED (#159): mailto: is not an HTTP URL. Google does not crawl it,
# does not pass PageRank through it. nofollow on mailto is a no-op with zero SEO effect.
# Deep research: no Google docs, no Googler statements, no SEO tool flags it,
# no A/B test, Google's own "qualify outbound links" page excludes non-HTTP schemes.
# Sources: developers.google.com/search/docs/crawling-indexing/qualify-outbound-links


def rule_99_short_description(soup, url, **_):
    """Description <70 chars underutilizes SERP snippet (#151).

    Google shows ~155 chars. Short descriptions waste half the preview.
    """
    stripped = url.strip("/")
    if not stripped or "/" not in stripped:
        return None
    meta = soup.find("meta", attrs={"name": "description"})
    if not meta:
        return None
    desc = (meta.get("content", "") or "").strip()
    if desc and len(desc) < 70:
        return LintResult(
            "RULE-99", url,
            f"Description is only {len(desc)} chars (target: 120-155). "
            f"Expand to use more SERP snippet space.",
            "Metadata")
    return None


def rule_97_no_prose(soup, url, **_):
    """Article pages with no <p> tags = non-prose content (#148).

    Articles should have paragraph text. Pages with only headings, lists,
    or code blocks may be outlines that need a different layout.
    """
    stripped = url.strip("/")
    if not stripped or "/" not in stripped:
        return None
    content = soup.find("article") or soup.find("main")
    if not content:
        return None
    paragraphs = [p for p in content.find_all("p")
                  if p.get_text(strip=True)]
    if not paragraphs:
        return LintResult(
            "RULE-97", url,
            "No paragraph text in article body. "
            "Add prose content — headings and lists alone don't rank.",
            "Content quality")
    return None


def rule_96_no_semantic_html(soup, url, **_):
    """Pages should use semantic HTML elements (#146).

    <article> or <main> helps Google understand page structure and
    supports AI content extraction for featured snippets.
    Only checks article pages (topic/slug) — legal and utility pages skip.
    """
    stripped = url.strip("/")
    if not stripped or "/" not in stripped:
        return None
    if soup.find("article") or soup.find("main"):
        return None
    return LintResult(
        "RULE-96", url,
        "No <article> or <main> element found. "
        "Use semantic HTML for better content structure.",
        "Accessibility")


def rule_95_long_title(soup, url, **_):
    """Title >60 chars gets truncated in Google SERPs (#145)."""
    title = soup.find("title")
    if not title:
        return None
    text = title.get_text(strip=True)
    if len(text) > 60:
        return LintResult(
            "RULE-95", url,
            f"Title is {len(text)} chars (max 60). "
            f"Google truncates at ~600px (~60 chars). "
            f"Move keywords to the front.",
            "Metadata")
    return None


def rule_93_table_no_thead(soup, url, **_):
    """Tables without <thead> hurt accessibility and SEO (#143)."""
    content = soup.find("article") or soup.find("main")
    if not content:
        return None
    for table in content.find_all("table"):
        if not table.find("thead") and not table.find("th"):
            return LintResult(
                "RULE-93", url,
                "Table without <thead>/<th>. Add header row for "
                "accessibility and semantic meaning.",
                "Accessibility")
    return None


def rule_94_long_description(soup, url, **_):
    """Description >160 chars gets truncated in SERPs (#144)."""
    meta = soup.find("meta", attrs={"name": "description"})
    if not meta:
        return None
    desc = meta.get("content", "") or ""
    if len(desc) > 160:
        return LintResult(
            "RULE-94", url,
            f"Meta description is {len(desc)} chars (max 160). "
            f"Truncated text wastes the SERP snippet.",
            "Metadata")
    return None


def rule_92_weak_integration(soup, url, **_):
    """Article with only 1 outbound internal link = weak integration (#139).

    Google needs 2+ entry/exit points. 1 link means a single path in and
    one context signal. 0 links caught by RULE-78 (dead-end).
    """
    parts = url.strip("/").split("/")
    if len(parts) < 2 or not parts[-1]:
        return None
    content = soup.find(class_="article-body") or soup.find("article") or soup.find("main")
    if not content:
        return None
    internal_count = 0
    for a in content.find_all("a", href=True):
        href = a["href"]
        if href.startswith("/") or (not href.startswith(("http", "mailto:", "#", "tel:"))):
            internal_count += 1
    if internal_count == 1:
        return LintResult(
            "RULE-92", url,
            "Only 1 internal link — weakly integrated. "
            "Add 2+ outbound internal links for better crawlability.",
            "Links")
    return None


def rule_91_deep_heading_nesting(soup, url, **_):
    """Heading depth >H4 is over-structured (#138).

    Google's heading understanding works best with H1+H2+H3.
    Deeper levels add complexity without SEO value.
    """
    content = soup.find("article") or soup.find("main")
    if not content:
        return None
    deep = content.find_all(["h5", "h6"])
    if deep:
        return LintResult(
            "RULE-91", url,
            f"Deep heading nesting: {len(deep)} H5/H6 element(s). "
            f"Flatten to H2-H4 for better content structure.",
            "Content quality")
    return None


# RULE-90 REMOVED (#159): Zero evidence across 6 dimensions.
# No Google docs, no A/B tests, no SEO tool flags it, no UX research (NNg/Baymard),
# no AI detector documents heading length uniformity as a feature.
# "Pricing / Features / Integrations / Support" has uniform length and is fine.
# Heading quality is about relevance and hierarchy, not word count uniformity.
# Deep research confirmed: burstiness metrics operate at prose level, not heading level.


def rule_89_no_subheadings(soup, url, **_):
    """Articles with 300+ words and no H2 lack structure (#134).

    Google uses heading hierarchy for content understanding and
    featured snippet extraction. Unstructured walls of text rank poorly.
    """
    content = soup.find("article") or soup.find("main")
    if not content:
        return None
    words = len(content.get_text(strip=True).split())
    if words < 300:
        return None
    h2s = content.find_all("h2")
    if not h2s:
        return LintResult(
            "RULE-89", url,
            f"{words}-word page with no H2 subheadings. "
            f"Add headings to structure the content for readers and search engines.",
            "Content quality")
    return None


def rule_88_keyword_stuffing(soup, url, **_):
    """Single word >5% of body text = keyword stuffing (#133, #158).

    Google's spam policies penalize keyword stuffing. Natural writing
    doesn't repeat the same word excessively. But topic vocabulary is
    not stuffing — a page about "wordpress" will naturally use it often.

    Threshold: 5% (research shows 1-3% normal, >7% harmful; 5% is the
    midpoint that catches real stuffing while allowing topic vocabulary).
    Title keywords are excluded since they ARE the topic.
    """
    content = soup.find(class_="article-body") or soup.find("article") or soup.find("main")
    if not content:
        return None
    # Extract title keywords to exclude — they're the topic, not stuffing (#158)
    title_el = soup.find("title")
    title_words = set()
    if title_el and title_el.string:
        title_words = set(re.findall(r'\b[a-zäöüßéèêë]{4,}\b', title_el.string.lower()))
    # Also exclude H1 words (same logic — the page's declared topic)
    h1 = soup.find("h1")
    if h1:
        title_words |= set(re.findall(r'\b[a-zäöüßéèêë]{4,}\b', h1.get_text().lower()))
    # Skip nav, code blocks
    for tag in content.find_all(["nav", "code", "pre", "script"]):
        tag.decompose()
    text = content.get_text(" ", strip=True).lower()
    words = re.findall(r'\b[a-zäöüßéèêë]{4,}\b', text)
    if len(words) < 200:
        return None
    # Count frequency, skip stopwords + title keywords
    _stops = {"this", "that", "with", "from", "have", "been", "more", "also",
              "your", "will", "they", "their", "when", "which", "about",
              "into", "than", "each", "just", "only", "very", "some",
              "eine", "einen", "einer", "einem", "sich", "wird", "sind",
              "dass", "oder", "aber", "auch", "nach", "noch", "über",
              "content", "page", "site", "wire"}
    skip = _stops | title_words
    from collections import Counter
    counts = Counter(w for w in words if w not in skip)
    total = len(words)
    for word, count in counts.most_common(3):
        ratio = count / total
        if ratio > 0.05:
            pct = round(ratio * 100, 1)
            return LintResult(
                "RULE-88", url,
                f"Keyword stuffing: '{word}' appears {count} times "
                f"({pct}% of body). Rewrite to reduce repetition.",
                "Content quality")
    return None


def rule_86_description_matches_title(soup, url, **_):
    """Description starting with title text = lazy metadata (#131).

    Title already appears in SERP. Description should add new information
    to encourage clicks, not repeat the title.
    """
    # Skip top-level pages (legal, about) — title repeating in desc is expected
    stripped = url.strip("/")
    if not stripped or "/" not in stripped:
        return None
    title = soup.find("title")
    meta = soup.find("meta", attrs={"name": "description"})
    if not title or not meta:
        return None
    title_text = title.get_text(strip=True).lower()
    desc = (meta.get("content", "") or "").strip().lower()
    if not title_text or not desc:
        return None
    # Flag if description starts with first 30 chars of title
    prefix = title_text[:30]
    if len(prefix) >= 15 and desc.startswith(prefix):
        return LintResult(
            "RULE-86", url,
            f"Description starts with title text. "
            f"Add unique information to the SERP snippet — "
            f"the title already shows in search results.",
            "Metadata")
    return None


def rule_87_outline_content(soup, url, **_):
    """Heading-only pages with no depth between headings (#132).

    Multiple headings with <40 words average between them = outline,
    not article. AI content often produces structured outlines that
    look like articles but have no substance.

    Exempt: pages with FAQPage JSON-LD schema (#161) — FAQ/reference
    pages intentionally have many headings with short answers.
    """
    # Skip pages with FAQPage schema — reference/FAQ pages are intentionally thin
    for script in soup.find_all("script", type="application/ld+json"):
        if "FAQPage" in script.get_text():
            return None
    content = soup.find("article") or soup.find("main")
    if not content:
        return None
    headings = content.find_all(["h2", "h3"])
    if len(headings) < 5:
        return None
    # Measure text between headings
    sections = []
    for i, h in enumerate(headings):
        words = 0
        sibling = h.next_sibling
        while sibling:
            if hasattr(sibling, 'name') and sibling.name in ("h2", "h3"):
                break
            if hasattr(sibling, 'get_text'):
                words += len(sibling.get_text(strip=True).split())
            sibling = sibling.next_sibling
        sections.append(words)
    avg = sum(sections) / len(sections) if sections else 0
    if avg < 40:
        return LintResult(
            "RULE-87", url,
            f"Outline-style content: {len(headings)} headings with "
            f"avg {avg:.0f} words between them. "
            f"Add depth — expand thin sections or consolidate headings.",
            "Content quality")
    return None


def rule_84_long_list_items(soup, url, **_):
    """List items >50 words = paragraphs hiding as bullets (#129).

    AI content uses bullet points as paragraph substitutes.
    Lists are for scannable items, not full sentences.
    """
    content = soup.find(class_="article-body") or soup.find("article") or soup.find("main")
    if not content:
        return None
    long_items = 0
    for li in content.find_all("li"):
        if li.find_parent(["code", "pre", "nav"]):
            continue
        if len(li.get_text(strip=True).split()) > 50:
            long_items += 1
    if long_items >= 3:
        return LintResult(
            "RULE-84", url,
            f"{long_items} list items with 50+ words. "
            f"Convert long list items to paragraphs — lists are for scannable items.",
            "Content quality")
    return None


def rule_85_no_external_links(soup, url, **_):
    """Pages with 500+ words and no external links lack source credibility (#130).

    Google's E-E-A-T framework values citations and references.
    Substantial content pages should link to authoritative external sources.
    """
    content = soup.find(class_="article-body") or soup.find("article") or soup.find("main")
    if not content:
        return None
    total_words = len(content.get_text(strip=True).split())
    if total_words < 500:
        return None
    for a in content.find_all("a", href=True):
        if a["href"].startswith(("http://", "https://")):
            return None  # Has at least one external link
    return LintResult(
        "RULE-85", url,
        f"No external links on a {total_words}-word page. "
        f"Cite authoritative sources to strengthen E-E-A-T credibility.",
        "Content quality")


def rule_83_excessive_bold(soup, url, **_):
    """Excessive bold text (>10%) = AI writing pattern (#128).

    AI tools bold entire phrases systematically. Human writers use bold
    sparingly. >10% of body in <strong>/<b> tags reads as AI-generated.
    """
    content = soup.find(class_="article-body") or soup.find("article") or soup.find("main")
    if not content:
        return None
    total_text = content.get_text(strip=True)
    total_words = len(total_text.split())
    if total_words < 100:  # Skip short pages
        return None
    bold_words = 0
    for tag in content.find_all(["strong", "b"]):
        if not tag.find_parent(["code", "pre", "nav", "header"]):
            bold_words += len(tag.get_text(strip=True).split())
    ratio = bold_words / total_words if total_words else 0
    if ratio > 0.10:
        pct = round(ratio * 100)
        return LintResult(
            "RULE-83", url,
            f"{pct}% of body text is bold ({bold_words}/{total_words} words). "
            f"Use bold sparingly for emphasis, not entire sentences.",
            "Content quality")
    return None


    # RULE-82 REMOVED (#155): title matching H1 is GOOD, not bad.
    # Evidence: Zyppy (81K titles) — matching H1 reduces Google rewrites 61%→20%.
    # SearchPilot A/B: +28% when H1 keywords ALIGN with title.
    # Google (Gary Illyes): no penalty for identical title/H1.
    # RULE-100 catches the real problem: title/H1 about DIFFERENT topics.


def rule_81_conflicting_anchors(soup, url, **_):
    """Same internal URL linked with different anchor text (#125).

    Multiple links to the same URL with different anchors sends conflicting
    signals about what the target page is about. Google uses first anchor.
    """
    content = soup.find(class_="article-body") or soup.find("article") or soup.find("main")
    if not content:
        return None
    # Collect internal link anchors by target URL
    anchors_by_url = defaultdict(set)
    for a in content.find_all("a", href=True):
        href = a["href"].split("#")[0].split("?")[0]
        if not href.startswith("/"):
            continue
        text = a.get_text(strip=True).lower()
        if text:
            anchors_by_url[href].add(text)
    # Flag URLs with 2+ different anchors
    conflicts = [(href, anchors) for href, anchors in anchors_by_url.items()
                 if len(anchors) >= 2]
    if conflicts:
        href, anchors = conflicts[0]
        return LintResult(
            "RULE-81", url,
            f"Conflicting anchors for {href}: "
            f"{', '.join(repr(a) for a in sorted(anchors)[:3])}. "
            f"Use consistent anchor text for the same target.",
            "Links")
    return None


def rule_80_duplicate_first_paragraph(soup, url, all_first_paragraphs=None, **_):
    """Identical first paragraphs = template content (#123).

    AI generators often produce similar opening sentences across pages in a topic.
    This reduces uniqueness and can be seen as thin/duplicate content by Google.
    """
    content = soup.find(class_="article-body") or soup.find("article") or soup.find("main")
    if not content:
        return None
    first_p = content.find("p")
    if not first_p:
        return None
    # Skip author byline paragraphs — same author bio on every article is not "duplicate content"
    if first_p.find_parent(class_="author-byline") or "author-desc" in (first_p.get("class") or []):
        first_p = first_p.find_next("p")
        while first_p and (first_p.find_parent(class_="author-byline") or "author-desc" in (first_p.get("class") or [])):
            first_p = first_p.find_next("p")
    if not first_p:
        return None
    text = first_p.get_text(strip=True)
    # Skip very short paragraphs — too common to be meaningful
    if len(text.split()) < 20:
        return None
    if all_first_paragraphs is not None:
        if text in all_first_paragraphs and all_first_paragraphs[text] != url:
            return LintResult(
                "RULE-80", url,
                f"Duplicate opening paragraph — also used by "
                f"{all_first_paragraphs[text]}. Rewrite the introduction.",
                "Content quality")
        all_first_paragraphs[text] = url
    return None


# RULE-79 REMOVED (#160): Paragraph length is not a ranking signal.
# John Mueller: "Word count is not a ranking factor."
# Google's own style guide recommends short paragraphs (5-6 sentences max).
# NNG research: 79% of web users scan — short paragraphs aid scanning.
# Burstiness detection fails on modern models (Pangram Labs arXiv 2402.14873).
# The rule fired on 40 of 47 Wire pages including pages following Google's guidelines.
# Evidence documented in docs/guides/seo-reference/ "Paragraph Length" section.


def rule_77_large_images(soup, url, site_dir=None, **_):
    """Images >200KB hurt page speed and Core Web Vitals (#119).

    Large images are the #1 cause of slow pages, especially on mobile.
    Only checks local images (not external CDN URLs).
    """
    if not site_dir:
        return None
    content = soup.find("article") or soup.find("main") or soup
    hits = []
    for img in content.find_all("img", src=True):
        src = img["src"]
        if src.startswith(("http://", "https://", "data:")):
            continue
        # Resolve relative path
        img_path = Path(site_dir) / src.lstrip("/")
        if img_path.exists():
            size_kb = img_path.stat().st_size / 1024
            if size_kb > 200:
                hits.append(f"{src} ({size_kb:.0f}KB)")
    if hits:
        return LintResult(
            "RULE-77", url,
            f"{len(hits)} large image(s) >200KB: {hits[0]}. "
            f"Compress images to improve page speed.",
            "Performance")
    return None


def rule_78_dead_end_page(soup, url, **_):
    """Pages with zero outbound internal links are dead-ends (#120).

    Visitors can't navigate deeper. Google's crawler stops here.
    No link equity flows to the rest of the site.
    """
    # Only article pages — skip homepage and topic indices
    parts = url.strip("/").split("/")
    if len(parts) < 2 or not parts[-1]:
        return None

    content = soup.find(class_="article-body") or soup.find("article") or soup.find("main")
    if not content:
        return None

    for a in content.find_all("a", href=True):
        href = a["href"]
        # Internal link: starts with / or is relative (no scheme)
        if href.startswith("/") or (not href.startswith(("http", "mailto:", "#", "tel:"))):
            return None  # Has at least one internal link

    return LintResult(
        "RULE-78", url,
        "Dead-end page: zero outbound internal links. "
        "Add links to related pages so visitors can navigate deeper.",
        "Links")


def rule_76_missing_date(soup, url, **_):
    """Article pages should have date metadata for E-E-A-T freshness (#117).

    Google uses date association as a ranking signal (confirmed in 2024 API leak).
    Pages without datePublished miss the freshness signal entirely.
    """
    # Only article pages (topic + slug) — skip indices, homepage, author pages
    parts = url.strip("/").split("/")
    if len(parts) < 2 or not parts[-1]:
        return None
    # Only Article/NewsArticle need datePublished. Other schema types use
    # different date properties or none at all (schema.org spec):
    # - ProfilePage: dateCreated/dateModified
    # - CollectionPage: no date properties
    # - WebSite: no date properties
    # - Organization: foundingDate (different concept)
    import json
    _NEEDS_DATE = {"Article", "NewsArticle"}
    for script in soup.find_all("script", type="application/ld+json"):
        data = json.loads(script.string or "{}")
        schema_type = data.get("@type", "")
        if schema_type and schema_type not in _NEEDS_DATE:
            return None  # This page uses a schema that doesn't need datePublished

    # Check for <time> element or JSON-LD datePublished
    if soup.find("time", attrs={"datetime": True}):
        return None
    for script in soup.find_all("script", type="application/ld+json"):
        try:
            import json
            data = json.loads(script.string or "")
            if data.get("datePublished"):
                return None
        except (json.JSONDecodeError, TypeError):
            pass

    return LintResult(
        "RULE-76", url,
        "No date metadata found. Add 'created:' to frontmatter for "
        "E-E-A-T freshness signals. Google uses dates for ranking.",
        "Metadata")


def rule_75_click_depth(url, depth_map=None, **_):
    """Pages >3 clicks from homepage lose crawl priority (#115).

    Google's crawl budget and link equity decrease with depth.
    John Mueller: 'Crawl depth matters more than directory depth.'
    """
    if not depth_map or url not in depth_map:
        return None
    depth = depth_map[url]
    if depth > 3:
        return LintResult(
            "RULE-75", url,
            f"Click depth {depth} (max recommended: 3). "
            f"Add an internal link from a shallower page.",
            "Links")
    return None


def rule_74_first_image_lazy(soup, url, **_):
    """First image must not use loading=lazy — kills LCP (#113).

    loading="lazy" on the first visible image delays Largest Contentful Paint.
    Google's Core Web Vitals threshold is 2.5s. Lazy hero images add 200-500ms.
    """
    content = soup.find("article") or soup.find("main")
    if not content:
        return None
    first_img = content.find("img")
    if not first_img:
        return None
    if first_img.get("loading") == "lazy":
        return LintResult(
            "RULE-74", url,
            f"First image has loading=\"lazy\" — delays LCP. "
            f"Remove the attribute or set loading=\"eager\".",
            "Performance")
    return None


def rule_73_duplicate_description(soup, url, all_descriptions=None, **_):
    """No duplicate meta descriptions across pages (#112).

    Two pages with identical descriptions compete in SERPs. Google may
    rewrite the snippet, but the signal confusion hurts both.
    """
    meta = soup.find("meta", attrs={"name": "description"})
    if not meta:
        return None
    desc = meta.get("content", "").strip()
    if not desc:
        return None
    if all_descriptions is not None:
        if desc in all_descriptions and all_descriptions[desc] != url:
            return LintResult(
                "RULE-73", url,
                f"Duplicate meta description — also used by "
                f"{all_descriptions[desc]}. Differentiate.",
                "Metadata")
        all_descriptions[desc] = url
    return None


def rule_103_root_index_layout(soup, url, **_):
    """Root index page must have explicit layout (#164).

    The root index (/) is a marketing page. Without layout: landing or
    layout: home, it gets treated as a content page and fails content rules.
    """
    if url != "/":
        return None
    # Only check Wire-generated pages (have div.layout wrapper)
    layout_div = soup.find(class_="layout")
    if not layout_div:
        return None  # not a Wire-generated page
    # Wire adds layout-{name} class to a div.layout element
    if soup.find(class_="layout-landing") or soup.find(class_="layout-article"):
        return None
    # Check for home template (rendered by home.html)
    if soup.find(class_="layout-home") or soup.find(class_="home"):
        return None
    return LintResult(
        "RULE-103", url,
        "Root index page has no layout. Add layout: landing or layout: home "
        "to frontmatter. Without it, your homepage is treated as a plain "
        "content page.",
        "Page structure")


def rule_104_landing_components(soup, url, **_):
    """Landing pages should use Wire components (#163).

    A layout: landing page without shortcode components (:::cta, :::cards,
    :::split, etc.) looks empty and unprofessional. Either use components
    or change to layout: page.
    """
    if not soup.find(class_="layout-landing"):
        return None
    # Exempt FAQPage schema — reference/protocol docs don't need marketing components
    for script in soup.find_all("script", type="application/ld+json"):
        if "FAQPage" in script.get_text():
            return None
    content = soup.find("main") or soup.find("article")
    if not content:
        return None
    # Check for Wire component classes
    component_classes = {
        "cta-block", "card-grid", "split", "banner-block",
        "stats-bar", "progress-block", "tabs-block", "faq-block",
        "pricing-grid", "logo-cloud", "section-light", "section-default",
        "testimonial-block", "alert-block", "badges-block",
    }
    for cls in component_classes:
        if content.find(class_=cls):
            return None
    # Check for <hr> which creates landing sections
    if content.find("hr"):
        return None
    return LintResult(
        "RULE-104", url,
        "Landing page has no Wire components. Use :::cta, :::cards, "
        ":::split, :::stats, or other shortcodes to create a professional "
        "layout. Or change to layout: page if this is a content page.",
        "Page structure")


def rule_105_card_external_link(soup, url, **_):
    """Card links must be internal — cards are site navigation, not outbound links.

    External URLs on cards send visitors away from the site. Use regular
    inline links for external references.
    """
    for card in soup.find_all("a", class_="feature-card"):
        href = card.get("href", "")
        if href.startswith("http://") or href.startswith("https://"):
            return LintResult(
                "RULE-105", url,
                f"Card links to external URL: {href}. "
                f"Cards are navigation elements — use internal links only.",
                "Content")
    return None


def rule_106_card_link_consistency(soup, url, **_):
    """All cards in a block must be consistently linked or unlinked.

    Mixed linked/unlinked cards look broken — some are clickable, others aren't.
    Either all cards link somewhere or none do.
    """
    for grid in soup.find_all(class_="feature-grid"):
        a_cards = grid.find_all("a", class_="feature-card")
        div_cards = grid.find_all("div", class_="feature-card")
        if a_cards and div_cards:
            return LintResult(
                "RULE-106", url,
                f"Card block has {len(a_cards)} linked and {len(div_cards)} "
                f"unlinked cards. Add links to all cards or remove all links.",
                "Content")
    return None


# ============================================================================
# Page-level rules (applied per page)
# ============================================================================

PAGE_RULES = [
    rule_01_h1_present,
    rule_02_single_h1,
    rule_03_heading_hierarchy,
    rule_04_target_query,
    rule_05_title,
    rule_06_single_title,
    rule_07_meta_description,
    rule_08_word_count,
    rule_09_og_tags,
    rule_10_viewport,
    rule_11_charset,
    rule_12_canonical,
    rule_13_single_canonical,
    rule_16_duplicate_h1,
    rule_22_trailing_slash,
    rule_34_empty_anchor,
    rule_37_mixed_content,
    rule_40_img_alt,
    rule_42_img_dimensions,
    rule_43_hreflang_valid,
    rule_44_hreflang_xdefault,
    rule_45_jsonld_present,
    rule_46_jsonld_valid,
    rule_47_jsonld_type,
    rule_50_nofollow_internal,
    rule_51_no_video_iframes,
    rule_52_no_em_dashes,
    rule_53_discovery_step_ids,
    rule_55_jsonld_recommended_fields,
    rule_63_stats_bar_count,
    rule_64_custom_hero_section,
    rule_65_og_image,
    rule_66_form_without_handler,
    rule_67_numbered_headings,
    rule_68_progress_bar_values,
    rule_69_cross_language_links,
    rule_70_absolute_self_links,
    rule_71_article_link_minimum,
    rule_72_generic_anchor_text,
    rule_73_duplicate_description,
    rule_74_first_image_lazy,
    rule_75_click_depth,
    rule_76_missing_date,
    rule_78_dead_end_page,
    # rule_79 removed (#160) — paragraph length is not a ranking signal. See docs/guides/seo-reference/
    rule_80_duplicate_first_paragraph,
    rule_81_conflicting_anchors,
    # rule_82 removed (#155) — title=H1 is good per evidence
    rule_83_excessive_bold,
    rule_84_long_list_items,
    rule_85_no_external_links,
    rule_86_description_matches_title,
    rule_87_outline_content,
    rule_88_keyword_stuffing,  # re-enabled: title words excluded, threshold 5% (#158)
    rule_89_no_subheadings,
    # rule_90 removed (#159) — zero evidence across 6 dimensions
    rule_91_deep_heading_nesting,
    rule_92_weak_integration,
    rule_93_table_no_thead,
    rule_94_long_description,
    rule_95_long_title,
    rule_96_no_semantic_html,
    rule_97_no_prose,
    # rule_98 removed (#159) — mailto not crawled, nofollow meaningless
    rule_99_short_description,
    rule_100_title_h1_misaligned,
    rule_101_tel_format,
    rule_102_pdf_link,
    rule_103_root_index_layout,
    rule_104_landing_components,
    rule_105_card_external_link,
    rule_106_card_link_consistency,
    rule_36_redirect_links,
]

# Rules that need the full site_dir for file checks
SITE_AWARE_PAGE_RULES = [
    rule_15_canonical_in_sitemap,
    rule_33_internal_links,
    rule_41_broken_images,
    rule_48_jsonld_urls,
    rule_77_large_images,
]

# Site-level rules (applied once)
SITE_RULES = [
    rule_23_sitemap_exists,
    rule_25_noindex_in_sitemap,
    rule_26_robots_blocked_in_sitemap,
    rule_28_robots_exists,
    rule_29_robots_css_js,
    rule_30_robots_sitemap,
    rule_31_robots_block_all,
    rule_32_legal_links,
]

# URL-only rules (no soup needed)
URL_RULES = [
    rule_17_lowercase_url,
    rule_18_url_characters,
    rule_19_no_underscores,
    rule_20_url_length,
    rule_21_no_query_params,
]


def _build_inbound_links(pages_data: list[dict]) -> dict:
    """Count inbound internal links for each page URL."""
    inbound = defaultdict(int)
    for page_data in pages_data:
        soup = page_data["soup"]
        page_url = page_data["url"]
        for a in soup.find_all("a", href=True):
            href = a["href"]
            if href.startswith(("http", "#", "javascript:", "mailto:")):
                continue
            # Resolve relative links against this page's URL
            resolved = _resolve_href(page_url, href)
            # Normalize
            resolved = resolved.rstrip("/") + "/"
            if not resolved.startswith("/"):
                resolved = "/" + resolved
            inbound[resolved] += 1
    return dict(inbound)


def _build_hreflang_map(pages_data: list[dict]) -> dict:
    """Build map of canonical URL → {lang: href} for hreflang reciprocal checks."""
    hreflang_map = {}
    for page_data in pages_data:
        soup = page_data["soup"]
        hreflangs = soup.find_all("link", attrs={"rel": "alternate", "hreflang": True})
        if not hreflangs:
            continue
        canonical_tag = soup.find("link", attrs={"rel": "canonical"})
        if not canonical_tag:
            continue
        canonical = canonical_tag.get("href", "")
        if not canonical:
            continue
        langs = {}
        for link in hreflangs:
            lang = link.get("hreflang", "")
            href = link.get("href", "")
            if lang and href:
                langs[lang] = href
        hreflang_map[canonical] = langs
    return hreflang_map


def _build_redirect_map(all_pages_data: list[dict]) -> dict:
    """Build map of redirect URL → target URL from meta-refresh pages.

    Scans pages that have <meta http-equiv="refresh"> and extracts
    the target URL. Called once per lint run, result passed to rule_36.
    """
    redirect_map = {}
    for page_data in all_pages_data:
        soup = page_data["soup"]
        meta = soup.find("meta", attrs={"http-equiv": "refresh"})
        if not meta:
            continue
        meta_content = meta.get("content", "")
        target = ""
        if "url=" in meta_content:
            raw = meta_content.split("url=", 1)[1].strip()
            # Strip quotes and trailing semicolons
            target = raw.strip("'\"").rstrip(";").strip()
        redirect_map[page_data["url"]] = target
    return redirect_map


def lint_page(html_path: Path, site_dir: Path, url: str,
              all_titles: dict, all_h1s: dict,
              inbound_links: dict = None,
              hreflang_map: dict = None,
              redirect_map: dict = None,
              enabled_rules: set = None,
              lang_prefixes: set = None,
              site_url: str = None,
              all_descriptions: dict = None,
              depth_map: dict = None,
              all_first_paragraphs: dict = None) -> list[LintResult]:
    """Lint a single rendered HTML page.

    Returns list of LintResult failures (empty = page passes).
    """
    raw_html = html_path.read_text(encoding="utf-8")
    soup = BeautifulSoup(raw_html, "html.parser")

    results = []
    ctx = {
        "soup": soup,
        "url": url,
        "raw_html": raw_html,
        "site_dir": str(site_dir),
        "all_titles": all_titles,
        "all_h1s": all_h1s,
        "inbound_links": inbound_links,
        "hreflang_map": hreflang_map,
        "redirect_map": redirect_map,
        "lang_prefixes": lang_prefixes,
        "site_url": site_url,
        "all_descriptions": all_descriptions,
        "depth_map": depth_map,
        "all_first_paragraphs": all_first_paragraphs,
    }

    # Per-page lint suppression via _overruled frontmatter (#196)
    overruled = set()
    overruled_meta = soup.find("meta", attrs={"name": "wire-overruled"})
    if overruled_meta and overruled_meta.get("content"):
        overruled = {r.strip() for r in overruled_meta["content"].split(",")}
        # Cannot suppress errors — warn about the attempt
        blocked = overruled & LINT_ERRORS
        if blocked:
            results.append(LintResult(
                "RULE-00", url,
                f"_overruled cannot suppress error rules: "
                f"{', '.join(sorted(blocked))}. Fix these instead.",
                "Overruled"))
            overruled -= blocked  # Don't suppress errors

    # Page rules
    for rule_fn in PAGE_RULES:
        rule_id = rule_fn.__name__.split("_")[1].upper()
        full_rule_id = f"RULE-{rule_id}"
        if enabled_rules and full_rule_id not in enabled_rules:
            continue
        result = rule_fn(**ctx)
        if result:
            results.append(result)

    # Site-aware page rules
    for rule_fn in SITE_AWARE_PAGE_RULES:
        rule_id = rule_fn.__name__.split("_")[1].upper()
        full_rule_id = f"RULE-{rule_id}"
        if enabled_rules and full_rule_id not in enabled_rules:
            continue
        result = rule_fn(**ctx)
        if result:
            results.append(result)

    # URL rules
    for rule_fn in URL_RULES:
        rule_id = rule_fn.__name__.split("_")[1].upper()
        full_rule_id = f"RULE-{rule_id}"
        if enabled_rules and full_rule_id not in enabled_rules:
            continue
        result = rule_fn(url=url)
        if result:
            results.append(result)

    # Orphan page check
    if not enabled_rules or "RULE-35" in enabled_rules:
        result = rule_35_orphan_pages(url=url, inbound_links=inbound_links)
        if result:
            results.append(result)

    # Noindex with inbound links check
    if not enabled_rules or "RULE-49" in enabled_rules:
        result = rule_49_noindex_with_links(
            soup=soup, url=url, inbound_links=inbound_links)
        if result:
            results.append(result)

    # Hreflang reciprocal check
    if not enabled_rules or "RULE-45" in enabled_rules:
        result = rule_45_hreflang_reciprocal(
            soup=soup, url=url, hreflang_map=hreflang_map)
        if result:
            results.append(result)

    # Filter overruled warnings — keep them but mark as overruled
    if overruled:
        filtered = []
        for r in results:
            if r.rule_id in overruled and r.severity != "error":
                r.overruled = True
            filtered.append(r)
        results = filtered

    return results


def lint_site(site_dir: str | Path,
              enabled_rules: set = None,
              base_path: str = "",
              site_url: str = None) -> list[LintResult]:
    """Lint all HTML pages in a built site.

    Args:
        site_dir: Path to built site output (e.g., site/).
        enabled_rules: Set of rule IDs to run (None = all rules).
        base_path: Deprecated, ignored. Kept for backward compatibility.
        site_url: Site URL (e.g., https://example.com) for self-link detection.

    Returns:
        List of all LintResult failures across the site.
    """
    site_dir = Path(site_dir)
    results = []

    # Site-level rules
    for rule_fn in SITE_RULES:
        rule_id = rule_fn.__name__.split("_")[1].upper()
        full_rule_id = f"RULE-{rule_id}"
        if enabled_rules and full_rule_id not in enabled_rules:
            continue
        result = rule_fn(site_dir=str(site_dir))
        if result:
            results.append(result)

    # Collect all HTML pages
    html_files = sorted(site_dir.rglob("*.html"))
    if not html_files:
        logger.warning(f"No HTML files found in {site_dir}")
        return results

    # Build page data for cross-page checks
    pages_data = []
    for html_file in html_files:
        rel = html_file.relative_to(site_dir)
        rel_str = str(rel).replace("\\", "/")
        if rel_str == "index.html":
            url = "/"
        elif rel_str.endswith("/index.html"):
            url = "/" + rel_str[:-len("index.html")]
        else:
            url = "/" + rel_str
        pages_data.append({
            "path": html_file,
            "url": url,
            "soup": BeautifulSoup(
                html_file.read_text(encoding="utf-8"), "html.parser"),
        })

    # Build redirect map BEFORE filtering — rule_36 needs this
    redirect_map = _build_redirect_map(pages_data)

    # Skip redirect pages (meta http-equiv="refresh") — they're intentionally minimal
    # Also skip 410 Gone stub pages — they have no real content to lint
    pages_data = [p for p in pages_data
                  if not p["soup"].find("meta", attrs={"http-equiv": "refresh"})
                  and not (p["soup"].title and p["soup"].title.string
                           and "410" in p["soup"].title.string)]

    # Skip utility pages (404, search) — auto-generated, not content pages
    _UTILITY_SUFFIXES = {"/404.html", "/search/", "/news/"}
    pages_data = [p for p in pages_data
                  if not any(p["url"].endswith(s) for s in _UTILITY_SUFFIXES)
                  and not p["url"].rstrip("/").endswith("/404.html")]

    # Build inbound link map
    inbound_links = _build_inbound_links(pages_data)

    # Build hreflang map for reciprocal checks
    hreflang_map = _build_hreflang_map(pages_data)

    # Detect language prefixes for cross-language link checks
    lang_prefixes = set()
    for page_data in pages_data:
        parts = page_data["url"].strip("/").split("/")
        if parts and len(parts[0]) == 2 and parts[0].isalpha():
            lang_prefixes.add(parts[0])

    # Compute click depth via BFS from homepage (#115)
    outbound = defaultdict(set)
    for p in pages_data:
        soup = p["soup"]
        for a in soup.find_all("a", href=True):
            href = a["href"].split("#")[0].split("?")[0]
            if href.startswith("/"):
                norm = href.rstrip("/") + "/" if href != "/" else "/"
                outbound[p["url"]].add(norm)
    depth_map = {"/": 0}
    queue = ["/"]
    while queue:
        current = queue.pop(0)
        for target in outbound.get(current, []):
            if target not in depth_map:
                depth_map[target] = depth_map[current] + 1
                queue.append(target)

    # Cross-page dedup trackers
    all_titles = {}
    all_h1s = {}
    all_descriptions = {}
    all_first_paragraphs = {}

    # Lint each page
    for page_data in pages_data:
        page_results = lint_page(
            page_data["path"], site_dir, page_data["url"],
            all_titles, all_h1s, inbound_links, hreflang_map,
            redirect_map, enabled_rules, lang_prefixes,
            site_url=site_url, all_descriptions=all_descriptions,
            depth_map=depth_map, all_first_paragraphs=all_first_paragraphs)
        results.extend(page_results)

    return results


def format_results(results: list[LintResult]) -> str:
    """Format lint results for terminal output."""
    if not results:
        return "LINT: All checks passed."

    active = [r for r in results if not getattr(r, "overruled", False)]
    overruled_list = [r for r in results if getattr(r, "overruled", False)]
    errors = [r for r in active if r.severity == "error"]
    warnings = [r for r in active if r.severity == "warning"]

    summary = f"LINT: {len(errors)} error(s), {len(warnings)} warning(s)"
    if overruled_list:
        summary += f", {len(overruled_list)} overruled"
    lines = [summary + ".\n"]

    # Group by group (active results only)
    by_group = defaultdict(list)
    for r in active:
        by_group[r.group or "Other"].append(r)

    for group in sorted(by_group):
        lines.append(f"  {group}:")
        for r in by_group[group]:
            tag = "ERROR" if r.severity == "error" else "WARN"
            rule_anchor = r.rule_id.lower().replace("-", "-")
            lines.append(f"    [{r.rule_id}] [{tag}] {r.message}")
            lines.append(f"      URL: {r.url}")
            lines.append(
                f"      Docs: /guides/seo-reference/#{rule_anchor}")
        lines.append("")

    if overruled_list:
        lines.append("  Overruled by customer:")
        for r in overruled_list:
            lines.append(f"    {r.rule_id} on {r.url} (frontmatter)")
        lines.append("")

    # Suggest _overruled for warnings (#232)
    if warnings and not overruled_list:
        lines.append(
            "  Hint: add _overruled: [RULE-XX] to a page's frontmatter "
            "to accept a warning on that page.")
    elif warnings:
        lines.append(
            "  Hint: _overruled: [RULE-XX] in frontmatter accepts "
            "a warning per-page.")

    return "\n".join(lines)


def main():
    """CLI entry point."""
    import argparse

    parser = argparse.ArgumentParser(
        description="wire.lint — build-time HTML content linter")
    parser.add_argument("--site", required=True,
                        help="Path to built site directory (e.g., site/)")
    parser.add_argument("--rules", default=None,
                        help="Comma-separated rule IDs to run (e.g., RULE-01,RULE-05)")
    parser.add_argument("-v", "--verbose", action="store_true")

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(message)s",
    )

    enabled = set(args.rules.split(",")) if args.rules else None
    results = lint_site(args.site, enabled)
    print(format_results(results))

    if results:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
