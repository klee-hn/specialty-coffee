#!/usr/bin/env python3
"""
wire.build_dev — Dev server with file watching for automatic rebuilds.

Runs a full build on startup, then watches docs/ and templates/ for changes.
On file change, performs a dirty rebuild of the changed page only.

Usage:
    python -m wire.build_dev --site /path/to/site
    python -m wire.build_dev --site /path/to/site --port 3000
"""

import logging
import threading
import time
from datetime import datetime
from pathlib import Path

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

from wire.build import build, load_config

logger = logging.getLogger(__name__)

# Minimum interval between rebuilds (seconds)
DEBOUNCE_SECONDS = 0.5


class RebuildHandler(FileSystemEventHandler):
    """Watches for file changes and triggers dirty rebuilds."""

    def __init__(self, site_dir: Path, config: dict):
        super().__init__()
        self.site_dir = site_dir
        self.config = config
        self._last_rebuild = 0.0
        self._lock = threading.Lock()

    def on_any_event(self, event):
        # Only react to file modifications and creations
        if event.is_directory:
            return
        if event.event_type not in ("modified", "created", "moved"):
            return

        # Determine the relevant file path
        src = event.src_path
        if event.event_type == "moved":
            src = event.dest_path

        path = Path(src)

        # Only rebuild for markdown, HTML (templates), CSS, JS changes
        if path.suffix not in (".md", ".html", ".css", ".js", ".yml", ".yaml"):
            return

        # Debounce: skip if too soon after last rebuild
        now = time.monotonic()
        with self._lock:
            if now - self._last_rebuild < DEBOUNCE_SECONDS:
                return
            self._last_rebuild = now

        timestamp = datetime.now().strftime("%H:%M:%S")
        rel_path = path
        try:
            rel_path = path.relative_to(self.site_dir)
        except ValueError:
            pass

        logger.info(f"[{timestamp}] Changed: {rel_path}")

        try:
            start = time.monotonic()
            result = build(self.site_dir, dirty=True, run_lint=False)
            elapsed = time.monotonic() - start
            count = result["page_count"]
            if result["errors"]:
                for err in result["errors"]:
                    logger.error(f"[{timestamp}] Build error: {err}")
            else:
                logger.info(
                    f"[{timestamp}] Rebuilt {count} page(s) in {elapsed:.2f}s"
                )
        except Exception as e:
            logger.error(f"[{timestamp}] Build failed: {e}")


def dev_serve(site_dir: str | Path, port: int = 8000):
    """Start dev server with file watching.

    1. Full build on startup
    2. Start HTTP server on port (respects base_path from site_url)
    3. Watch docs/ and templates/ for changes
    4. Dirty rebuild on change
    """
    import functools
    import http.server

    site_dir = Path(site_dir)
    config = load_config(site_dir)
    docs_dir = config["docs_dir"]
    templates_dir = config["templates_dir"]
    output_dir = config["output_dir"]

    # Full build on startup
    logger.info("Running full build...")
    result = build(site_dir, dirty=False, run_lint=False)
    if result["errors"]:
        logger.error(f"Initial build had {len(result['errors'])} error(s).")
        for err in result["errors"]:
            logger.error(f"  {err}")
        # Continue anyway — serve what we can

    # Set up file watcher
    handler = RebuildHandler(site_dir, config)
    observer = Observer()

    watch_dirs = []
    if docs_dir.exists():
        observer.schedule(handler, str(docs_dir), recursive=True)
        watch_dirs.append(str(docs_dir.relative_to(site_dir)))
    if templates_dir.exists():
        observer.schedule(handler, str(templates_dir), recursive=True)
        watch_dirs.append(str(templates_dir.relative_to(site_dir)))

    observer.start()

    # Start HTTP server — relative paths just work, no URL rewriting needed
    http_handler = functools.partial(
        http.server.SimpleHTTPRequestHandler,
        directory=str(output_dir),
    )

    server = http.server.HTTPServer(("", port), http_handler)
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()

    serve_url = f"http://localhost:{port}/"
    print(f"Dev server: {serve_url}")
    print(f"Watching: {', '.join(watch_dirs)}")
    print("Press Ctrl+C to stop.\n")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping...")
    finally:
        observer.stop()
        observer.join()
        server.shutdown()


def main():
    """CLI entry point."""
    import argparse

    parser = argparse.ArgumentParser(
        description="wire.build_dev — dev server with file watching")
    parser.add_argument("--site", required=True,
                        help="Path to site directory (containing wire.yml)")
    parser.add_argument("--port", type=int, default=8000,
                        help="Dev server port (default: 8000)")
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="Verbose output")

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(message)s",
    )

    dev_serve(args.site, args.port)


if __name__ == "__main__":
    main()
