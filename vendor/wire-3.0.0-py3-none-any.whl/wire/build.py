#!/usr/bin/env python3
"""
wire.build — Static site generator.

Replaces MkDocs with a single-pass pipeline:
  markdown → frontmatter parse → mistune render → Jinja2 template → HTML

Usage:
    python -m wire.build --site /path/to/site
    python -m wire.build --site /path/to/site --dirty
"""

import html as html_module
import logging
import re
import shutil
import struct
import subprocess
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

import frontmatter as fm
import jinja2
import mistune
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

# Files and directories excluded from build
EXCLUDE_PATTERNS = [
    r'.*/\d{4}-\d{2}-\d{2}\.md$',          # pending news files
    r'(^|.*/)_[^/]*\.md$',                    # underscore files (_style.md, etc.)
    r'.*/comparisons/.*',                    # auto-generated comparisons (optional)
    r'.*\.steps\.md$',                       # discovery step files
    r'(^|.*/)steps\.md$',                    # discovery step files (index variant)
]


def load_config(site_dir: Path) -> dict:
    """Load wire.yml config from site directory.

    Returns:
        Config dict with keys: site_name, site_url, description,
        docs_dir, templates_dir, site_dir, nav, theme, exclude.
    """
    config_path = site_dir / "wire.yml"
    if not config_path.exists():
        raise FileNotFoundError(
            f"No wire.yml found in {site_dir}. "
            f"Create one with at least site_name and docs_dir."
        )

    # Simple YAML-like parser for wire.yml
    # We avoid adding PyYAML as dependency — wire.yml is simple enough
    import yaml  # mkdocs already requires it, so it's available
    with open(config_path, encoding="utf-8") as f:
        raw = yaml.safe_load(f)

    # Required fields — fail loud, no silent defaults
    missing = []
    if "site_name" not in raw:
        missing.append("site_name")
    if "site_url" not in raw:
        missing.append("site_url")
    if "lang" not in raw and not raw.get("languages"):
        missing.append("lang (or languages)")
    if "nav" not in raw:
        missing.append("nav")
    if missing:
        raise ValueError(
            f"wire.yml missing required field(s): {', '.join(missing)}. "
            f"These are strategic decisions - Wire does not guess."
        )

    # Derive base_path from site_url for subdirectory deployments
    from urllib.parse import urlparse
    _parsed_url = urlparse(raw["site_url"])
    _base_path = _parsed_url.path.rstrip("/")  # e.g. "/helm-nagel-com" or ""

    config = {
        "site_name": raw["site_name"],
        "site_url": raw["site_url"],
        "_base_path": _base_path,
        "description": raw.get("description", ""),
        "lang": raw.get("lang", ""),
        "docs_dir": site_dir / raw.get("docs_dir", "docs"),
        "templates_dir": site_dir / raw.get("templates_dir", "templates"),
        "output_dir": site_dir / raw.get("output_dir", "site"),
        "nav": raw.get("nav"),
        "theme": raw.get("theme", {}),
        "exclude": raw.get("exclude", []),
        "extra": raw.get("extra", {}),
        "footer": raw.get("footer", {}),
        "search": raw.get("search", True),
        "exclude_gsc_data_for_path": raw.get("exclude_gsc_data_for_path", []),
        "extra_css": raw.get("extra_css", []),
        "noindex": raw.get("noindex", False),
    }

    # Parse header config (offerings bar, utilities, CTA)
    raw_header = raw.get("header", {})
    if raw_header and isinstance(raw_header, dict):
        config["header"] = raw_header
    else:
        config["header"] = {}

    # Detect language codes early — needed for nested CTA/label validation
    raw_langs = raw.get("languages")
    _lang_codes = [lg["code"] for lg in raw_langs] if raw_langs and isinstance(raw_langs, list) else []

    # Validate sidebar_cta — required for article layout
    wire_extra = raw.get("extra", {}).get("wire", {})
    sidebar_cta = wire_extra.get("sidebar_cta")
    if not sidebar_cta or not isinstance(sidebar_cta, dict):
        raise ValueError(
            "wire.yml missing required 'extra.wire.sidebar_cta'. "
            "Article pages need a sidebar CTA card. Add:\n"
            "extra:\n"
            "  wire:\n"
            "    sidebar_cta:\n"
            "      title: \"Your CTA title\"\n"
            "      description: \"Short description\"\n"
            "      link: /your-page/\n"
            "      link_text: \"Learn more\""
        )
    _required_cta_keys = {"title", "description", "link", "link_text"}
    # For multi-language: validate each language's config
    if _lang_codes and any(k in _lang_codes for k in sidebar_cta):
        for code in _lang_codes:
            lang_cta = sidebar_cta.get(code, {})
            if not lang_cta:
                raise ValueError(
                    f"wire.yml extra.wire.sidebar_cta missing config for "
                    f"language '{code}'. Multi-language sites need per-language "
                    f"sidebar CTA.")
            missing = _required_cta_keys - set(lang_cta.keys())
            if missing:
                raise ValueError(
                    f"wire.yml extra.wire.sidebar_cta[{code}] missing required "
                    f"keys: {', '.join(sorted(missing))}")
    else:
        missing = _required_cta_keys - set(sidebar_cta.keys())
        if missing:
            example_values = {
                "title": '"Your CTA title"',
                "description": '"One sentence explaining your offer"',
                "link": "/your-page/",
                "link_text": '"Learn more"',
            }
            fix_lines = "\n".join(
                f"      {k}: {example_values[k]}" for k in sorted(missing)
            )
            raise ValueError(
                f"wire.yml extra.wire.sidebar_cta missing required keys: "
                f"{', '.join(sorted(missing))}\n"
                f"Add to your wire.yml under extra.wire.sidebar_cta:\n{fix_lines}"
            )

    # Validate article_cta — required bottom CTA banner on every article
    article_cta = wire_extra.get("article_cta")
    if not article_cta or not isinstance(article_cta, dict):
        raise ValueError(
            "wire.yml missing required 'extra.wire.article_cta'. "
            "Every article needs a bottom CTA banner. Add:\n"
            "extra:\n"
            "  wire:\n"
            "    article_cta:\n"
            "      title: \"Ready to get started?\"\n"
            "      description: \"Book a free consultation.\"\n"
            "      link: /contact/\n"
            "      link_text: \"Get in touch\""
        )
    _required_article_cta_keys = {"title", "description", "link", "link_text"}
    # For multi-language: validate each language's config
    if _lang_codes and any(k in _lang_codes for k in article_cta):
        for code in _lang_codes:
            lang_cta = article_cta.get(code, {})
            if not lang_cta:
                raise ValueError(
                    f"wire.yml extra.wire.article_cta missing config for "
                    f"language '{code}'.")
            empty_or_missing = {
                k for k in _required_article_cta_keys
                if not lang_cta.get(k)
            }
            if empty_or_missing:
                raise ValueError(
                    f"wire.yml extra.wire.article_cta[{code}] missing or empty "
                    f"required keys: {', '.join(sorted(empty_or_missing))}")
    else:
        # Check for missing OR empty values
        empty_or_missing = {
            k for k in _required_article_cta_keys
            if not article_cta.get(k)
        }
        if empty_or_missing:
            raise ValueError(
                f"wire.yml extra.wire.article_cta missing or empty required keys: "
                f"{', '.join(sorted(empty_or_missing))}"
            )

    # Logo and favicon — required, fail loud
    if "logo" not in raw:
        raise ValueError(
            "wire.yml missing required 'logo'. Add one of:\n"
            "  logo: assets/logo.svg   # path to logo image\n"
            "  logo: false             # text-only mode (show site_name)")
    if "favicon" not in raw:
        raise ValueError(
            "wire.yml missing required 'favicon'. Add one of:\n"
            "  favicon: assets/favicon.svg   # path to favicon\n"
            "  favicon: false                # no favicon")

    logo = raw["logo"]
    favicon = raw["favicon"]
    if logo and logo is not True:
        logo_path = config["docs_dir"] / logo
        if not logo_path.exists():
            raise FileNotFoundError(
                f"logo file not found: {logo}. "
                f"Expected at: {logo_path}")
        config["logo"] = str(logo)
    else:
        config["logo"] = False

    if favicon and favicon is not True:
        favicon_path = config["docs_dir"] / favicon
        if not favicon_path.exists():
            raise FileNotFoundError(
                f"favicon file not found: {favicon}. "
                f"Expected at: {favicon_path}")
        config["favicon"] = str(favicon)
    else:
        config["favicon"] = False

    # og_image — must be a local file path, not a full URL (#217)
    # Wire auto-generates the full URL via site_url + path for JSON-LD/OG tags.
    theme = raw.get("theme", {})
    if isinstance(theme, dict) and theme.get("og_image"):
        og_val = theme["og_image"]
        if og_val.startswith(("http://", "https://")):
            raise ValueError(
                f"wire.yml theme.og_image must be a local file path, not a URL.\n"
                f"  Wrong:  og_image: {og_val}\n"
                f"  Right:  og_image: assets/images/social.png\n"
                f"Wire auto-generates the full URL from site_url.")
        og_path = config["docs_dir"] / og_val
        if not og_path.exists():
            raise FileNotFoundError(
                f"og_image file not found: {og_val}. "
                f"Expected at: {og_path}")

    # BotPoison key — must be public key (pk_), not secret key (sk_)
    bp_key = wire_extra.get("form_botpoison", "")
    if bp_key and isinstance(bp_key, str) and bp_key.startswith("sk_"):
        raise ValueError(
            "wire.yml extra.wire.form_botpoison starts with 'sk_' (secret key). "
            "Use your public key (pk_...) instead. "
            "Secret keys must never be exposed client-side."
        )

    # Detect language directories masquerading as topics
    # Common ISO 639-1 codes that are unlikely to be real topic names
    _LANG_CODES = {
        "ar", "bg", "bn", "cs", "da", "de", "el", "en", "es", "et",
        "fa", "fi", "fr", "he", "hi", "hu", "id", "ja", "ko", "lt",
        "lv", "ms", "nl", "no", "pl", "pt", "ro", "ru", "sk", "sl",
        "sr", "sv", "th", "tr", "uk", "vi", "zh",
    }
    if not raw.get("languages"):
        docs_dir = config["docs_dir"]
        if docs_dir.is_dir():
            lang_dirs = sorted(
                d.name for d in docs_dir.iterdir()
                if d.is_dir() and d.name in _LANG_CODES
                and (d / "index.md").exists()
            )
            if len(lang_dirs) >= 2:
                codes = ", ".join(lang_dirs)
                example = "\n".join(
                    f"  - code: {c}\n    name: {c}\n    docs_dir: "
                    f"{raw.get('docs_dir', 'docs')}/{c}"
                    for c in lang_dirs
                )
                raise ValueError(
                    f"docs/ contains directories that look like language "
                    f"codes: {codes}\n"
                    f"This creates broken nav tabs instead of a proper "
                    f"multi-language site.\n"
                    f"Configure languages in wire.yml:\n\n"
                    f"languages:\n{example}\n\n"
                    f"See: docs/guides/multi-language/"
                )

    # Parse deploy config
    raw_deploy = raw.get("deploy", {})
    if raw_deploy and isinstance(raw_deploy, dict):
        config["deploy"] = raw_deploy

    # Parse multi-language config
    raw_langs = raw.get("languages")
    if raw_langs and isinstance(raw_langs, list):
        languages = []
        for lang in raw_langs:
            languages.append({
                "code": lang["code"],
                "name": lang.get("name", lang["code"]),
                "docs_dir": site_dir / lang["docs_dir"],
                "default": lang.get("default", False),
            })
        config["languages"] = languages

    return config


class Page:
    """A single page in the site."""

    __slots__ = ("source", "meta", "raw_body", "html", "url", "topic",
                 "slug", "reading_time", "word_count")

    def __init__(self, source: Path, docs_dir: Path):
        self.source = source
        post = fm.load(source)
        self.meta = dict(post.metadata)
        self.raw_body = post.content
        self.html = ""
        self.word_count = len(self.raw_body.split())
        self.reading_time = max(1, round(self.word_count / 220))

        # Compute URL path from file location
        rel = source.relative_to(docs_dir)
        if rel.name == "index.md":
            parent = rel.parent
            parent_str = str(parent).replace("\\", "/")
            self.url = f"/{parent_str}/" if parent_str != "." else "/"
        else:
            self.url = f"/{rel.stem}/".replace("\\", "/")

        # Extract topic and slug from path
        parts = rel.parts
        if len(parts) >= 3 and parts[-1] == "index.md":
            self.topic = parts[0]
            self.slug = parts[-2]
        elif len(parts) >= 2 and parts[-1] == "index.md":
            self.topic = parts[0]
            self.slug = ""
        else:
            self.topic = ""
            self.slug = rel.stem

    @property
    def title(self) -> str:
        return self.meta.get("title", "Untitled")

    @property
    def description(self) -> str:
        return self.meta.get("description", "")


def url_prefix(lang: str, languages) -> str:
    """Return '/{lang}' for multi-language builds, '' for single-language (#105).

    One function, one truth. Every place that needs a language prefix calls
    this instead of inline `if lang and languages` checks. Prevents drift
    between 14+ code paths that caused #73, #82, #90, #94.
    """
    if lang and languages:
        return f"/{lang}"
    return ""


def _compute_rel_root(page_url: str) -> str:
    """Compute relative path from a page URL back to the site root.

    Examples:
        "/" → ""
        "/guides/" → "../"
        "/guides/setup/" → "../../"
    """
    # Count depth: number of path segments (excluding leading/trailing /)
    stripped = page_url.strip("/")
    if not stripped:
        return ""
    depth = len(stripped.split("/"))
    return "../" * depth


def _abs_to_rel(from_url: str, to_url: str) -> str:
    """Convert an absolute internal link to a relative path.

    Both from_url and to_url should be absolute paths starting with /.

    Examples:
        _abs_to_rel("/guides/setup/", "/vendors/acme/") → "../../vendors/acme/"
        _abs_to_rel("/guides/setup/", "/guides/") → "../"
        _abs_to_rel("/", "/guides/setup/") → "guides/setup/"
        _abs_to_rel("/guides/setup/", "/") → "../../"
    """
    # Handle anchor-only or empty
    if not to_url or not to_url.startswith("/"):
        return to_url

    rel_root = _compute_rel_root(from_url)

    # Strip leading / from target
    target = to_url.lstrip("/")

    # Combine: rel_root gets us to site root, then target navigates down
    result = rel_root + target

    # Special case: link to root from root
    if not result:
        return "./"

    return result


class WireRenderer(mistune.HTMLRenderer):
    """Custom mistune renderer with link sculpting and code highlighting."""

    def __init__(self, own_domain: str = "", page_url: str = "/",
                 lang_prefix: str = ""):
        super().__init__(escape=False)
        self._ext_count = 0
        self._own_domain = own_domain
        self._page_url = page_url
        self._lang_prefix = lang_prefix  # e.g., "/de" for multi-lang

    def link(self, text, url, title=None):
        if not url:
            return text

        # Internal links — convert absolute to relative paths
        if not url.startswith("http"):
            if url.startswith("/"):
                # Strip lang prefix from target URL before computing relative
                # path — both page and links are within the same lang output
                # dir (#245). e.g., /de/blog/foo/ → /blog/foo/
                sculpt_url = url
                if self._lang_prefix and url.startswith(self._lang_prefix + "/"):
                    sculpt_url = url[len(self._lang_prefix):]
                url = _abs_to_rel(self._page_url, sculpt_url)
            title_attr = f' title="{title}"' if title else ""
            return f'<a href="{url}"{title_attr}>{text}</a>'

        # Own domain links — treat as internal
        if self._own_domain and self._own_domain in url:
            title_attr = f' title="{title}"' if title else ""
            return f'<a href="{url}"{title_attr}>{text}</a>'

        # External links — first 3 dofollow, rest nofollow
        self._ext_count += 1
        title_attr = f' title="{title}"' if title else ""
        if self._ext_count <= 3:
            return (f'<a href="{url}" rel="noopener" target="_blank"'
                    f'{title_attr}>{text}</a>')
        else:
            return (f'<a href="{url}" rel="nofollow noopener" target="_blank"'
                    f'{title_attr}>{text}</a>')

    def heading(self, text, level, **attrs):
        # Generate anchor ID from heading text
        slug = re.sub(r'[^\w\s-]', '', text.lower())
        slug = re.sub(r'[-\s]+', '-', slug).strip('-')
        return f'<h{level} id="{slug}">{text}</h{level}>\n'

    def codespan(self, text):
        escaped = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        return f'<code>{escaped}</code>'

    def block_code(self, code, info=None, **attrs):
        if info == "terminal":
            return self._render_terminal(code)
        lang_class = f' class="language-{info}"' if info else ""
        escaped = (code.replace("&", "&amp;")
                       .replace("<", "&lt;")
                       .replace(">", "&gt;"))
        return f'<pre><code{lang_class}>{escaped}</code></pre>\n'

    @staticmethod
    def _render_terminal(code: str) -> str:
        """Render a terminal code block as styled command showcase."""
        lines = []
        for raw in code.rstrip("\n").split("\n"):
            stripped = raw.strip()
            escaped = (stripped.replace("&", "&amp;")
                               .replace("<", "&lt;")
                               .replace(">", "&gt;"))
            if stripped.startswith("#"):
                lines.append(
                    f'<div class="line">'
                    f'<span class="comment">{escaped}</span></div>')
            elif stripped.startswith("$ "):
                cmd = escaped[2:]  # Strip "$ " prefix
                lines.append(
                    f'<div class="line">'
                    f'<span class="prompt">$</span> '
                    f'<code>{cmd}</code></div>')
            elif stripped.startswith("+ "):
                lines.append(
                    f'<div class="line">'
                    f'<samp class="pass">{escaped}</samp></div>')
            elif stripped.startswith("- "):
                lines.append(
                    f'<div class="line">'
                    f'<samp class="fail">{escaped}</samp></div>')
            elif stripped.startswith("-- ") and stripped.endswith(" --"):
                lines.append(
                    f'<div class="line">'
                    f'<samp class="section-header">{escaped}</samp></div>')
            elif stripped:
                lines.append(
                    f'<div class="line"><samp>{escaped}</samp></div>')
        return '<div class="command-showcase">\n' + "\n".join(lines) + "\n</div>\n"


def collect_pages(docs_dir: Path, exclude: list[str] = None) -> list[Page]:
    """Walk docs directory, parse all markdown files, return Page objects.

    Excludes files matching EXCLUDE_PATTERNS and any custom exclude patterns.
    """
    patterns = [re.compile(p) for p in EXCLUDE_PATTERNS]
    if exclude:
        patterns.extend(re.compile(p) for p in exclude)

    pages = []
    for md_file in sorted(docs_dir.rglob("*.md")):
        rel_str = str(md_file.relative_to(docs_dir)).replace("\\", "/")

        # Check exclusions
        if any(p.search(rel_str) for p in patterns):
            # Don't warn about known Wire files that are intentionally excluded
            fname = md_file.name
            is_wire_file = (
                fname == "steps.md"
                or fname.startswith("_")  # _styleguide.md, _prompt*.md
                or "/news/" in rel_str    # news pipeline files
            )
            if not is_wire_file:
                line_count = len(md_file.read_text(encoding="utf-8").splitlines())
                if line_count >= 50:
                    logger.warning(
                        f"Excluded page has {line_count} lines of content: "
                        f"{rel_str}\n"
                        f"  Consider linking it from nav or moving its content "
                        f"elsewhere.")
            continue

        page = Page(md_file, docs_dir)

        # Validate required frontmatter
        if "title" not in page.meta:
            logger.warning(f"Skipping {rel_str}: missing 'title' in frontmatter")
            continue

        pages.append(page)

    return pages


# Topics excluded from nav — reachable via footer, author bylines, etc.
NAV_EXCLUDE_TOPICS = {
    # EN
    "imprint", "privacy", "legal", "terms", "cookie", "cookies",
    "disclaimer", "search", "contact", "authors", "bot",
    # DE
    "impressum", "datenschutz", "kontakt",
    # FR
    "mentions-legales", "impression", "confidentialite",
    "politique-de-confidentialite", "vie-privee", "recherche",
    # ES
    "imprimir", "privacidad", "aviso-legal", "politica-de-privacidad",
    "buscar",
}
# Substring patterns for topics that vary (e.g. "pongase-en-contacto-con")
NAV_EXCLUDE_CONTAINS = {"contacto", "kontakt", "contact"}


def build_nav(pages: list[Page], nav_config: list = None,
              nav_exclude: list = None) -> list[dict]:
    """Build navigation structure from pages.

    Uses nav_config from wire.yml (required).

    Args:
        nav_exclude: Additional slugs to exclude from auto-nav (from wire.yml).

    Returns:
        List of {title, url, description, children: [{title, url, description}]}
    """
    nav_exclude_set = {s.lower() for s in nav_exclude} if nav_exclude else set()

    if nav_config:
        nav = _nav_from_config(nav_config, pages)
        # Auto-append news/ if it has content and isn't already in nav
        if "news" not in nav_exclude_set:
            nav = _maybe_append_news(nav, pages)
        return nav

    # Auto-discover: group by topic directory
    # Exclude legal/utility/meta pages from nav (belong in footer or standalone)
    # Merge customer-provided nav_exclude slugs
    _NAV_EXCLUDE = NAV_EXCLUDE_TOPICS | nav_exclude_set
    topics = {}
    homepage = None
    for page in pages:
        if page.url == "/":
            homepage = {"title": page.title, "url": page.url,
                        "description": page.meta.get("description", ""),
                        "children": []}
            continue
        topic = page.topic
        topic_lower = topic.lower()
        if topic_lower in _NAV_EXCLUDE:
            continue
        if any(pat in topic_lower for pat in NAV_EXCLUDE_CONTAINS):
            continue
        if topic not in topics:
            topics[topic] = {"title": topic.replace("-", " ").title(),
                             "url": f"/{topic}/",
                             "description": "",
                             "children": []}
        if page.slug:
            topics[topic]["children"].append(
                {"title": page.meta.get("short_title", page.title),
                 "url": page.url,
                 "description": page.meta.get("description", "")})

    # Build nav — news always goes last (convention over configuration)
    news_section = topics.pop("news", None)
    nav = []
    if homepage:
        nav.append(homepage)
    for topic_name in sorted(topics):
        section = topics[topic_name]
        # Use topic index page title and description if available
        topic_page = next(
            (p for p in pages if p.topic == topic_name and not p.slug), None)
        if topic_page:
            section["title"] = topic_page.meta["short_title"]
            section["description"] = topic_page.meta.get("description", "")
        nav.append(section)

    # Append news last — only if it has articles (not just index.md)
    # News children are NOT shown in nav — they're only reachable via
    # the auto-generated listing page at /news/
    if news_section and news_section["children"]:
        topic_page = next(
            (p for p in pages if p.topic == "news" and not p.slug), None)
        if topic_page:
            news_section["title"] = topic_page.meta["short_title"]
            news_section["description"] = topic_page.meta.get("description", "")
        news_section["children"] = []
        nav.append(news_section)

    return nav


def _maybe_append_news(nav: list[dict], pages: list[Page]) -> list[dict]:
    """Auto-append news/ section to nav if it has articles and isn't already listed.

    Convention over configuration: news/ always appears last in nav.
    Only appends when news pages exist with actual content (not just index.md).
    """
    # Check if news is already in nav
    for item in nav:
        if item.get("url", "").strip("/") == "news":
            return nav

    # Gather news pages
    news_children = [
        p for p in pages if p.topic == "news" and p.slug
    ]
    if not news_children:
        return nav

    # Build the news section — link only, no article children in nav.
    # Individual articles are only reachable via the listing page.
    topic_page = next(
        (p for p in pages if p.topic == "news" and not p.slug), None)
    section = {
        "title": topic_page.meta.get("short_title", "News") if topic_page else "News",
        "url": "/news/",
        "description": topic_page.meta.get("description", "") if topic_page else "",
        "children": [],
    }
    nav.append(section)
    return nav


def resolve_offerings(header: dict, nav: list[dict]) -> tuple[list[dict], list[dict]]:
    """Resolve header.offerings from topic name to nav items.

    If offerings is a string (topic name), finds that topic in nav,
    extracts its children as offerings links, and removes it from nav.
    Fails loud if the topic doesn't exist.

    Returns:
        (offerings_links, filtered_nav) — offerings as [{label: url}] dicts,
        and nav with the offerings topic removed.
    """
    offerings = header.get("offerings")
    if not offerings:
        return [], nav

    # Already a list of dicts (manual config) — filter matching topics from nav
    if isinstance(offerings, list):
        # Build URL→nav title lookup for label resolution (multi-language)
        nav_titles = {}
        for n in nav:
            nav_titles[n.get("url", "").rstrip("/") + "/"] = n.get("title", "")
        offerings_urls = set()
        resolved = []
        for item in offerings:
            if isinstance(item, dict):
                for label, url in item.items():
                    norm = url.rstrip("/") + "/"
                    offerings_urls.add(norm)
                    # Use nav title (per-language short_title) when available
                    nav_label = nav_titles.get(norm, label)
                    resolved.append({nav_label: url})
            else:
                resolved.append(item)
        filtered_nav = [n for n in nav
                        if n.get("url") not in offerings_urls]
        return resolved, filtered_nav

    # String = topic name — resolve from nav
    topic_name = str(offerings).strip().lower()
    matched = None
    for item in nav:
        # Match by URL pattern (/topic/) or by title
        item_topic = item["url"].strip("/").lower()
        if item_topic == topic_name or item["title"].lower() == topic_name:
            matched = item
            break

    if not matched:
        available = [n["title"] for n in nav if n["url"] != "/"]
        raise ValueError(
            f"header.offerings: topic '{offerings}' not found in nav. "
            f"Available: {', '.join(available)}"
        )

    # Build offerings links from children
    links = []
    for child in matched.get("children", []):
        links.append({child["title"]: child["url"]})

    # Also add the overview/index page itself
    if not links:
        links.append({matched["title"]: matched["url"]})

    # Remove offerings topic from content nav (Row 2)
    filtered_nav = [n for n in nav if n is not matched]

    return links, filtered_nav


def _nav_from_config(nav_config: list, pages: list[Page]) -> list[dict]:
    """Build nav from explicit wire.yml nav configuration.

    Nav declares topics and their order — that's the strategic decision.
    Child pages within a topic are auto-discovered from the directory.
    Explicitly listed children appear first (in config order), then
    remaining pages in the topic are appended alphabetically by title.
    """
    page_map = {p.url: p for p in pages}
    # Group pages by topic for auto-discovery within sections
    pages_by_topic: dict[str, list[Page]] = {}
    for p in pages:
        if p.topic:
            pages_by_topic.setdefault(p.topic, []).append(p)
    nav = []

    for item in nav_config:
        if isinstance(item, str):
            # Simple page reference — use short_title for nav (#190)
            url = _md_to_url(item)
            page = page_map.get(url)
            nav.append({"title": page.meta.get("short_title", page.title) if page else item,
                        "url": url,
                        "description": page.meta.get("description", "") if page else "",
                        "children": []})
        elif isinstance(item, dict):
            for section_title, children in item.items():
                if isinstance(children, str):
                    # Standalone page with custom title:
                    #   - "Über uns": about/index.md
                    url = _md_to_url(children)
                    page = page_map.get(url)
                    nav.append({"title": section_title, "url": url,
                                "description": page.meta.get("description", "") if page else "",
                                "children": []})
                elif isinstance(children, list):
                    section = {"title": section_title, "url": "",
                               "description": "", "children": []}
                    explicit_urls = set()
                    section_topic = None
                    for child in children:
                        if isinstance(child, str):
                            path_str = child
                            label = None
                        elif isinstance(child, dict):
                            label, path_str = next(iter(child.items()))
                        else:
                            continue
                        url = _md_to_url(path_str)
                        page = page_map.get(url)
                        explicit_urls.add(url)
                        # Topic = first directory in path (e.g. "services/index.md" → "services")
                        # Nav title ("Leistungen") is display-only, topic drives auto-discovery
                        if not section_topic and "/" in path_str:
                            section_topic = path_str.split("/")[0]
                        title = label or (page.meta.get("short_title", page.title) if page else path_str)
                        section["children"].append({
                            "title": title, "url": url,
                            "description": page.meta.get("description", "") if page else ""})
                    # Auto-discover remaining pages in this topic
                    if section_topic and section_topic in pages_by_topic:
                        remaining = [
                            p for p in pages_by_topic[section_topic]
                            if p.url not in explicit_urls and p.slug
                        ]
                        remaining.sort(key=lambda p: p.title.lower())
                        for p in remaining:
                            section["children"].append({
                                "title": p.meta.get("short_title", p.title),
                                "url": p.url,
                                "description": p.meta.get("description", "")})
                    # Set section URL and description to first child
                    if section["children"]:
                        section["url"] = section["children"][0]["url"]
                        first_page = page_map.get(section["children"][0]["url"])
                        if first_page:
                            section["description"] = first_page.meta.get("description", "")
                    nav.append(section)

    return nav


def _nav_urls(nav: list[dict]) -> set[str]:
    """Extract all URLs from a nav structure (including children)."""
    urls = set()
    for item in nav:
        if item.get("url"):
            urls.add(item["url"])
        for child in item.get("children", []):
            if child.get("url"):
                urls.add(child["url"])
    return urls


def check_nav_orphans(pages: list[Page], nav_config: list,
                      nav: list[dict],
                      header: dict | None = None) -> list[str]:
    """Find pages whose topic isn't declared in navigation.

    Since _nav_from_config auto-discovers children within declared topics,
    this only catches pages in topics that aren't in nav at all.
    CTA pages are reachable via the header button — excluded.

    Returns list of orphan page URLs.
    """
    if not nav_config:
        return []

    nav_urls = _nav_urls(nav)
    # CTA page is reachable via the header button, not the nav
    if header:
        cta = header.get("cta")
        if isinstance(cta, dict) and cta.get("url"):
            nav_urls.add(cta["url"])
    orphans = []
    for page in pages:
        if page.url not in nav_urls:
            # News articles are reachable via the auto-generated listing page
            if page.topic == "news":
                continue
            # Legal, author, contact, bot pages are reachable via footer/bylines/direct URL
            topic_lower = page.topic.lower() if page.topic else ""
            slug_lower = page.slug.lower() if page.slug else ""
            check_name = topic_lower or slug_lower
            if check_name in NAV_EXCLUDE_TOPICS:
                continue
            if any(pat in check_name for pat in NAV_EXCLUDE_CONTAINS):
                continue
            orphans.append(page.url)
    return sorted(orphans)


def _md_to_url(path: str) -> str:
    """Convert a markdown file path to a URL path."""
    path = path.replace("\\", "/")
    if path == "index.md":
        return "/"
    elif path.endswith("/index.md"):
        return "/" + path[:-len("index.md")]
    elif path.endswith(".md"):
        return "/" + path[:-3] + "/"
    return "/" + path


DEFAULT_TEMPLATES_DIR = Path(__file__).parent / "templates"
DEFAULT_ASSETS_DIR = Path(__file__).parent / "assets"


def build_jinja_env(templates_dir: Path) -> jinja2.Environment:
    """Create Jinja2 environment from templates directory.

    Uses a chain: customer's templates/ first, then wire/templates/ as fallback.
    This lets customers override individual templates while inheriting defaults.
    """
    search_paths = []
    if templates_dir.exists():
        search_paths.append(str(templates_dir))
    if DEFAULT_TEMPLATES_DIR.exists():
        search_paths.append(str(DEFAULT_TEMPLATES_DIR))

    if not search_paths:
        raise FileNotFoundError(
            f"No templates found at {templates_dir} or {DEFAULT_TEMPLATES_DIR}.")

    env = jinja2.Environment(
        loader=jinja2.FileSystemLoader(search_paths),
        autoescape=jinja2.select_autoescape(["html"]),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    return env


_YT_PATTERN = re.compile(r'!yt\[([a-zA-Z0-9_-]{11})\]')
_MAKEIMG_PATTERN = re.compile(r'(?<!`)!makeIMG\[([^\]]+)\](?:\{(\w+)\})?')


def _process_makeimg_embeds(body: str, output_dir: Path = None) -> str:
    """Convert !makeIMG[slug]{preset} to <img> tags.

    Images must exist as docs/assets/images/{slug}.png — generated
    ahead of time via `python -m wire.chief images`. Missing images
    are a build error (Wire is opinionated).

    Skips matches inside code fences or inline code.
    """
    # Build set of code-protected ranges (fences + inline backticks)
    _code_ranges: list[tuple[int, int]] = []
    for m in re.finditer(r'```.*?```', body, re.DOTALL):
        _code_ranges.append((m.start(), m.end()))
    for m in re.finditer(r'`[^`]+`', body):
        _code_ranges.append((m.start(), m.end()))

    def _in_code(pos: int) -> bool:
        return any(s <= pos < e for s, e in _code_ranges)

    matches = [m for m in _MAKEIMG_PATTERN.finditer(body) if not _in_code(m.start())]
    if not matches:
        return body

    # Find docs_dir by walking up from output_dir, or use config
    docs_dir = None
    if output_dir:
        # output_dir is typically 'site/', docs_dir is sibling 'docs/'
        candidate = output_dir.parent / "docs"
        if candidate.is_dir():
            docs_dir = candidate

    errors = []
    for m in matches:
        slug = m.group(1)
        img_path = None
        if docs_dir:
            img_path = docs_dir / "assets" / "images" / f"{slug}.png"
        if img_path and not img_path.exists():
            errors.append(slug)

    if errors:
        msg = "BUILD ERROR: Missing !makeIMG images:\n"
        for slug in errors:
            msg += f"  - {slug}.png\n"
        msg += "Run: python -m wire.chief images"
        raise FileNotFoundError(msg)

    def _replace(m):
        slug = m.group(1)
        alt = slug.replace('-', ' ').replace('"', '&quot;')
        src = f"__RELROOT__assets/images/{slug}.png"

        # Copy to output if output_dir is set
        if output_dir and docs_dir:
            src_file = docs_dir / "assets" / "images" / f"{slug}.png"
            dest_dir = output_dir / "assets" / "images"
            dest_dir.mkdir(parents=True, exist_ok=True)
            dest_file = dest_dir / f"{slug}.png"
            if not dest_file.exists() and src_file.exists():
                shutil.copy2(str(src_file), str(dest_file))

        return (
            f'<img src="{src}" alt="{alt}" loading="lazy" '
            f'class="wire-img">'
        )

    return _MAKEIMG_PATTERN.sub(_replace, body)


def _download_youtube_thumbnails(body: str, output_dir: Path) -> dict:
    """Download YouTube thumbnails locally for privacy.

    Returns dict mapping video_id to local relative path (or None on failure).
    Caches downloads in .wire/yt-cache/ to avoid re-downloading.
    """
    ids = _YT_PATTERN.findall(body)
    if not ids:
        return {}

    cache_dir = output_dir.parent / ".wire" / "yt-cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    assets_dir = output_dir / "assets" / "yt"
    assets_dir.mkdir(parents=True, exist_ok=True)

    result = {}
    for vid in set(ids):
        cached = cache_dir / f"yt-{vid}.jpg"
        dest = assets_dir / f"yt-{vid}.jpg"

        if not cached.exists():
            for quality in ("maxresdefault", "hqdefault"):
                url = f"https://i.ytimg.com/vi/{vid}/{quality}.jpg"
                try:
                    urllib.request.urlretrieve(url, str(cached))
                    if cached.stat().st_size > 1000:
                        break
                    cached.unlink()
                except Exception:
                    if cached.exists():
                        cached.unlink()
                    continue

        if cached.exists():
            shutil.copy2(str(cached), str(dest))
            result[vid] = f"assets/yt/yt-{vid}.jpg"
        else:
            result[vid] = None

    return result


def _process_youtube_embeds(body: str, output_dir: Path = None) -> str:
    """Convert !yt[VIDEO_ID] shortcodes to privacy-safe HTML embeds.

    If output_dir is provided, downloads thumbnails locally for privacy.
    Falls back to YouTube CDN URLs on download failure.
    """
    local_paths = {}
    if output_dir:
        local_paths = _download_youtube_thumbnails(body, output_dir)

    def _replace(m):
        vid = m.group(1)
        local = local_paths.get(vid)
        if local:
            # Use __RELROOT__ placeholder — resolved to correct relative path
            # by render_page() after page depth is known.
            src = f"__RELROOT__{local}"
        else:
            src = f"https://i.ytimg.com/vi/{vid}/maxresdefault.jpg"
        return (
            f'<div class="yt-embed" data-id="{vid}">'
            f'<img src="{src}" '
            f'alt="Video thumbnail" loading="lazy" width="1280" height="720">'
            f'<button aria-label="Play video" class="yt-play"></button>'
            f'<span class="yt-notice">Click to load video from '
            f'<span class="yt-yt">YouTube</span></span>'
            f'</div>'
        )
    return _YT_PATTERN.sub(_replace, body)


# ---- Shortcode preprocessor ----
# Converts :::name blocks to HTML before mistune runs.
# Mistune passes raw HTML through untouched, so the output renders as-is.
# Code fences are protected so shortcodes inside examples aren't processed.

# Module-level config for shortcodes that need site context (set by build())
_SHORTCODE_LOGO = ""      # logo path relative to site root
_SHORTCODE_SITE_NAME = "" # site name from wire.yml
_SHORTCODE_LANG = ""      # language code for multi-language link prefixing
_SHORTCODE_BASE_PATH = "" # base path for subdirectory deployments

_FENCE_PATTERN = re.compile(
    r'^(`{3,}|~{3,})[^\n]*\n.*?\n\1\s*$', re.MULTILINE | re.DOTALL)

_SHORTCODE_PATTERN = re.compile(
    r'^:::(\w+)(?:[ \t]+([^\n]+))?\n(.*?)\n:::\s*$',
    re.MULTILINE | re.DOTALL,
)


def _render_shortcode(match) -> str:
    """Convert a single :::name block to HTML."""
    name = match.group(1).lower()
    arg = (match.group(2) or "").strip()
    body = match.group(3).strip()

    handler = _SHORTCODE_HANDLERS.get(name)
    if not handler:
        return match.group(0)
    return handler(body, arg)


def _shortcode_stats(body: str, arg: str) -> str:
    """:::stats — exactly 4 key metrics in a row.

    Syntax:
        :::stats
        300+ | Vendors Compared
        24 | Capability Categories
        :::
    """
    items = []
    for line in body.split("\n"):
        line = line.strip()
        if not line:
            continue
        if "|" in line:
            value, label = line.split("|", 1)
        else:
            value, label = line, ""
        items.append(
            f'<div class="stat">'
            f'<span class="stat-value">{value.strip()}</span>'
            f'<span class="stat-label">{label.strip()}</span>'
            f'</div>'
        )
    return f'<div class="stats-bar">{"".join(items)}</div>\n\n'


def _shortcode_cards(body: str, arg: str) -> str:
    r""":::cards — grid of cards, split by ### headings.

    Syntax:
        :::cards
        ### Title
        Description text.
        [Link text](/url/)

        ### Title 2
        More description.
        [Link text](/url/)
        :::
    """
    # Split on ### headings, keeping the heading text
    parts = re.split(r'^###\s+', body, flags=re.MULTILINE)
    cards = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        lines = part.split("\n", 1)
        title = lines[0].strip()
        content = lines[1].strip() if len(lines) > 1 else ""
        # Check if the title itself is a markdown link: ### [Text](/url/)
        title_link = re.match(r'^\[([^\]]+)\]\(([^)]+)\)$', title)
        if title_link and title_link.group(2).startswith("/"):
            title = title_link.group(1)
            card_url = _prefix_link(title_link.group(2), _SHORTCODE_LANG, _SHORTCODE_BASE_PATH)
        else:
            if title_link:
                title = title_link.group(1)
            # Extract first INTERNAL link from body (cards are navigation, not outbound)
            all_links = re.findall(r'\[([^\]]+)\]\(([^)]+)\)', content)
            internal = [(t, u) for t, u in all_links if u.startswith("/")]
            card_url = _prefix_link(internal[0][1], _SHORTCODE_LANG, _SHORTCODE_BASE_PATH) if internal else ""
        # Convert markdown links to HTML in content
        content_html = re.sub(
            r'\[([^\]]+)\]\(([^)]+)\)',
            r'<span class="card-link">\1 &rarr;</span>',
            content,
        )
        # Convert remaining lines to paragraphs
        paras = [ln.strip() for ln in content_html.split("\n") if ln.strip()]
        body_html = "".join(f"<p>{p}</p>" for p in paras)
        if card_url:
            cards.append(
                f'<a href="{card_url}" class="feature-card">'
                f'<h3>{title}</h3>'
                f'{body_html}'
                f'</a>'
            )
        else:
            cards.append(
                f'<div class="feature-card">'
                f'<h3>{title}</h3>'
                f'{body_html}'
                f'</div>'
            )
    return f'<div class="feature-grid">{"".join(cards)}</div>\n\n'


def _shortcode_split(body: str, arg: str) -> str:
    """:::split — two columns separated by ---.

    Syntax:
        :::split
        Left column **with markdown**.

        ---

        Right column content.
        :::

    Variant — :::split comparison
        Highlights the second column (primary border, accent background,
        top bar). Use for before/after or old-vs-new comparisons.

    If no --- separator is found, renders as a single full-width column.
    """
    is_comparison = arg.strip().lower() == "comparison"
    parts = re.split(r'\n---\n', body, maxsplit=1)
    left = parts[0].strip()
    right = parts[1].strip() if len(parts) > 1 else ""
    if not right:
        return (
            f'<div class="split split-single">'
            f'<div class="split-col">\n\n{left}\n\n</div>'
            f'</div>\n\n'
        )
    wrapper_cls = "split split-comparison" if is_comparison else "split"
    right_cls = "split-col split-col--highlight" if is_comparison else "split-col"
    return (
        f'<div class="{wrapper_cls}">'
        f'<div class="split-col">\n\n{left}\n\n</div>'
        f'<div class="{right_cls}">\n\n{right}\n\n</div>'
        f'</div>\n\n'
    )


def _shortcode_banner(body: str, arg: str) -> str:
    """:::banner VALUE — big number callout.

    Syntax:
        :::banner 223%
        Companies using structured content see 223% higher ROI.
        :::
    """
    value = arg or ""
    if len(value) > 6:
        raise ValueError(
            f":::banner value '{value}' is {len(value)} chars (max 6). "
            f"Short values only — long text breaks the layout."
        )
    return (
        f'<div class="banner">'
        f'<span class="banner-value">{value}</span>'
        f'<span class="banner-text">{body}</span>'
        f'</div>\n\n'
    )


def _shortcode_progress(body: str, arg: str) -> str:
    """:::progress — horizontal bar chart for comparisons.

    Syntax:
        :::progress
        Content-Engagement | 34%
        Webinar-Einladung | 31%
        :::
    """
    bars = []
    for line in body.split("\n"):
        line = line.strip()
        if not line:
            continue
        if "|" not in line:
            continue
        label, value = line.rsplit("|", 1)
        value = value.strip()
        # Extract numeric part for width (strip % if present)
        width = value.rstrip("%").strip()
        bars.append(
            f'<div class="progress-bar">'
            f'<div class="progress-label">'
            f'<span class="progress-name">{label.strip()}</span>'
            f'<span class="progress-value">{value}</span>'
            f'</div>'
            f'<div class="progress-track">'
            f'<div class="progress-fill" style="width: {width}%"></div>'
            f'</div>'
            f'</div>'
        )
    return f'<div class="progress-group">{"".join(bars)}</div>\n\n'


def _shortcode_cta(body: str, arg: str) -> str:
    """:::cta — button group from markdown links.

    Syntax:
        :::cta
        [Primary Button](/url/){primary}
        [Secondary Button](/url/)
        :::
    """
    buttons = []
    first = True
    for line in body.split("\n"):
        line = line.strip()
        if not line:
            continue
        # Find all [text](url) links on this line, with optional {primary}/{secondary}
        for m in re.finditer(r'\[([^\]]+)\]\(([^)]+)\)(\{[^}]+\})?', line):
            text = m.group(1)
            url = _prefix_link(m.group(2), _SHORTCODE_LANG, _SHORTCODE_BASE_PATH)
            marker = m.group(3) or ""
            is_primary = marker == "{primary}" or (first and marker != "{secondary}")
            cls = "btn btn-primary" if is_primary else "btn btn-secondary"
            buttons.append(f'<a href="{url}" class="{cls}">{text}</a>')
            first = False
    return f'<div class="hero-actions">{"".join(buttons)}</div>\n\n'


def _shortcode_tabs(body: str, arg: str) -> str:
    """:::tabs — tabbed content panels, split by ### headings.

    Syntax:
        :::tabs
        ### Tab One
        Content for first tab.

        ### Tab Two
        Content for second tab.
        :::
    """
    parts = re.split(r'^###\s+', body, flags=re.MULTILINE)
    tabs = []
    panels = []
    # Unique ID per tabs block to scope radio buttons
    tab_id = f"tabs-{abs(hash(body)) % 100000}"
    for part in parts:
        part = part.strip()
        if not part:
            continue
        lines = part.split("\n", 1)
        title = lines[0].strip()
        content = lines[1].strip() if len(lines) > 1 else ""
        idx = len(tabs)
        checked = ' checked' if idx == 0 else ''
        tabs.append(
            f'<input type="radio" name="{tab_id}" id="{tab_id}-{idx}"'
            f' class="tab-radio"{checked}>'
            f'<label for="{tab_id}-{idx}" class="tab-label">{title}</label>'
        )
        panels.append(
            f'<div class="tab-panel">\n\n{content}\n\n</div>'
        )
    return (
        f'<div class="tabs">'
        f'<div class="tab-bar">{"".join(tabs)}</div>'
        f'<div class="tab-panels">{"".join(panels)}</div>'
        f'</div>\n\n'
    )


def _shortcode_faq(body: str, arg: str) -> str:
    """:::faq — collapsible accordion using native <details>.

    Syntax:
        :::faq
        ### Question one?
        Answer to question one.

        ### Question two?
        Answer to question two.
        :::
    """
    parts = re.split(r'^###\s+', body, flags=re.MULTILINE)
    items = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        lines = part.split("\n", 1)
        question = lines[0].strip()
        answer = lines[1].strip() if len(lines) > 1 else ""
        # Convert markdown links in answer (prefix for multi-language)
        answer_html = re.sub(
            r'\[([^\]]+)\]\(([^)]+)\)',
            lambda m: f'<a href="{_prefix_link(m.group(2), _SHORTCODE_LANG, _SHORTCODE_BASE_PATH)}">{m.group(1)}</a>',
            answer,
        )
        paras = [ln.strip() for ln in answer_html.split("\n") if ln.strip()]
        answer_body = "".join(f"<p>{p}</p>" for p in paras)
        items.append(
            f'<details class="faq-item">'
            f'<summary>{question}</summary>'
            f'<div class="faq-answer">{answer_body}</div>'
            f'</details>'
        )
    # Generate FAQPage JSON-LD alongside HTML (#116)
    import json
    faq_schema = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [],
    }
    for part in re.split(r'^###\s+', body, flags=re.MULTILINE):
        part = part.strip()
        if not part:
            continue
        lines = part.split("\n", 1)
        q = lines[0].strip()
        a = lines[1].strip() if len(lines) > 1 else ""
        # Strip markdown links from answer for plain text
        a_text = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', a)
        faq_schema["mainEntity"].append({
            "@type": "Question",
            "name": q,
            "acceptedAnswer": {
                "@type": "Answer",
                "text": a_text,
            },
        })
    jsonld = json.dumps(faq_schema, ensure_ascii=False)
    return (f'<div class="faq">{"".join(items)}</div>\n'
            f'<script type="application/ld+json">{jsonld}</script>\n\n')


def _shortcode_badges(body: str, arg: str) -> str:
    """:::badges — inline tag/badge list, pipe-separated.

    Syntax:
        :::badges
        On-Premise | Kubernetes | OCR | ISO 27.001
        :::
    """
    raw = body.replace("\n", "|")
    tags = [t.strip() for t in raw.split("|") if t.strip()]
    spans = "".join(f'<span class="badge">{t}</span>' for t in tags)
    return f'<div class="badges">{spans}</div>\n\n'


def _shortcode_alert(body: str, arg: str) -> str:
    """:::alert [info|success|warning|error] — callout box.

    Syntax:
        :::alert warning
        This action cannot be undone.
        :::
    """
    level = arg.strip() if arg else "info"
    return f'<div class="alert alert-{level}">\n\n{body}\n\n</div>\n\n'


def _shortcode_section(body: str, arg: str) -> str:
    """:::section [light] — full-width background band.

    Syntax:
        :::section light
        ## Heading
        Content inside the band.
        :::
    """
    variant = arg.strip() if arg else "light"
    if variant in ("dark", "accent"):
        raise SystemExit(
            f"BUILD ERROR: :::section {variant} is not supported. "
            "Wire removed dark/accent sections — customers own their own dark styling. "
            "Use :::section light or plain :::section instead."
        )
    return (
        f'<div class="section section-{variant}">'
        f'<div class="section-inner">\n\n{body}\n\n</div>'
        f'</div>\n\n'
    )


def _shortcode_testimonial(body: str, arg: str) -> str:
    r""":::testimonial — quote with attribution.

    Syntax:
        :::testimonial
        This product changed everything for our team.
        — Jane Doe, CTO at Acme Corp
        :::
    """
    lines = body.strip().split("\n")
    # Last line starting with — or -- is the attribution
    quote_lines = []
    author = ""
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("—") or stripped.startswith("--"):
            author = stripped.lstrip("—- ").strip()
        else:
            quote_lines.append(stripped)
    quote = " ".join(ln for ln in quote_lines if ln)
    author_html = (f'<cite class="testimonial-author">{author}</cite>'
                   if author else "")
    return (
        f'<blockquote class="testimonial">'
        f'<p class="testimonial-quote">{quote}</p>'
        f'{author_html}'
        f'</blockquote>\n\n'
    )


def _shortcode_logos(body: str, arg: str) -> str:
    """:::logos — logo cloud (centered flex row of partner/client logos).

    Syntax:
        :::logos
        ![Alt text](/assets/img/logo1.png)
        ![Alt text](/assets/img/logo2.png)
        :::
    """
    imgs = []
    for line in body.split("\n"):
        line = line.strip()
        if not line:
            continue
        m = re.match(r'^!\[([^\]]*)\]\(([^)]+)\)$', line)
        if m:
            alt, src = m.group(1), m.group(2)
            # Apply base_path for subdirectory deployments
            if src.startswith("/") and _SHORTCODE_BASE_PATH:
                src = _SHORTCODE_BASE_PATH + src
            imgs.append(
                f'<img src="{src}" alt="{alt}" class="logo-cloud-item">'
            )
    return f'<div class="logo-cloud">{"".join(imgs)}</div>\n\n'


def _shortcode_pricing(body: str, arg: str) -> str:
    r""":::pricing — pricing table with 2-3 plan cards.

    Syntax:
        :::pricing
        ### Starter
        $29/mo
        For small teams getting started.
        - 10 pages
        - Basic SEO
        [Get started](/signup/)

        ### Pro
        $99/mo
        For growing content operations.
        - 100 pages
        - Full SEO suite
        [Start free trial](/signup/){primary}
        :::
    """
    parts = re.split(r'^###\s+', body, flags=re.MULTILINE)
    cards = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        lines = [ln for ln in part.split("\n") if ln.strip()]
        if not lines:
            continue
        name = lines[0].strip()
        price = lines[1].strip() if len(lines) > 1 else ""
        desc = lines[2].strip() if len(lines) > 2 else ""
        features = []
        cta_text = ""
        cta_url = ""
        is_primary = False
        for ln in lines[3:]:
            ln = ln.strip()
            # CTA link line
            link_m = re.match(
                r'^\[([^\]]+)\]\(([^)]+)\)(\{primary\})?$', ln
            )
            if link_m:
                cta_text = link_m.group(1)
                cta_url = _prefix_link(link_m.group(2), _SHORTCODE_LANG, _SHORTCODE_BASE_PATH)
                if link_m.group(3):
                    is_primary = True
                continue
            # Feature bullet
            bullet_m = re.match(r'^-\s+(.+)$', ln)
            if bullet_m:
                features.append(bullet_m.group(1))
        card_cls = "pricing-card pricing-featured" if is_primary else "pricing-card"
        btn_cls = "btn btn-primary" if is_primary else "btn btn-secondary"
        features_html = "".join(f"<li>{f}</li>" for f in features)
        cta_html = (
            f'<a href="{cta_url}" class="{btn_cls}">{cta_text}</a>'
            if cta_text else ""
        )
        cards.append(
            f'<div class="{card_cls}">'
            f'<h3 class="pricing-name">{name}</h3>'
            f'<div class="pricing-price">{price}</div>'
            f'<p class="pricing-desc">{desc}</p>'
            f'<ul class="pricing-features">{features_html}</ul>'
            f'{cta_html}'
            f'</div>'
        )
    return f'<div class="pricing-grid">{"".join(cards)}</div>\n\n'


def _shortcode_steps(body: str, arg: str) -> str:
    r""":::steps — horizontal numbered steps (3-4 max).

    Syntax:
        :::steps
        ### Create
        Write content from search gaps and client questions.

        ### Optimize
        Reword titles and headings to match real search queries.

        ### Publish
        Build to static HTML with 45-rule linting.
        :::
    """
    parts = re.split(r'^###\s+', body, flags=re.MULTILINE)
    items = []
    for i, part in enumerate(parts):
        part = part.strip()
        if not part:
            continue
        lines = part.split("\n", 1)
        title = lines[0].strip()
        desc = lines[1].strip() if len(lines) > 1 else ""
        desc_html = re.sub(
            r'\[([^\]]+)\]\(([^)]+)\)',
            lambda m: f'<a href="{_prefix_link(m.group(2), _SHORTCODE_LANG, _SHORTCODE_BASE_PATH)}">{m.group(1)}</a>',
            desc,
        )
        paras = [ln.strip() for ln in desc_html.split("\n") if ln.strip()]
        body_html = "".join(f"<p>{p}</p>" for p in paras)
        items.append(
            f'<div class="step">'
            f'<div class="step-marker">{i}</div>'
            f'<h3 class="step-title">{title}</h3>'
            f'{body_html}'
            f'</div>'
        )
    count = len(items)
    return (
        f'<div class="steps steps-{count}">{"".join(items)}</div>\n\n'
    )


def _visual_pattern_index(label: str) -> int:
    """Deterministic pattern selection from label text (DJB2 hash)."""
    h = 5381
    for c in label:
        h = ((h << 5) + h + ord(c)) & 0xFFFFFFFF
    return h % 3


def _shortcode_visual(body: str, arg: str) -> str:
    """:::visual Label — inline visual break with brand colors.

    Renders a styled card with label, title, and optional description.
    Background pattern is deterministically selected from the label text.
    Uses the customer's color scheme via CSS custom properties.

    Syntax:
        :::visual Methodik
        Datengetrieben, nicht raten
        Echte GSC-Daten statt Bauchgefühl.
        :::
    """
    label = arg.strip() if arg else ""
    lines = [ln for ln in body.split("\n") if ln.strip()]
    title = lines[0].strip().lstrip("#").strip() if lines else ""
    desc_lines = lines[1:] if len(lines) > 1 else []

    # Separate bullet lines from plain description lines
    bullets = [ln.strip().lstrip("- ").strip()
               for ln in desc_lines if ln.strip().startswith("- ")]
    plain = [ln.strip() for ln in desc_lines
             if not ln.strip().startswith("- ")]
    description = " ".join(plain)

    pattern_idx = _visual_pattern_index(label or title)

    parts = [f'<section class="visual visual-pattern-{pattern_idx}">']
    parts.append('<div class="visual-inner">')
    if _SHORTCODE_LOGO or _SHORTCODE_SITE_NAME:
        logo_html = ""
        if _SHORTCODE_LOGO:
            logo_html = (f'<img src="/{_SHORTCODE_LOGO}" alt="" '
                         f'class="visual-logo" width="20" height="20">')
        name_html = (f'<span class="visual-site">{_SHORTCODE_SITE_NAME}</span>'
                     if _SHORTCODE_SITE_NAME else "")
        parts.append(f'<div class="visual-brand">{logo_html}{name_html}</div>')
    if label:
        parts.append(f'<div class="visual-label">{label}</div>')
    if title:
        parts.append(f'<h3 class="visual-title">{title}</h3>')
    if description:
        parts.append(f'<p class="visual-desc">{description}</p>')
    if bullets:
        items = "".join(f"<li>{b}</li>" for b in bullets)
        parts.append(f'<ul class="visual-list">{items}</ul>')
    parts.append('</div>')
    parts.append('</section>\n\n')
    return "".join(parts)


_SHORTCODE_HANDLERS = {
    "stats": _shortcode_stats,
    "cards": _shortcode_cards,
    "split": _shortcode_split,
    "banner": _shortcode_banner,
    "progress": _shortcode_progress,
    "cta": _shortcode_cta,
    "tabs": _shortcode_tabs,
    "faq": _shortcode_faq,
    "badges": _shortcode_badges,
    "alert": _shortcode_alert,
    "section": _shortcode_section,
    "testimonial": _shortcode_testimonial,
    "logos": _shortcode_logos,
    "pricing": _shortcode_pricing,
    "steps": _shortcode_steps,
    "visual": _shortcode_visual,
}


def _process_shortcodes(body: str, output_dir: Path = None) -> str:
    """Convert all :::shortcode blocks and !yt[] embeds to HTML.

    Protects code fences first so shortcodes inside examples aren't processed.
    """
    # Extract code fences, replace with placeholders
    fences = []

    def _save_fence(m):
        fences.append(m.group(0))
        return f"\x00FENCE{len(fences) - 1}\x00"

    protected = _FENCE_PATTERN.sub(_save_fence, body)
    # Process shortcodes inside-out (nested shortcodes resolve first)
    result = protected
    for _ in range(5):  # max nesting depth
        new = _SHORTCODE_PATTERN.sub(_render_shortcode, result)
        if new == result:
            break
        result = new
    result = _process_youtube_embeds(result, output_dir=output_dir)
    result = _process_makeimg_embeds(result, output_dir=output_dir)
    # Restore code fences
    for i, fence in enumerate(fences):
        result = result.replace(f"\x00FENCE{i}\x00", fence)
    return result


def render_markdown(page: Page, own_domain: str = "",
                    page_url: str = "/",
                    output_dir: Path = None,
                    lang_prefix: str = "") -> str:
    """Render a page's markdown body to HTML using mistune."""
    body = _process_shortcodes(page.raw_body, output_dir=output_dir)
    renderer = WireRenderer(own_domain=own_domain, page_url=page_url,
                            lang_prefix=lang_prefix)
    md = mistune.create_markdown(renderer=renderer, plugins=["table"])
    html = md(body)
    # Wrap tables for horizontal scroll on mobile
    html = html.replace("<table>", '<div class="table-wrap"><table>')
    html = html.replace("</table>", "</table></div>")
    return html


_IMG_SRC_PATTERN = re.compile(r'<img\s[^>]*src="([^"]+)"', re.IGNORECASE)
_IMG_TAG_PATTERN = re.compile(r'<img\s([^>]*)>', re.IGNORECASE)


def _get_image_dimensions(filepath: Path) -> tuple[int, int] | None:
    """Read width/height from PNG, JPEG, or GIF file headers without PIL."""
    try:
        with open(filepath, "rb") as f:
            header = f.read(32)
            if len(header) < 8:
                return None

            # PNG: bytes 16-23 contain width (4) and height (4)
            if header[:8] == b'\x89PNG\r\n\x1a\n':
                w, h = struct.unpack(">II", header[16:24])
                return (w, h)

            # GIF: bytes 6-9 contain width (2 LE) and height (2 LE)
            if header[:3] in (b'GIF',) and len(header) >= 10:
                w = struct.unpack("<H", header[6:8])[0]
                h = struct.unpack("<H", header[8:10])[0]
                return (w, h)

            # JPEG: scan for SOF0/SOF2 marker
            if header[:2] in (b'\xff\xd8',):
                f.seek(2)
                while True:
                    marker = f.read(2)
                    if len(marker) < 2:
                        return None
                    if marker[0] != 0xFF:
                        return None
                    if marker[1] in (0xC0, 0xC2):  # SOF0, SOF2
                        data = f.read(7)
                        if len(data) < 7:
                            return None
                        h = struct.unpack(">H", data[3:5])[0]
                        w = struct.unpack(">H", data[5:7])[0]
                        return (w, h)
                    # Skip this segment
                    length_bytes = f.read(2)
                    if len(length_bytes) < 2:
                        return None
                    length = struct.unpack(">H", length_bytes)[0]
                    f.seek(length - 2, 1)
    except Exception:
        return None
    return None


def _inject_image_dimensions(html: str, page_dir: Path,
                              output_dir: Path) -> str:
    """Add width/height to local <img> tags missing dimensions."""
    def _replace_img(m):
        attrs = m.group(1)
        # Skip if already has width and height
        if 'width=' in attrs and 'height=' in attrs:
            return m.group(0)
        # Extract src
        src_m = re.search(r'src="([^"]+)"', attrs)
        if not src_m:
            return m.group(0)
        src = src_m.group(1)
        # Skip external images
        if src.startswith(("http://", "https://", "data:", "//")):
            return m.group(0)

        # Resolve path — try relative to page dir, then absolute in output
        if src.startswith("/"):
            img_path = output_dir / src.lstrip("/")
        else:
            img_path = (page_dir / src).resolve()

        dims = _get_image_dimensions(img_path)
        if not dims:
            return m.group(0)
        w, h = dims
        return f'<img {attrs} width="{w}" height="{h}">'

    return _IMG_TAG_PATTERN.sub(_replace_img, html)


_DISCOVERY_LABELS = ("discovery_start", "discovery_read")
_ARTICLE_LABELS = ("on_this_page", "related_articles", "read_more")


def _resolve_lang_config(config_val, lang: str, lang_codes: list) -> dict:
    """Resolve per-language config from flat or nested dict.

    Flat:   {title: "...", link: "/..."}          → returned as-is
    Nested: {de: {title: "..."}, en: {title: ...}} → resolved by lang

    Detection: if any top-level key matches a configured language code,
    treat as nested. Otherwise treat as flat.
    """
    if not config_val or not isinstance(config_val, dict):
        return config_val
    if lang_codes and any(k in lang_codes for k in config_val):
        return config_val.get(lang, {})
    return config_val


def _prefix_link(url: str, lang_prefix: str,
                  base_path: str = "") -> str:
    """Prefix an internal link with base_path and /{lang}/ for deployments.

    Only prefixes paths starting with / (not external URLs, anchors, or
    paths that already include the language prefix).
    base_path: subdirectory prefix from site_url (e.g. "/helm-nagel-com").
    """
    if not url or not url.startswith("/"):
        return url
    # Apply lang prefix first (if not already present)
    if lang_prefix and not url.startswith(f"/{lang_prefix}/"):
        url = f"/{lang_prefix}{url}"
    # Apply base_path (if not already present)
    if base_path and not url.startswith(base_path):
        url = f"{base_path}{url}"
    return url


def _prefix_config_links(config: dict, header: dict, wire_config: dict,
                          lang: str, languages: list) -> tuple:
    """Prefix internal links in config dicts for multi-language/subdirectory builds.

    Returns (header, wire_config, footer) with links prefixed.
    Applies lang prefix for multi-language and base_path for subdirectory deployments.
    """
    footer = config.get("footer", {})
    base_path = config.get("_base_path", "")
    if not lang and not languages and not base_path:
        return header, wire_config, footer

    import copy
    header = copy.deepcopy(header)
    wire_config = copy.deepcopy(wire_config)
    _lang = lang if languages else ""

    # header.cta.url
    cta = header.get("cta")
    if isinstance(cta, dict) and cta.get("url"):
        cta["url"] = _prefix_link(cta["url"], _lang, base_path)

    # sidebar_cta.link
    sidebar = wire_config.get("sidebar_cta")
    if isinstance(sidebar, dict) and sidebar.get("link"):
        sidebar["link"] = _prefix_link(sidebar["link"], _lang, base_path)

    # article_cta.link
    article = wire_config.get("article_cta")
    if isinstance(article, dict) and article.get("link"):
        article["link"] = _prefix_link(article["link"], _lang, base_path)

    # footer.links — {group_name: [{text: url}, ...]}
    if isinstance(footer, dict) and (footer.get("links") or footer.get("legal")):
        footer = copy.deepcopy(footer)
        for group_name, links in footer.get("links", {}).items():
            for i, link_dict in enumerate(links):
                if isinstance(link_dict, dict):
                    footer["links"][group_name][i] = {
                        text: _prefix_link(url, _lang, base_path)
                        for text, url in link_dict.items()
                    }
        # footer.legal — [{text: url}, ...]
        footer["legal"] = [
            {text: _prefix_link(url, _lang, base_path) for text, url in ld.items()}
            if isinstance(ld, dict) else ld
            for ld in footer.get("legal", [])
        ]

    return header, wire_config, footer


def _validate_discovery_labels(lang: str, labels: dict,
                                has_discovery: bool) -> None:
    """Refuse to build non-English sites with discovery steps but no labels.

    English sites get default labels. Non-English sites must configure them
    in wire.yml extra.wire.labels — customers should not see English buttons
    on a German page.
    """
    if not has_discovery or lang == "en":
        return
    missing = [k for k in _DISCOVERY_LABELS if k not in labels]
    if missing:
        raise ValueError(
            f"Non-English site (lang={lang}) has discovery steps but "
            f"missing labels: {', '.join(missing)}. "
            f"Add to wire.yml under extra.wire.labels:\n"
            f"  labels:\n"
            f"    discovery_start: \"...\"\n"
            f"    discovery_read: \"...\"\n")


def _validate_article_labels(lang: str, labels: dict) -> None:
    """Refuse to build without article labels.

    Article templates use on_this_page, related_articles, read_more.
    Every site must configure these — no hardcoded English fallbacks.
    """
    missing = [k for k in _ARTICLE_LABELS if k not in labels]
    if missing:
        raise ValueError(
            f"Missing required labels: {', '.join(missing)}. "
            f"Add to wire.yml under extra.wire.labels:\n"
            f"  labels:\n"
            + "".join(f"    {k}: \"...\"\n" for k in missing))


def _extract_og_image(page: Page, html: str, config: dict) -> str | None:
    """Extract og:image URL with priority: frontmatter > body img > site default.

    Relative paths are converted to absolute URLs using site_url.
    """
    site_url = config.get("site_url", "").rstrip("/")

    image = page.meta.get("image")
    if not image:
        m = _IMG_SRC_PATTERN.search(html)
        if m:
            image = m.group(1)

    if not image:
        theme = config.get("theme", {})
        if isinstance(theme, dict):
            image = theme.get("og_image")

    if not image:
        return None

    if image.startswith(("http://", "https://")):
        return image
    if site_url:
        image = image.lstrip("/")
        return f"{site_url}/{image}"
    return image


_SECTION_CYCLE = ["section-white", "section-light", "section-white",
                   "section-light"]


def _extract_toc(html: str) -> list[dict]:
    """Extract table of contents from rendered HTML headings.

    Returns list of dicts with keys: id, text, level (2 or 3).
    Only includes h2 and h3 headings.
    """
    toc = []
    for m in re.finditer(r'<h([23])\s+id="([^"]+)"[^>]*>(.*?)</h\1>', html):
        level = int(m.group(1))
        heading_id = m.group(2)
        # Strip HTML tags from heading text (e.g. <code>, <a>)
        text = re.sub(r'<[^>]+>', '', m.group(3))
        toc.append({"id": heading_id, "text": text, "level": level})
    return toc


def _landing_sections(html: str) -> str:
    """Replace <hr> tags with alternating section wrappers on landing pages.

    Splits HTML at <hr> boundaries and wraps each chunk in a
    <div class="section section-{variant}"> for visual rhythm.
    First section becomes a hero (light background, large text).
    Sections that already contain a .section div are left unwrapped.
    """
    parts = re.split(r'\s*<hr\s*/?\s*>\s*', html)
    if len(parts) <= 1:
        return html
    # Filter empty parts
    non_empty = [p.strip() for p in parts if p.strip()]
    if len(non_empty) <= 1:
        return html
    sections = []
    total = len(non_empty)
    real_index = 0
    for part in non_empty:
        # Skip wrapping if the part already has a :::section shortcode output
        if 'class="section ' in part:
            sections.append(part)
        elif real_index == 0:
            # First section = hero
            # If customer provides a <section> with section-hero class,
            # they own the hero — pass through without wrapping
            if '<section' in part and 'section-hero' in part:
                sections.append(part)
            else:
                sections.append(
                    f'<div class="section section-hero">'
                    f'<div class="section-inner">{part}</div>'
                    f'</div>'
                )
        else:
            variant = _SECTION_CYCLE[(real_index - 1) % len(_SECTION_CYCLE)]
            sections.append(
                f'<div class="section {variant}">'
                f'<div class="section-inner">{part}</div>'
                f'</div>'
            )
        real_index += 1
    return "\n".join(sections)


# Cache for author resolution (keyed by docs_dir + slug)
_author_cache: dict[str, dict | None] = {}


def _resolve_author(slug: str, docs_dir: Path) -> dict | None:
    """Resolve an author slug to author metadata.

    Looks for docs/authors/{slug}/index.md and extracts frontmatter.

    Returns:
        Dict with name, slug, role, photo_url, page_url — or None if not found.
    """
    cache_key = f"{docs_dir}:{slug}"
    if cache_key in _author_cache:
        return _author_cache[cache_key]

    author_path = docs_dir / "authors" / slug / "index.md"
    if not author_path.exists():
        _author_cache[cache_key] = None
        return None

    post = fm.load(author_path)
    meta = dict(post.metadata)
    name = meta.get("title", slug.replace("-", " ").title())
    # Strip subtitle from author page titles (#256)
    # Supports: " — ", " - ", ": " separators
    if " — " in name:
        name = name.split(" — ")[0].strip()
    elif " - " in name:
        name = name.split(" - ")[0].strip()
    elif ": " in name:
        name = name.split(": ")[0].strip()

    # Check for author photo
    photo_path = docs_dir / "authors" / slug / "photo.jpg"
    photo_url = f"/authors/{slug}/photo.jpg" if photo_path.exists() else ""

    # Social links for sameAs in JSON-LD (#141)
    social = meta.get("social", [])
    if isinstance(social, str):
        social = [social]

    # LinkedIn URL from social list (#211)
    linkedin = ""
    for url in social:
        if "linkedin.com" in url:
            linkedin = url
            break

    # Description: first paragraph of author page body (#211)
    body = post.content.strip()
    description = ""
    if body:
        # First non-empty line before a heading or blank line
        for line in body.split("\n"):
            line = line.strip()
            if not line or line.startswith("#"):
                break
            description = line
            break
        # Strip markdown links to plain text — byline is not rendered as HTML (#222)
        if description:
            description = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', description)

    result = {
        "name": name,
        "slug": slug,
        "role": meta.get("role", ""),
        "photo_url": photo_url,
        "page_url": f"/authors/{slug}/",
        "social": social,
        "linkedin": linkedin,
        "description": description,
    }
    _author_cache[cache_key] = result
    return result


_MD_LINK_RE = re.compile(r'\[([^\]]+)\]\((/[^)]*?)\)')


def _extract_related_pages(raw_body: str, pages_lookup: dict) -> list[dict]:
    """Extract internal links from raw markdown and resolve to related pages.

    Uses raw markdown body (not rendered HTML) since rendered HTML converts
    absolute links to relative paths.

    Args:
        raw_body: Raw markdown body text.
        pages_lookup: Dict mapping URL → Page object.

    Returns:
        List of dicts with title, description, url, topic (max 8, deduped).
    """
    seen = set()
    related = []

    for m in _MD_LINK_RE.finditer(raw_body):
        url = m.group(2)
        # Normalize: ensure trailing slash
        if not url.endswith("/"):
            url = url + "/"
        if url in seen or url == "/":
            continue
        seen.add(url)

        page = pages_lookup.get(url)
        if page and page.slug:  # Only content pages, not index pages
            related.append({
                "title": page.title,
                "description": page.description,
                "url": url,
                "topic": page.topic,
            })
            if len(related) >= 8:
                break

    return related


def render_page(page: Page, nav: list[dict], env: jinja2.Environment,
                config: dict, output_dir: Path,
                lang: str = "", languages: list[dict] = None,
                **kwargs) -> Path:
    """Render a single page to HTML and write to output directory.

    Returns the output file path.
    """
    # Compute rel_root for this page's depth (e.g. "../../" for depth 2)
    rel_root = _compute_rel_root(page.url)

    # Render markdown to HTML — internal links become relative
    wire_config_raw = config.get("extra", {}).get("wire", {})
    # Resolve per-language config (labels, sidebar_cta, article_cta)
    lang_codes = [lg["code"] for lg in config.get("languages", [])]
    build_lang = lang or config.get("lang", "")
    wire_config = dict(wire_config_raw)  # shallow copy — don't mutate shared config
    for key in ("labels", "sidebar_cta", "article_cta"):
        if key in wire_config:
            wire_config[key] = _resolve_lang_config(
                wire_config[key], build_lang, lang_codes)
    # page.url is without lang prefix; link sculpting strips lang prefix
    # from target links so relative paths resolve within the lang output dir (#245)
    lang_prefix = url_prefix(lang, languages)
    page.html = render_markdown(page, config.get("site_url", ""),
                                page_url=page.url,
                                output_dir=output_dir,
                                lang_prefix=lang_prefix)
    # Determine layout — auto-detect "article" for topic items
    explicit_layout = page.meta.get("layout")
    if explicit_layout:
        layout = explicit_layout
    elif page.topic and page.slug:
        # Topic items default to "article" unless site opts out
        default_item_layout = wire_config.get("default_item_layout", "article")
        layout = default_item_layout
    else:
        layout = "page"

    # Strip first H1 from body — template renders title as H1 (avoid duplicate)
    # Applies to page and article layouts — landing/raw templates don't add H1
    if layout in ("page", "article"):
        page.html = re.sub(r'<h1[^>]*>.*?</h1>\s*', '', page.html, count=1)

    # Resolve __RELROOT__ placeholders (used by YouTube embeds for local thumbnails)
    if "__RELROOT__" in page.html:
        page.html = page.html.replace("__RELROOT__", rel_root)

    # Inject image dimensions for local images (prevents CLS)
    if "<img " in page.html:
        # Use source page directory for resolution (output images not yet copied)
        page_src_dir = page.source.parent
        page.html = _inject_image_dimensions(page.html, page_src_dir, output_dir)

    # Landing pages: replace <hr> with alternating section bands
    if layout == "landing" and "<hr" in page.html:
        page.html = _landing_sections(page.html)

    # Check for discovery steps file
    discovery_html = ""
    try:
        from wire.discovery import find_steps_file, parse_steps, render_discovery_html
        steps_file = find_steps_file(page.source)
        if steps_file:
            steps_data = parse_steps(steps_file.read_text(encoding="utf-8"))
            if steps_data:
                discovery_labels = wire_config.get("labels", {})
                _validate_discovery_labels(
                    lang=lang or config["lang"],
                    labels=discovery_labels,
                    has_discovery=True)
                discovery_html = render_discovery_html(steps_data, labels=discovery_labels)
                # Article layout: pass separately for hero slot placement
                # Other layouts: inline into page body as before
                if layout != "article":
                    page.html = discovery_html + "\n" + page.html
                    discovery_html = ""
    except ImportError:
        pass  # discovery module not available

    # Extract table of contents for page and article layouts
    toc = _extract_toc(page.html) if layout in ("page", "article") else []

    # Build template context
    context = {
        "page": page,
        "nav": nav,
        "toc": toc,
        "site": {
            "name": config["site_name"],
            "url": (config.get("site_url", "").rstrip("/") +
                    url_prefix(lang, languages)),
            "description": config.get("description", ""),
        },
        "config": config,
        "rel_root": rel_root,
        "lang": lang,
        "languages": _page_language_switcher(page, lang, languages or []),
    }

    # Inject logo and favicon
    logo = config.get("logo")
    context["logo"] = f"{rel_root}{logo}" if logo else False
    favicon = config.get("favicon")
    context["favicon"] = f"{rel_root}{favicon}" if favicon else False

    # Inject discovery HTML for article hero slot
    context["discovery_html"] = discovery_html
    context["has_discovery"] = bool(discovery_html)

    # Inject header config — prefix internal links for multi-language builds
    raw_header = config.get("header", {})
    prefixed_header, wire_config, prefixed_footer = _prefix_config_links(
        config, raw_header, wire_config, lang, languages)
    context["header"] = prefixed_header
    context["wire_config"] = wire_config
    context["footer"] = prefixed_footer

    # Inject theme CSS variables from config
    theme = config.get("theme", {})
    context["theme"] = theme

    # ISO 8601 timestamps for OG article:published_time/modified_time (#184)
    # Today: real time. Past: deterministic hash. Never claim future time.
    def _date_to_iso(val):
        v = str(val) if val else ""
        if v and re.match(r'^\d{4}-\d{2}-\d{2}$', v):
            from datetime import date as _d, datetime as _dt, timezone as _tz
            if v == str(_d.today()):
                now = _dt.now(_tz.utc)
                return now.strftime("%Y-%m-%dT%H:%M:%S+00:00")
            h = hash(v) & 0xFFFFFFFF
            hour = 8 + (h % 10)
            minute = (h >> 4) % 60
            second = (h >> 10) % 60
            return f"{v}T{hour:02d}:{minute:02d}:{second:02d}+00:00"
        return v
    context["iso_created"] = _date_to_iso(page.meta.get("created", ""))
    context["iso_modified"] = _date_to_iso(page.meta.get("date", ""))

    # Inject JSON-LD structured data
    context["jsonld"] = build_jsonld(page, config, lang=lang,
                                     languages=languages)

    # BreadcrumbList JSON-LD (#118) — shows breadcrumb trail in SERPs
    context["breadcrumb_jsonld"] = _build_breadcrumb_jsonld(
        page, config, lang=lang, languages=languages)

    # RSS autodiscovery (#126)
    prefix = url_prefix(lang, languages)
    context["feed_url"] = f"{rel_root}{prefix.lstrip('/')}/feed.xml".replace("//", "/") if prefix else f"{rel_root}feed.xml"

    # Inject og:image
    context["og_image"] = _extract_og_image(page, page.html, config)

    # Inject hreflang alternates
    hreflang_map = kwargs.get("hreflang_map") or {}
    hreflang_entry = hreflang_map.get((lang, page.url), {})
    site_url = config.get("site_url", "").rstrip("/")
    hreflangs = []
    if hreflang_entry:
        for hl_lang, hl_url in sorted(hreflang_entry.items()):
            hreflangs.append({
                "lang": hl_lang,
                "href": f"{site_url}{hl_url}" if site_url else hl_url,
            })
    context["hreflangs"] = hreflangs

    # Inject CTA block for matching topics
    cta_config = wire_config.get("cta", {})
    if isinstance(cta_config, dict) and page.topic and page.slug:
        cta_html = cta_config.get(page.topic, "")
        if cta_html:
            page.html = page.html + "\n" + cta_html

    # Form handling: page tracker always runs, form config only with form_id
    form_id = wire_config.get("form_id", "")
    if form_id and "<form" in page.html:
        import json as _json
        form_cfg = {"id": form_id}
        bp = wire_config.get("form_botpoison", "")
        if bp:
            form_cfg["botpoison"] = bp
        success_msg = wire_config.get("form_success", "")
        if success_msg:
            form_cfg["success"] = success_msg
        context["form_config"] = _json.dumps(form_cfg)
    else:
        context["form_config"] = ""

    # Resolve author for article layout
    author = None
    docs_dir = config.get("docs_dir")
    if layout == "article" and page.meta.get("author") and docs_dir:
        author = _resolve_author(page.meta["author"], Path(docs_dir))
        # Allow per-page role override
        if author and page.meta.get("role"):
            author = dict(author)  # copy to avoid mutating cache
            author["role"] = page.meta["role"]
    context["author"] = author

    # Resolve reviewer — optional second author for transparency (#218)
    reviewer = None
    if layout == "article" and page.meta.get("reviewer") and docs_dir:
        reviewer = _resolve_author(page.meta["reviewer"], Path(docs_dir))
    context["reviewer"] = reviewer

    # Inject subscribe config (inline newsletter form)
    context["subscribe"] = wire_config.get("subscribe", {})

    # Inject sidebar CTA config (right column promotional card)
    _sidebar_cta = dict(wire_config.get("sidebar_cta", {}))
    # Sidebar card image: explicit > og_image fallback (#216)
    if not _sidebar_cta.get("image"):
        og_img = config.get("theme", {}).get("og_image", "")
        if og_img:
            _sidebar_cta["image"] = og_img
    context["sidebar_cta"] = _sidebar_cta

    # Inject article bottom CTA (full-width banner before footer)
    context["article_cta"] = wire_config.get("article_cta", {})

    # Resolve related pages from internal links (article layout only)
    pages_lookup = kwargs.get("pages_lookup", {})
    if layout == "article" and pages_lookup:
        context["related_pages"] = _extract_related_pages(page.raw_body, pages_lookup)
    else:
        context["related_pages"] = []

    # Choose template: layout → template mapping, or explicit template override
    _LAYOUT_TEMPLATES = {
        "page": "page.html",
        "article": "article.html",
        "landing": "landing.html",
        "raw": "raw.html",
    }
    template_name = page.meta.get("template",
                                   _LAYOUT_TEMPLATES.get(layout, "page.html"))
    context["layout"] = layout
    template = env.get_template(template_name)
    html_output = template.render(**context)

    # Write output
    if page.url == "/":
        out_path = output_dir / "index.html"
    else:
        out_path = output_dir / page.url.strip("/") / "index.html"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(html_output, encoding="utf-8")

    return out_path


def generate_sitemap(pages: list[Page], config: dict, output_dir: Path,
                     lang: str = ""):
    """Generate sitemap.xml from all pages."""
    site_url = config.get("site_url", "").rstrip("/")
    if not site_url:
        return

    prefix = f"/{lang}" if lang else ""

    lines = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']

    for page in sorted(pages, key=lambda p: p.url):
        url = f"{site_url}{prefix}{page.url}"
        # lastmod: date > created > file mtime (#136)
        date = (page.meta.get("date", "")
                or page.meta.get("created", ""))
        if not date and hasattr(page, 'source') and page.source.exists():
            from datetime import datetime
            mtime = page.source.stat().st_mtime
            date = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d")
        if date:
            lines.append(f"  <url><loc>{url}</loc>"
                         f"<lastmod>{date}</lastmod></url>")
        else:
            lines.append(f"  <url><loc>{url}</loc></url>")

    lines.append("</urlset>")
    (output_dir / "sitemap.xml").write_text(
        "\n".join(lines), encoding="utf-8")


def generate_raw_exports(config: dict, output_dir: Path):
    """Export raw markdown files stripped of frontmatter and Unicode.

    Reads source markdown, strips YAML frontmatter, converts common
    Unicode characters to ASCII, writes to output as .md.
    """
    wire_config = config.get("extra", {}).get("wire", {})
    raw_paths = wire_config.get("raw_export", [])
    if not raw_paths:
        return

    docs_dir = config["docs_dir"]
    # Unicode → ASCII substitutions
    unicode_map = {
        "\u2019": "'", "\u2018": "'",   # smart quotes
        "\u201c": '"', "\u201d": '"',   # double quotes
        "\u2013": "-", "\u2014": "--",  # dashes
        "\u2026": "...",                 # ellipsis
        "\u2192": "->", "\u2190": "<-", # arrows
        "\u00a0": " ",                   # non-breaking space
        "\u00e9": "e", "\u00e8": "e",   # accented e
        "\u00fc": "ue", "\u00f6": "oe", "\u00e4": "ae",  # German umlauts
        "\u00df": "ss",                  # eszett
    }

    for rel_path in raw_paths:
        src = docs_dir / rel_path
        if not src.exists():
            logger.warning(f"raw_export: '{rel_path}' not found, skipping")
            continue

        content = src.read_text(encoding="utf-8")

        # Strip YAML frontmatter
        if content.startswith("---"):
            end = content.find("---", 3)
            if end != -1:
                content = content[end + 3:].lstrip("\n")

        # Unicode → ASCII
        for uni, ascii_char in unicode_map.items():
            content = content.replace(uni, ascii_char)

        # Output path: bots/index.md → bots.md
        parts = Path(rel_path).parts
        if parts[-1] == "index.md" and len(parts) > 1:
            out_name = parts[-2] + ".md"
            out_path = output_dir / out_name
        else:
            out_path = output_dir / Path(rel_path).name

        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(content, encoding="utf-8")
        logger.info(f"Raw export: {rel_path} → {out_path.relative_to(output_dir)}")


def _render_utility_page(config: dict, env, *, title: str, description: str,
                         inner_html: str, url: str, rel_root: str,
                         nav=None, languages: list[dict] = None,
                         lang: str = "", meta_extras: dict = None) -> str | None:
    """Render auto-generated pages (404, search) through page.html.

    Single code path for utility pages — eliminates duplicate boilerplate
    that was in generate_404() and generate_search_page(). (#106)
    """
    try:
        template = env.get_template("page.html")
    except Exception:
        return None

    meta = {"description": description, "hide_meta": True, "hide_title": True}
    if meta_extras:
        meta.update(meta_extras)

    page_obj = type("Page", (), {
        "title": title,
        "description": description,
        "meta": meta,
        "html": inner_html,
        "url": url,
        "reading_time": 0,
    })()

    base_path = config.get("_base_path", "")
    site = {
        "name": config["site_name"],
        "url": config["site_url"],
        "description": config.get("description", ""),
    }

    # Prefix config links for multi-language builds (footer, header, sidebar)
    raw_header = config.get("header", {})
    wire_config_raw = config.get("extra", {}).get("wire", {})
    wire_cfg = dict(wire_config_raw)
    prefixed_header, wire_cfg, prefixed_footer = _prefix_config_links(
        config, raw_header, wire_cfg, lang, languages or [])

    logo = config.get("logo")
    favicon = config.get("favicon")
    return template.render(
        page=page_obj, nav=nav or [], toc=[], config=config,
        site=site, base_path=base_path, rel_root=rel_root,
        header=prefixed_header,
        theme=config.get("theme", {}), lang=lang or config.get("lang", ""),
        languages=languages or [], form_config="",
        jsonld="", layout="landing",
        footer=prefixed_footer, wire_config=wire_cfg,
        logo=f"{rel_root}{logo}" if logo else False,
        favicon=f"{rel_root}{favicon}" if favicon else False,
    )


def generate_404(config: dict, output_dir: Path, env, nav=None,
                 languages: list[dict] = None, lang: str = ""):
    """Generate a styled 404 page using the site's base template."""
    site_name = config["site_name"]
    wire_config = config.get("extra", {}).get("wire", {})
    labels = wire_config.get("labels", {})

    title_404 = labels.get("404_title", "Page Not Found")
    message_404 = labels.get("404_message",
                             "The page you're looking for doesn't exist "
                             "or has been moved.")
    back_404 = labels.get("404_back", f"Back to {site_name or 'home'}")

    # 404 can be served from any URL — use absolute root so CSS/links work.
    # Multi-language: point to default language so nav links resolve correctly.
    base_path = config.get("_base_path", "")
    _pfx = url_prefix(lang, languages)
    abs_root = f"{_pfx}/" if _pfx else (base_path.rstrip("/") + "/" if base_path else "/")

    inner_html = (
        '<div style="text-align:center;padding:80px 20px">'
        '<p style="font-size:6rem;font-weight:700;margin:0;opacity:0.15;'
        'line-height:1">404</p>'
        f'<p style="font-size:1.25rem;margin:16px 0 32px">'
        f'{html_module.escape(message_404)}</p>'
        f'<a href="{abs_root}" '
        f'style="color:var(--primary);font-weight:600">'
        f'{html_module.escape(back_404)}</a>'
        '</div>'
    )

    html = _render_utility_page(
        config, env, title=title_404, description=message_404,
        inner_html=inner_html, url="/404.html", rel_root=abs_root,
        nav=nav, languages=languages, lang=lang,
    )
    if html is None:
        return
    (output_dir / "404.html").write_text(html, encoding="utf-8")
    logger.info("Generated 404.html")


def generate_search_page(config: dict, output_dir: Path, env, nav=None,
                         languages: list[dict] = None, lang: str = ""):
    """Generate a client-side search page using search_index.json."""
    search_html = (
        '<div id="search-container">'
        '<h1 class="search-title">Search</h1>'
        '<input type="search" id="search-input" placeholder="Search..." '
        'aria-label="Search" autofocus>'
        '<div id="search-results"></div>'
        '</div>'
        '<script>'
        '(function(){'
        'var input=document.getElementById("search-input"),'
        'results=document.getElementById("search-results"),index=null;'
        'fetch("../search_index.json")'
        '.then(function(r){return r.json()})'
        '.then(function(d){index=d})'
        '.catch(function(){results.innerHTML="<p>Search index not available.</p>"});'
        'input.addEventListener("input",function(){'
        'if(!index)return;'
        'var q=this.value.trim().toLowerCase();'
        'if(q.length<2){results.innerHTML="";return}'
        'var terms=q.split(/\\s+/),'
        'scored=index.map(function(p){'
        'var t=(p.title||"").toLowerCase(),'
        'd=(p.description||"").toLowerCase(),'
        'b=(p.body||"").toLowerCase(),s=0;'
        'terms.forEach(function(w){'
        'if(t.indexOf(w)>=0)s+=10;'
        'if(d.indexOf(w)>=0)s+=5;'
        'if(b.indexOf(w)>=0)s+=1});'
        'return{title:p.title,description:p.description,url:p.url,score:s}'
        '}).filter(function(p){return p.score>0})'
        '.sort(function(a,b){return b.score-a.score})'
        '.slice(0,20);'
        'if(!scored.length){results.innerHTML="<p>No results.</p>";return}'
        'results.innerHTML=scored.map(function(p){'
        'return\'<div class="search-result">\''
        '+\'<a href="\'+p.url+\'">\'+p.title+\'</a>\''
        '+\'<p>\'+( p.description||"")+\'</p></div>\'}).join("")});'
        'var q=new URLSearchParams(location.search).get("q");'
        'if(q){input.value=q;input.dispatchEvent(new Event("input"))}'
        '})()'
        '</script>'
    )

    site_name = config["site_name"]
    search_desc = f"Search {site_name} for articles, guides, and resources."

    html = _render_utility_page(
        config, env, title=f"Search articles and guides - {site_name}",
        description=search_desc, inner_html=search_html, url="/search/",
        rel_root="../", nav=nav, languages=languages, lang=lang,
        meta_extras={"noindex": True},
    )
    if html is None:
        return
    search_dir = output_dir / "search"
    search_dir.mkdir(parents=True, exist_ok=True)
    (search_dir / "index.html").write_text(html, encoding="utf-8")
    logger.info("Generated search/index.html")


def _extract_first_paragraph(raw_body: str, max_chars: int = 120) -> str:
    """Extract first paragraph text from markdown body, truncated to max_chars.

    Skips headings, blank lines, and frontmatter. Returns plain text (no HTML).
    """
    for line in raw_body.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("#"):
            continue
        # Found a paragraph line
        text = stripped
        if len(text) > max_chars:
            # Truncate at word boundary
            text = text[:max_chars].rsplit(" ", 1)[0] + "…"
        return text
    return ""


def generate_news_page(news_pages: list[Page], output_dir: Path,
                       docs_dir: Path, config: dict = None,
                       env=None, nav=None, languages=None,
                       lang: str = "") -> None:
    """Auto-generate a news listing page when docs/news/ has articles.

    Renders a listing through the page template: title, 120-char excerpt from
    first paragraph (markdown, not HTML), author name, publish date.
    Includes NewsArticle JSON-LD for each article.
    """
    if not news_pages:
        return

    # Sort by date descending (newest first)
    def _sort_key(p: Page) -> str:
        return str(p.meta.get("date", "0000-00-00"))

    sorted_pages = sorted(news_pages, key=_sort_key, reverse=True)

    # Build JSON-LD
    import json
    jsonld_items = []
    for p in sorted_pages:
        item = {
            "@type": "NewsArticle",
            "headline": p.title,
            "description": p.description,
            "url": p.url,
        }
        if p.meta.get("date"):
            item["datePublished"] = str(p.meta["date"])
        author_slug = p.meta.get("author", "")
        if author_slug:
            author_info = _resolve_author(author_slug, docs_dir)
            if author_info:
                item["author"] = {"@type": "Person", "name": author_info["name"]}
        jsonld_items.append(item)

    jsonld_str = json.dumps({
        "@context": "https://schema.org",
        "@type": "ItemList",
        "itemListElement": [
            {"@type": "ListItem", "position": i + 1, "item": item}
            for i, item in enumerate(jsonld_items)
        ],
    }, ensure_ascii=False)

    # Build HTML listing
    cards = []
    for p in sorted_pages:
        excerpt = _extract_first_paragraph(p.raw_body)
        date_str = str(p.meta.get("date", ""))
        author_slug = p.meta.get("author", "")
        author_name = ""
        if author_slug:
            author_info = _resolve_author(author_slug, docs_dir)
            if author_info:
                author_name = author_info["name"]
        meta_parts = []
        if date_str:
            meta_parts.append(f'<time datetime="{date_str}">{date_str}</time>')
        if author_name:
            meta_parts.append(f'<span class="news-author">{author_name}</span>')
        meta_html = " · ".join(meta_parts)
        cards.append(
            f'<a href="../{p.url.strip("/")!s}/" class="news-card">'
            f'<h2 class="news-card-title">{p.title}</h2>'
            f'<p class="news-card-excerpt">{excerpt}</p>'
            f'<p class="news-card-meta">{meta_html}</p>'
            f'</a>'
        )

    listing_html = '<div class="news-listing">\n' + "\n".join(cards) + '\n</div>'

    # Render through template if available, otherwise write minimal HTML
    if env and config:
        try:
            template = env.get_template("page.html")
            site_name = config.get("site_name", "")
            page_obj = type("Page", (), {
                "title": "News",
                "meta": {"description": f"Latest news from {site_name}.",
                         "hide_meta": True, "hide_title": True},
                "html": listing_html,
                "url": "/news/",
                "reading_time": 0,
            })()
            base_path = config.get("_base_path", "")
            site = {
                "name": site_name,
                "url": config.get("site_url", ""),
                "description": config.get("description", ""),
            }
            raw_header = config.get("header", {})
            wire_config_raw = config.get("extra", {}).get("wire", {})
            wire_cfg = dict(wire_config_raw)
            prefixed_header, wire_cfg, prefixed_footer = _prefix_config_links(
                config, raw_header, wire_cfg, lang, languages or [])
            logo = config.get("logo")
            favicon = config.get("favicon")
            html = template.render(
                page=page_obj, nav=nav or [], toc=[], config=config,
                site=site, base_path=base_path, rel_root="../",
                header=prefixed_header,
                theme=config.get("theme", {}),
                lang=lang or config.get("lang", ""),
                languages=languages or [], form_config="",
                jsonld=jsonld_str, layout="landing",
                footer=prefixed_footer, wire_config=wire_cfg,
                logo=f"../{logo}" if logo else False,
                favicon=f"../{favicon}" if favicon else False,
            )
        except Exception:
            html = None
    else:
        html = None

    if not html:
        # Fallback: minimal HTML (for tests without template env)
        html = (
            '<!DOCTYPE html><html><head>'
            '<meta charset="utf-8">'
            '<title>News</title>'
            f'<script type="application/ld+json">{jsonld_str}</script>'
            '</head><body>'
            + listing_html
            + '</body></html>'
        )

    news_dir = output_dir / "news"
    news_dir.mkdir(parents=True, exist_ok=True)
    (news_dir / "index.html").write_text(html, encoding="utf-8")
    logger.info("Generated news/index.html")


def _generate_humans_txt(config: dict, output_dir: Path):
    """Generate humans.txt for site attribution (#142)."""
    site_name = config["site_name"]
    lines = [
        f"/* TEAM */",
        f"Site: {site_name}",
        f"Built with: Wire (https://wire.wise-relations.com)",
        "",
        f"/* TECHNOLOGY */",
        f"Generator: Wire",
        f"Language: Python",
        f"Standards: HTML5, CSS3, Schema.org",
    ]
    (output_dir / "humans.txt").write_text(
        "\n".join(lines) + "\n", encoding="utf-8")


def _generate_sitemap_index(config: dict, output_dir: Path,
                            languages: list[dict]):
    """Generate sitemap-index.xml referencing per-language sitemaps (#124)."""
    site_url = config.get("site_url", "").rstrip("/")
    if not site_url:
        return
    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
    ]
    for lang_cfg in languages:
        code = lang_cfg["code"]
        lines.append(f"  <sitemap><loc>{site_url}/{code}/sitemap.xml</loc></sitemap>")
    lines.append("</sitemapindex>")
    (output_dir / "sitemap-index.xml").write_text(
        "\n".join(lines) + "\n", encoding="utf-8")
    logger.info("Generated sitemap-index.xml")


def generate_robots_txt(config: dict, output_dir: Path):
    """Generate robots.txt with sitemap reference."""
    site_url = config.get("site_url", "").rstrip("/")
    lines = ["User-agent: *", "Allow: /"]
    if site_url:
        languages = config.get("languages")
        if languages:
            for lang in languages:
                lines.append(f"Sitemap: {site_url}/{lang['code']}/sitemap.xml")
        else:
            lines.append(f"Sitemap: {site_url}/sitemap.xml")
    (output_dir / "robots.txt").write_text(
        "\n".join(lines) + "\n", encoding="utf-8")


def generate_cname(config: dict, output_dir: Path):
    """Generate CNAME file for GitHub Pages custom domain."""
    site_url = config.get("site_url", "")
    if not site_url:
        return
    from urllib.parse import urlparse
    hostname = urlparse(site_url).hostname
    if hostname and not hostname.endswith(".github.io"):
        (output_dir / "CNAME").write_text(hostname + "\n", encoding="utf-8")


def generate_htaccess(config: dict, output_dir: Path, site_dir: Path = None):
    """Generate Apache .htaccess file for sites deployed to Apache/SiteGround.

    Only generates when deploy.target is 'apache' in wire.yml.
    Includes redirect rules (301 RewriteRule, 410 ErrorDocument) from load_redirects().
    """
    deploy = config.get("deploy", {})
    if not isinstance(deploy, dict) or deploy.get("target") != "apache":
        return

    cache = deploy.get("cache", {})
    www_redirect = deploy.get("www_redirect", "non-www")
    sections = []

    # HTTPS redirect
    if deploy.get("https_redirect", True):
        sections.append(
            "# HTTPS redirect\n"
            "RewriteEngine On\n"
            "RewriteCond %{HTTPS} off\n"
            "RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]"
        )

    # www redirect
    if www_redirect == "non-www":
        sections.append(
            "# www to non-www redirect\n"
            "RewriteEngine On\n"
            "RewriteCond %{HTTP_HOST} ^www\\. [NC]\n"
            "RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]\n"
            "RewriteCond %{HTTP_HOST} ^www\\.(.+)$ [NC]\n"
            "RewriteRule ^ https://%1%{REQUEST_URI} [L,R=301]"
        )
    elif www_redirect == "www":
        sections.append(
            "# non-www to www redirect\n"
            "RewriteEngine On\n"
            "RewriteCond %{HTTP_HOST} !^www\\. [NC]\n"
            "RewriteRule ^ https://www.%{HTTP_HOST}%{REQUEST_URI} [L,R=301]"
        )

    # Trailing slash enforcement
    if deploy.get("trailing_slash", True):
        sections.append(
            "# Trailing slash\n"
            "RewriteEngine On\n"
            "RewriteCond %{REQUEST_FILENAME} !-f\n"
            "RewriteCond %{REQUEST_URI} !(.*)/$\n"
            "RewriteRule ^(.*)$ %{REQUEST_URI}/ [L,R=301]"
        )

    # Cache headers — always generated with opinionated defaults
    # Static assets (images, CSS, JS) get 1 year; HTML gets 1 hour
    # Customers can override via deploy.cache in wire.yml
    cache_images = cache.get("images", "1 year")
    cache_css_js = cache.get("css_js", "1 year")
    cache_html = cache.get("html", "1 hour")
    cache_lines = [
        "# Cache headers\n"
        "<IfModule mod_expires.c>\n"
        "ExpiresActive On",
        f'ExpiresByType image/jpeg "access plus {cache_images}"',
        f'ExpiresByType image/png "access plus {cache_images}"',
        f'ExpiresByType image/webp "access plus {cache_images}"',
        f'ExpiresByType image/svg+xml "access plus {cache_images}"',
        f'ExpiresByType image/gif "access plus {cache_images}"',
        f'ExpiresByType image/x-icon "access plus {cache_images}"',
        f'ExpiresByType text/css "access plus {cache_css_js}"',
        f'ExpiresByType application/javascript "access plus {cache_css_js}"',
        f'ExpiresByType text/html "access plus {cache_html}"',
        f'ExpiresByType application/json "access plus {cache_html}"',
        "</IfModule>",
    ]
    sections.append("\n".join(cache_lines))

    # Security headers
    if deploy.get("security_headers", True):
        sections.append(
            "# Security headers\n"
            "<IfModule mod_headers.c>\n"
            'Header set X-Frame-Options "SAMEORIGIN"\n'
            'Header set X-Content-Type-Options "nosniff"\n'
            'Header set Referrer-Policy "strict-origin-when-cross-origin"\n'
            "Header set Content-Security-Policy \"frame-ancestors 'self'\"\n"
            "</IfModule>"
        )

    # Gzip compression
    if deploy.get("gzip", True):
        sections.append(
            "# Gzip compression\n"
            "<IfModule mod_deflate.c>\n"
            "AddOutputFilterByType DEFLATE text/html\n"
            "AddOutputFilterByType DEFLATE text/css\n"
            "AddOutputFilterByType DEFLATE application/javascript\n"
            "AddOutputFilterByType DEFLATE application/json\n"
            "AddOutputFilterByType DEFLATE image/svg+xml\n"
            "</IfModule>"
        )

    # Redirects from wire.yml / .wire/redirects.yml
    from wire.tools import load_redirects
    redirect_site_dir = site_dir or Path.cwd()
    redirects = load_redirects(site_dir=redirect_site_dir)
    redirect_lines = []
    gone_lines = []
    for r in redirects:
        from_url = r.get("from", "").strip("/")
        to_url = r.get("to", "")
        status = r.get("status", 301)
        if not from_url:
            continue
        if status == 410:
            gone_lines.append(f"RewriteRule ^{from_url}/?$ - [G,L]")
        elif to_url:
            redirect_lines.append(
                f"RewriteRule ^{from_url}/?$ {to_url} [R={status},L]")
    if redirect_lines or gone_lines:
        parts = ["# Redirects\nRewriteEngine On"]
        parts.extend(gone_lines)
        parts.extend(redirect_lines)
        sections.append("\n".join(parts))

    # Custom 404
    sections.append("# Custom 404\nErrorDocument 404 /404.html")

    content = "\n\n".join(sections) + "\n"
    (output_dir / ".htaccess").write_text(content, encoding="utf-8")
    logger.info("Generated .htaccess")


def _get_git_dates(filepath: Path) -> tuple[str, str]:
    """Get created and modified dates from git history.

    Returns (created_iso, modified_iso) or ("", "") if git unavailable.
    """
    try:
        result = subprocess.run(
            ["git", "log", "--follow", "--format=%aI", "--", str(filepath)],
            capture_output=True, text=True, timeout=10)
        if result.returncode != 0 or not result.stdout.strip():
            return ("", "")
        dates = result.stdout.strip().split("\n")
        # Oldest commit = last line, newest = first line
        return (dates[-1][:10], dates[0][:10])
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return ("", "")


def _build_breadcrumb_jsonld(page: Page, config: dict,
                             lang: str = "", languages=None) -> str:
    """Generate BreadcrumbList JSON-LD for topic hierarchy (#118).

    Structure: Home > Topic > Page. Shows breadcrumb trail in SERPs.
    Only generates for pages with a topic (skips homepage, landing pages).
    """
    if not page.topic:
        return ""
    import json
    site_url = config.get("site_url", "").rstrip("/")
    prefix = url_prefix(lang, languages)

    items = [
        {"@type": "ListItem", "position": 1, "name": config["site_name"],
         "item": f"{site_url}{prefix}/"},
    ]
    # Topic level
    topic_title = page.topic.replace("-", " ").replace("_", " ").title()
    items.append(
        {"@type": "ListItem", "position": 2, "name": topic_title,
         "item": f"{site_url}{prefix}/{page.topic}/"},
    )
    # Page level (if has slug — not topic index)
    if page.slug:
        items.append(
            {"@type": "ListItem", "position": 3, "name": page.title},
        )

    schema = {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": items,
    }
    return json.dumps(schema, ensure_ascii=False)


def build_jsonld(page: Page, config: dict, lang: str = "",
                 languages: list[dict] = None) -> str:
    """Build JSON-LD structured data for a page.

    Routes to schema type based on URL path and frontmatter.
    Returns JSON string or empty string if no schema applies.
    """
    import json

    site_url = config.get("site_url", "").rstrip("/")
    if not site_url:
        return ""

    # Add language prefix for multi-language builds
    prefix = url_prefix(lang, languages)
    page_url = f"{site_url}{prefix}{page.url}"
    created = str(page.meta.get("created", ""))
    modified = str(page.meta.get("date", ""))

    # If no dates in frontmatter, try git
    if not created or not modified:
        git_created, git_modified = _get_git_dates(page.source)
        if not created:
            created = git_created
        if not modified:
            modified = git_modified

    # Google requires full ISO 8601 timestamps in JSON-LD to show dates in SERPs.
    # Date-only values (2026-02-10) get zero SERP date display. (#184)
    # For today's date: use actual current time (avoids claiming a future time).
    # For past dates: derive time from the date string (deterministic, consistent).
    def _to_iso8601(val: str) -> str:
        """Convert date-only to full ISO 8601 with honest time."""
        if val and re.match(r'^\d{4}-\d{2}-\d{2}$', val):
            from datetime import date as _d, datetime as _dt, timezone as _tz
            if val == str(_d.today()):
                # Today: use real current time — never claim a future time
                now = _dt.now(_tz.utc)
                return now.strftime("%Y-%m-%dT%H:%M:%S+00:00")
            # Past dates: deterministic time from date hash
            h = hash(val) & 0xFFFFFFFF
            hour = 8 + (h % 10)        # 08:00-17:00
            minute = (h >> 4) % 60      # 00-59
            second = (h >> 10) % 60     # 00-59
            return f"{val}T{hour:02d}:{minute:02d}:{second:02d}+00:00"
        return val
    created = _to_iso8601(created)
    modified = _to_iso8601(modified)

    schema = None
    og_type = page.meta.get("og_type", "")
    schema_type = page.meta.get("schema_type", "")

    if og_type == "website":
        # Homepage or landing page — WebSite schema with SearchAction (#121)
        schema = {
            "@context": "https://schema.org",
            "@type": "WebSite",
            "name": config["site_name"],
            "url": site_url + prefix + "/",
            "description": config.get("description", ""),
        }
        # Organization publisher for Knowledge Graph (#147)
        org = {"@type": "Organization", "name": config["site_name"]}
        logo = config.get("logo")
        if logo and logo is not False:
            logo_url = (f"{site_url}/{logo.lstrip('/')}"
                        if not str(logo).startswith("http") else str(logo))
            org["logo"] = logo_url
        schema["publisher"] = org
        # SearchAction enables sitelinks search box in SERPs
        if config.get("search", True) is not False:
            schema["potentialAction"] = {
                "@type": "SearchAction",
                "target": f"{site_url}{prefix}/search/?q={{search_term_string}}",
                "query-input": "required name=search_term_string",
            }
    elif schema_type == "Organization" or page.meta.get("company"):
        # Vendor/company page — Organization schema
        schema = {
            "@context": "https://schema.org",
            "@type": "Organization",
            "name": page.title,
            "description": page.description,
            "url": page_url,
        }
        company = page.meta.get("company", {})
        if isinstance(company, dict):
            if company.get("website"):
                schema["url"] = company["website"]
            if company.get("founded"):
                schema["foundingDate"] = str(company["founded"])
            if company.get("address"):
                schema["address"] = company["address"]
        # Product details as SoftwareApplication offer
        product = page.meta.get("product", {})
        if isinstance(product, dict) and product:
            offer = {"@type": "SoftwareApplication", "name": page.title}
            if product.get("deployment"):
                deploy = product["deployment"]
                if isinstance(deploy, list):
                    offer["applicationCategory"] = ", ".join(str(d) for d in deploy)
                else:
                    offer["applicationCategory"] = str(deploy)
            if product.get("certifications"):
                certs = product["certifications"]
                if isinstance(certs, list):
                    offer["featureList"] = ", ".join(str(c) for c in certs)
                else:
                    offer["featureList"] = str(certs)
            schema["makesOffer"] = {"@type": "Offer", "itemOffered": offer}
    elif schema_type == "NewsArticle" or (
            page.topic and page.slug and (
                "news" in page.url.lower()
                or re.match(r'.*\d{4}-\d{2}-\d{2}', page.slug))):
        # News/report page — NewsArticle schema
        schema = {
            "@context": "https://schema.org",
            "@type": "NewsArticle",
            "headline": page.title,
            "description": page.description,
            "url": page_url,
            "mainEntityOfPage": page_url,
        }
        if created:
            schema["datePublished"] = created
        if modified:
            schema["dateModified"] = modified
        if config.get("site_name"):
            schema["publisher"] = {
                "@type": "Organization",
                "name": config["site_name"],
            }
        # Resolve author from frontmatter
        author_slug = page.meta.get("author", "")
        if author_slug:
            docs_dir_path = Path(config.get("docs_dir", "docs"))
            author_info = _resolve_author(author_slug, docs_dir_path)
            if author_info:
                author_entity = {
                    "@type": "Person",
                    "name": author_info["name"],
                    "url": f"{site_url}{author_info['page_url']}",
                }
                # jobTitle for E-E-A-T (#178)
                if author_info.get("role"):
                    author_entity["jobTitle"] = author_info["role"]
                # sameAs links for E-E-A-T (#141)
                if author_info.get("social"):
                    author_entity["sameAs"] = author_info["social"]
                # Reviewer: optional second author → JSON-LD array (#218)
                reviewer_slug = page.meta.get("reviewer", "")
                if reviewer_slug and docs_dir_path:
                    reviewer_info = _resolve_author(reviewer_slug, docs_dir_path)
                    if reviewer_info:
                        reviewer_entity = {
                            "@type": "Person",
                            "name": reviewer_info["name"],
                            "url": f"{site_url}{reviewer_info['page_url']}",
                        }
                        if reviewer_info.get("role"):
                            reviewer_entity["jobTitle"] = reviewer_info["role"]
                        if reviewer_info.get("social"):
                            reviewer_entity["sameAs"] = reviewer_info["social"]
                        schema["author"] = [author_entity, reviewer_entity]
                    else:
                        schema["author"] = author_entity
                else:
                    schema["author"] = author_entity
            else:
                schema["author"] = {
                    "@type": "Person",
                    "name": author_slug.replace("-", " ").title(),
                }
    elif schema_type == "ProfilePage" or (
            page.topic and "authors" in page.url.lower()):
        # Author/profile page — ProfilePage schema
        schema = {
            "@context": "https://schema.org",
            "@type": "ProfilePage",
            "name": page.title,
            "description": page.description,
            "url": page_url,
            "mainEntity": {
                "@type": "Person",
                "name": page.title,
            },
        }
    elif page.topic and page.slug:
        # Content page — Article schema (default for content pages)
        article_type = schema_type if schema_type else "Article"
        schema = {
            "@context": "https://schema.org",
            "@type": article_type,
            "headline": page.title,
            "description": page.description,
            "url": page_url,
            "mainEntityOfPage": page_url,
        }
        if created:
            schema["datePublished"] = created
        if modified:
            schema["dateModified"] = modified
        if config.get("site_name"):
            schema["publisher"] = {
                "@type": "Organization",
                "name": config["site_name"],
            }
        # Resolve author from frontmatter
        author_slug = page.meta.get("author", "")
        if author_slug:
            docs_dir_path = Path(config.get("docs_dir", "docs"))
            author_info = _resolve_author(author_slug, docs_dir_path)
            if author_info:
                author_entity = {
                    "@type": "Person",
                    "name": author_info["name"],
                    "url": f"{site_url}{author_info['page_url']}",
                }
                # jobTitle for E-E-A-T (#178)
                if author_info.get("role"):
                    author_entity["jobTitle"] = author_info["role"]
                # sameAs links for E-E-A-T (#141)
                if author_info.get("social"):
                    author_entity["sameAs"] = author_info["social"]
                # Reviewer: optional second author → JSON-LD array (#218)
                reviewer_slug = page.meta.get("reviewer", "")
                if reviewer_slug and docs_dir_path:
                    reviewer_info = _resolve_author(reviewer_slug, docs_dir_path)
                    if reviewer_info:
                        reviewer_entity = {
                            "@type": "Person",
                            "name": reviewer_info["name"],
                            "url": f"{site_url}{reviewer_info['page_url']}",
                        }
                        if reviewer_info.get("role"):
                            reviewer_entity["jobTitle"] = reviewer_info["role"]
                        if reviewer_info.get("social"):
                            reviewer_entity["sameAs"] = reviewer_info["social"]
                        schema["author"] = [author_entity, reviewer_entity]
                    else:
                        schema["author"] = author_entity
                else:
                    schema["author"] = author_entity
            else:
                # Fallback: use slug as name if author page doesn't exist
                schema["author"] = {
                    "@type": "Person",
                    "name": author_slug.replace("-", " ").title(),
                }
    elif page.topic and not page.slug:
        # Topic index page — CollectionPage
        schema = {
            "@context": "https://schema.org",
            "@type": "CollectionPage",
            "name": page.title,
            "description": page.description,
            "url": page_url,
        }
    elif schema_type:
        # Explicit schema_type in frontmatter (e.g. WebPage for root pages)
        schema = {
            "@context": "https://schema.org",
            "@type": schema_type,
            "name": page.title,
            "description": page.description,
            "url": page_url,
        }

    if not schema:
        return ""

    # Enrich Article/NewsArticle with wordCount + image + timeRequired (#109, #140)
    if schema.get("@type") in ("Article", "NewsArticle"):
        if hasattr(page, 'reading_time') and page.reading_time:
            schema["wordCount"] = page.reading_time * 200
            schema["timeRequired"] = f"PT{page.reading_time}M"
        page_image = page.meta.get("image", "")
        if page_image:
            schema["image"] = (f"{site_url}{page_image}"
                               if not page_image.startswith("http")
                               else page_image)
        elif config.get("theme", {}).get("og_image"):
            og_val = config["theme"]["og_image"]
            if og_val.startswith("http"):
                schema["image"] = og_val
            else:
                schema["image"] = f"{site_url}/{og_val.lstrip('/')}"

    return json.dumps(schema, ensure_ascii=False)


def _to_rfc822(date_val) -> str:
    """Convert a date string or date object to RFC 822 format for RSS.

    Uses same time logic as JSON-LD: today = real time, past = hash-derived.
    Never outputs 00:00:00 (looks automated).
    """
    from email.utils import format_datetime as _fmt_dt
    import datetime as _dt_mod
    if not date_val:
        return ""
    if hasattr(date_val, "strftime"):
        s = date_val.strftime("%Y-%m-%d")
    else:
        s = str(date_val).strip()
    # Parse date part
    for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            dt = datetime.strptime(s[:10], "%Y-%m-%d")
            break
        except ValueError:
            continue
    else:
        return s
    # Apply same time logic as JSON-LD (#184): today=now, past=hash
    date_str = dt.strftime("%Y-%m-%d")
    if date_str == str(_dt_mod.date.today()):
        now = _dt_mod.datetime.now(_dt_mod.timezone.utc)
        dt = dt.replace(hour=now.hour, minute=now.minute, second=now.second)
    else:
        h = hash(date_str) & 0xFFFFFFFF
        dt = dt.replace(hour=8 + (h % 10), minute=(h >> 4) % 60,
                        second=(h >> 10) % 60)
    dt = dt.replace(tzinfo=_dt_mod.timezone.utc)
    return _fmt_dt(dt)


def generate_rss(pages: list[Page], config: dict, output_dir: Path,
                 lang: str = ""):
    """Generate RSS 2.0 feed (feed.xml) compatible with follow.it and other readers."""
    site_url = config.get("site_url", "").rstrip("/")
    if not site_url:
        return

    # Only include pages that have dates — prefer created (publication date)
    dated_pages = [p for p in pages if p.meta.get("created") or p.meta.get("date")]
    if not dated_pages:
        return

    # Sort by date (last modified) descending, then created — RSS shows
    # recently updated content first, not just recently published (#175)
    def _date_key(p):
        val = p.meta.get("date", p.meta.get("created", ""))
        return str(val) if val else ""
    dated_pages.sort(key=_date_key, reverse=True)
    dated_pages = dated_pages[:20]

    prefix = f"/{lang}" if lang else ""
    feed_url = f"{site_url}{prefix}/feed.xml"
    site_name = html_module.escape(config["site_name"])
    site_desc = html_module.escape(config.get("description", ""))
    feed_lang = lang or config.get("lang", "en")
    now_rfc822 = _to_rfc822(datetime.now(__import__("datetime").timezone.utc
                                       ).strftime("%Y-%m-%d %H:%M:%S"))

    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">',
        '<channel>',
        f'  <title>{site_name}</title>',
        f'  <description>{site_desc}</description>',
        f'  <link>{site_url}{prefix}/</link>',
        f'  <atom:link href="{feed_url}" rel="self" type="application/rss+xml"/>',
        f'  <language>{feed_lang}</language>',
        f'  <pubDate>{now_rfc822}</pubDate>',
        f'  <lastBuildDate>{now_rfc822}</lastBuildDate>',
        '  <ttl>1440</ttl>',
        '  <generator>Wire</generator>',
    ]

    for page in dated_pages:
        title = html_module.escape(page.title)
        desc = html_module.escape(page.description)
        url = f"{site_url}{prefix}{page.url}"
        pub_date = _to_rfc822(page.meta.get("date", page.meta.get("created", "")))
        lines.append("  <item>")
        lines.append(f"    <title>{title}</title>")
        lines.append(f"    <description>{desc}</description>")
        lines.append(f"    <link>{url}</link>")
        if pub_date:
            lines.append(f"    <pubDate>{pub_date}</pubDate>")
        lines.append(f'    <source url="{feed_url}">{site_name}</source>')
        lines.append(f'    <guid isPermaLink="true">{url}</guid>')
        lines.append("  </item>")

    lines.append("</channel>")
    lines.append("</rss>")
    content = "\n".join(lines)
    (output_dir / "feed.xml").write_text(content, encoding="utf-8")
    # Legacy alias for existing feed readers (follow.it, etc.)
    (output_dir / "feed_rss_created.xml").write_text(content, encoding="utf-8")


def generate_search_index(pages: list[Page], output_dir: Path):
    """Generate search_index.json for client-side full-text search.

    Each entry contains title, description, url, and first 500 words
    of body text (stripped of markdown syntax).
    """
    import json

    _MD_STRIP = re.compile(
        r'```[\s\S]*?```'         # fenced code blocks
        r'|`[^`]+`'              # inline code
        r'|!?\[[^\]]*\]\([^)]*\)' # links/images
        r'|#{1,6}\s+'            # heading markers
        r'|\*{1,3}|_{1,3}'      # bold/italic
        r'|^\s*[-*+]\s'          # list markers
        r'|^\s*\d+\.\s'         # ordered lists
        r'|<[^>]+>'             # HTML tags
        r'|^\s*>\s',            # blockquotes
        re.MULTILINE,
    )

    entries = []
    for page in pages:
        body = page.raw_body or ""
        clean = _MD_STRIP.sub(" ", body)
        words = clean.split()[:500]
        entries.append({
            "title": page.meta.get("title", ""),
            "description": page.meta.get("description", ""),
            "url": page.url,
            "body": " ".join(words),
        })

    index_path = output_dir / "search_index.json"
    index_path.write_text(json.dumps(entries, ensure_ascii=False), encoding="utf-8")


def generate_llms_txt(pages: list[Page], config: dict, output_dir: Path,
                      lang: str = ""):
    """Generate /llms.txt — machine-readable site summary for AI agents.

    Follows the emerging llms.txt specification (llmstxt.org).
    Groups pages by topic with title and truncated description.
    """
    site_name = config.get("site_name", "Wire Site")
    site_desc = config.get("description", "")
    site_url = config.get("site_url", "").rstrip("/")
    prefix = f"/{lang}" if lang else ""

    lines = [f"# {site_name}"]
    if site_desc:
        lines.append(f"> {site_desc}")
    lines.append("")

    # Group pages by topic
    topics: dict[str, list[Page]] = {}
    for page in sorted(pages, key=lambda p: p.url):
        topic = page.topic or "Pages"
        topics.setdefault(topic, []).append(page)

    for topic_name, topic_pages in sorted(topics.items()):
        # Capitalize topic name for readability
        heading = topic_name.replace("-", " ").replace("_", " ").title()
        lines.append(f"## {heading}")
        for page in topic_pages:
            title = page.meta.get("title", "Untitled")
            desc = page.meta.get("description", "")
            if desc and len(desc) > 100:
                desc = desc[:97] + "..."
            url = page.url
            if site_url:
                url = f"{site_url}{prefix}{url}"
            if desc:
                lines.append(f"- [{title}]({url}): {desc}")
            else:
                lines.append(f"- [{title}]({url})")
        lines.append("")

    (output_dir / "llms.txt").write_text("\n".join(lines), encoding="utf-8")


def generate_bot_dir(pages: list[Page], config: dict, output_dir: Path,
                     docs_dir: Path):
    """Generate /bot/ directory with agent-facing site context.

    Opt-in via extra.wire.bot_dir: true in wire.yml (#179).
    Default is off — customers must explicitly choose to expose site
    structure to AI agents. Without opt-in, no /bot/ is generated.

    Produces two files:
      bot/README.md    — site name, topics, page counts, CTA, structure
      bot/_styleguide.md — copy of docs/_styleguide.md (if it exists)

    This is build output, same pattern as sitemap.xml or llms.txt.
    External agents curl these files to understand the site.
    """
    # Opt-in: only generate when explicitly enabled (#179)
    wire_config = config.get("extra", {}).get("wire", {})
    if not wire_config.get("bot_dir"):
        return

    bot_dir = output_dir / "bot"
    bot_dir.mkdir(parents=True, exist_ok=True)

    # 1. Copy styleguide if it exists
    styleguide = docs_dir / "_styleguide.md"
    if styleguide.exists():
        shutil.copy2(styleguide, bot_dir / "_styleguide.md")

    # 2. Generate README.md from config + pages
    site_name = config.get("site_name", "Wire Site")
    site_url = config.get("site_url", "").rstrip("/")
    lang = config.get("lang", "")
    wire_config = config.get("extra", {}).get("wire", {})
    sidebar_cta = wire_config.get("sidebar_cta", {})

    # Group pages by topic with counts
    topics: dict[str, int] = {}
    for page in pages:
        topic = page.topic or "pages"
        topics[topic] = topics.get(topic, 0) + 1

    lines = [
        f"# {site_name}",
        "",
        f"Site: {site_url}" if site_url else "",
        f"Language: {lang}" if lang else "",
        "",
        "## Topics",
        "",
    ]
    # Remove empty lines from conditional fields
    lines = [l for l in lines if l != "" or lines[lines.index(l) - 1] != ""]

    for topic_name in sorted(topics):
        count = topics[topic_name]
        heading = topic_name.replace("-", " ").replace("_", " ").title()
        lines.append(f"- **{heading}**: {count} page(s)")

    lines.append("")
    lines.append(f"Total: {len(pages)} pages")
    lines.append("")

    # CTA information
    if sidebar_cta:
        lines.append("## Call to Action")
        lines.append("")
        if sidebar_cta.get("title"):
            lines.append(f"- {sidebar_cta['title']}")
        if sidebar_cta.get("description"):
            lines.append(f"- {sidebar_cta['description']}")
        if sidebar_cta.get("link"):
            lines.append(f"- Link: {sidebar_cta['link']}")
        lines.append("")

    # Styleguide pointer
    if styleguide.exists():
        lines.append("## Writing Style")
        lines.append("")
        lines.append(
            "Read the styleguide before creating or editing content:")
        lines.append(f"  {site_url}/bot/_styleguide.md"
                     if site_url else "  /bot/_styleguide.md")
        lines.append("")

    (bot_dir / "README.md").write_text(
        "\n".join(lines), encoding="utf-8")
    logger.info(f"Generated bot/ directory ({len(topics)} topics)")


def _check_redirect_source_conflicts(redirects: list[dict],
                                      docs_dir: Path) -> list[str]:
    """Check for redirect sources that also have a docs file — ambiguous state.

    Returns list of error messages. Empty = no conflicts.
    """
    errors = []
    for r in redirects:
        from_path = r.get("from", "").strip("/")
        if not from_path:
            continue
        source_file = docs_dir / from_path / "index.md"
        if source_file.exists():
            errors.append(
                f"CONFLICT: redirect /{from_path}/ has a source file at "
                f"{source_file.relative_to(docs_dir.parent)}. "
                f"Delete the file or remove the redirect.")
    return errors


def generate_redirects(site_dir: Path, output_dir: Path):
    """Generate redirect files from load_redirects() (both .wire/ and wire.yml).

    Output format is Netlify/Cloudflare Pages compatible:
      /old-path/ /new-path/ 301
      /deleted-path/ 410
    Also generates HTML pages as fallback for static hosts:
      301 → meta-refresh redirect
      410 → "Gone" page (no redirect)
    """
    from wire.tools import load_redirects
    redirects = load_redirects(site_dir=site_dir)
    if not redirects:
        return

    # Generate _redirects file (Netlify/Cloudflare format)
    lines = ["# Auto-generated by Wire. Do not edit manually.", ""]
    for r in redirects:
        from_url = r.get("from", "")
        to_url = r.get("to", "")
        status = r.get("status", 301)
        if not from_url:
            continue
        if to_url and status != 410:
            lines.append(f"{from_url} {to_url} {status}")
        elif status == 410:
            lines.append(f"{from_url} {status}")
        else:
            continue  # No to and not 410 — skip
    (output_dir / "_redirects").write_text("\n".join(lines) + "\n", encoding="utf-8")

    # Generate HTML pages as fallback (static hosts)
    for r in redirects:
        from_url = r.get("from", "").strip("/")
        to_url = r.get("to", "")
        status = r.get("status", 301)
        if not from_url:
            continue
        redirect_dir = output_dir / from_url
        redirect_dir.mkdir(parents=True, exist_ok=True)

        if status == 410:
            # Gone page — no redirect, inform crawlers
            gone_html = (
                '<!DOCTYPE html>\n'
                '<html><head><title>410 Gone</title></head>\n'
                '<body><h1>410 Gone</h1>'
                '<p>This page has been permanently removed.</p></body></html>\n'
            )
            (redirect_dir / "index.html").write_text(gone_html, encoding="utf-8")
        elif to_url:
            redirect_html = (
                '<!DOCTYPE html>\n'
                f'<html><head><meta http-equiv="refresh" content="0; url={to_url}">'
                f'<link rel="canonical" href="{to_url}"></head>\n'
                f'<body><p>Moved to <a href="{to_url}">{to_url}</a></p></body></html>\n'
            )
            (redirect_dir / "index.html").write_text(redirect_html, encoding="utf-8")

    logger.info(f"Redirects: {len(redirects)} entries")


def _suggest_cross_lang_redirect(url: str,
                                 redirect_map: dict) -> dict | None:
    """Find a cross-language redirect for an uncovered URL.

    If /en/slug/ has no redirect but /de/slug/ → /topic/slug/ exists,
    returns {'from': '/de/slug/', 'to': '/topic/slug/'}.
    """
    # Extract slug from URL: strip language prefix like /en/, /de/, /fr/, /es/
    parts = url.strip("/").split("/")
    if len(parts) < 2:
        return None
    lang_prefix = parts[0]
    # Only match 2-letter language prefixes
    if len(lang_prefix) != 2:
        return None
    slug_part = "/".join(parts[1:])

    # Check all redirects for a matching slug with different language prefix
    for source, target in redirect_map.items():
        source_parts = source.strip("/").split("/")
        if len(source_parts) < 2:
            continue
        source_lang = source_parts[0]
        if len(source_lang) != 2 or source_lang == lang_prefix:
            continue
        source_slug = "/".join(source_parts[1:])
        if source_slug == slug_part:
            return {"from": source, "to": target}

    return None


def check_seo_audit(site_dir: Path = None, docs_dir: Path = None) -> list[str]:
    """Check for unresolved content cannibalization (hard overlaps).

    Returns list of error messages for hard overlaps. Empty list = clean.
    Silently returns empty if no GSC database exists.
    """
    if docs_dir is not None:
        db_path = Path(docs_dir).resolve().parent / ".wire" / "gsc.db"
    elif site_dir is not None:
        db_path = Path(site_dir) / ".wire" / "gsc.db"
    else:
        return []

    if not db_path.exists():
        return []

    try:
        from wire.db import find_overlaps
        overlaps = find_overlaps(docs_dir=docs_dir)
    except Exception:
        return []

    if not overlaps:
        return []

    # Classify hard overlaps: ratio > 0.4, skew > 0.7, same topic
    hard = []
    for ov in overlaps:
        ratio = ov["overlap_ratio"]
        skew = max(ov["traffic_share_a"], 1 - ov["traffic_share_a"])
        cross_topic = ov.get("topic_a") != ov.get("topic_b")
        if ratio > 0.4 and skew > 0.7 and not cross_topic:
            hard.append(ov)

    if not hard:
        return []

    # Collect affected topics for the error message
    topics = sorted({ov["topic_a"] for ov in hard})
    topic_hint = " → ".join(
        f"python -m wire.chief audit {t} → deduplicate {t}" for t in topics
    )
    errors = [
        f"BUILD REFUSED: {len(hard)} content cannibalization issue(s) detected. "
        f"Run: {topic_hint}"
    ]
    for ov in hard:
        errors.append(
            f"  Hard overlap: {ov['topic_a']}/{ov['slug_a']} ↔ "
            f"{ov['topic_b']}/{ov['slug_b']} "
            f"(ratio={ov['overlap_ratio']}, "
            f"skew={max(ov['traffic_share_a'], 1 - ov['traffic_share_a']):.2f})"
        )

    return errors


def check_gsc_coverage(page_urls: set, redirects: list[dict],
                       docs_dir: Path = None,
                       exclude_gsc_data_for_path: list = None) -> list[str]:
    """Check that every GSC URL with impressions is covered by a page or redirect.

    Returns list of error messages for uncovered URLs. Empty list = all covered.
    Silently returns empty if no GSC URL discovery data exists.
    """
    try:
        from wire.db import get_gsc_urls
        gsc_urls = get_gsc_urls(docs_dir=docs_dir)
    except Exception:
        return []

    if not gsc_urls:
        return []

    redirect_sources = {r.get("from", "") for r in redirects}
    redirect_map = {r.get("from", ""): r.get("to", "") for r in redirects
                    if r.get("from") and r.get("to")}
    # Normalize page URLs to have trailing slashes
    normalized_pages = set()
    for p in page_urls:
        normalized_pages.add(p)
        if not p.endswith("/"):
            normalized_pages.add(p + "/")
        else:
            normalized_pages.add(p.rstrip("/"))
    # Case-insensitive lookup for case-insensitive filesystems (Windows)
    normalized_pages_lower = {p.lower() for p in normalized_pages}

    errors = []
    for entry in gsc_urls:
        url = entry["url"]
        impressions = entry.get("impressions", 0)
        if impressions == 0:
            continue
        # Strip fragment — GSC tracks /#section URLs but the base page covers them
        base_url = url.split("#")[0] if "#" in url else url
        # Skip asset URLs (images, CSS, JS) — not pages
        if any(base_url.endswith(ext) for ext in (".png", ".jpg", ".jpeg", ".webp",
                                                   ".gif", ".svg", ".css", ".js")):
            continue
        # Skip excluded paths (e.g. /tools/ — web apps on the same domain)
        if exclude_gsc_data_for_path and any(
                base_url.startswith(prefix) for prefix in exclude_gsc_data_for_path):
            continue
        # Check coverage: page exists OR redirect exists
        if base_url in normalized_pages or base_url in redirect_sources:
            continue
        if url in normalized_pages or url in redirect_sources:
            continue
        # Multi-language: GSC reports /en/about/ but page_urls has /about/
        # Strip 2-letter lang prefix and check again
        _parts = base_url.strip("/").split("/", 1)
        if len(_parts) >= 2 and len(_parts[0]) == 2:
            stripped = "/" + _parts[1]
            if not stripped.endswith("/"):
                stripped += "/"
            if stripped in normalized_pages or stripped.rstrip("/") in normalized_pages:
                continue
        # Case-insensitive match — Windows FS is case-insensitive, GSC may
        # report /vendors/tiny-IDP/ while real page is /vendors/tiny-idp/
        if base_url.lower() in normalized_pages_lower:
            continue
        # Try with/without trailing slash
        alt = base_url.rstrip("/") + "/" if not base_url.endswith("/") else base_url.rstrip("/")
        if alt in normalized_pages or alt in redirect_sources:
            continue
        # Check for cross-language redirect suggestion
        suggestion = _suggest_cross_lang_redirect(base_url, redirect_map)
        msg = (f"GSC URL {url} ({impressions} impressions) has no page "
               f"and no redirect.")
        if suggestion:
            msg += (f"\n  Similar redirect exists: {suggestion['from']} "
                    f"→ {suggestion['to']}\n"
                    f"  Suggested: {base_url} → {suggestion['to']}")
        else:
            msg += " Add a redirect or 410 entry in wire.yml."
        errors.append(msg)

    return errors


def summarize_excluded_traffic(exclude_prefixes: list,
                                docs_dir: Path = None) -> list[dict]:
    """Summarize GSC traffic hidden by exclude_gsc_data_for_path.

    Returns [{'prefix': str, 'impressions': int, 'clicks': int}] for each
    prefix that hides at least one URL with impressions. Empty list if no
    exclusions or no GSC data.
    """
    if not exclude_prefixes:
        return []

    try:
        from wire.db import get_gsc_urls
        gsc_urls = get_gsc_urls(docs_dir=docs_dir)
    except Exception:
        return []

    if not gsc_urls:
        return []

    totals = {}
    for prefix in exclude_prefixes:
        totals[prefix] = {"prefix": prefix, "impressions": 0, "clicks": 0}

    for entry in gsc_urls:
        url = entry["url"]
        imp = entry.get("impressions", 0)
        clicks = entry.get("clicks", 0)
        if imp == 0 and clicks == 0:
            continue
        for prefix in exclude_prefixes:
            if url.startswith(prefix):
                totals[prefix]["impressions"] += imp
                totals[prefix]["clicks"] += clicks
                break  # each URL counted once

    return [t for t in totals.values() if t["impressions"] > 0 or t["clicks"] > 0]


def copy_assets(docs_dir: Path, output_dir: Path):
    """Copy non-markdown assets (CSS, JS, images) to output directory.

    Copies default assets from wire/assets/ first, then overlays the
    customer's docs/assets/ on top so they can override individual files.
    """
    dest = output_dir / "assets"

    # 1. Copy defaults from wire/assets/
    if DEFAULT_ASSETS_DIR.exists():
        # Preserve build-generated directories (e.g. yt/ thumbnails)
        yt_dir = dest / "yt"
        yt_backup = None
        if yt_dir.exists():
            yt_backup = output_dir / ".yt_backup"
            if yt_backup.exists():
                shutil.rmtree(yt_backup)
            shutil.move(str(yt_dir), str(yt_backup))
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(DEFAULT_ASSETS_DIR, dest)
        if yt_backup and yt_backup.exists():
            shutil.move(str(yt_backup), str(yt_dir))

    # 2. Overlay customer's assets on top
    assets_dir = docs_dir / "assets"
    if assets_dir.exists():
        if not dest.exists():
            shutil.copytree(assets_dir, dest)
        else:
            shutil.copytree(assets_dir, dest, dirs_exist_ok=True)

    # Copy any other non-markdown files (images in content dirs, etc.)
    # Skip files Wire generates at build time — stale source copies would overwrite them
    _wire_generated = {"robots.txt", "llms.txt", "llms-full.txt", "sitemap.xml",
                       "feed.xml", "feed_rss_created.xml", "search_index.json"}
    for f in docs_dir.rglob("*"):
        if f.is_file() and f.suffix not in (".md", ".yml", ".yaml"):
            if f.name in _wire_generated:
                logger.warning(f"Skipping docs/{f.relative_to(docs_dir)}: "
                               f"Wire generates this file at build time")
                continue
            rel = f.relative_to(docs_dir)
            dest = output_dir / rel
            if not dest.exists():
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(f, dest)

    # Minify CSS files (strip comments and collapse whitespace)
    css_dir = output_dir / "assets" / "css"
    if css_dir.exists():
        for css_file in css_dir.glob("*.css"):
            _minify_css(css_file)


def copy_dirs(config: dict, output_dir: Path):
    """Copy verbatim directories listed in wire.yml copy_dirs to output.

    These are non-content directories (HTML/JS apps, tools, etc.) that
    should be copied as-is without markdown processing.
    """
    dirs_to_copy = config.get("copy_dirs", [])
    if not dirs_to_copy:
        return

    docs_dir = config["docs_dir"]
    for dir_name in dirs_to_copy:
        src = docs_dir / dir_name
        dst = output_dir / dir_name
        if not src.exists():
            logger.warning(f"copy_dirs: '{dir_name}' not found in {docs_dir}, skipping")
            continue
        if not src.is_dir():
            logger.warning(f"copy_dirs: '{dir_name}' is not a directory, skipping")
            continue
        shutil.copytree(src, dst, dirs_exist_ok=True)
        logger.info(f"Copied {dir_name}/ to output")


def _minify_html(html_text: str) -> str:
    """Minify HTML: strip comments, collapse whitespace.

    Preserves whitespace inside <pre>, <code>, <script>, <style>, and
    <textarea> blocks. Preserves IE conditional comments.
    """
    # Extract and protect pre/code/script/style/textarea blocks
    protected = []
    protect_re = re.compile(
        r'(<(?:pre|code|script|style|textarea)\b[^>]*>)(.*?)(</(?:pre|code|script|style|textarea)>)',
        re.DOTALL | re.IGNORECASE
    )

    def _protect(m):
        idx = len(protected)
        protected.append(m.group(0))
        return f'\x00PROTECTED{idx}\x00'

    html_text = protect_re.sub(_protect, html_text)

    # Strip HTML comments (but keep IE conditionals <!--[if ...)
    html_text = re.sub(r'<!--(?!\[if\s).*?-->', '', html_text, flags=re.DOTALL)

    # Collapse whitespace between tags
    html_text = re.sub(r'>\s+<', '> <', html_text)

    # Collapse runs of whitespace to single space
    html_text = re.sub(r'\s{2,}', ' ', html_text)

    # Restore protected blocks
    for idx, block in enumerate(protected):
        html_text = html_text.replace(f'\x00PROTECTED{idx}\x00', block)

    return html_text.strip()


def _minify_css(path: Path):
    """Minify a CSS file in-place. Strips comments and collapses whitespace."""
    import re
    css = path.read_text(encoding="utf-8")
    original_size = len(css)
    # Remove block comments
    css = re.sub(r'/\*.*?\*/', '', css, flags=re.DOTALL)
    # Collapse whitespace around structural characters
    css = re.sub(r'\s*([{}:;,])\s*', r'\1', css)
    # Collapse runs of whitespace to single space
    css = re.sub(r'\s+', ' ', css)
    css = css.strip()
    path.write_text(css, encoding="utf-8")
    saved = original_size - len(css)
    if saved > 0:
        logger.debug(f"Minified {path.name}: {original_size:,} -> {len(css):,} ({saved:,} bytes saved)")


_LANGUAGE_ASYMMETRY_THRESHOLD = 0.20  # 20%

_PENDING_NEWS_RE = re.compile(r'^\d{4}-\d{2}-\d{2}\.md$')


def check_pending_news(docs_dir: Path) -> list[str]:
    """Check for unprocessed pending news files in content directories.

    Pending news files are YYYY-MM-DD.md directly inside a content item
    directory (not inside a news/ subdirectory, which means archived).
    Tracker files (type: tracker in frontmatter) are excluded.

    Returns list of error messages. Empty list = no pending news.
    """
    # Map: relative content path → list of pending news dates
    pending: dict[str, list[str]] = {}

    for md_file in sorted(docs_dir.rglob("*.md")):
        if not _PENDING_NEWS_RE.match(md_file.name):
            continue
        # Skip archived news (inside a news/ subdirectory)
        rel = md_file.relative_to(docs_dir)
        rel_parts = rel.parts
        if "news" in rel_parts:
            continue
        # Skip tracker files
        try:
            post = fm.load(md_file)
            if post.get("type") == "tracker":
                continue
        except Exception:
            continue
        # Build content path (parent directory relative to docs_dir)
        content_path = "/" + str(rel.parent).replace("\\", "/") + "/"
        pending.setdefault(content_path, []).append(md_file.stem)

    if not pending:
        return []

    total = sum(len(dates) for dates in pending.values())
    lines = [
        f"BUILD REFUSED: {total} page(s) have unprocessed pending news\n"
    ]
    for path, dates in sorted(pending.items()):
        latest = max(dates)
        count_label = (f"{len(dates)} pending news file"
                       + ("s" if len(dates) != 1 else ""))
        lines.append(f"  {path} — {count_label} (latest: {latest})")
    lines.append("")
    lines.append("  Run: python -m wire.chief refine <topic>")
    return ["\n".join(lines)]


# Files that are allowed at site root (not migration artifacts)
_ALLOWED_ROOT_PY = {"setup.py", "conftest.py"}


def _check_migration_artifacts(site_dir: Path) -> list[str]:
    """Gate 4: Check for leftover migration scripts at site root.

    *.py files at the site root (except allowed ones) indicate
    the customer hasn't cleaned up after migration. BUILD REFUSED.
    """
    errors = []
    for f in site_dir.glob("*.py"):
        if f.name not in _ALLOWED_ROOT_PY:
            errors.append(
                f"Migration artifact at site root: {f.name}. "
                f"Delete migration scripts after migration is complete. "
                f"See: /guides/post-migration/")
    return errors


_LANGUAGE_DIR_CODES = {
    "af", "ar", "bg", "bn", "ca", "cs", "cy", "da", "de", "el", "en", "es",
    "et", "eu", "fa", "fi", "fr", "ga", "gl", "gu", "he", "hi", "hr", "hu",
    "hy", "id", "is", "it", "ja", "ka", "kk", "km", "kn", "ko", "lb", "lo",
    "lt", "lv", "mk", "ml", "mn", "mr", "ms", "my", "nb", "ne", "nl", "nn",
    "no", "pa", "pl", "pt", "ro", "ru", "si", "sk", "sl", "sq", "sr", "sv",
    "sw", "ta", "te", "th", "tr", "uk", "ur", "uz", "vi", "zh",
}


def _check_orphan_language_dirs(docs_parent: Path,
                                 configured_codes: set[str]) -> list[str]:
    """Gate 2: Check for language dirs that exist but aren't configured.

    Catches leftover fr/ or es/ dirs from WordPress migrations.
    Only flags 2-letter dirs that look like language codes.
    """
    errors = []
    if not docs_parent.is_dir():
        return errors
    for d in sorted(docs_parent.iterdir()):
        if not d.is_dir():
            continue
        code = d.name
        if len(code) == 2 and code in _LANGUAGE_DIR_CODES:
            if code not in configured_codes:
                # Check it actually has content (not just empty dir)
                if any(d.rglob("*.md")):
                    errors.append(
                        f"Directory '{code}/' exists with content but is not "
                        f"in languages config. Either add it to wire.yml "
                        f"languages or delete the directory.")
    return errors


def _check_orphan_language_config(languages: list[dict],
                                   existing_dirs: set[str]) -> list[str]:
    """Gate 3: Check for configured languages whose dirs don't exist.

    Catches typos or premature language config.
    """
    errors = []
    for lang in languages:
        code = lang["code"]
        if code not in existing_dirs:
            errors.append(
                f"Language '{code}' is configured but its docs directory "
                f"does not exist. Either create the directory or remove "
                f"'{code}' from wire.yml languages.")
    return errors


def _check_language_asymmetry(page_counts: dict[str, int],
                               default_lang: str) -> list[str]:
    """Gate 1: Check language page count asymmetry.

    If any configured language has <20% of the default language's page count,
    BUILD REFUSED. This catches ghost-town translations.

    Args:
        page_counts: {lang_code: page_count}
        default_lang: The default language code

    Returns list of error strings. Empty = all clean.
    """
    errors = []
    default_count = page_counts.get(default_lang, 0)
    if default_count == 0:
        return errors

    for code, count in page_counts.items():
        if code == default_lang:
            continue
        ratio = count / default_count
        if ratio < _LANGUAGE_ASYMMETRY_THRESHOLD:
            pct = int(ratio * 100)
            errors.append(
                f"Language '{code}' has {count} pages ({pct}% of "
                f"'{default_lang}' with {default_count}). "
                f"This looks like a ghost-town translation. "
                f"Remove '{code}' from languages config or add content.")
    return errors


def _check_duplicate_titles_across_languages(
        titles_by_lang: dict[str, list[str]]) -> list[str]:
    """Gate 13: Check for untranslated titles across languages.

    If the same title appears in multiple languages, it likely wasn't
    translated. BUILD REFUSED.

    Args:
        titles_by_lang: {lang_code: [list of page titles]}
    """
    errors = []
    if len(titles_by_lang) < 2:
        return errors

    langs = list(titles_by_lang.keys())
    for i, lang1 in enumerate(langs):
        for lang2 in langs[i + 1:]:
            shared = set(titles_by_lang[lang1]) & set(titles_by_lang[lang2])
            for title in sorted(shared):
                errors.append(
                    f"Title '{title}' appears in both '{lang1}' and "
                    f"'{lang2}' — likely untranslated. Translate or "
                    f"differentiate the title.")
    return errors


# Stopword sets for language detection (Gate 14)
# Function words that appear constantly in natural text regardless of topic.
_STOPWORDS = {
    "de": {"der", "die", "das", "und", "ist", "in", "von", "für", "mit",
           "ein", "eine", "auf", "den", "des", "dem", "nicht", "sich",
           "auch", "als", "wie", "oder", "wir", "ihr", "uns"},
    "en": {"the", "and", "is", "in", "of", "for", "with", "that", "this",
           "are", "was", "not", "from", "but", "have", "has", "been",
           "also", "our", "can", "will", "how", "you", "your", "we"},
    "es": {"el", "la", "los", "las", "de", "en", "un", "una", "del",
           "que", "por", "con", "para", "como", "más", "sus", "son",
           "esta", "este", "pero", "ser", "está", "nos", "nuestro"},
    "fr": {"le", "la", "les", "de", "des", "un", "une", "du", "en",
           "est", "que", "qui", "dans", "pour", "par", "sur", "avec",
           "sont", "pas", "nous", "vous", "cette", "nos", "ses"},
}
_MIN_WORDS_FOR_DETECTION = 50  # skip short pages


def _detect_language(text: str) -> str | None:
    """Detect language of text using stopword ratio.

    Returns 2-letter language code or None if inconclusive.
    Only supports languages in _STOPWORDS.
    """
    words = re.findall(r'\b[a-zäöüßéèêëàâçîïôùûñ]+\b', text.lower())
    if len(words) < _MIN_WORDS_FOR_DETECTION:
        return None

    scores = {}
    for lang, stops in _STOPWORDS.items():
        scores[lang] = sum(1 for w in words if w in stops)

    if not scores:
        return None

    best = max(scores, key=scores.get)
    total_stops = sum(scores.values())
    if total_stops == 0:
        return None

    # Only flag if the dominant language has >60% of all stopword hits
    if scores[best] / total_stops > 0.6:
        return best
    return None


def _check_untranslated_bodies(
        bodies_by_lang: dict[str, dict[str, str]]) -> list[str]:
    """Gate 14: Check for untranslated page bodies across languages.

    Uses stopword ratio to detect when a page's content doesn't match
    its language directory. BUILD REFUSED.

    Args:
        bodies_by_lang: {lang_code: {page_url: body_text}}
    """
    errors = []
    if len(bodies_by_lang) < 2:
        return errors

    for expected_lang, pages in bodies_by_lang.items():
        if expected_lang not in _STOPWORDS:
            supported = ", ".join(sorted(_STOPWORDS.keys()))
            errors.append(
                f"Language '{expected_lang}' has no stopword set for "
                f"translation detection. Supported: {supported}. "
                f"Add stopwords for '{expected_lang}' to wire/build.py "
                f"or request support via GitHub issue.")
            continue
        for url, body in pages.items():
            detected = _detect_language(body)
            if detected and detected != expected_lang:
                errors.append(
                    f"Page '{url}' is in '{expected_lang}' directory but "
                    f"content appears to be '{detected}' (stopword analysis). "
                    f"Translate the page or move it to the correct language "
                    f"directory.")
    return errors


def _build_language(docs_dir: Path, output_dir: Path, config: dict,
                    env: jinja2.Environment, dirty: bool = False,
                    lang: str = "",
                    languages: list[dict] = None,
                    hreflang_map: dict = None) -> dict:
    """Build one language's pages into output_dir.

    Core build logic extracted from build() so it can be called once
    (single-language) or per language (multi-language).

    Returns dict with page_count, errors, all_pages.
    """
    pages = collect_pages(docs_dir, config.get("exclude"))
    logger.info(f"Found {len(pages)} pages" +
                (f" [{lang}]" if lang else ""))

    if not pages:
        return {"page_count": 0, "errors": [], "all_pages": []}

    # Gate: Pending news files must be processed before build
    pending_news_errors = check_pending_news(docs_dir)
    if pending_news_errors:
        for err in pending_news_errors:
            logger.error(err)
        return {
            "page_count": 0, "errors": pending_news_errors,
            "all_pages": [],
        }

    # Validate frontmatter, source syntax, layouts, and nav titles
    try:
        from wire.schema import validate_build_pages, validate_source_syntax
        from wire.schema_ext import (validate_layouts, validate_nav_titles,
                                      validate_numbered_slugs,
                                      validate_topic_depth,
                                      validate_authors)
        hard_errors, warnings = validate_build_pages(pages)
        source_errors = validate_source_syntax(pages)
        layout_errors = validate_layouts(pages, docs_dir)
        nav_title_errors = validate_nav_titles(pages)
        slug_errors = validate_numbered_slugs(pages)
        topic_errors = validate_topic_depth(pages)
        author_errors = validate_authors(pages, docs_dir)
        all_errors = (hard_errors + source_errors + layout_errors
                      + nav_title_errors + slug_errors + topic_errors
                      + author_errors)
        if all_errors:
            if hard_errors:
                logger.error(
                    f"BUILD REFUSED: {len(hard_errors)} page(s) missing "
                    f"required frontmatter (title, description):")
                for err in hard_errors:
                    logger.error(f"  {err}")
            if source_errors:
                logger.error(
                    f"BUILD REFUSED: {len(source_errors)} MkDocs syntax "
                    f"error(s):")
                for err in source_errors:
                    logger.error(f"  {err}")
                logger.error(
                    "Wire does not process MkDocs extensions. "
                    "Fix these pages or exclude them in wire.yml. "
                    "See docs/guides/components/ → Migrating from MkDocs")
            if layout_errors:
                logger.error(
                    f"BUILD REFUSED: {len(layout_errors)} page(s) missing "
                    f"required layout:")
                for err in layout_errors:
                    logger.error(f"  {err}")
            if nav_title_errors:
                logger.error(
                    f"BUILD REFUSED: {len(nav_title_errors)} topic page(s) "
                    f"missing or invalid short_title:")
                for err in nav_title_errors:
                    logger.error(f"  {err}")
            if slug_errors:
                logger.error(
                    f"BUILD REFUSED: {len(slug_errors)} page(s) with "
                    f"numbered slugs:")
                for err in slug_errors:
                    logger.error(f"  {err}")
            if topic_errors:
                logger.error(
                    f"BUILD REFUSED: {len(topic_errors)} empty topic(s):")
                for err in topic_errors:
                    logger.error(f"  {err}")
            if author_errors:
                logger.error(
                    f"BUILD REFUSED: {len(author_errors)} page(s) "
                    f"reference unknown authors:")
                for err in author_errors:
                    logger.error(f"  {err}")
            return {
                "page_count": 0, "errors": all_errors,
                "all_pages": [],
            }
        if warnings:
            logger.warning(
                f"Schema: {len(warnings)} page(s) missing 'created' date:")
            for err in warnings:
                logger.warning(f"  {err}")
            logger.warning(
                "Run: python -m wire.migrate to backfill created dates "
                "from git history.")
    except ImportError:
        pass

    # Validate article labels for non-English sites
    build_lang = lang or config.get("lang", "")
    wire_config = config.get("extra", {}).get("wire", {})
    lang_codes = [lg["code"] for lg in config.get("languages", [])]
    resolved_labels = _resolve_lang_config(
        wire_config.get("labels", {}), build_lang, lang_codes)
    _validate_article_labels(build_lang, resolved_labels or {})

    # Warn if no footer configured
    if not config.get("footer"):
        logger.warning(
            "No footer configured. Add a 'footer:' section to wire.yml.\n"
            "  See: docs/guides/adding-a-site/ for footer setup.\n"
            "  Minimum: copyright, legal links (Imprint + Privacy — "
            "required by EU law)."
        )
    else:
        _footer = config["footer"]
        if isinstance(_footer, dict) and "links" in _footer:
            if not isinstance(_footer["links"], dict):
                raise ValueError(
                    "footer.links must be a dict of groups, not a list.\n"
                    "  Wrong:  footer:\n"
                    "            links:\n"
                    "              - title: Imprint\n"
                    "                url: /imprint/\n"
                    "  Right:  footer:\n"
                    "            links:\n"
                    "              Company:\n"
                    "                - About: /about/\n"
                    "                - Contact: /contact/"
                )

    # Dirty build: filter to recently modified files
    if dirty:
        marker = output_dir / ".build_timestamp"
        if marker.exists():
            last_build = marker.stat().st_mtime
            pages = [p for p in pages if p.source.stat().st_mtime > last_build]
            logger.info(f"Dirty build: {len(pages)} modified pages")
            if not pages:
                logger.info("Nothing changed. Skipping build.")
                marker.write_text(str(time.time()))
                return {"page_count": 0, "errors": [],
                        "all_pages": collect_pages(docs_dir, config.get("exclude"))}

    # Build nav from all pages (even in dirty mode, nav needs full picture)
    all_pages = collect_pages(docs_dir, config.get("exclude")) if dirty else pages
    nav_config = config.get("nav")
    nav = build_nav(all_pages, nav_config,
                    nav_exclude=config.get("nav_exclude"))

    # Check for pages not in nav (only when nav is explicitly configured)
    # Must run BEFORE resolve_offerings filters the offerings topic out
    orphans = check_nav_orphans(all_pages, nav_config, nav,
                                    header=config.get("header"))
    if orphans:
        logger.error(
            f"BUILD REFUSED: {len(orphans)} page(s) not reachable via nav "
            f"in wire.yml:")
        for url in orphans:
            logger.error(f"  {url}")
        logger.error(
            "Add these pages to 'nav:' in wire.yml, or exclude them "
            "with 'exclude:' patterns.")
        return {
            "page_count": 0,
            "errors": [f"Nav orphan: {url}" for url in orphans],
            "all_pages": [],
        }

    # Resolve offerings — require explicit config when site has topics
    header = config.get("header", {})
    topics_with_children = [
        item["title"] for item in nav
        if item["url"] != "/" and item.get("children")]
    has_topics = bool(topics_with_children)

    if has_topics and "offerings" not in header:
        logger.error(
            "BUILD REFUSED: header.offerings not configured in wire.yml.\n"
            "  Set which topic appears in the offerings bar (Row 1):\n"
            "    header:\n"
            "      offerings: <topic-name>\n"
            f"  Available topics: {', '.join(topics_with_children)}\n"
            "  See: docs/guides/configuration/ → Header")
        return {
            "page_count": 0,
            "errors": ["header.offerings not configured"],
            "all_pages": [],
        }
    if has_topics and header.get("offerings") is False:
        logger.warning(
            "offerings: false on a site with topics.\n"
            "  Your topics ARE your offerings. Configure them:\n"
            "    header:\n"
            "      offerings: <topic-name>\n"
            f"  Available topics: {', '.join(topics_with_children)}\n"
            "  See: docs/guides/configuration/ → Header")
    if header.get("offerings") and header["offerings"] is not False:
        offerings_links, nav = resolve_offerings(header, nav)
        header["offerings"] = offerings_links
        config["header"] = header
    elif header.get("offerings") is False:
        # No topics — offerings: false is fine
        header["offerings"] = None
        config["header"] = header

    # Require explicit CTA config when site has topics
    if has_topics and "cta" not in header:
        logger.error(
            "BUILD REFUSED: header.cta not configured in wire.yml.\n"
            "  Set the CTA button in the sticky nav bar:\n"
            "    header:\n"
            "      cta:\n"
            "        label: Get Started\n"
            "        url: /getting-started/\n"
            "  Or disable it:\n"
            "    header:\n"
            "      cta: false\n"
            "  See: docs/guides/configuration/ → Header")
        return {
            "page_count": 0,
            "errors": ["header.cta not configured"],
            "all_pages": [],
        }

    output_dir.mkdir(parents=True, exist_ok=True)

    # Build pages lookup for related page resolution
    pages_lookup = {p.url: p for p in all_pages}

    # Validate nav config: ordering, duplicates, layout requirements
    try:
        from wire.schema_ext import validate_nav_config
        nav_config_errors = validate_nav_config(
            nav, header, pages_lookup,
            nav_is_configured=bool(nav_config))
        if nav_config_errors:
            logger.error(
                f"BUILD REFUSED: {len(nav_config_errors)} nav config "
                f"error(s):")
            for err in nav_config_errors:
                logger.error(f"  {err}")
            return {
                "page_count": 0, "errors": nav_config_errors,
                "all_pages": [],
            }
    except ImportError:
        pass

    # Set shortcode config for :::visual (logo + site name)
    global _SHORTCODE_LOGO, _SHORTCODE_SITE_NAME, _SHORTCODE_LANG, _SHORTCODE_BASE_PATH
    logo = config.get("logo")
    _SHORTCODE_LOGO = logo if logo and logo is not False else ""
    _SHORTCODE_SITE_NAME = config["site_name"]
    # URL prefix: only multi-language builds prefix shortcode links.
    # url_prefix() is the single source of truth for lang prefixing (#105).
    # _SHORTCODE_LANG is a global because shortcodes run during markdown parsing.
    _SHORTCODE_LANG = url_prefix(lang, languages).lstrip("/")
    _SHORTCODE_BASE_PATH = config.get("_base_path", "")

    # Sidebar card image fallback: log once if defaulting to og_image (#216)
    wire_cfg_raw = config.get("extra", {}).get("wire", {})
    _scta = wire_cfg_raw.get("sidebar_cta", {})
    if isinstance(_scta, dict) and not _scta.get("image"):
        _og = config.get("theme", {}).get("og_image", "")
        if _og:
            logger.info(
                "Sidebar card using theme.og_image as default. "
                "Set extra.wire.sidebar_cta.image to override.")

    # Render pages in parallel
    errors = []
    rendered = 0

    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = {
            pool.submit(render_page, page, nav, env, config, output_dir,
                        lang=lang, languages=languages or [],
                        pages_lookup=pages_lookup,
                        hreflang_map=hreflang_map): page
            for page in pages
        }
        for future in as_completed(futures):
            page = futures[future]
            try:
                future.result()
                rendered += 1
            except Exception as e:
                errors.append(f"{page.source}: {e}")
                logger.error(f"Failed to render {page.source}: {e}")

    # Copy non-markdown assets from this language's docs_dir
    copy_assets(docs_dir, output_dir)

    # Generate per-language sitemap, RSS, search index, and llms.txt
    # Only add lang prefix to URLs for multi-language builds (languages is set)
    url_lang = url_prefix(lang, languages).lstrip("/")
    generate_sitemap(all_pages, config, output_dir, lang=url_lang)
    generate_rss(all_pages, config, output_dir, lang=url_lang)
    generate_search_index(all_pages, output_dir)
    generate_llms_txt(all_pages, config, output_dir, lang=url_lang)

    # Write build timestamp
    marker = output_dir / ".build_timestamp"
    marker.write_text(str(time.time()))

    return {"page_count": rendered, "errors": errors, "all_pages": all_pages,
            "nav": nav}


def _build_language_switcher(languages: list[dict]) -> list[dict]:
    """Build language switcher data for templates.

    Returns list of dicts with code, name, homepage URL for each language.
    """
    return [
        {"code": lang["code"], "name": lang["name"],
         "url": f"/{lang['code']}/"}
        for lang in languages
    ]


def _page_language_switcher(page, lang: str,
                            languages: list[dict]) -> list[dict]:
    """Build per-page language switcher, using alternate frontmatter.

    If the page has alternate: {en: /en/about/}, the switcher link for 'en'
    points to /en/about/ instead of /en/ (homepage).

    Pages without alternate get the default homepage links (no change).
    """
    if not languages:
        return []
    alt = page.meta.get("alternate")
    if not alt or not isinstance(alt, dict):
        return languages  # No alternate — use default homepage links

    import re as _re
    result = []
    for entry in languages:
        code = entry["code"]
        if code == lang:
            # Current language — link to self (current page with lang prefix)
            result.append({
                "code": code,
                "name": entry["name"],
                "url": f"/{lang}{page.url}",
            })
        elif code in alt:
            # Alternate exists — link to the mapped page
            target = str(alt[code])
            # If target already has lang prefix, use as-is
            m = _re.match(r'^/([a-z]{2})(/.*)', target)
            if m:
                result.append({
                    "code": code,
                    "name": entry["name"],
                    "url": target,
                })
            else:
                result.append({
                    "code": code,
                    "name": entry["name"],
                    "url": f"/{code}{target}",
                })
        else:
            # No alternate for this language — fall back to homepage
            result.append(dict(entry))
    return result



def _validate_alternates(pages_by_lang: dict[str, list]) -> list[str]:
    """Validate alternate frontmatter mappings.

    Checks:
      1. Every alternate target path must exist as a built page (BUILD REFUSED)
      2. Mappings must be reciprocal: if DE→EN, then EN must→DE (BUILD REFUSED)

    Returns list of error strings (empty = valid).
    """
    import re as _re
    if len(pages_by_lang) < 2:
        return []

    errors = []

    # Index all known page URLs per language
    known_urls = {}  # {lang: set(url)}
    for lang, pages in pages_by_lang.items():
        known_urls[lang] = {p.url for p in pages}

    # Collect all explicit pairs
    # (source_lang, source_url, target_lang, target_rel_url)
    pairs = []
    for lang, pages in pages_by_lang.items():
        for page in pages:
            alt = page.meta.get("alternate")
            if not alt:
                continue
            if isinstance(alt, dict):
                for target_lang, target_url in alt.items():
                    target_lang = str(target_lang)
                    m = _re.match(r'^/([a-z]{2})(/.*)', str(target_url))
                    if m:
                        pairs.append((lang, page.url, m.group(1), m.group(2)))
                    else:
                        pairs.append((lang, page.url, target_lang, str(target_url)))
            elif isinstance(alt, str):
                m = _re.match(r'^/([a-z]{2})(/.*)', alt)
                if m:
                    pairs.append((lang, page.url, m.group(1), m.group(2)))

    # Check 1: target exists
    for src_lang, src_url, tgt_lang, tgt_rel in pairs:
        if tgt_lang not in known_urls:
            errors.append(
                f"alternate target language '{tgt_lang}' in "
                f"/{src_lang}{src_url} does not exist as a configured "
                f"language. Check wire.yml languages.")
        elif tgt_rel not in known_urls[tgt_lang]:
            errors.append(
                f"alternate target /{tgt_lang}{tgt_rel} in "
                f"/{src_lang}{src_url} does not exist. "
                f"Remove the mapping or create the page.")

    # Check 2: reciprocal — for each A→B, B must→A
    # Build lookup: (lang, url) → set of (target_lang, target_url)
    mapping = {}
    for src_lang, src_url, tgt_lang, tgt_rel in pairs:
        mapping.setdefault((src_lang, src_url), set()).add((tgt_lang, tgt_rel))

    for src_lang, src_url, tgt_lang, tgt_rel in pairs:
        reverse = mapping.get((tgt_lang, tgt_rel), set())
        if (src_lang, src_url) not in reverse:
            errors.append(
                f"Non-reciprocal alternate: /{src_lang}{src_url} maps to "
                f"/{tgt_lang}{tgt_rel}, but /{tgt_lang}{tgt_rel} does not "
                f"map back. Add alternate: {{'{src_lang}': "
                f"'/{src_lang}{src_url}'}} to /{tgt_lang}{tgt_rel}.")

    return errors


def _build_hreflang_map(pages_by_lang: dict[str, list],
                       default_lang: str,
                       site_url: str = "") -> dict:
    """Build hreflang map for multi-language sites.

    Pages are matched by relative path (page.url is language-relative,
    e.g. /guides/intro/ — the language prefix is NOT in page.url).

    Matching strategies:
      1. Path convention: same page.url across languages = same content
      2. Explicit 'alternate' frontmatter: overrides path matching

    Returns {(lang, page_url): [{lang, href}, ...]} keyed by
    (language_code, page_url) so render_page() can look up the right entry.

    Single-language sites return empty dict.
    """
    if len(pages_by_lang) < 2:
        return {}

    # Index pages by relative URL (page.url is already language-relative)
    by_rel_path = {}  # {rel_url: {lang: page_url}}
    for lang, pages in pages_by_lang.items():
        for page in pages:
            by_rel_path.setdefault(page.url, {})[lang] = page.url

    # Build explicit alternates from frontmatter
    # alternate can be:
    #   - dict: {lang: url} e.g. {en: /en/about/}
    #   - string: /de/build/ki-agenten/ (parsed for lang prefix)
    explicit_pairs = []  # [(page_lang, page_url, target_lang, target_rel_url)]
    for lang, pages in pages_by_lang.items():
        for page in pages:
            alt = page.meta.get("alternate")
            if not alt:
                continue
            if isinstance(alt, dict):
                for target_lang, target_url in alt.items():
                    import re as _re
                    m = _re.match(r'^/([a-z]{2})(/.*)', str(target_url))
                    if m:
                        explicit_pairs.append((lang, page.url, m.group(1), m.group(2)))
                    else:
                        explicit_pairs.append((lang, page.url, str(target_lang), str(target_url)))
            elif isinstance(alt, str):
                import re as _re
                m = _re.match(r'^/([a-z]{2})(/.*)', alt)
                if m:
                    explicit_pairs.append((lang, page.url, m.group(1), m.group(2)))

    # Build hreflang map
    # Key: (lang, page_url) → value: list of {lang, href}
    hreflang_map = {}

    # Path convention matches
    for rel_url, lang_urls in by_rel_path.items():
        if len(lang_urls) < 2:
            continue
        for lang in lang_urls:
            entry = {}
            for other_lang in lang_urls:
                entry[other_lang] = f"/{other_lang}{rel_url}"
            if default_lang in lang_urls:
                entry["x-default"] = f"/{default_lang}{rel_url}"
            hreflang_map[(lang, rel_url)] = entry

    # Explicit alternate overrides
    for page_lang, page_url, target_lang, target_rel in explicit_pairs:
        if target_lang in pages_by_lang:
            # Check target exists
            target_exists = any(p.url == target_rel
                                for p in pages_by_lang[target_lang])
            if target_exists:
                # Source page entry
                entry = hreflang_map.get((page_lang, page_url), {})
                entry[page_lang] = f"/{page_lang}{page_url}"
                entry[target_lang] = f"/{target_lang}{target_rel}"
                if default_lang in (page_lang, target_lang):
                    dl = page_lang if page_lang == default_lang else target_lang
                    dr = page_url if page_lang == default_lang else target_rel
                    entry["x-default"] = f"/{dl}{dr}"
                hreflang_map[(page_lang, page_url)] = entry

                # Reciprocal entry for target page
                t_entry = hreflang_map.get((target_lang, target_rel), {})
                t_entry[page_lang] = f"/{page_lang}{page_url}"
                t_entry[target_lang] = f"/{target_lang}{target_rel}"
                if default_lang in (page_lang, target_lang):
                    t_entry["x-default"] = entry.get("x-default", "")
                hreflang_map[(target_lang, target_rel)] = t_entry

    return hreflang_map


def _clean_output_dir(output_dir: Path, dirty: bool) -> None:
    """Remove previous build output. Called only after all gates pass."""
    if dirty or not output_dir.exists():
        output_dir.mkdir(parents=True, exist_ok=True)
        return
    try:
        shutil.rmtree(output_dir)
    except PermissionError:
        for f in output_dir.rglob("*"):
            if f.is_file():
                try:
                    f.unlink()
                except PermissionError:
                    pass
    output_dir.mkdir(parents=True, exist_ok=True)


def build(site_dir: str | Path, dirty: bool = False,
          run_lint: bool = True, run_qa: bool = True,
          lang: str = "") -> dict:
    """Build the entire site.

    Args:
        site_dir: Path to site root (containing wire.yml).
        dirty: If True, only rebuild pages modified since last build.
        run_lint: If True, run linter after build (default True).
        run_qa: If True, run QA checks after build (default True).
        lang: Build only this language from a multi-language site.
              Skips cross-language gates. For translation workflow (#93).

    Returns:
        Build stats dict with page_count, elapsed_seconds, errors, lint_issues.
    """
    site_dir = Path(site_dir)
    start = time.monotonic()

    config = load_config(site_dir)
    templates_dir = config["templates_dir"]
    output_dir = config["output_dir"]

    # Gate 4: Migration artifacts
    artifact_errors = _check_migration_artifacts(site_dir)
    if artifact_errors:
        for err in artifact_errors:
            logger.error(f"BUILD REFUSED: {err}")
        return {
            "page_count": 0, "errors": artifact_errors,
            "lint_issues": 0, "all_pages": [],
        }

    # Build Jinja2 environment (shared across languages)
    env = build_jinja_env(templates_dir)

    languages = config.get("languages")
    # Single-language build from multi-lang site (#93): filter to one language,
    # skip cross-language gates (asymmetry, duplicate titles, untranslated bodies).
    single_lang_mode = False
    if lang and languages:
        matched = [l for l in languages if l["code"] == lang]
        if not matched:
            available = [l["code"] for l in languages]
            return {
                "page_count": 0, "lint_issues": 0, "all_pages": [],
                "errors": [f"Language '{lang}' not in languages config. "
                           f"Available: {', '.join(available)}"],
            }
        languages = matched
        single_lang_mode = True

    total_rendered = 0
    all_errors = []
    all_pages_combined = []

    built_nav = []

    if languages:
        # Cross-language gates: skip when building a single language (#93).
        # These gates compare languages — meaningless for single-lang builds.
        if single_lang_mode:
            logger.info(f"Single-language build: {lang} only — "
                        f"skipping cross-language gates")

        # Gate 1: Language asymmetry check
        page_counts = {}
        default_lang = next(
            (l["code"] for l in languages if l.get("default")),
            languages[0]["code"]
        )
        for lang_config in languages:
            docs_path = lang_config["docs_dir"]
            if docs_path.is_dir():
                count = sum(1 for _ in docs_path.rglob("index.md"))
                page_counts[lang_config["code"]] = count
        asymmetry_errors = _check_language_asymmetry(page_counts, default_lang)
        if asymmetry_errors and not single_lang_mode:
            for err in asymmetry_errors:
                logger.error(f"BUILD REFUSED: {err}")
            all_errors.extend(asymmetry_errors)
            return {
                "page_count": 0, "errors": all_errors,
                "lint_issues": 0, "all_pages": [],
            }

        # Gate 2: Orphan language directories (exist but not configured)
        configured_codes = {l["code"] for l in languages}
        docs_parent = languages[0]["docs_dir"].parent
        orphan_dir_errors = _check_orphan_language_dirs(
            docs_parent, configured_codes)
        if orphan_dir_errors and not single_lang_mode:
            for err in orphan_dir_errors:
                logger.error(f"BUILD REFUSED: {err}")
            all_errors.extend(orphan_dir_errors)
            return {
                "page_count": 0, "errors": all_errors,
                "lint_issues": 0, "all_pages": [],
            }

        # Gate 3: Configured languages with missing directories
        existing_dirs = {d.name for d in docs_parent.iterdir()
                         if d.is_dir()} if docs_parent.is_dir() else set()
        orphan_cfg_errors = _check_orphan_language_config(
            languages, existing_dirs)
        if orphan_cfg_errors and not single_lang_mode:
            for err in orphan_cfg_errors:
                logger.error(f"BUILD REFUSED: {err}")
            all_errors.extend(orphan_cfg_errors)
            return {
                "page_count": 0, "errors": all_errors,
                "lint_issues": 0, "all_pages": [],
            }

        # Gate 13: Duplicate titles across languages = untranslated content
        titles_by_lang = {}
        for lang_config in languages:
            code = lang_config["code"]
            docs_path = lang_config["docs_dir"]
            if docs_path.is_dir():
                titles = []
                for md in docs_path.rglob("index.md"):
                    try:
                        post = fm.load(md)
                        t = post.get("title", "")
                        if t:
                            titles.append(str(t))
                    except Exception:
                        pass
                titles_by_lang[code] = titles
        dup_errors = _check_duplicate_titles_across_languages(titles_by_lang)
        if dup_errors and not single_lang_mode:
            for err in dup_errors:
                logger.error(f"BUILD REFUSED: {err}")
            all_errors.extend(dup_errors)
            return {
                "page_count": 0, "errors": all_errors,
                "lint_issues": 0, "all_pages": [],
            }

        # Gate 14: Untranslated bodies = wrong language in wrong dir
        bodies_by_lang = {}
        for lang_config in languages:
            code = lang_config["code"]
            docs_path = lang_config["docs_dir"]
            if docs_path.is_dir():
                page_bodies = {}
                for md in docs_path.rglob("index.md"):
                    try:
                        post = fm.load(md)
                        # Skip draft pages — not rendered, no need to check (#241)
                        if post.metadata.get("draft"):
                            continue
                        body = post.content or ""
                        rel = md.relative_to(docs_path)
                        url = f"/{code}/{str(rel.parent).replace(chr(92), '/')}/"
                        if url.endswith("/./"):
                            url = f"/{code}/"
                        page_bodies[url] = body
                    except Exception:
                        pass
                bodies_by_lang[code] = page_bodies
        body_errors = _check_untranslated_bodies(bodies_by_lang)
        if body_errors and not single_lang_mode:
            for err in body_errors:
                logger.error(f"BUILD REFUSED: {err}")
            all_errors.extend(body_errors)
            return {
                "page_count": 0, "errors": all_errors,
                "lint_issues": 0, "all_pages": [],
            }

        # Multi-language build: each language is an independent sub-site
        switcher = _build_language_switcher(languages)

        # Pre-collect pages for hreflang map
        default_lang_code = next(
            (l["code"] for l in languages if l.get("default")),
            languages[0]["code"]
        )
        pages_by_lang = {}
        for lang_config in languages:
            code = lang_config["code"]
            lang_docs = lang_config["docs_dir"]
            if lang_docs.is_dir():
                pages_by_lang[code] = collect_pages(lang_docs,
                                                     config.get("exclude"))
        # Validate alternate frontmatter before building
        alt_errors = _validate_alternates(pages_by_lang)
        if alt_errors and not single_lang_mode:
            for err in alt_errors:
                logger.error(f"BUILD REFUSED: {err}")
            all_errors.extend(alt_errors)
            return {
                "page_count": 0, "errors": all_errors,
                "lint_issues": 0, "all_pages": [],
            }

        hreflang_map = _build_hreflang_map(pages_by_lang, default_lang_code,
                                            config.get("site_url", ""))

        # All pre-build gates passed — clean output dir before rendering
        _clean_output_dir(output_dir, dirty)

        logger.info(f"Building {config['site_name']} — "
                     f"{len(languages)} languages: "
                     f"{', '.join(l['code'] for l in languages)}")

        for lang_config in languages:
            code = lang_config["code"]
            lang_docs = lang_config["docs_dir"]
            lang_output = output_dir / code

            logger.info(f"Building [{code}] from {lang_docs}")
            result = _build_language(
                lang_docs, lang_output, config, env, dirty=dirty,
                lang=code, languages=switcher,
                hreflang_map=hreflang_map)

            total_rendered += result["page_count"]
            all_errors.extend(result["errors"])
            all_pages_combined.extend(result.get("all_pages", []))
            if not built_nav:
                built_nav = result.get("nav", [])

        # Root redirect to default language
        default_lang = next(
            (l for l in languages if l.get("default")),
            languages[0]
        )
        _bp = config.get("_base_path", "")
        redirect_html = (
            '<!DOCTYPE html><html><head>'
            f'<meta http-equiv="refresh" content="0;url={_bp}/{default_lang["code"]}/">'
            f'<link rel="canonical" href="{config["site_url"]}/{default_lang["code"]}/">'
            '</head><body></body></html>'
        )
        (output_dir / "index.html").write_text(redirect_html, encoding="utf-8")
        logger.info(f"Generated root redirect → /{default_lang['code']}/")

        # Per-language search pages
        if config.get("search", True) is not False:
            for lang_config in languages:
                code = lang_config["code"]
                lang_output = output_dir / code
                generate_search_page(config, lang_output, env, nav=built_nav,
                                     languages=switcher, lang=code)

        # Shared assets go to root output_dir (not per-language)
        copy_assets(config["docs_dir"], output_dir)
    else:
        # Single-language build — no build()-level gates, clean before rendering
        _clean_output_dir(output_dir, dirty)
        docs_dir = config["docs_dir"]
        logger.info(f"Building {config['site_name']} from {docs_dir}")

        result = _build_language(docs_dir, output_dir, config, env, dirty=dirty,
                                lang=config["lang"])

        total_rendered = result["page_count"]
        all_errors = result["errors"]
        all_pages_combined = result.get("all_pages", [])
        built_nav = result.get("nav", [])

        if total_rendered == 0 and not all_errors:
            if not all_pages_combined:
                logger.warning("No pages found. Check docs_dir and exclude patterns.")
                return {"page_count": 0, "elapsed_seconds": 0, "errors": []}

    # Pre-render gate blocked: skip downstream checks (GSC, SEO, lint, QA).
    # When 0 pages rendered due to gate failure, downstream checks run against
    # empty page sets and produce false positives (#192).
    if total_rendered == 0 and all_errors:
        elapsed = time.monotonic() - start
        logger.error(f"{len(all_errors)} pre-render error(s) — "
                     f"fix these first (skipping GSC/lint/QA checks):")
        for err in all_errors:
            logger.error(f"  {err}")
        wire_dir = site_dir / ".wire"
        wire_dir.mkdir(exist_ok=True)
        (wire_dir / "build-errors.txt").write_text(
            "\n".join(all_errors), encoding="utf-8")
        logger.info(f"  {len(all_errors)} issue(s) written to .wire/build-errors.txt")
        return {
            "page_count": 0,
            "elapsed_seconds": round(elapsed, 2),
            "errors": all_errors,
            "lint_issues": 0,
            "lint_errors": 0,
            "lint_warnings": 0,
            "qa_issues": 0,
        }

    # Copy verbatim directories (shared)
    copy_dirs(config, output_dir)

    # Generate 404 page
    if languages:
        switcher_404 = _build_language_switcher(languages)
        default_404 = next(
            (l for l in languages if l.get("default")), languages[0])
        generate_404(config, output_dir, env, nav=built_nav,
                     languages=switcher_404, lang=default_404["code"])
    else:
        generate_404(config, output_dir, env, nav=built_nav)

    # Generate search page (auto, disable with search: false in wire.yml)
    # For multi-language sites, search pages are generated per-language above
    if not languages and config.get("search", True) is not False:
        generate_search_page(config, output_dir, env, nav=built_nav)

    # Auto-generate news listing page when docs/news/ has articles
    if not languages:
        news_pages = [p for p in all_pages_combined
                      if p.topic == "news" and p.slug]
        if news_pages:
            generate_news_page(news_pages, output_dir,
                               config["docs_dir"], config=config,
                               env=env, nav=built_nav)

    # Minify HTML output
    for html_file in output_dir.rglob("*.html"):
        try:
            content = html_file.read_text(encoding="utf-8")
            minified = _minify_html(content)
            html_file.write_text(minified, encoding="utf-8")
        except Exception as e:
            logger.warning(f"HTML minify failed for {html_file}: {e}")

    # Generate site-wide files (robots.txt, CNAME, redirects)
    # humans.txt — site attribution (#142)
    _generate_humans_txt(config, output_dir)
    generate_robots_txt(config, output_dir)
    # Sitemap index for multi-language sites (#124)
    if languages:
        _generate_sitemap_index(config, output_dir, languages)
    generate_cname(config, output_dir)
    generate_htaccess(config, output_dir, site_dir=site_dir)
    generate_redirects(site_dir, output_dir)
    generate_raw_exports(config, output_dir)

    # Generate /bot/ directory (agent-facing site context)
    if languages:
        # Multi-language: use default language's docs_dir
        default_lang_cfg = next(
            (l for l in languages if l.get("default")), languages[0])
        bot_docs = default_lang_cfg["docs_dir"]
    else:
        bot_docs = config["docs_dir"]
    generate_bot_dir(all_pages_combined, config, output_dir, bot_docs)

    # Check redirect-source conflicts BEFORE GSC guard
    from wire.tools import load_redirects
    redirects = load_redirects(site_dir=site_dir)
    if languages:
        # Multi-language: check each language's docs_dir
        redirect_conflicts = []
        for lang_config in languages:
            redirect_conflicts.extend(
                _check_redirect_source_conflicts(
                    redirects, lang_config["docs_dir"]))
    else:
        redirect_conflicts = _check_redirect_source_conflicts(
            redirects, docs_dir)
    if redirect_conflicts:
        for conflict in redirect_conflicts:
            logger.error(f"BUILD REFUSED: {conflict}")
        all_errors.extend(redirect_conflicts)
        return {
            "page_count": 0, "errors": all_errors,
            "lint_issues": 0, "all_pages": all_pages_combined,
        }

    # GSC Build Guard — every URL Google knows must be covered
    page_urls = {p.url for p in all_pages_combined}
    gsc_errors = check_gsc_coverage(
        page_urls, redirects,
        exclude_gsc_data_for_path=config.get("exclude_gsc_data_for_path", []))
    if gsc_errors:
        for err in gsc_errors:
            logger.error(f"  {err}")
        logger.error(
            f"Build blocked: {len(gsc_errors)} GSC URL(s) have no page and no redirect.\n"
            f"Fix: add redirects in wire.yml or run 'python -m wire.chief data' to refresh GSC URLs."
        )
        all_errors.extend(gsc_errors)

    # SEO Audit Build Guard — refuse if hard overlaps exist (cannibalization)
    seo_errors = check_seo_audit(site_dir=site_dir)
    if seo_errors:
        for err in seo_errors:
            logger.error(err)
        all_errors.extend(seo_errors)

    # For single-language sites, sitemap/RSS already generated by _build_language
    # For multi-language, each language has its own sitemap in /{code}/

    render_elapsed = time.monotonic() - start
    lint_start = time.monotonic()

    if all_errors:
        logger.error(f"{len(all_errors)} page(s) failed:")
        for err in all_errors:
            logger.error(f"  {err}")

    # Auto-lint after build
    lint_results = []
    lint_errors = 0
    lint_warnings = 0
    if run_lint:
        try:
            from wire.lint import lint_site, format_results
            lint_results = lint_site(str(output_dir),
                                     site_url=config.get("site_url"))
            if lint_results:
                active = [r for r in lint_results
                          if not getattr(r, "overruled", False)]
                lint_errors = sum(1 for r in active
                                 if r.severity == "error")
                lint_warnings = sum(1 for r in active
                                   if r.severity == "warning")
                logger.error(format_results(lint_results))
            else:
                logger.info("Lint: all checks passed.")
        except Exception as e:
            logger.warning(f"Lint skipped: {e}")

    lint_elapsed = time.monotonic() - lint_start

    # Auto-QA after build
    qa_issues = 0
    if run_qa:
        try:
            from wire.qa import qa_site
            report = qa_site(str(output_dir), full=True)
            qa_issues = len(report.errors)
            if report.has_critical_errors:
                logger.warning(report.summary())
            else:
                logger.info(f"QA: {report.pages_checked} pages checked. All passed.")
        except Exception as e:
            logger.warning(f"QA skipped: {e}")

    elapsed = time.monotonic() - start
    logger.info(
        f"Built {total_rendered} pages in {elapsed:.2f}s "
        f"(render {render_elapsed:.2f}s, lint {lint_elapsed:.2f}s)")

    # Persist all errors to .wire/build-errors.txt so they survive terminal scroll (#181)
    # Exclude overruled lint results — customer reviewed and accepted these
    all_issues = list(all_errors)
    if lint_results:
        all_issues.extend(f"[{r.rule_id}] [{r.severity.upper()}] {r.message} — {r.url}"
                         for r in lint_results
                         if not getattr(r, "overruled", False))
    if all_issues:
        wire_dir = site_dir / ".wire"
        wire_dir.mkdir(exist_ok=True)
        (wire_dir / "build-errors.txt").write_text(
            "\n".join(all_issues), encoding="utf-8")
        logger.info(f"  {len(all_issues)} issue(s) written to .wire/build-errors.txt")
    else:
        # Clean up stale error file from previous builds
        err_file = site_dir / ".wire" / "build-errors.txt"
        if err_file.exists():
            err_file.unlink()

    return {
        "page_count": total_rendered,
        "elapsed_seconds": round(elapsed, 2),
        "errors": all_errors,
        "lint_issues": len(active) if lint_results else 0,
        "lint_errors": lint_errors,
        "lint_warnings": lint_warnings,
        "qa_issues": qa_issues,
        "timing": {
            "render": round(render_elapsed, 2),
            "lint": round(lint_elapsed, 2),
        },
    }


def serve(site_dir: str | Path, port: int = 8000):
    """Start a local dev server for the built site.

    Serves from the output directory. All links in the built HTML are
    relative, so the site works from any directory without URL rewriting.
    """
    import http.server
    import functools

    site_dir = Path(site_dir)
    config = load_config(site_dir)
    output_dir = config["output_dir"]

    if not output_dir.exists():
        logger.info("No built site found. Building first...")
        build(site_dir)

    handler = functools.partial(
        http.server.SimpleHTTPRequestHandler,
        directory=str(output_dir))

    serve_url = f"http://localhost:{port}/"
    logger.info(f"Serving {config['site_name']} at {serve_url}")
    logger.info(f"  Source: {output_dir}")
    logger.info("  Press Ctrl+C to stop.\n")

    with http.server.HTTPServer(("", port), handler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            logger.info("\nServer stopped.")


def main():
    """CLI entry point."""
    import argparse

    parser = argparse.ArgumentParser(
        description="wire.build — static site generator")
    parser.add_argument("--site", default=".",
                        help="Path to site directory (default: current dir)")
    parser.add_argument("--dirty", action="store_true",
                        help="Only rebuild modified pages")
    parser.add_argument("--serve", action="store_true",
                        help="Start local dev server after building")
    parser.add_argument("--port", type=int, default=8000,
                        help="Dev server port (default: 8000)")
    parser.add_argument("--no-qa", action="store_true",
                        help="Skip QA checks after build")
    parser.add_argument("--lang",
                        help="Build only this language (multi-lang sites)")
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="Verbose output")

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(message)s",
    )

    result = build(args.site, dirty=args.dirty, run_qa=not args.no_qa,
                   lang=args.lang or "")

    if result["errors"]:
        raise SystemExit(1)

    # Lint errors and QA errors block the build (exit 1).
    # Lint warnings are visible but non-blocking (exit 0) (#226).
    # This lets CI distinguish "fix required" from "fix recommended".
    lint_errors = result.get("lint_errors", 0)
    lint_warnings = result.get("lint_warnings", 0)
    qa_issues = result.get("qa_issues", 0)

    blocked = []
    if lint_errors:
        blocked.append(f"{lint_errors} lint error(s)")
    if qa_issues:
        blocked.append(f"{qa_issues} QA error(s)")
    if blocked:
        logger.error(f"Build blocked: {', '.join(blocked)}. Fix them before deploying.")
        raise SystemExit(1)

    if lint_warnings:
        logger.warning(
            f"{lint_warnings} lint warning(s). Build succeeded — "
            f"warnings do not block deployment.")

    if args.serve:
        serve(args.site, args.port)


if __name__ == "__main__":
    main()
