"""Schema extensions: layout, nav, author validation.

Separated from schema.py to avoid circular imports with external tooling.
"""
from pathlib import Path

import re

VALID_LAYOUTS = {"page", "article", "landing", "raw", "home"}

# Help text for layout errors
_LAYOUT_HELP = (
    "  page     \u2014 default for topic index pages (nav, no sidebar)\n"
    "  article  \u2014 content pages with TOC, sidebar CTA, reading progress\n"
    "  landing  \u2014 marketing pages split into alternating sections at <hr>\n"
    "  raw      \u2014 bare HTML, no chrome (for embeds, widgets)\n"
    "  home     \u2014 homepage with hero section\n"
    "See: docs/guides/configuration/ \u2192 Page Layouts"
)

NAV_TITLE_MAX = 20

# Minimum sections to check alphabetical ordering (2 is too few to detect)
_MIN_SECTIONS_FOR_ALPHA_CHECK = 3

# Trailing fragments that indicate a broken short_title
_TRAILING_PREPOSITIONS = {
    "für", "und", "oder", "mit", "von", "zu", "in", "an", "auf", "bei",
    "with", "for", "and", "or", "of", "to", "in", "at", "on", "by",
}
_TRAILING_PUNCTUATION = {"—", "–", "-", ":", ",", ";"}

# Pattern to detect mid-word truncation: ends with lowercase without
# common word endings
_TRUNCATION_RE = re.compile(r'[a-zäöü]{2,}$')


def validate_layouts(pages, docs_dir) -> list[str]:
    """Check that parent pages (index.md with child dirs) declare layout.

    Without explicit layout, parent pages silently get 'article' layout
    which is wrong for topic indices and homepage. Fail loud.

    Returns list of error strings. Empty = all clean.
    """
    errors = []
    for page in pages:
        layout = page.meta.get("layout", "")

        # Validate layout value if set
        if layout and layout not in VALID_LAYOUTS:
            errors.append(
                f"{page.source}: unknown layout '{layout}'. "
                f"Valid layouts:\n{_LAYOUT_HELP}")
            continue

        # Only check index.md pages (directory pages)
        if page.source.name != "index.md":
            continue

        # Check if this page's directory has child content pages
        # Only count dirs that contain index.md (actual pages, not assets/)
        page_dir = page.source.parent
        child_content_dirs = [
            d for d in page_dir.iterdir()
            if d.is_dir() and not d.name.startswith(".")
            and (d / "index.md").exists()
        ]

        if child_content_dirs and not layout:
            child_count = len(child_content_dirs)
            errors.append(
                f"{page.source}: parent page with {child_count}"
                f" child dir(s) but no layout set. "
                f"Add to frontmatter: layout: page\n{_LAYOUT_HELP}")
    return errors


def validate_nav_titles(pages) -> list[str]:
    """Require short_title on all topic pages (nav tabs + sidebar).

    Topic index pages: short_title used for header nav tabs.
    Content pages: short_title used for sidebar navigation.
    Build refuses without it. No fallback to title \u2014 be opinionated.
    """
    errors = []
    topic_pages = [p for p in pages if p.topic]
    for page in topic_pages:
        st = page.meta.get("short_title")
        if not st:
            where = "nav tab" if not page.slug else "sidebar"
            errors.append(
                f"{page.source}: missing 'short_title' "
                f"\u2014 needed for {where} label (max {NAV_TITLE_MAX} chars)")
        elif not isinstance(st, str):
            errors.append(
                f"{page.source}: 'short_title' must be a string, "
                f"got {type(st).__name__}")
        elif len(str(st).strip()) > NAV_TITLE_MAX:
            errors.append(
                f"{page.source}: short_title '{st}' is {len(st)} chars "
                f"(max {NAV_TITLE_MAX}) \u2014 shorten for nav")
        else:
            # Gate 9: trailing fragments
            st_stripped = st.strip()
            last_word = st_stripped.split()[-1] if st_stripped.split() else ""
            if last_word.lower() in _TRAILING_PREPOSITIONS:
                errors.append(
                    f"{page.source}: short_title '{st}' ends with "
                    f"trailing preposition '{last_word}' \u2014 incomplete label")
            elif last_word in _TRAILING_PUNCTUATION:
                errors.append(
                    f"{page.source}: short_title '{st}' ends with "
                    f"trailing punctuation '{last_word}' \u2014 incomplete label")
    return errors


def validate_numbered_slugs(pages) -> list[str]:
    """Gate 10: Numbered slugs suggest wrong ordering pattern.

    Slugs like 2-adding-chatbot/ or 7-advanced/ indicate the customer
    is using directory numbering for sequencing. Wire uses frontmatter
    for that. BUILD REFUSED.

    Excludes date-based slugs (YYYY-MM-DD-*) used by news articles.

    Returns list of error strings. Empty = all clean.
    """
    errors = []
    # Match single/double digit prefix (not 4-digit year prefixes like 2026-)
    _NUMBERED = re.compile(r'^\d{1,2}-')
    _DATE_SLUG = re.compile(r'^\d{4}-\d{2}-\d{2}-')
    for page in pages:
        slug = getattr(page, 'slug', '')
        if not slug:
            continue
        if _DATE_SLUG.match(slug):
            continue  # Date-based news slugs are fine
        if _NUMBERED.match(slug):
            errors.append(
                f"{page.source}: slug '{slug}' starts with a number. "
                f"Use descriptive slugs instead of numbered directories.")
    return errors


def validate_topic_depth(pages) -> list[str]:
    """Gate 7: Check for empty topic directories.

    A topic with only an index page (no content pages) is likely
    a placeholder or abandoned. BUILD REFUSED.

    Returns list of error strings. Empty = all clean.
    """
    errors = []
    # Group pages by topic
    topics: dict[str, list] = {}
    for page in pages:
        if page.topic:
            topics.setdefault(page.topic, []).append(page)

    for topic, topic_pages in topics.items():
        content_pages = [p for p in topic_pages if p.slug]
        if not content_pages:
            # Skip standalone pages — they're self-contained, not empty
            # topics (e.g. /about/, /services/, /kontakt/, /impressum/).
            # Landing pages and pages without explicit topic content are OK.
            index_page = next(
                (p for p in topic_pages if not p.slug), None)
            if index_page:
                layout = index_page.meta.get("layout", "")
                # Any explicit layout = standalone page, not empty topic (#250)
                if layout:
                    continue
            errors.append(
                f"Topic '{topic}' has no content pages (only index). "
                f"Add content pages or remove the empty topic directory.")
    return errors


def _extract_offerings_urls(header: dict) -> set[str]:
    """Extract all URLs from resolved offerings links."""
    urls = set()
    offerings = header.get("offerings")
    if not offerings or not isinstance(offerings, list):
        return urls
    for item in offerings:
        if isinstance(item, dict):
            for url in item.values():
                if isinstance(url, str):
                    urls.add(url)
    return urls


def _extract_nav_urls(nav: list[dict]) -> set[str]:
    """Extract all URLs from content nav (sections + children)."""
    urls = set()
    for item in nav:
        url = item.get("url", "")
        if url and url != "/":
            urls.add(url)
        for child in item.get("children", []):
            child_url = child.get("url", "")
            if child_url:
                urls.add(child_url)
    return urls


def validate_nav_config(nav: list[dict], header: dict,
                        page_map: dict, **_kw) -> list[str]:
    """Validate nav configuration: ordering, duplicates, layout requirements.

    Checks:
    1. Alphabetical nav sections = uncurated (refuse if >= 3 sections in alpha order)
    2. Duplicate URLs across offerings and content nav (refuse)
    3. CTA URL must not duplicate a content nav URL (refuse)
    4. CTA target page must have layout: landing
    5. Offerings child pages must have layout: landing

    Args:
        nav: Built navigation structure (after resolve_offerings filtered it)
        header: Resolved header config (offerings already resolved to links)
        page_map: {url: Page} lookup for layout checks

    Returns list of error strings. Empty = all clean.
    """
    errors = []

    # 1. Alphabetical nav order = uncurated
    # Skip when offerings are configured — filtering changes nav composition,
    # so remaining sections may be coincidentally alphabetical.
    has_offerings = bool(header.get("offerings"))
    sections = [item["title"] for item in nav if item.get("url") != "/"]
    if (not has_offerings
            and len(sections) >= _MIN_SECTIONS_FOR_ALPHA_CHECK):
        if sections == sorted(sections, key=str.casefold):
            errors.append(
                f"Nav sections are in alphabetical order: "
                f"{', '.join(sections)}. "
                f"This looks uncurated \u2014 reorder sections by importance, "
                f"not alphabet. Put your highest-value topic first.")

    # 2. Duplicate URLs across offerings and content nav
    offerings_urls = _extract_offerings_urls(header)
    content_urls = _extract_nav_urls(nav)
    duplicates = offerings_urls & content_urls
    for url in sorted(duplicates):
        errors.append(
            f"Duplicate URL in offerings and content nav: {url}. "
            f"A page cannot be both an offering and regular content. "
            f"Create a separate landing page for your offering, or "
            f"remove it from one of the two navigation rows.")

    # 3. CTA URL must not duplicate a content nav URL
    cta = header.get("cta")
    if cta and isinstance(cta, dict):
        cta_url = cta.get("url", "")
        if cta_url and cta_url in content_urls:
            errors.append(
                f"CTA URL {cta_url} is already in content nav. "
                f"Remove it from nav sections \u2014 the CTA button is its "
                f"own navigation element. Having it in both places confuses "
                f"visitors and wastes a nav slot.")

    # 4. CTA target page must have layout: landing
    if cta and isinstance(cta, dict):
        cta_url = cta.get("url", "")
        if cta_url and page_map:
            cta_page = page_map.get(cta_url)
            if cta_page:
                cta_layout = cta_page.meta.get("layout", "")
                if cta_layout != "landing":
                    errors.append(
                        f"CTA page {cta_url} has layout '{cta_layout or 'none'}' "
                        f"\u2014 must be 'landing'. The CTA is your primary "
                        f"conversion page. Add to frontmatter: layout: landing")

    # 4. Offerings child pages must have an explicit layout
    for url in sorted(offerings_urls):
        if url and page_map:
            page = page_map.get(url)
            if page:
                layout = page.meta.get("layout", "")
                if layout not in ("landing", "page", "article"):
                    errors.append(
                        f"Offerings page {url} has layout '{layout or 'none'}' "
                        f"\u2014 must be 'landing', 'page', or 'article'. Add to "
                        f"frontmatter: layout: landing | page | article")

    # 6. Legal pages must not appear in top nav (#171)
    # Only actual legal pages — not authors, search, contact, etc.
    _LEGAL_NAV_REFUSE = {
        "imprint", "impressum", "datenschutz", "privacy", "legal",
        "terms", "disclaimer", "cookie", "cookies",
    }
    for item in nav:
        url_lower = item.get("url", "").lower().strip("/")
        slug_parts = [p for p in url_lower.split("/") if p]
        slug = slug_parts[0] if slug_parts else ""
        if slug in _LEGAL_NAV_REFUSE:
            errors.append(
                f"'{item.get('title', slug)}' belongs in footer.legal, "
                f"not in nav. Wire auto-adds legal pages to the footer. "
                f"Remove from nav to declutter your header.")
        for child in item.get("children", []):
            child_url = child.get("url", "").lower().strip("/")
            child_parts = [p for p in child_url.split("/") if p]
            child_slug = child_parts[0] if child_parts else ""
            if child_slug in _LEGAL_NAV_REFUSE:
                errors.append(
                    f"'{child.get('title', child_slug)}' belongs in "
                    f"footer.legal, not in nav. Remove from nav.")

    # 7. Offerings limit: 1-4 (#165)
    if has_offerings and isinstance(header.get("offerings"), list):
        count = len(header["offerings"])
        if count > 4:
            errors.append(
                f"Too many offerings ({count}). Maximum is 4 \u2014 the header "
                f"layout breaks with more. Consolidate your offerings or split "
                f"into a primary offering + content nav sections.")

    return errors


def validate_authors(pages: list, docs_dir: Path) -> list[str]:
    """Validate author references on article pages (#177).

    Only enforced when the site has an authors/ topic directory.
    Sites without authors/ are not required to have author attribution.

    Checks:
    - Article pages (topic + slug, not index) must have author: in frontmatter
    - The author: value must match a slug in authors/ directory

    Returns list of error strings. Empty = all clean.
    """
    authors_dir = docs_dir / "authors"
    if not authors_dir.is_dir():
        return []  # no authors topic = no gate

    # Collect valid author slugs
    valid_slugs = set()
    for d in authors_dir.iterdir():
        if d.is_dir() and (d / "index.md").exists():
            valid_slugs.add(d.name)

    if not valid_slugs:
        return []  # authors dir exists but has no author pages

    errors = []
    for page in pages:
        # Skip author pages themselves, topic indices, and non-content pages
        if not page.topic or not page.slug:
            continue
        if page.topic == "authors":
            continue
        # Skip topic index pages (they don't need authors)
        if page.url.strip("/").count("/") < 2 and page.slug == page.topic:
            continue

        author = page.meta.get("author", "")
        if not author:
            errors.append(
                f"{page.source}: missing author. "
                f"Add author: <slug> matching a page in authors/. "
                f"Available: {', '.join(sorted(valid_slugs))}")
        elif author not in valid_slugs:
            errors.append(
                f"{page.source}: author '{author}' not found in authors/. "
                f"Available: {', '.join(sorted(valid_slugs))}")

        # Reviewer: optional, but must be valid if present (#218)
        reviewer = page.meta.get("reviewer", "")
        if reviewer and reviewer not in valid_slugs:
            errors.append(
                f"{page.source}: reviewer '{reviewer}' not found in authors/. "
                f"Available: {', '.join(sorted(valid_slugs))}")

    return errors
