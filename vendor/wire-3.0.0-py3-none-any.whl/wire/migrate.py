#!/usr/bin/env python3
"""
wire.migrate — Backfill `created` dates from git history into frontmatter.

One-time migration tool. Walks all index.md files under docs_dir, finds those
missing `created` in frontmatter, and backfills from git log (first commit date)
or file mtime as fallback.

Usage:
    python -m wire.migrate --docs docs/              # dry-run (default)
    python -m wire.migrate --docs docs/ --write      # apply changes
"""

import argparse
import subprocess
import sys
from datetime import datetime
from pathlib import Path

import frontmatter


def git_first_date(filepath: Path) -> str | None:
    """Get the first commit date for a file from git history.

    Uses --follow to track renames. Returns YYYY-MM-DD or None.
    """
    try:
        result = subprocess.run(
            ["git", "log", "--follow", "--format=%aI", "--",
             str(filepath)],
            capture_output=True, text=True, timeout=10
        )
        if result.stdout.strip():
            # Last line = earliest commit
            return result.stdout.strip().split("\n")[-1][:10]
    except (subprocess.TimeoutExpired, FileNotFoundError,
            subprocess.SubprocessError):
        pass
    return None


def file_mtime_date(filepath: Path) -> str:
    """Get file modification time as YYYY-MM-DD."""
    mtime = filepath.stat().st_mtime
    return datetime.fromtimestamp(mtime).strftime("%Y-%m-%d")


def backfill_created(docs_dir: Path, write: bool = False) -> dict:
    """Walk docs_dir, backfill missing `created` dates.

    Args:
        docs_dir: Path to the docs directory.
        write: If True, write changes to disk. If False, dry-run only.

    Returns:
        dict with keys: backfilled (list of tuples), skipped (int),
        errors (list of tuples).
    """
    backfilled = []  # (filepath, date_source, date_value)
    skipped = 0
    errors = []  # (filepath, error_message)

    index_files = sorted(docs_dir.rglob("index.md"))

    for filepath in index_files:
        try:
            post = frontmatter.load(filepath)
        except Exception as e:
            errors.append((filepath, f"Failed to read: {e}"))
            continue

        # Skip if title is missing (not a proper content page)
        if "title" not in post.metadata:
            continue

        # Skip if already has created
        if "created" in post.metadata and post.metadata["created"] is not None:
            skipped += 1
            continue

        # Try git history first, then mtime fallback
        created_date = git_first_date(filepath)
        source = "git"
        if created_date is None:
            created_date = file_mtime_date(filepath)
            source = "mtime"

        backfilled.append((filepath, source, created_date))

        if write:
            post["created"] = created_date
            frontmatter.dump(post, filepath)

    return {
        "backfilled": backfilled,
        "skipped": skipped,
        "errors": errors,
    }


def main():
    parser = argparse.ArgumentParser(
        description="Backfill created dates from git history into frontmatter."
    )
    parser.add_argument(
        "--docs", required=True, type=Path,
        help="Path to the docs directory (e.g., docs/)"
    )
    parser.add_argument(
        "--write", action="store_true",
        help="Apply changes (default is dry-run)"
    )
    args = parser.parse_args()

    if not args.docs.is_dir():
        print(f"Error: {args.docs} is not a directory", file=sys.stderr)
        sys.exit(1)

    mode = "WRITE" if args.write else "DRY-RUN"
    print(f"[{mode}] Scanning {args.docs}/ for missing created dates...\n")

    result = backfill_created(args.docs, write=args.write)

    # Report backfilled
    for filepath, source, date_value in result["backfilled"]:
        rel = filepath.relative_to(args.docs)
        action = "Set" if args.write else "Would set"
        print(f"  {action} created: {date_value}  ({source})  {rel}")

    # Report errors
    for filepath, error in result["errors"]:
        rel = filepath.relative_to(args.docs)
        print(f"  ERROR: {rel} — {error}")

    # Summary
    n_backfilled = len(result["backfilled"])
    n_skipped = result["skipped"]
    n_errors = len(result["errors"])
    print(f"\nBackfilled {n_backfilled} pages, "
          f"skipped {n_skipped} (already had created)")
    if n_errors:
        print(f"Errors: {n_errors}")
    if not args.write and n_backfilled > 0:
        print("\nRe-run with --write to apply changes.")


if __name__ == "__main__":
    main()
