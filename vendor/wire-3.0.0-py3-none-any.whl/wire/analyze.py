#!/usr/bin/env python3
"""
Local content analysis for SEO improvement decisions.

All functions in this module are FREE — no Claude API calls.
They use GSC database queries + filesystem reads + local math
to build amendment briefs that tell Claude exactly what to do.
"""

import re
import math
import logging
from collections import Counter
from datetime import datetime

import frontmatter as fm

logger = logging.getLogger(__name__)

# Minimum word count before a page is considered "broad" (may need splitting)
BROAD_WORD_THRESHOLD = 2500
BROAD_KEYWORD_THRESHOLD = 15

# Impression ratio above which a keyword may deserve its own page
HIGH_RATIO_THRESHOLD = 0.4

# BM25 parameters (standard values)
BM25_K1 = 1.5
BM25_B = 0.75

# Common stopwords for tokenization (English + German)
STOPWORDS = frozenset({
    # English
    "a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for",
    "of", "with", "by", "from", "is", "are", "was", "were", "be", "been",
    "has", "have", "had", "do", "does", "did", "will", "would", "can",
    "could", "should", "may", "might", "this", "that", "these", "those",
    "it", "its", "not", "no", "so", "if", "as", "up", "out", "about",
    "into", "than", "then", "also", "just", "more", "most", "very",
    "how", "what", "which", "who", "when", "where", "why", "all", "each",
    "every", "both", "few", "many", "much", "some", "any", "other",
    # German
    "der", "die", "das", "ein", "eine", "und", "oder", "aber", "in",
    "auf", "an", "zu", "für", "von", "mit", "ist", "sind", "war",
    "hat", "haben", "wird", "kann", "nicht", "auch", "noch", "nur",
    "nach", "über", "bei", "aus", "wie", "was", "wer", "den", "dem",
    "des", "sich", "es", "sie", "er", "ich", "wir", "ihr", "uns",
    "als", "so", "wenn", "dass", "ob", "im", "am", "um", "zum",
})


def _strip_code_blocks(text: str) -> str:
    """Remove fenced code blocks from markdown."""
    return re.sub(r'```[\s\S]*?```', '', text)


def _keyword_in_text(keyword: str, text: str) -> bool:
    """Unicode-aware keyword presence check.

    Uses \\w boundary which is Unicode-aware with re.UNICODE flag,
    handling German umlauts and other non-ASCII word characters.
    """
    pattern = r'(?<!\w)' + re.escape(keyword) + r'(?!\w)'
    return bool(re.search(pattern, text, re.IGNORECASE | re.UNICODE))


def keyword_presence(body: str, keywords: list[dict]) -> list[dict]:
    """Check if GSC opportunity keywords appear in page body and/or headings.

    Args:
        body: Markdown page content (frontmatter stripped by caller).
        keywords: List of dicts with 'query' key (from page_queries),
                  pre-filtered to position > 5 and score > 0.

    Returns:
        [{keyword, status: "absent"|"body_only"|"in_heading",
          section_context: str|None}]
    """
    if not body or not keywords:
        return [{"keyword": kw["query"], "status": "absent",
                 "section_context": None} for kw in keywords]

    clean_body = _strip_code_blocks(body)

    # Extract headings with their line positions
    headings = []
    for m in re.finditer(r'^(#{1,6})\s+(.+)$', clean_body, re.MULTILINE):
        headings.append({"level": len(m.group(1)), "text": m.group(2),
                         "pos": m.start()})
    heading_texts = [h["text"] for h in headings]

    results = []
    for kw_data in keywords:
        kw = kw_data["query"]

        # Check headings first
        in_heading = any(_keyword_in_text(kw, h) for h in heading_texts)
        if in_heading:
            results.append({"keyword": kw, "status": "in_heading",
                            "section_context": None})
            continue

        # Check body
        in_body = _keyword_in_text(kw, clean_body)
        if in_body:
            # Find nearest heading above the match
            match = re.search(
                r'(?<!\w)' + re.escape(kw) + r'(?!\w)',
                clean_body, re.IGNORECASE | re.UNICODE)
            section = None
            if match and headings:
                match_pos = match.start()
                for h in reversed(headings):
                    if h["pos"] < match_pos:
                        section = f"{'#' * h['level']} {h['text']}"
                        break
            results.append({"keyword": kw, "status": "body_only",
                            "section_context": section})
        else:
            results.append({"keyword": kw, "status": "absent",
                            "section_context": None})

    return results


def tokenize(text: str) -> list[str]:
    """Tokenize text for BM25: lowercase, split, remove stopwords."""
    words = re.findall(r'\w+', text.lower(), re.UNICODE)
    return [w for w in words if w not in STOPWORDS and len(w) > 1]


def bm25_scores(corpus_tokens: list[list[str]],
                query_tokens: list[str]) -> list[float]:
    """Compute BM25 scores for each document in corpus against query.

    Args:
        corpus_tokens: List of tokenized documents.
        query_tokens: Tokenized query terms.

    Returns:
        List of BM25 scores, one per document.
    """
    n = len(corpus_tokens)
    if n == 0:
        return []

    # Document frequencies
    df = Counter()
    for doc in corpus_tokens:
        unique_terms = set(doc)
        for term in unique_terms:
            df[term] += 1

    # Average document length
    avg_dl = sum(len(doc) for doc in corpus_tokens) / n

    scores = []
    for doc in corpus_tokens:
        score = 0.0
        dl = len(doc)
        tf_counter = Counter(doc)

        for term in query_tokens:
            if term not in df:
                continue
            # IDF
            idf = math.log((n - df[term] + 0.5) / (df[term] + 0.5) + 1)
            # TF with saturation and length normalization
            tf = tf_counter.get(term, 0)
            tf_norm = (tf * (BM25_K1 + 1)) / (
                tf + BM25_K1 * (1 - BM25_B + BM25_B * (dl / avg_dl))
            )
            score += idf * tf_norm

        scores.append(score)

    return scores


def bm25_semantic_fit(keyword: str, page_body: str,
                      competitor_texts: list[str]) -> str:
    """Score page against competitor corpus for a keyword.

    Args:
        keyword: The keyword to check fitness for.
        page_body: Current page's markdown body.
        competitor_texts: Pre-fetched competitor page texts (already fetched
                         by caller to avoid import dependencies).

    Returns:
        "close" | "distant" | "unknown"
    """
    # Need at least 3 competitor pages for meaningful comparison
    valid_texts = [t for t in competitor_texts if t and len(t) > 500]
    if len(valid_texts) < 3:
        return "unknown"

    # Build corpus: competitors + our page (last)
    corpus = valid_texts + [page_body]
    corpus_tokens = [tokenize(doc) for doc in corpus]

    # Skip if our page is too short to score
    if len(corpus_tokens[-1]) < 50:
        return "unknown"

    query_tokens = tokenize(keyword)
    if not query_tokens:
        return "unknown"

    scores = bm25_scores(corpus_tokens, query_tokens)

    our_score = scores[-1]
    competitor_scores = sorted(scores[:-1], reverse=True)

    # Percentile: what fraction of competitors do we score >= ?
    beats = sum(1 for s in competitor_scores if our_score >= s)
    percentile = beats / len(competitor_scores)

    if percentile >= 0.5:
        return "close"
    elif percentile < 0.25:
        return "distant"
    return "close"  # default to adding when uncertain


def keyword_routing(keyword: str, keyword_data: dict,
                    item_slug: str, item_topic: str,
                    page_body: str, page_word_count: int,
                    page_keyword_count: int,
                    ownership: list[dict] | None = None,
                    competitor_texts: list[str] | None = None) -> dict:
    """Decide how to handle a keyword opportunity.

    Args:
        keyword: The GSC keyword string.
        keyword_data: Dict with impressions, position, score.
        item_slug: Slug of the page being analyzed.
        item_topic: Topic of the page.
        page_body: Page markdown content.
        page_word_count: Current word count.
        page_keyword_count: Total GSC keywords for this page.
        ownership: Pre-fetched keyword_ownership_batch result for this keyword.
        competitor_texts: Pre-fetched competitor texts for BM25 (may be None).

    Returns:
        {action: "add_section"|"add_substantial"|"mention_link"|"create",
         reason: str, target_slug: str|None}
    """
    # Check if another page in same topic ranks better
    if ownership:
        same_topic = [o for o in ownership
                      if o["topic"] == item_topic and o["slug"] != item_slug]
        if same_topic:
            best = same_topic[0]  # sorted by position ASC
            if best["position"] < keyword_data.get("position", 100):
                return {
                    "action": "link",
                    "reason": f"/{item_topic}/{best['slug']}/ ranks #{best['position']:.0f}",
                    "target_slug": best["slug"],
                }

    # Signal A: impression ratio
    ratio = keyword_data.get("impressions", 0)
    page_top = keyword_data.get("_page_top_impressions", 1)
    if page_top > 0:
        imp_ratio = ratio / page_top
    else:
        imp_ratio = 0.0

    # Signal B: page breadth
    page_broad = (page_word_count > BROAD_WORD_THRESHOLD
                  and page_keyword_count > BROAD_KEYWORD_THRESHOLD)

    # Signal C: BM25 (only for high-ratio keywords to save cost)
    if imp_ratio > HIGH_RATIO_THRESHOLD and competitor_texts is not None:
        fit = bm25_semantic_fit(keyword, page_body, competitor_texts)
    else:
        fit = "close"  # default for low-ratio (obvious subtopics)

    # Route per decision matrix
    if imp_ratio > HIGH_RATIO_THRESHOLD:
        if fit == "distant" or page_broad:
            return {"action": "create",
                    "reason": f"ratio={imp_ratio:.0%}, fit={fit}, broad={page_broad}",
                    "target_slug": None}
        else:
            return {"action": "add_substantial",
                    "reason": f"ratio={imp_ratio:.0%}, fits on page",
                    "target_slug": None}
    else:
        if fit == "distant":
            return {"action": "mention_link",
                    "reason": f"ratio={imp_ratio:.0%}, semantically distant",
                    "target_slug": None}
        else:
            return {"action": "add_section",
                    "reason": f"ratio={imp_ratio:.0%}, subtopic",
                    "target_slug": None}


def build_amendment_brief(item, search_data: dict | None,
                          topic: str,
                          overlap_slugs: set | None = None,
                          ownership_map: dict | None = None,
                          min_opportunity_score: float = 15.0,
                          touched_within_days: int = 28) -> dict:
    """Build a complete improvement brief for a single page.

    All analysis is local (free). No API calls.

    Args:
        item: Content item (needs .read_index(), .slug, .news_files(),
              .get_stamp(), .index_path).
        search_data: GSC data from get_search_terms(), or None.
        topic: Topic name.
        overlap_slugs: Set of slugs blocked by merge/differentiate.
        ownership_map: Pre-fetched keyword_ownership_batch results.
        min_opportunity_score: Minimum score threshold for keywords.
        touched_within_days: Skip pages touched within this many days.

    Returns:
        Amendment brief dict with skip_reason=None if actionable.
    """
    brief = {
        "expand_keywords": [],
        "link_targets": [],
        "heading_promotions": [],
        "create_suggestions": [],
        "news_files": [],
        "thin_content": False,
        "word_count": 0,
        "skip_reason": None,
    }

    # Gate: blocked by overlaps
    if overlap_slugs and item.slug in overlap_slugs:
        brief["skip_reason"] = "blocked by overlap (run deduplicate first)"
        return brief

    # Gate: recently touched
    last_date = item.get_stamp("date")
    if last_date:
        if isinstance(last_date, str):
            last_dt = datetime.strptime(last_date, "%Y-%m-%d")
        else:
            last_dt = datetime.combine(last_date, datetime.min.time())
        age = (datetime.now() - last_dt).days
        if age < touched_within_days:
            brief["skip_reason"] = f"touched {age} days ago (waiting for Google)"
            return brief

    # Gate: no GSC data
    if not search_data:
        brief["skip_reason"] = "no GSC data"
        return brief

    # Read page and strip frontmatter
    raw = item.read_index()
    if not raw or not raw.strip():
        brief["skip_reason"] = "empty page"
        return brief

    post = fm.loads(raw)
    body = post.content

    if not body or not body.strip():
        brief["skip_reason"] = "empty page"
        return brief

    word_count = len(body.split())
    brief["word_count"] = word_count
    brief["thin_content"] = word_count < 500

    # Check news files (news_files() returns [] if no directory)
    brief["news_files"] = item.news_files() or []

    # Filter opportunity keywords: position 5-30, score > threshold
    page_queries = search_data.get("page_queries", [])
    opportunities = [
        q for q in page_queries
        if 5 < q.get("position", 0) <= 30
        and q.get("score", 0) >= min_opportunity_score
    ]

    if not opportunities and not brief["news_files"]:
        brief["skip_reason"] = "no opportunities and no news"
        return brief

    # Get page's top keyword impressions for ratio calculation
    all_impressions = [q.get("impressions", 0) for q in page_queries]
    page_top_imp = max(all_impressions) if all_impressions else 1

    # Get keyword count for breadth check
    page_kw_count = len(page_queries)

    # Check keyword presence
    presence = keyword_presence(body, opportunities)

    for kp in presence:
        kw = kp["keyword"]
        status = kp["status"]

        if status == "in_heading":
            continue  # already well-covered

        if status == "body_only":
            brief["heading_promotions"].append({
                "keyword": kw,
                "status": "body_only",
                "section_context": kp["section_context"],
            })
            continue

        # Absent keyword — route it
        kw_data = next((q for q in opportunities if q["query"] == kw), {})
        kw_data["_page_top_impressions"] = page_top_imp

        # Get ownership info from pre-fetched map
        kw_ownership = (ownership_map or {}).get(kw)

        routing = keyword_routing(
            keyword=kw,
            keyword_data=kw_data,
            item_slug=item.slug,
            item_topic=topic,
            page_body=body,
            page_word_count=word_count,
            page_keyword_count=page_kw_count,
            ownership=kw_ownership,
        )

        if routing["action"] == "link":
            brief["link_targets"].append({
                "keyword": kw,
                "target_slug": routing["target_slug"],
                "target_path": f"/{topic}/{routing['target_slug']}/",
            })
        elif routing["action"] == "create":
            brief["create_suggestions"].append({
                "keyword": kw,
                "impressions": kw_data.get("impressions", 0),
                "reason": routing["reason"],
            })
        elif routing["action"] in ("add_section", "add_substantial"):
            brief["expand_keywords"].append({
                "keyword": kw,
                "position": kw_data.get("position", 0),
                "impressions": kw_data.get("impressions", 0),
                "score": kw_data.get("score", 0),
                "routing": routing["action"],
            })
        elif routing["action"] == "mention_link":
            # Brief mention — treat as a lightweight expand
            brief["expand_keywords"].append({
                "keyword": kw,
                "position": kw_data.get("position", 0),
                "impressions": kw_data.get("impressions", 0),
                "score": kw_data.get("score", 0),
                "routing": "mention_link",
            })

    # Cap expand keywords to avoid overloading the prompt
    brief["expand_keywords"] = sorted(
        brief["expand_keywords"],
        key=lambda x: x.get("score", 0),
        reverse=True,
    )[:5]

    # Set skip if nothing actionable
    if (not brief["expand_keywords"] and not brief["link_targets"]
            and not brief["heading_promotions"] and not brief["news_files"]):
        brief["skip_reason"] = "keywords already covered"

    return brief
