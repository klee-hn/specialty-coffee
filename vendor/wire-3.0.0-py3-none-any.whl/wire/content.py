#!/usr/bin/env python3
"""
Content (content.py)

Creates and refines content pages.

Usage:
    python -m wire.content create vendors/anyline           # Create new vendor
    python -m wire.content refine vendors/abbyy             # Refine existing vendor
    python -m wire.content expand vendors/abbyy "pricing"   # Expand with specific topic
    python -m wire.content consolidate vendors/abbyy        # Consolidate comparisons into hub

For batch processing: python -m wire.chief content vendors
"""
import shutil
import argparse
import logging
import frontmatter
from datetime import datetime, timedelta

from wire import tools
from wire.tools import claude_text, load_prompt, web_search, fetch_page, validate_frontmatter, write_md, Content, Topic, NEWS_API_MAX_DAYS_BACK, generate_link_context, analyze_source_diversity, format_source_diversity, find_primary_sources, add_redirect
from wire.discovery import extract_h2_ids
from wire.gsc import get_search_terms
from wire.news import NewsReporter

logger = logging.getLogger(__name__)


# ============================================================================
# Conversational output detection — rejects meta-commentary from Claude
# ============================================================================

_CONVERSATIONAL_STARTS = (
    "the page has already been",
    "the page looks complete",
    "the page is already",
    "the content has already",
    "the content looks",
    "this page has already",
    "this page looks",
    "i've reviewed",
    "i have reviewed",
    "after reviewing",
    "looking at the",
    "based on my review",
    "here's what i",
    "here is what i",
    "no changes needed",
    "no updates needed",
    "no changes are needed",
    "no updates are needed",
)

_CONVERSATIONAL_PHRASES = (
    "would you like me to",
    "is there something specific",
    "let me know if",
    "shall i",
    "do you want me to",
    "happy to help",
    "i can help",
    "would you prefer",
    "here are some options",
    "here are the options",
)


def _is_conversational(text: str) -> str | None:
    """Detect conversational/meta output from Claude instead of page content.

    Returns a reason string if conversational, None if the output looks like
    real content.
    """
    stripped = text.strip()
    if not stripped:
        return None

    # Check first non-frontmatter line
    body = stripped
    if body.startswith("---"):
        parts = body.split("---", 2)
        if len(parts) >= 3:
            body = parts[2].strip()

    first_line = body.split("\n")[0].strip().lower() if body else ""

    for pattern in _CONVERSATIONAL_STARTS:
        if first_line.startswith(pattern):
            return f"conversational output detected: starts with '{first_line[:60]}'"

    lower = body.lower()
    for phrase in _CONVERSATIONAL_PHRASES:
        if phrase in lower:
            return f"conversational output detected: contains '{phrase}'"

    # Numbered options list after a meta-statement (e.g., "Options:\n1. ...")
    if "options:" in lower:
        import re
        if re.search(r'options:\s*\n\s*1\.', lower):
            return "conversational output detected: contains numbered options list"

    return None


def _format_search_terms(data: dict) -> str:
    """Format get_search_terms() dict as markdown tables for prompt injection."""
    lines = [
        "### Queries this page ranks for",
        "| Search Term | Impressions | Clicks | Avg Position |",
        "|---|---|---|---|",
    ]
    for q in data.get("page_queries", []):
        lines.append(f"| {q['query']} | {q['impressions']} | {q['clicks']} | {q['position']} |")
    if not data.get("page_queries"):
        lines.append("| (no data) | - | - | - |")

    lines.extend([
        "",
        "### Brand queries ranking on OTHER pages (opportunities)",
        "| Search Term | Impressions | Ranking Page |",
        "|---|---|---|",
    ])
    for q in data.get("opportunities", []):
        lines.append(f"| {q['query']} | {q['impressions']} | {q['ranking_page']} |")
    if not data.get("opportunities"):
        lines.append("| (no data) | - | - |")

    return "\n".join(lines)


def _format_opportunity_hints(search_data: dict) -> str:
    """Extract high-score page queries as markdown table for news_search hints.

    Filters page_queries to position 4-30, sorted by score descending.
    """
    candidates = [
        q for q in search_data.get("page_queries", [])
        if 3 < q["position"] <= 30 and q.get("score", 0) > 0
    ]
    if not candidates:
        return ""
    candidates.sort(key=lambda q: q["score"], reverse=True)
    lines = [
        "| Query | Impressions | Position | Score |",
        "|---|---|---|---|",
    ]
    for q in candidates[:50]:
        lines.append(f"| {q['query']} | {q['impressions']} | {q['position']} | {q['score']} |")
    return "\n".join(lines)


class ContentEditor:
    """
    Content Editor - creates and refines content pages.

    Methods:
        create(topic, hint) - Create new content from research
        update(item) - Gather news and refine existing content
        refine(item) - Refine existing content with pending news
    """

    def __init__(self, nogsc: bool = False):
        self.reporter = NewsReporter()
        self.nogsc = nogsc

    def _archive_news(self, item: Content, news_files: list):
        """Move processed news files to news/ subfolder."""
        archive_dir = item.fs_path / "news"
        archive_dir.mkdir(exist_ok=True)

        for filepath in news_files:
            if filepath.exists():
                shutil.move(str(filepath), str(archive_dir / filepath.name))

    def create(self, topic: str, hint: str) -> str:
        """
        Create new content from research.

        Args:
            topic: Topic name (e.g., "vendors", "capabilities")
            hint: Hint for what to create (e.g., "anyline", "ABBYY OCR vendor")

        Returns:
            Result string for logging
        """
        logger.info(f"Creating {topic}/{hint}: researching...")

        urls = web_search(hint)

        if not urls:
            return "failed (no URLs found)"

        # Fetch content from URLs
        research_parts = []
        for url in urls:
            logger.info(f"Creating {topic}/{hint}: fetching {url}")
            text = fetch_page(url)
            if text:
                research_parts.append(f"## Source: {url}\n\n{text[:5000]}")

        if not research_parts:
            return "failed (no content fetched)"

        research = "\n\n---\n\n".join(research_parts)

        # Build prompt
        slug = Content.make_slug(hint)
        target = tools.DOCS_DIR / topic / slug
        if (target / "index.md").exists():
            logger.warning(f"Already exists: {topic}/{slug}")
            return f"skipped ({slug} already exists)"

        item = Content(slug=slug, title=hint,
                       path=f"/{topic}/{slug}/", summary="")
        site_directory = generate_link_context(item)

        example_page = ""
        try:
            items = Topic(topic).list()
            if items:
                example_page = f"```markdown\n{items[0].read_index()}\n```"
        except (ValueError, FileNotFoundError) as e:
            logger.warning(f"Could not load example page for topic '{topic}': {e}")

        prompt = load_prompt(topic, "content_create", item=item,
                             research=research, site_directory=site_directory,
                             example_page=example_page)

        # Call Claude -- outputs complete markdown file directly
        logger.info(f"Creating {topic}/{hint}: generating initial content...")
        response = claude_text(prompt, description=f"Create: {hint}", max_tokens=8000, temperature=0.3)

        if not response:
            return "failed (API error)"

        # Validate and save -- Claude outputs frontmatter + body
        item.save_index(response)
        item.stamp(wire_action="created")

        logger.info(f"Created {topic}/{slug}")
        return f"created ({slug})"

    def update(self, item: Content, days: int = NEWS_API_MAX_DAYS_BACK) -> str:
        """
        Gather news and refine existing content.

        Args:
            item: Content item to update
            days: Number of days back to search for news

        Returns:
            Result string for logging
        """
        logger.info(f"Updating {item.topic}/{item.slug}: gathering news ({days} days)...")

        # Fetch GSC data once -- used for both news hints and content refinement
        search_data = None
        search_hints = ""
        try:
            search_data = get_search_terms(item.slug, item.title, item.topic)
            if search_data:
                search_hints = _format_opportunity_hints(search_data)
                if search_hints:
                    n = len([q for q in search_data["page_queries"] if q["position"] > 3])
                    logger.info(f"Updating {item.topic}/{item.slug}: GSC search hints ({n} terms)")
        except (ValueError, OSError) as e:
            logger.warning(f"GSC failed for {item.slug}: {e}")

        # Gather news (single web search with GSC hints as research directions)
        to_date = datetime.now()
        from_date = to_date - timedelta(days=days)
        news_result = self.reporter.cover_item(item, from_date, to_date,
                                               max_articles=20, search_hints=search_hints)
        logger.info(f"Updating {item.topic}/{item.slug}: news -> {news_result}")

        # Refine if news was found -- reuse GSC data to avoid redundant API call
        if news_result != "no news":
            logger.info(f"Updating {item.topic}/{item.slug}: refining with news...")
            refine_result = self.refine(item, search_data=search_data)
            logger.info(f"Updating {item.topic}/{item.slug}: refine -> {refine_result}")
            return f"{news_result} + {refine_result}"

        return "no news"

    def refine(self, item: Content, search_data: dict = None) -> str:
        """
        Refine a single item's index.md with pending news.

        Args:
            item: Content item to refine
            search_data: Pre-fetched GSC data (from update). Fetched if None.

        Returns:
            Result string for logging (e.g., "refined (3 files)", "skipped (no news)")
        """
        # Get pending news files
        news_files = item.news_files()
        if not news_files:
            return "skipped (no news)"

        # Read and combine news
        news_parts = [f.read_text(encoding='utf-8') for f in news_files]
        if not any(news_parts):
            return "skipped (empty news files)"

        # Skip tracker-only files (no real news to integrate)
        all_trackers = all(
            frontmatter.load(f).get('type') == 'tracker' for f in news_files
        )
        if all_trackers:
            try:
                self._archive_news(item, news_files)
            except OSError as e:
                logger.warning(f"Failed to archive trackers for {item.slug}: {e}")
                return f"failed (tracker archive error: {e})"
            return f"skipped (tracker only, {len(news_files)} archived)"

        combined_news = "\n\n".join(news_parts)

        old_h2s = extract_h2_ids(item.read_index())

        # Call Claude
        if search_data is None and not self.nogsc:
            search_data = get_search_terms(item.slug, item.title, item.topic)
        formatted_search = _format_search_terms(search_data) if search_data else ""
        site_directory = generate_link_context(item)
        diversity = analyze_source_diversity(item.read_index())
        source_diversity = format_source_diversity(diversity)
        if diversity["concentrated"]:
            primary = find_primary_sources(diversity)
            if primary:
                source_diversity += "\n\n" + primary
        prompt = load_prompt(item.topic, "content_update", item=item,
                             current_page=item.read_index(), news_research=combined_news,
                             search_terms=formatted_search, site_directory=site_directory,
                             source_diversity=source_diversity)
        refined = claude_text(prompt, description=f"ContentEditor: {item.slug}", max_tokens=16000, temperature=0.2)

        if not refined:
            return "failed (API error)"

        # Conversational output guard — reject meta-commentary
        conv_reason = _is_conversational(refined)
        if conv_reason:
            logger.error(f"REJECTED [{item.slug}]: {conv_reason}")
            return f"rejected ({conv_reason})"

        # Body shrinkage guard — prevents content destruction
        original_body = item.read_index()
        original_words = len(original_body.split())
        refined_words = len(refined.split())
        if original_words > 50 and refined_words < original_words * 0.8:
            logger.error(f"REJECTED [{item.slug}]: body shrank >20% "
                         f"({original_words} -> {refined_words} words) — "
                         f"original preserved")
            return "rejected (body shrank >20%)"

        # Save first, then archive. If save fails, news files remain
        # available for retry. Re-processing on archive failure is harmless
        # (Claude gets same news + already-updated page); data loss is not.
        item.save_index(refined)
        item.stamp(wire_action="refined")
        self._maybe_rediscover(item, old_h2s)

        try:
            self._archive_news(item, news_files)
        except OSError as e:
            logger.warning(f"Refined {item.slug} but archive failed: {e}")
            return f"refined ({len(news_files)} files, archive pending)"

        return f"refined ({len(news_files)} files)"

    def seo(self, item: Content, target_keywords: str, search_terms: str) -> str:
        """
        Reword existing content to naturally embed search terms. No web research.

        Args:
            item: Content item to optimize
            target_keywords: Top opportunity keywords (formatted for display)
            search_terms: Full GSC ranking data via _format_search_terms()

        Returns:
            Result string for logging
        """
        logger.info(f"SEO reword {item.topic}/{item.slug}")

        old_h2s = extract_h2_ids(item.read_index())

        site_directory = generate_link_context(item)
        prompt = load_prompt(item.topic, "content_seo", item=item,
                             current_page=item.read_index(),
                             target_keywords=target_keywords,
                             search_terms=search_terms,
                             site_directory=site_directory)
        reworded = claude_text(prompt, description=f"SEO: {item.slug}", max_tokens=16000, temperature=0.2)

        if not reworded:
            return "failed (API error)"

        # Conversational output guard
        conv_reason = _is_conversational(reworded)
        if conv_reason:
            logger.error(f"REJECTED [{item.slug}]: {conv_reason}")
            return f"rejected ({conv_reason})"

        item.save_index(reworded)
        today = datetime.now().strftime("%Y-%m-%d")
        item.stamp(wire_action="reworded", wire_reworded=today)
        self._maybe_rediscover(item, old_h2s)
        return "seo reworded"

    def seo_light(self, item: Content, target_keywords: str, search_terms: str) -> str:
        """
        Optimize only title and description frontmatter for search terms.

        Lighter alternative to seo() -- touches only the HTML <title> and meta
        description, not the body. Used for tier 2 pages (rank 20-50% by
        opportunity score) where a full rewrite isn't worth the cost.

        Args:
            item: Content item to optimize
            target_keywords: Top opportunity keywords (formatted for display)
            search_terms: Full GSC ranking data via _format_search_terms()

        Returns:
            Result string for logging
        """
        logger.info(f"SEO light {item.topic}/{item.slug}")

        prompt = load_prompt(item.topic, "content_seo_light", item=item,
                             current_page=item.read_index(),
                             target_keywords=target_keywords,
                             search_terms=search_terms)
        reworded = claude_text(prompt, description=f"SEO light: {item.slug}",
                               max_tokens=16000, temperature=0.2)

        if not reworded:
            return "failed (API error)"

        # Conversational output guard
        conv_reason = _is_conversational(reworded)
        if conv_reason:
            logger.error(f"REJECTED [{item.slug}]: {conv_reason}")
            return f"rejected ({conv_reason})"

        item.save_index(reworded)
        today = datetime.now().strftime("%Y-%m-%d")
        item.stamp(wire_action="seo_light", wire_reworded=today)
        return "seo light (title+desc)"

    def crosslink(self, item: Content, targets: list[dict]) -> str:
        """
        Add internal links to underlinked sibling pages.

        Args:
            item: Content item to process (add links FROM this page)
            targets: List of dicts with 'path', 'title', 'summary', 'inbound_count'

        Returns:
            Result string for logging
        """
        if not targets:
            return "skipped (no targets)"

        current = item.read_index()
        if not current:
            return "skipped (empty page)"

        # Check which targets are already linked in the page
        unlinked = [t for t in targets if t["path"] not in current]
        if not unlinked:
            return "skipped (all targets already linked)"

        # Format targets for prompt
        target_lines = []
        for t in unlinked:
            target_lines.append(
                f"- [{t['title']}]({t['path']}): {t['summary']} "
                f"({t['inbound_count']} inbound links)")
        targets_text = "\n".join(target_lines)

        site_directory = generate_link_context(item)
        prompt = load_prompt(item.topic, "content_crosslink", item=item,
                             current_page=current, targets=targets_text,
                             site_directory=site_directory)

        result = claude_text(prompt, description=f"Crosslink: {item.slug}",
                             max_tokens=16000, temperature=0.2)

        if not result:
            return "failed (API error)"

        # Conversational output guard
        conv_reason = _is_conversational(result)
        if conv_reason:
            logger.error(f"REJECTED [{item.slug}]: {conv_reason}")
            return f"rejected ({conv_reason})"

        # Body shrinkage guard — prevents content destruction from truncated responses
        original_words = len(current.split())
        result_words = len(result.split())
        if original_words > 50 and result_words < original_words * 0.8:
            logger.error(f"REJECTED [{item.slug}]: body shrank >20% "
                         f"({original_words} -> {result_words} words) — "
                         f"original preserved")
            return "rejected (body shrank >20%)"

        item.save_index(result)
        item.stamp(wire_action="crosslinked")
        return "crosslinked"

    def compare(self, topic: str, slug_a: str, slug_b: str) -> str:
        """
        Generate a comparison page between two content items.

        Args:
            topic: Topic name (e.g., "vendors")
            slug_a: First item slug (e.g., "abbyy")
            slug_b: Second item slug (e.g., "rossum")

        Returns:
            Result string for logging
        """
        # Load both items
        try:
            item_a = Content.from_location(f"{topic}/{slug_a}")
            item_b = Content.from_location(f"{topic}/{slug_b}")
        except (FileNotFoundError, ValueError) as e:
            return f"failed ({e})"

        page_a = item_a.read_index()
        page_b = item_b.read_index()

        if not page_a or not page_b:
            return "failed (could not read one or both pages)"

        # Build comparison slug
        comp_slug = f"{slug_a}-vs-{slug_b}"
        comp_item = Content(slug=comp_slug, title=f"{item_a.title} vs {item_b.title}",
                            path=f"/comparisons/{comp_slug}/", summary="")

        # Auto-create comparisons topic directory if missing
        comparisons_index = tools.DOCS_DIR / "comparisons" / "index.md"
        if not comparisons_index.exists():
            write_md(comparisons_index,
                     {"title": "Comparisons", "description": "Side-by-side comparisons", "layout": "page"},
                     "")
            logger.info("Auto-created comparisons topic directory")

        site_directory = generate_link_context(comp_item)
        prompt = load_prompt("comparisons", "content_compare", item=comp_item,
                             item_a=item_a.title, item_b=item_b.title,
                             page_a=page_a, page_b=page_b,
                             site_directory=site_directory)

        logger.info(f"Comparing {slug_a} vs {slug_b}")
        response = claude_text(prompt, description=f"Compare: {slug_a} vs {slug_b}",
                               max_tokens=8000, temperature=0.3)

        if not response:
            return "failed (API error)"

        # Save to comparisons directory
        comp_item.save_index(response)
        comp_item.stamp(wire_action="compared")

        logger.info(f"Created comparison: {comp_slug}")
        return f"compared ({comp_slug})"

    def consolidate(self, vendor_slug: str, topic_name: str) -> str:
        """
        Consolidate all primary comparisons for a vendor into a hub page.

        Args:
            vendor_slug: Vendor slug (e.g., "abbyy")
            topic_name: Topic containing the vendor page (e.g., "vendors")

        Returns:
            Result string for logging
        """
        # Load vendor page
        try:
            vendor = Content.from_location(f"{topic_name}/{vendor_slug}")
        except (FileNotFoundError, ValueError) as e:
            return f"failed ({e})"
        vendor_page = vendor.read_index()

        if not vendor_page:
            return "failed (could not read vendor page)"

        # Discover primary comparisons: {vendor_slug}-vs-*
        comparisons_dir = tools.DOCS_DIR / "comparisons"
        if not comparisons_dir.exists():
            return "skipped (no comparisons directory)"
        primary_dirs = sorted([
            d for d in comparisons_dir.iterdir()
            if d.is_dir() and d.name.startswith(f"{vendor_slug}-vs-")
        ])

        if not primary_dirs:
            return "skipped (no primary comparisons)"

        # Read each comparison's index.md
        comparison_parts = []
        for comp_dir in primary_dirs:
            index_file = comp_dir / "index.md"
            if index_file.exists():
                content = index_file.read_text(encoding='utf-8')
                comparison_parts.append(f"## COMPARISON: {comp_dir.name}\n\n{content}")

        if not comparison_parts:
            return "skipped (no comparison index.md files found)"

        comparison_pages = "\n\n---\n\n".join(comparison_parts)

        # Discover secondary comparisons: *-vs-{vendor_slug}
        secondary_dirs = sorted([
            d for d in comparisons_dir.iterdir()
            if d.is_dir() and d.name.endswith(f"-vs-{vendor_slug}")
        ])
        secondary_parts = []
        for comp_dir in secondary_dirs:
            other_slug = comp_dir.name.replace(f"-vs-{vendor_slug}", "")
            secondary_parts.append(f"- {other_slug} (on {other_slug}'s hub page at /evaluate/{other_slug}/)")
        secondary_comparisons = "\n".join(secondary_parts) if secondary_parts else "(none)"

        # Build prompt
        site_directory = generate_link_context(vendor)
        prompt = load_prompt("comparisons", "content_consolidate",
                             item_name=vendor.title,
                             item_slug=vendor_slug,
                             item_page=vendor_page,
                             comparison_pages=comparison_pages,
                             comparison_count=str(len(comparison_parts)),
                             secondary_comparisons=secondary_comparisons,
                             site_directory=site_directory)

        logger.info(f"Consolidating {vendor_slug}: {len(comparison_parts)} primary, {len(secondary_dirs)} secondary")
        response = claude_text(prompt, description=f"Consolidate: {vendor_slug}",
                               max_tokens=32000, temperature=0.3)

        if not response:
            return "failed (API error)"

        # Save to comparisons/{vendor_slug}/index.md
        hub_item = Content(slug=vendor_slug, title=f"{vendor.title} Comparisons",
                           path=f"/evaluate/{vendor_slug}/", summary="")
        hub_item.save_index(response)
        hub_item.stamp(wire_action="consolidated")

        logger.info(f"Consolidated {vendor_slug}: {len(comparison_parts)} comparisons")
        return f"consolidated ({len(comparison_parts)} comparisons)"

    def merge(self, keeper: Content, donor: Content, overlap_data: dict) -> str:
        """Merge donor page content into keeper page.

        Args:
            keeper: Content item to keep (stronger SEO)
            donor: Content item to absorb (will be archived)
            overlap_data: Dict from find_overlaps with shared_keywords

        Returns:
            Result string for logging

        Side effects:
            - Updates keeper's index.md with merged content
            - Renames donor's index.md to index.md.archived
        """
        logger.info(f"Merging {donor.slug} into {keeper.slug}")

        old_h2s = extract_h2_ids(keeper.read_index())

        keeper_page = keeper.read_index()
        donor_page = donor.read_index()

        # Format shared keywords table
        shared_keywords = self._format_shared_keywords(
            overlap_data, label_a="Keeper", label_b="Donor")
        site_directory = generate_link_context(keeper)

        prompt = load_prompt(keeper.topic, "content_merge", item=keeper,
                             donor_title=donor.title, keeper_page=keeper_page,
                             donor_page=donor_page, shared_keywords=shared_keywords,
                             site_directory=site_directory)
        merged = claude_text(prompt, description=f"Merge: {donor.slug} -> {keeper.slug}",
                             max_tokens=16000, temperature=0.2)

        if not merged:
            return "failed (API error)"

        # Conversational output guard
        conv_reason = _is_conversational(merged)
        if conv_reason:
            logger.error(f"REJECTED [{keeper.slug}]: {conv_reason}")
            return f"rejected ({conv_reason})"

        # Merge guard: output must retain at least 80% of keeper content
        try:
            merged_post = validate_frontmatter(merged)
            keeper_body_len = len(frontmatter.loads(keeper_page).content)
            merged_body_len = len(merged_post.content)
            if keeper_body_len > 500 and merged_body_len < keeper_body_len * 0.8:
                logger.error(f"REJECTED [{keeper.slug}]: merge output {merged_body_len} chars "
                             f"< 80% of keeper {keeper_body_len} chars — original preserved")
                return (f"rejected (merge guard: output too short, "
                        f"{merged_body_len}/{keeper_body_len} chars)")
        except ValueError:
            pass  # validate_frontmatter failed -- save_index will catch it

        keeper.save_index(merged)
        keeper.stamp(wire_action="merged")
        self._maybe_rediscover(keeper, old_h2s)

        # Archive donor and create redirect
        donor_index = donor.fs_path / "index.md"
        try:
            if donor_index.exists():
                donor_index.rename(donor.fs_path / "index.md.archived")

            # Create redirect page at donor URL -> keeper URL (preserves ~90-99% PageRank)
            keeper_url = f"/{keeper.topic}/{keeper.slug}/"
            redirect_md = (
                f"---\ntitle: {donor.title}\n"
                f"redirect: {keeper_url}\n"
                f"---\n\n"
                f'<meta http-equiv="refresh" content="0; url={keeper_url}">\n\n'
                f"This page has been merged into [{keeper.title}]({keeper_url}).\n"
            )
            donor_index.write_text(redirect_md, encoding="utf-8")
        except OSError as e:
            logger.warning(f"Merged {donor.slug} into {keeper.slug} but redirect failed: {e}")
            return f"merged ({donor.slug} -> {keeper.slug}, redirect failed)"

        # Add to central redirect map
        donor_url = f"/{donor.topic}/{donor.slug}/"
        add_redirect(donor_url, keeper_url,
                     reason=f"merged: {donor.slug} absorbed into {keeper.slug}")

        logger.info(f"Merged {donor.slug} into {keeper.slug} (redirect -> {keeper_url})")
        return f"merged ({donor.slug} -> {keeper.slug})"

    def differentiate(self, item: Content, competing: Content,
                      overlap_data: dict) -> str:
        """Reword page to reduce keyword competition with another page.

        Like seo() but with competing-page context and instructions
        to drop specific keywords + add cross-links.

        Args:
            item: Content item to differentiate (imp_a in overlap_data)
            competing: The competing Content item (imp_b in overlap_data)
            overlap_data: Dict from find_overlaps with shared_keywords.
                imp_a/pos_a must correspond to `item`, imp_b/pos_b to `competing`.

        Returns:
            Result string for logging
        """
        logger.info(f"Differentiating {item.slug} from {competing.slug}")

        old_h2s = extract_h2_ids(item.read_index())

        current_page = item.read_index()
        competing_page = competing.read_index()

        shared_keywords = self._format_shared_keywords(
            overlap_data, label_a="This Page", label_b="Competing")
        site_directory = generate_link_context(item)

        prompt = load_prompt(item.topic, "content_differentiate", item=item,
                             competing_title=competing.title,
                             competing_path=competing.path,
                             current_page=current_page,
                             competing_page=competing_page,
                             shared_keywords=shared_keywords,
                             site_directory=site_directory)
        differentiated = claude_text(prompt,
                                     description=f"Differentiate: {item.slug} vs {competing.slug}",
                                     max_tokens=16000, temperature=0.2)

        if not differentiated:
            return "failed (API error)"

        # Conversational output guard
        conv_reason = _is_conversational(differentiated)
        if conv_reason:
            logger.error(f"REJECTED [{item.slug}]: {conv_reason}")
            return f"rejected ({conv_reason})"

        item.save_index(differentiated)
        today = datetime.now().strftime("%Y-%m-%d")
        item.stamp(wire_action="differentiated",
                   wire_differentiated=today,
                   wire_differentiated_from=competing.slug)
        self._maybe_rediscover(item, old_h2s)
        return f"differentiated ({item.slug} from {competing.slug})"

    @staticmethod
    def _format_shared_keywords(overlap_data: dict,
                                label_a: str = "A",
                                label_b: str = "B") -> str:
        """Format shared_keywords from overlap_data into a markdown table.

        Args:
            overlap_data: Dict with 'shared_keywords' list
            label_a: Column header for imp_a/pos_a (e.g., "This Page", "Keeper")
            label_b: Column header for imp_b/pos_b (e.g., "Competing", "Donor")
        """
        keywords = overlap_data.get("shared_keywords", [])
        if not keywords:
            return "(no shared keywords data)"
        lines = [
            f"| Keyword | Impressions {label_a} | Impressions {label_b} | Position {label_a} | Position {label_b} |",
            "|---|---|---|---|---|",
        ]
        for kw in keywords:
            lines.append(
                f"| {kw['keyword']} | {kw['imp_a']} | {kw['imp_b']} "
                f"| {kw['pos_a']} | {kw['pos_b']} |"
            )
        return "\n".join(lines)

    def expand(self, item: Content, expansion_topic: str) -> str:
        """
        Expand a page with targeted research on a specific topic.

        Args:
            item: Content item to expand
            expansion_topic: Topic to research and add (e.g., "pricing", "SDK integration")

        Returns:
            Result string for logging
        """
        logger.info(f"Expanding {item.topic}/{item.slug} with topic: {expansion_topic}")

        # Research the specific topic
        query = f"{item.title} {expansion_topic}"
        urls = web_search(query)

        if not urls:
            return "failed (no URLs found)"

        # Fetch content from URLs
        research_parts = []
        for url in urls:
            logger.info(f"Expanding {item.slug}: fetching {url}")
            text = fetch_page(url)
            if text:
                research_parts.append(f"## Source: {url}\n\n{text[:5000]}")

        if not research_parts:
            return "failed (no content fetched)"

        research = "\n\n---\n\n".join(research_parts)

        # Call Claude
        raw_search = get_search_terms(item.slug, item.title, item.topic)
        search_data = _format_search_terms(raw_search) if raw_search else ""
        site_directory = generate_link_context(item)
        prompt = load_prompt(item.topic, "content_expand", item=item,
                             expansion_topic=expansion_topic, current_page=item.read_index(),
                             research=research, search_terms=search_data,
                             site_directory=site_directory)
        expanded = claude_text(prompt, description=f"Expand: {item.slug} + {expansion_topic}", max_tokens=16000, temperature=0.2)

        if not expanded:
            return "failed (API error)"

        # Save updated content
        item.save_index(expanded)
        item.stamp(wire_action="expanded")

        return f"expanded ({expansion_topic})"

    def improve(self, item: Content, brief: dict,
                research: str = "", news: str = "",
                search_data: dict = None) -> str:
        """Execute a pre-built amendment brief in a single Claude call.

        Args:
            item: Content item to improve.
            brief: AmendmentBrief dict from build_amendment_brief().
            research: Pre-fetched web research text (for expand keywords).
            news: Combined pending news text.
            search_data: GSC data for search_terms formatting.

        Returns:
            Result string for logging.
        """
        logger.info(f"Improving {item.topic}/{item.slug}")

        old_h2s = extract_h2_ids(item.read_index())

        original_body = item.read_index()
        amendment_brief = _format_amendment_brief(brief)
        formatted_search = _format_search_terms(search_data) if search_data else ""
        site_directory = generate_link_context(item)

        prompt = load_prompt(item.topic, "content_improve", item=item,
                             current_page=original_body,
                             amendment_brief=amendment_brief,
                             research=research or "(no expansion research needed)",
                             news=news or "(no pending news)",
                             search_terms=formatted_search,
                             site_directory=site_directory)

        result = claude_text(prompt, description=f"Improve: {item.slug}",
                             max_tokens=16000, temperature=0.2)

        if not result:
            return "failed (API error)"

        # Conversational output guard
        conv_reason = _is_conversational(result)
        if conv_reason:
            logger.error(f"REJECTED [{item.slug}]: {conv_reason}")
            return f"rejected ({conv_reason})"

        # Verify Claude executed the brief
        warnings = _verify_improvement(original_body, result, brief)
        for w in warnings:
            logger.warning(f"  {item.slug}: {w}")

        # Body shrinkage guard
        if len(result.split()) < len(original_body.split()) * 0.8:
            logger.error(f"REJECTED [{item.slug}]: body shrank >20% — "
                         f"original preserved")
            return "rejected (body shrank >20%)"

        item.save_index(result)

        today = datetime.now().strftime("%Y-%m-%d")
        item.stamp(wire_action="improved", wire_improved=today)
        self._maybe_rediscover(item, old_h2s)

        # Archive news files if present
        news_files = brief.get("news_files", [])
        if news_files:
            try:
                self._archive_news(item, news_files)
            except OSError as e:
                logger.warning(f"Improved {item.slug} but archive failed: {e}")
                return f"improved (archive pending)"

        actions = []
        if brief.get("expand_keywords"):
            actions.append(f"{len(brief['expand_keywords'])} expanded")
        if brief.get("heading_promotions"):
            actions.append(f"{len(brief['heading_promotions'])} promoted")
        if brief.get("link_targets"):
            actions.append(f"{len(brief['link_targets'])} linked")
        if brief.get("news_files"):
            actions.append(f"{len(brief['news_files'])} news")
        detail = ", ".join(actions) if actions else "improved"

        warn_suffix = f" ({len(warnings)} warning(s))" if warnings else ""
        return f"improved ({detail}){warn_suffix}"

    def discover(self, item: Content) -> str:
        """Generate a discovery reading layer (steps.md) for a content page.

        Reads the page content, calls Claude to design a guided reading
        experience using :::hook/:::step/:::choices syntax, and saves
        the result as steps.md next to the page's index.md.

        Args:
            item: Content item to generate discovery steps for.

        Returns:
            Result string for logging.
        """
        raw = item.read_index()
        if not raw:
            return "skipped (empty page)"

        # Extract body after frontmatter
        post = frontmatter.loads(raw)
        if not post.content.strip():
            return "skipped (empty page)"

        # Extract H2 anchor IDs for step ID validation
        import re
        h2_id_set = extract_h2_ids(raw)
        h2_lines = re.findall(r'^## (.+)$', post.content, re.MULTILINE)
        h2_ids = []
        for h2 in h2_lines:
            slug = re.sub(r'[^\w\s-]', '', h2.lower())
            slug = re.sub(r'[-\s]+', '-', slug).strip('-')
            h2_ids.append(f"- `{slug}` ← {h2}")
        h2_list = "\n".join(h2_ids) if h2_ids else "(no H2 headings found)"

        prompt = load_prompt(item.topic, "content_steps", item=item,
                             current_page=raw, h2_anchors=h2_list)

        result = claude_text(prompt, description=f"Discover: {item.slug}",
                             max_tokens=4000, temperature=0.4)

        if not result:
            return "failed (API error)"

        # Conversational output guard
        conv_reason = _is_conversational(result)
        if conv_reason:
            logger.error(f"REJECTED [{item.slug}] steps.md: {conv_reason}")
            return f"rejected ({conv_reason})"

        # Strip any frontmatter Claude may have added
        if result.startswith("---"):
            parts = result.split("---", 2)
            if len(parts) >= 3:
                result = parts[2].strip()

        # steps.md must start with :::hook — reject if not step syntax
        if not result.strip().startswith(":::"):
            logger.error(f"REJECTED [{item.slug}] steps.md: output does not start with ::: step syntax")
            return "rejected (steps.md output not in ::: syntax)"

        # Validate step IDs match H2 anchors
        valid_ids = h2_id_set | {"start"}
        used_ids = re.findall(r':::step id="([^"]+)"', result)
        bad_ids = [sid for sid in used_ids if sid not in valid_ids]
        if bad_ids:
            logger.warning(f"  {item.slug}: invalid step IDs: {', '.join(bad_ids)}")

        # Warn about topic-label choices (skip exit lines)
        banned = re.compile(r'^- (?:I want to (?:see|understand|know|check|learn)'
                            r'|I need to (?:see|understand|know|check|learn)'
                            r'|Learn about |See the |See how )', re.IGNORECASE)
        choice_lines = [l.strip() for l in result.splitlines()
                        if l.strip().startswith('- ') and '-> end' not in l]
        bad_choices = [l for l in choice_lines if banned.match(l)]
        if bad_choices:
            logger.warning(f"  {item.slug}: {len(bad_choices)} topic-label choice(s)")

        steps_path = item.fs_path / "steps.md"
        steps_path.write_text(result, encoding="utf-8")
        return "discovered"

    def _maybe_rediscover(self, item: Content, old_h2s: set[str]) -> str | None:
        """Regenerate discovery steps if H2 anchors changed or no steps.md exists."""
        new_h2s = extract_h2_ids(item.read_index())
        steps_exist = (item.fs_path / "steps.md").exists()
        if old_h2s != new_h2s or not steps_exist:
            return self.discover(item)
        return None


def _format_amendment_brief(brief: dict) -> str:
    """Format amendment brief as markdown for prompt injection."""
    parts = []

    expand = brief.get("expand_keywords", [])
    if expand:
        lines = ["### Keywords to ADD (expand with research)",
                 "| Keyword | Position | Impressions | Action |",
                 "|---------|----------|-------------|--------|"]
        for kw in expand:
            lines.append(f"| {kw['keyword']} | {kw['position']:.0f} "
                         f"| {kw['impressions']} | {kw['routing']} |")
        parts.append("\n".join(lines))

    promotions = brief.get("heading_promotions", [])
    if promotions:
        lines = ["### Keywords to PROMOTE to headings",
                 "| Keyword | Currently in | Near section |",
                 "|---------|-------------|-------------|"]
        for hp in promotions:
            section = hp.get("section_context") or "(no section)"
            lines.append(f"| {hp['keyword']} | body only | {section} |")
        parts.append("\n".join(lines))

    links = brief.get("link_targets", [])
    if links:
        lines = ["### Internal links to ADD",
                 "| Keyword context | Link to | Path |",
                 "|----------------|---------|------|"]
        for lt in links:
            lines.append(f"| {lt['keyword']} | {lt['target_slug']} "
                         f"| {lt['target_path']} |")
        parts.append("\n".join(lines))

    news_files = brief.get("news_files", [])
    if news_files:
        names = ", ".join(f.name for f in news_files)
        parts.append(f"### Pending news to INTEGRATE\n{len(news_files)} "
                     f"file(s): {names}")

    if not parts:
        return "(no amendments needed)"

    return "\n\n".join(parts)


def _verify_improvement(original_body: str, new_body: str,
                        brief: dict) -> list[str]:
    """Check Claude actually executed the brief. Returns warning list."""
    warnings = []

    for kw in brief.get("expand_keywords", []):
        if kw["keyword"].lower() not in new_body.lower():
            warnings.append(f"expand keyword '{kw['keyword']}' not in output")

    for lt in brief.get("link_targets", []):
        if lt["target_path"] not in new_body:
            warnings.append(f"link to {lt['target_path']} not added")

    if len(new_body.split()) < len(original_body.split()) * 0.8:
        warnings.append("body shrank >20%")

    return warnings


def _format_seo_data(search_data: dict) -> tuple[str, str]:
    """Extract top SEO keywords and format search terms for prompts.

    Args:
        search_data: GSC data dict with page_queries

    Returns:
        (keywords_csv, formatted_search_terms) tuple
    """
    candidates = [
        q for q in search_data.get("page_queries", [])
        if 3 < q["position"] <= 30 and q.get("score", 0) > 0
    ]
    candidates.sort(key=lambda q: q["score"], reverse=True)
    keywords = ", ".join(q["query"] for q in candidates[:5])
    search_terms = _format_search_terms(search_data)
    return keywords, search_terms


def _parse_target(target: str) -> tuple[str, str]:
    """Parse 'topic/slug' target into (topic, slug).

    Raises:
        ValueError: If target doesn't contain a slash separator.
    """
    target = target.lstrip('/')
    if '/' not in target:
        raise ValueError(
            f"Invalid target '{target}'. Expected format: topic/slug "
            f"(e.g., vendors/abbyy)")
    topic, slug = target.split('/', 1)
    if not topic or not slug:
        raise ValueError(
            f"Invalid target '{target}'. Both topic and slug are required "
            f"(e.g., vendors/abbyy)")
    return topic, slug


def main():
    from wire import __version__
    parser = argparse.ArgumentParser(
        description="Wire - content operations for individual pages",
        epilog="Commands & cost (per page, Claude Sonnet):\n"
               "  create    vendors/anyline              ~$0.05  web research + new page\n"
               "  update    vendors/abbyy                ~$0.08  gather news + refine\n"
               "  refine    vendors/abbyy                ~$0.03  integrate pending news\n"
               "  seo       vendors/abbyy                ~$0.04  full SEO rewrite (needs: data)\n"
               "  seo-light vendors/abbyy                ~$0.02  title + description only (needs: data)\n"
               "  expand    vendors/abbyy \"pricing\"      ~$0.05  targeted research on aspect\n"
               "  compare   vendors/abbyy vendors/rossum ~$0.04  side-by-side comparison\n"
               "  consolidate vendors/abbyy              ~$0.04  hub page from comparisons\n"
               "  steps     guides/seo-reference          ~$0.02  generate discovery steps.md\n"
               "\n"
               "Tips:\n"
               "  seo/seo-light require GSC data: run 'python -m wire.chief data' first\n"
               "\n"
               "For batch processing: python -m wire.chief -h",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument('--version', action='version', version=f'wire {__version__}')
    parser.add_argument('--nogsc', action='store_true',
                        help='Skip GSC database lookups (for new sites without search data)')
    subparsers = parser.add_subparsers(dest='command', required=True)

    # Create subcommand
    create_parser = subparsers.add_parser('create', help='Create new content')
    create_parser.add_argument('target', help='Topic/hint (e.g., vendors/anyline)')

    # Update subcommand
    update_parser = subparsers.add_parser('update', help='Gather news and refine')
    update_parser.add_argument('target', help='Content location (e.g., vendors/abbyy)')
    update_parser.add_argument('--days', type=int, default=NEWS_API_MAX_DAYS_BACK,
                               help=f'Days back to search (default: {NEWS_API_MAX_DAYS_BACK})')

    # Refine subcommand
    refine_parser = subparsers.add_parser('refine', help='Refine with pending news only')
    refine_parser.add_argument('target', help='Content location (e.g., vendors/abbyy)')

    # SEO subcommand
    seo_parser = subparsers.add_parser('seo', help='SEO reword with GSC data')
    seo_parser.add_argument('target', help='Content location (e.g., vendors/abbyy)')

    # Expand subcommand
    expand_parser = subparsers.add_parser('expand', help='Expand page with specific topic')
    expand_parser.add_argument('target', help='Content location (e.g., vendors/abbyy)')
    expand_parser.add_argument('topic', help='Topic to expand (e.g., "pricing", "SDK")')

    # Compare subcommand
    compare_parser = subparsers.add_parser('compare', help='Compare two items side-by-side')
    compare_parser.add_argument('item_a', help='First item (e.g., vendors/abbyy)')
    compare_parser.add_argument('item_b', help='Second item (e.g., vendors/rossum)')

    # SEO Light subcommand
    seo_light_parser = subparsers.add_parser('seo-light', help='Optimize title + description only')
    seo_light_parser.add_argument('target', help='Content location (e.g., vendors/abbyy)')

    # Consolidate subcommand
    consolidate_parser = subparsers.add_parser('consolidate', help='Consolidate comparisons into hub page')
    consolidate_parser.add_argument('target', help='Vendor location (e.g., vendors/abbyy)')

    # Steps subcommand
    steps_parser = subparsers.add_parser('steps', help='Generate discovery reading layer (steps.md)')
    steps_parser.add_argument('target', help='Content location (e.g., guides/seo-reference)')

    args = parser.parse_args()

    editor = ContentEditor(nogsc=args.nogsc)

    try:
        _dispatch(args, editor)
    except (ValueError, FileNotFoundError) as e:
        logger.error(str(e))
        raise SystemExit(1)


def _dispatch(args, editor: ContentEditor):
    """Route CLI command to the appropriate editor method."""
    if args.command == 'create':
        topic, hint = _parse_target(args.target)
        result = editor.create(topic, hint)
        logger.info(f"{hint} -> {result}")
    elif args.command == 'update':
        item = Content.from_location(args.target)
        result = editor.update(item, days=args.days)
        logger.info(f"{item.slug} -> {result}")
    elif args.command == 'refine':
        item = Content.from_location(args.target)
        result = editor.refine(item)
        logger.info(f"{item.slug} -> {result}")
    elif args.command == 'seo':
        item = Content.from_location(args.target)
        search_data = get_search_terms(item.slug, item.title, item.topic)
        if not search_data:
            raise ValueError(
                f"No GSC data for {item.slug}. "
                f"Run first: python -m wire.chief data")
        keywords, search_terms = _format_seo_data(search_data)
        result = editor.seo(item, target_keywords=keywords, search_terms=search_terms)
        logger.info(f"{item.slug} -> {result}")
    elif args.command == 'seo-light':
        item = Content.from_location(args.target)
        search_data = get_search_terms(item.slug, item.title, item.topic)
        if not search_data:
            raise ValueError(
                f"No GSC data for {item.slug}. "
                f"Run first: python -m wire.chief data")
        keywords, search_terms = _format_seo_data(search_data)
        result = editor.seo_light(item, target_keywords=keywords, search_terms=search_terms)
        logger.info(f"{item.slug} -> {result}")
    elif args.command == 'expand':
        item = Content.from_location(args.target)
        result = editor.expand(item, args.topic)
        logger.info(f"{item.slug} -> {result}")
    elif args.command == 'compare':
        topic_a, slug_a = _parse_target(args.item_a)
        _, slug_b = _parse_target(args.item_b)
        result = editor.compare(topic_a, slug_a, slug_b)
        logger.info(f"{slug_a} vs {slug_b} -> {result}")
    elif args.command == 'consolidate':
        topic, slug = _parse_target(args.target)
        result = editor.consolidate(slug, topic_name=topic)
        logger.info(f"{slug} -> {result}")
    elif args.command == 'steps':
        item = Content.from_location(args.target)
        result = editor.discover(item)
        logger.info(f"{item.slug} -> {result}")


if __name__ == "__main__":
    main()
