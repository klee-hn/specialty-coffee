#!/usr/bin/env python3
"""
News (news.py)

Covers ONE item: searches, analyzes, saves.
- cover_item(): Full workflow - search, analyze, save
- gather_news(): Search for articles and return analyzed summary
- analyze_articles(): Analyze relevance and extract key facts
"""

import logging
import re
from dataclasses import dataclass
from typing import Dict, List, Optional
from urllib.parse import urlparse

from datetime import datetime
from wire.tools import claude_text, load_prompt, parse_decision, news_search, fetch_page, Content


def _strip_llm_frontmatter(text: str) -> str:
    """Strip LLM-generated YAML frontmatter or code blocks from the start of output."""
    stripped = text.lstrip()

    # Strip leading ```yaml ... ``` code block
    m = re.match(r'^```(?:yaml|yml)?\s*\n.*?```\s*\n?', stripped, re.DOTALL)
    if m:
        stripped = stripped[m.end():].lstrip()

    # Strip leading YAML frontmatter (--- ... ---)
    m = re.match(r'^---\s*\n.*?---\s*\n?', stripped, re.DOTALL)
    if m:
        stripped = stripped[m.end():].lstrip()

    # Strip orphaned ``` at start (partial code block)
    if stripped.startswith('```'):
        stripped = re.sub(r'^```\w*\s*\n?', '', stripped).lstrip()

    return stripped


@dataclass
class ArticleEvaluation:
    """One evaluated article — output of analyze_article()."""
    title: str
    url: str
    source_type: str
    why: str
    content: str

logger = logging.getLogger(__name__)


def _evaluate_output_format(item_name: str) -> str:
    """Output format instructions for article evaluation. Wired because code parses WHY lines."""
    return (
        "\n\n## Output Format\n\n"
        "Start with a WHY line:\n\n"
        "**NOT RELEVANT** (wrong subject, off-topic, pure marketing fluff):\n"
        "```\n"
        "WHY: NOT_RELEVANT - [Brief reason]\n"
        "```\n\n"
        "**RELEVANT** (skip sections with no information):\n"
        "```\n"
        f"WHY: [One sentence why this matters for {item_name}]\n\n"
        "## Summary\n"
        "[2-3 sentence summary in journalistic style]\n\n"
        "(then structured analysis with facts, quotes, context)\n"
        "```"
    )


class NewsReporter:
    """
    News Reporter - gathers and analyzes news.

    Methods:
        cover_item(item, from_date, to_date) - Full coverage: search, analyze, save
        gather_news(topic, item_title, from_date, to_date) - Search and analyze, return summary
        analyze_article(url, title, topic, item_name) - Evaluate ONE article
        combine(topic, item_name, results) - Combine multiple evaluations
    """

    def __init__(self):
        pass

    def _get_source_type(self, article_url: str, vendor_name: str) -> str:
        """
        Classify if article is from vendor (first-party) or third-party.

        Third-party coverage is generally more credible than vendor PR.
        """
        article_domain = urlparse(article_url).netloc
        # Simple heuristic: if vendor name appears in domain, it's first-party
        vendor_slug = vendor_name.lower().replace(' ', '')
        if vendor_slug in article_domain.lower():
            return "vendor"
        return "third_party"

    def _create_evaluate_prompt(self, topic: str, item_name: str, article_title: str,
                                  article_content: str, source_type: str,
                                  from_date: str = "", to_date: str = "") -> str:
        """Create prompt for evaluating ONE article."""
        if source_type == "vendor":
            source_type_note = "vendor's own content - may be marketing"
        else:
            source_type_note = "third-party coverage - generally more credible"

        prompt = load_prompt(topic, "news_evaluate", output="decision",
                             item_name=item_name, source_type=source_type,
                             source_type_note=source_type_note,
                             article_title=article_title, article_content=article_content,
                             from_date=from_date, to_date=to_date)

        # Output format — code parses WHY lines, so this is infrastructure
        prompt += _evaluate_output_format(item_name)
        return prompt

    def _create_combine_prompt(self, topic: str, item_name: str,
                               junior_summaries: List[ArticleEvaluation]) -> str:
        """Create prompt for combining multiple article analyses."""
        submissions = ""
        for i, s in enumerate(junior_summaries, 1):
            submissions += f"""
### Article {i}: {s.title}
**Source:** {s.url} ({s.source_type})
**Junior's Reasoning:** {s.why}

{s.content}

---
"""

        return load_prompt(topic, "news_combine",
                           item_name=item_name, submissions=submissions)

    def analyze_article(self, url: str, title: str, topic: str, item_name: str,
                        from_date: str = "", to_date: str = "") -> Optional[ArticleEvaluation]:
        """
        Evaluate a single article for relevance and extract key facts.

        Returns:
            ArticleEvaluation or None if not relevant
        """
        if not url or not url.startswith(('http://', 'https://')):
            logger.warning(f"SKIP (invalid URL): {title} | {url!r}")
            return None

        content = fetch_page(url)

        if not content or len(content) < 100:
            logger.warning(f"SKIP (no content): {title} | {url}")
            return None

        # Classify source
        source_type = self._get_source_type(url, item_name)

        # Evaluate article
        prompt = self._create_evaluate_prompt(
            topic, item_name, title, content, source_type,
            from_date=from_date, to_date=to_date
        )

        junior_output = claude_text(prompt, description=f"Junior: {title[:50]}", max_tokens=2000)

        if not junior_output:
            logger.error(f"SKIP (API failed): {title} | {url}")
            return None

        # Parse WHY line
        why, content_after_why = parse_decision(junior_output)

        if not why:
            logger.warning(f"SKIP (no WHY line): {title} | {url}")
            return None

        # Check if rejected
        if "NOT_RELEVANT" in why.upper():
            logger.info(f"REJECT: {title} | {why} | {url}")
            return None

        logger.info(f"ACCEPT: {title} | {why} | {url}")

        return ArticleEvaluation(
            title=title,
            url=url,
            source_type=source_type,
            why=why,
            content=content_after_why,
        )

    def combine(self, topic: str, item_name: str, eval_results: List[ArticleEvaluation]) -> Optional[str]:
        """
        Combine multiple article evaluations into executive summary.

        Args:
            topic: Topic type ("vendors" or "capabilities")
            item_name: Item being covered
            eval_results: List of dicts from analyze_article() (non-None results only)

        Returns:
            Markdown summary string, or None if combining fails
        """
        if not eval_results:
            logger.warning(f"{item_name}: No results to combine")
            return None

        combine_prompt = self._create_combine_prompt(topic, item_name, eval_results)

        summary = claude_text(combine_prompt, description=f"Combine: {item_name}", max_tokens=4000)

        if not summary:
            logger.error(f"{item_name}: Combine produced no output")
            return None

        # Strip any LLM-generated frontmatter or YAML code blocks
        summary = _strip_llm_frontmatter(summary)

        return summary

    def analyze_articles(self, topic: str, item_name: str, articles: List[Dict],
                         max_articles: int = 20,
                         from_date: str = "", to_date: str = "") -> Optional[str]:
        """
        Analyze multiple articles and return formatted summary.

        Evaluates each article (1 fetch + 1 Claude call each), combines via Senior,
        then appends a source list.

        Returns:
            Formatted markdown summary with source list, or None if no relevant articles
        """
        if not articles:
            return None

        eval_results = []

        for article in articles[:max_articles]:
            title = article.get('title', 'Untitled')
            url = article.get('url', '')

            if not url:
                continue

            analysis = self.analyze_article(url, title, topic, item_name,
                                            from_date=from_date, to_date=to_date)

            if analysis:
                eval_results.append(analysis)

        if not eval_results:
            return None

        summary = self.combine(topic, item_name, eval_results)

        if not summary:
            return None

        # Build source list
        result = f"{summary}\n\n---\n\n## Source Articles\n\n"
        for i, a in enumerate(eval_results, 1):
            result += f"{i}. [{a.title}]({a.url}) ({a.source_type})\n"
            result += f"   *{a.why}*\n\n"

        return result

    def gather_news(
        self,
        item: Content,
        from_date,
        to_date,
        max_articles: int = 20,
        search_hints: str = None,
        source_gaps: str = None
    ) -> Optional[str]:
        """
        Search for articles and analyze them.

        Args:
            item: Content item to search for
            from_date: Start date for news search
            to_date: End date for news search
            max_articles: Maximum articles to process
            search_hints: Formatted GSC opportunity data passed as research directions
            source_gaps: Formatted source concentration data for diverse sourcing

        Returns:
            Formatted markdown summary, or None if no relevant articles
        """
        articles = news_search(
            item=item,
            from_date=from_date,
            to_date=to_date,
            max_results=max_articles,
            search_hints=search_hints,
            source_gaps=source_gaps
        )

        if not articles:
            return None

        from_str = from_date.strftime('%Y-%m-%d') if hasattr(from_date, 'strftime') else str(from_date)
        to_str = to_date.strftime('%Y-%m-%d') if hasattr(to_date, 'strftime') else str(to_date)

        return self.analyze_articles(item.topic, item.title, articles, max_articles,
                                     from_date=from_str, to_date=to_str)

    def cover_item(self, item: Content, from_date: datetime, to_date: datetime,
                   max_articles: int = 20, search_hints: str = None,
                   source_gaps: str = None) -> str:
        """
        Cover an item: search, analyze, save.

        Args:
            item: Content item to cover
            from_date: Start date for news search
            to_date: End date for news search
            max_articles: Maximum articles to process
            search_hints: Formatted GSC opportunity data passed as research directions
            source_gaps: Formatted source concentration data for diverse sourcing

        Returns:
            Result string for logging (e.g., "2024-01-15.md", "no news")
        """
        summary = self.gather_news(item, from_date, to_date,
                                   max_articles, search_hints=search_hints,
                                   source_gaps=source_gaps)

        if summary:
            filepath = item.save_news(summary, from_date, to_date)
            return filepath.name
        else:
            item.save_tracker()
            return "no news"
