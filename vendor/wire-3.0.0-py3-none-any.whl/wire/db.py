#!/usr/bin/env python3
"""
GSC snapshot database for keyword overlap detection.

SQLite database at {site_dir}/.wire/gsc.db storing keyword-page snapshots.
Enables cross-page keyword overlap detection via SQL self-joins.

Schema inspired by contentconsole/database.py but simplified for Wire.
"""

import sqlite3
import logging
from pathlib import Path
from contextlib import contextmanager

logger = logging.getLogger(__name__)

SCHEMA_VERSION = 2  # Increment on each schema change

SCHEMA = """
CREATE TABLE IF NOT EXISTS Content (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lang TEXT NOT NULL DEFAULT '',
    topic TEXT NOT NULL,
    slug TEXT NOT NULL,
    path TEXT NOT NULL,
    first_checked TEXT,
    last_checked TEXT,
    created TEXT,
    UNIQUE(lang, topic, slug)
);

CREATE TABLE IF NOT EXISTS Keyword (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    keyword TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS Snapshot (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    keyword_id INTEGER NOT NULL REFERENCES Keyword(id),
    content_id INTEGER NOT NULL REFERENCES Content(id),
    impressions INTEGER NOT NULL DEFAULT 0,
    clicks INTEGER NOT NULL DEFAULT 0,
    position REAL,
    ctr REAL,
    date TEXT NOT NULL,
    UNIQUE(keyword_id, content_id, date)
);

CREATE TABLE IF NOT EXISTS GscUrl (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    url TEXT NOT NULL,
    impressions INTEGER NOT NULL DEFAULT 0,
    clicks INTEGER NOT NULL DEFAULT 0,
    discovery_date TEXT NOT NULL,
    UNIQUE(url, discovery_date)
);
"""


def _db_path(docs_dir: Path = None) -> Path:
    """Database lives at {site_dir}/.wire/gsc.db.

    Unified database for all languages — lang is a column, not a directory.
    When docs_dir is explicitly passed (tests), use docs_dir.parent/.wire/.
    """
    if docs_dir is not None:
        docs_dir = Path(docs_dir).resolve()
        wire_dir = docs_dir.parent / ".wire"
        wire_dir.mkdir(exist_ok=True)
        return wire_dir / "gsc.db"

    from wire.tools import SITE_DIR
    wire_dir = SITE_DIR / ".wire"
    wire_dir.mkdir(exist_ok=True, parents=True)
    return wire_dir / "gsc.db"


@contextmanager
def get_db(docs_dir: Path = None):
    """Context manager for database connections."""
    conn = sqlite3.connect(str(_db_path(docs_dir)), timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    except sqlite3.Error:
        try:
            conn.rollback()
        except sqlite3.Error as rb_err:
            logger.error(f"DB rollback failed: {rb_err}")
        raise
    finally:
        conn.close()


def _migrate_db(conn):
    """Run schema migrations up to SCHEMA_VERSION.

    Uses PRAGMA user_version to track which migrations have been applied.
    Each migration block is idempotent — safe to re-run on already-migrated DBs.
    Table rebuilds disable foreign_keys to avoid FK constraint failures on DROP.
    """
    current = conn.execute("PRAGMA user_version").fetchone()[0]

    if current >= SCHEMA_VERSION:
        return  # Already up to date

    if current < 1:
        # v0 → v1: Add missing columns to Content table (pre-existing DBs)
        cols = {row[1] for row in conn.execute("PRAGMA table_info(Content)").fetchall()}
        if cols:  # Table exists (could be empty on fresh DB)
            if "first_checked" not in cols:
                conn.execute("ALTER TABLE Content ADD COLUMN first_checked TEXT")
            if "last_checked" not in cols:
                conn.execute("ALTER TABLE Content ADD COLUMN last_checked TEXT")
            if "created" not in cols:
                conn.execute("ALTER TABLE Content ADD COLUMN created TEXT")
            if "lang" not in cols:
                conn.execute("ALTER TABLE Content ADD COLUMN lang TEXT DEFAULT ''")

    if current < 2:
        # v1 → v2: UNIQUE(topic, slug) → UNIQUE(lang, topic, slug)
        # SQLite cannot ALTER constraints — must rebuild the table.
        # Detect old constraint by checking if 'lang' is in the unique index.
        cols = {row[1] for row in conn.execute("PRAGMA table_info(Content)").fetchall()}
        if cols and "lang" not in cols:
            conn.execute("ALTER TABLE Content ADD COLUMN lang TEXT DEFAULT ''")

        old_constraint = False
        for idx in conn.execute("PRAGMA index_list(Content)").fetchall():
            if idx[3] == "u":  # unique index
                idx_cols = [
                    row[2] for row in
                    conn.execute(f"PRAGMA index_info({idx[1]})").fetchall()
                ]
                if "lang" not in idx_cols and "topic" in idx_cols and "slug" in idx_cols:
                    old_constraint = True
                    break

        if old_constraint:
            logger.info("Migrating Content table: UNIQUE(topic,slug) → UNIQUE(lang,topic,slug)")
            # Disable FK checks for table rebuild (Snapshot references Content)
            conn.execute("PRAGMA foreign_keys = OFF")
            try:
                conn.execute("DROP TABLE IF EXISTS Content_new")
                conn.execute("""
                    CREATE TABLE Content_new (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        lang TEXT NOT NULL DEFAULT '',
                        topic TEXT NOT NULL,
                        slug TEXT NOT NULL,
                        path TEXT NOT NULL,
                        first_checked TEXT,
                        last_checked TEXT,
                        created TEXT,
                        UNIQUE(lang, topic, slug)
                    )
                """)
                conn.execute("""
                    INSERT INTO Content_new (id, lang, topic, slug, path, first_checked, last_checked, created)
                        SELECT id, COALESCE(lang, ''), topic, slug, path, first_checked, last_checked, created
                        FROM Content
                """)
                conn.execute("DROP TABLE Content")
                conn.execute("ALTER TABLE Content_new RENAME TO Content")
                conn.commit()
            finally:
                conn.execute("PRAGMA foreign_keys = ON")

    conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
    conn.commit()


def init_db(docs_dir: Path = None):
    """Create tables if they don't exist. Migrates schema if needed.

    Detects stale per-language databases (.wire/{lang}/gsc.db) left over
    from the old split-DB approach and refuses to continue.
    """
    with get_db(docs_dir) as conn:
        conn.executescript(SCHEMA)
        _migrate_db(conn)

        # Indexes for overlap self-join performance
        conn.execute("CREATE INDEX IF NOT EXISTS idx_snapshot_keyword ON Snapshot(keyword_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_snapshot_content ON Snapshot(content_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_snapshot_kw_content ON Snapshot(keyword_id, content_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_content_lang ON Content(lang)")

    # Detect stale per-language databases
    if docs_dir is None:
        from wire.tools import SITE_DIR
        stale_dbs = list((SITE_DIR / ".wire").glob("*/gsc.db"))
        if stale_dbs:
            langs = [db.parent.name for db in stale_dbs]
            raise SystemExit(
                f"BUILD REFUSED: Found stale per-language databases: {', '.join(langs)}\n"
                f"Wire now uses a single database at .wire/gsc.db.\n"
                f"Delete: {', '.join(str(db) for db in stale_dbs)}\n"
                f"Then run: python -m wire.chief data")


def _get_or_create_content(conn, topic: str, slug: str,
                           lang: str = "") -> int:
    """Get or insert a Content row, return its id."""
    row = conn.execute(
        "SELECT id FROM Content WHERE lang = ? AND topic = ? AND slug = ?",
        (lang, topic, slug),
    ).fetchone()
    if row:
        return row["id"]
    cursor = conn.execute(
        "INSERT INTO Content (lang, topic, slug, path) VALUES (?, ?, ?, ?)",
        (lang, topic, slug, f"/{topic}/{slug}/"),
    )
    return cursor.lastrowid


def _resolve_lang(lang: str = "") -> str:
    """Resolve language: use explicit value, or fall back to _ACTIVE_LANG."""
    if lang:
        return lang
    try:
        from wire.tools import _ACTIVE_LANG
        return _ACTIVE_LANG
    except ImportError:
        return ""


def register_content(topic: str, slug: str, created: str = None,
                     lang: str = "", docs_dir: Path = None):
    """Register a content page in the database with check timestamps.

    Always creates the Content row if missing, and updates last_checked.
    Sets first_checked only on the first call (never overwrites it).
    Stores the frontmatter ``created`` date for dead-page age-gating.

    Called by search_data for every page BEFORE the API call, so even
    pages with no GSC data get tracked for age-gating dead page detection.
    """
    from datetime import datetime
    lang = _resolve_lang(lang)
    today = datetime.now().strftime('%Y-%m-%d')
    path = f"/{topic}/{slug}/"

    with get_db(docs_dir) as conn:
        row = conn.execute(
            "SELECT id, first_checked, created FROM Content "
            "WHERE lang = ? AND topic = ? AND slug = ?",
            (lang, topic, slug),
        ).fetchone()
        if row:
            conn.execute(
                "UPDATE Content SET last_checked = ? WHERE id = ?",
                (today, row["id"]),
            )
            if not row["first_checked"]:
                conn.execute(
                    "UPDATE Content SET first_checked = ? WHERE id = ?",
                    (today, row["id"]),
                )
            if created and not row["created"]:
                conn.execute(
                    "UPDATE Content SET created = ? WHERE id = ?",
                    (created, row["id"]),
                )
        else:
            conn.execute(
                """INSERT INTO Content (lang, topic, slug, path, first_checked, last_checked, created)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (lang, topic, slug, path, today, today, created),
            )


def _get_or_create_keyword(conn, keyword: str) -> int:
    """Get or insert a Keyword row, return its id."""
    row = conn.execute(
        "SELECT id FROM Keyword WHERE keyword = ?", (keyword,)
    ).fetchone()
    if row:
        return row["id"]
    cursor = conn.execute(
        "INSERT INTO Keyword (keyword) VALUES (?)", (keyword,)
    )
    return cursor.lastrowid


def store_snapshot(topic: str, slug: str, rows: list[dict],
                   date_str: str, lang: str = "", docs_dir: Path = None):
    """Store GSC API response rows into database.

    Args:
        topic: Topic name (e.g., "vendors")
        slug: Content slug (e.g., "abbyy")
        rows: List of dicts with keys: query, impressions, clicks, position, ctr
        date_str: Snapshot date (YYYY-MM-DD)
        lang: Language code (auto-populated from _ACTIVE_LANG if empty)
        docs_dir: Override DOCS_DIR for testing
    """
    lang = _resolve_lang(lang)
    with get_db(docs_dir) as conn:
        content_id = _get_or_create_content(conn, topic, slug, lang=lang)

        # Delete existing snapshot for this content+date (replace)
        conn.execute(
            """DELETE FROM Snapshot WHERE content_id = ? AND date = ?""",
            (content_id, date_str),
        )

        for row in rows:
            keyword_id = _get_or_create_keyword(conn, row["query"])
            impressions = int(row.get("impressions", 0))
            clicks = int(row.get("clicks", 0))
            position = row.get("position")
            ctr = clicks / impressions if impressions > 0 else 0.0
            conn.execute(
                """INSERT OR REPLACE INTO Snapshot
                   (keyword_id, content_id, impressions, clicks, position, ctr, date)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (keyword_id, content_id, impressions, clicks, position, ctr, date_str),
            )

    logger.info(f"Stored {len(rows)} keywords for {topic}/{slug} ({date_str})")


def get_snapshot_date(topic: str, slug: str, lang: str = "",
                      docs_dir: Path = None) -> str | None:
    """Get the most recent snapshot date for a content item, or None.

    Falls back to last_checked from Content table when no Snapshot rows
    exist (i.e. "no data" pages). This prevents re-fetching pages that
    returned no data on the previous run.
    """
    lang = _resolve_lang(lang)
    with get_db(docs_dir) as conn:
        row = conn.execute(
            """SELECT MAX(s.date) as latest
               FROM Snapshot s
               JOIN Content c ON s.content_id = c.id
               WHERE c.lang = ? AND c.topic = ? AND c.slug = ?""",
            (lang, topic, slug),
        ).fetchone()
        if row and row["latest"]:
            return row["latest"]

        # No snapshot data — check if we've checked this page before
        content_row = conn.execute(
            "SELECT last_checked FROM Content WHERE lang = ? AND topic = ? AND slug = ?",
            (lang, topic, slug),
        ).fetchone()
        return content_row["last_checked"] if content_row and content_row["last_checked"] else None


def has_snapshot_data(topic: str, slug: str, lang: str = "",
                      docs_dir: Path = None) -> bool:
    """Check whether a content item has any Snapshot rows in the database.

    Returns True if at least one Snapshot row exists for this content item.
    Used to detect Content rows that were registered (e.g. by discover_urls
    or register_content) but never had per-page keyword data fetched from
    the GSC API — e.g. after DB recreation with cached GscUrl data.
    """
    lang = _resolve_lang(lang)
    with get_db(docs_dir) as conn:
        row = conn.execute(
            """SELECT COUNT(*) as cnt
               FROM Snapshot s
               JOIN Content c ON s.content_id = c.id
               WHERE c.lang = ? AND c.topic = ? AND c.slug = ?""",
            (lang, topic, slug),
        ).fetchone()
        return row["cnt"] > 0 if row else False


def find_overlaps(topic: str = None, min_shared: int = 3,
                  lang: str = "", docs_dir: Path = None) -> list[dict]:
    """Find page pairs sharing keywords via SQL self-join.

    Args:
        topic: Filter to this topic only. None = detect across ALL topics.
        min_shared: Minimum shared keywords to include a pair.
        lang: Language filter. Empty string = single-language site.

    Returns list sorted by total_shared_impressions desc, each with:
        slug_a, slug_b, topic_a, topic_b, shared_count,
        total_shared_impressions, traffic_share_a, overlap_ratio,
        shared_keywords: [{keyword, imp_a, imp_b, pos_a, pos_b}]
    """
    lang = _resolve_lang(lang)
    with get_db(docs_dir) as conn:
        # Build topic filter conditionally
        if topic:
            topic_where = "AND c1.topic = ? AND c2.topic = ?"
            topic_params = (topic, topic)
        else:
            topic_where = ""
            topic_params = ()

        # Build lang filter
        if lang:
            lang_where = "AND c1.lang = ? AND c2.lang = ?"
            lang_params = (lang, lang)
        else:
            lang_where = ""
            lang_params = ()

        pairs = conn.execute(
            f"""
            SELECT
                c1.slug as slug_a,
                c2.slug as slug_b,
                c1.topic as topic_a,
                c2.topic as topic_b,
                c1.id as id_a,
                c2.id as id_b,
                COUNT(*) as shared_count,
                SUM(s1.impressions + s2.impressions) as total_shared_impressions,
                SUM(s1.impressions) as total_imp_a,
                SUM(s2.impressions) as total_imp_b
            FROM Snapshot s1
            JOIN Snapshot s2 ON s1.keyword_id = s2.keyword_id
                            AND s1.content_id < s2.content_id
            JOIN Content c1 ON s1.content_id = c1.id
            JOIN Content c2 ON s2.content_id = c2.id
            WHERE s1.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = s1.content_id)
              AND s2.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = s2.content_id)
              {topic_where}
              {lang_where}
            GROUP BY c1.id, c2.id
            HAVING shared_count >= ?
            ORDER BY total_shared_impressions DESC
            """,
            (*topic_params, *lang_params, min_shared),
        ).fetchall()

        results = []
        for pair in pairs:
            # Get individual keyword details for this pair (by content id)
            keywords = conn.execute(
                """
                SELECT
                    k.keyword,
                    s1.impressions as imp_a,
                    s2.impressions as imp_b,
                    s1.position as pos_a,
                    s2.position as pos_b
                FROM Snapshot s1
                JOIN Snapshot s2 ON s1.keyword_id = s2.keyword_id
                                AND s1.content_id = ? AND s2.content_id = ?
                JOIN Keyword k ON s1.keyword_id = k.id
                WHERE s1.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = s1.content_id)
                  AND s2.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = s2.content_id)
                ORDER BY (s1.impressions + s2.impressions) DESC
                """,
                (pair["id_a"], pair["id_b"]),
            ).fetchall()

            total_imp_a = pair["total_imp_a"] or 0
            total_imp_b = pair["total_imp_b"] or 0
            total_shared = total_imp_a + total_imp_b
            traffic_share_a = total_imp_a / total_shared if total_shared > 0 else 0.5

            # Get total keyword counts for each page (for overlap ratio)
            count_a = conn.execute(
                """SELECT COUNT(DISTINCT s.keyword_id) as cnt
                   FROM Snapshot s WHERE s.content_id = ?
                   AND s.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = ?)""",
                (pair["id_a"], pair["id_a"]),
            ).fetchone()["cnt"]

            count_b = conn.execute(
                """SELECT COUNT(DISTINCT s.keyword_id) as cnt
                   FROM Snapshot s WHERE s.content_id = ?
                   AND s.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = ?)""",
                (pair["id_b"], pair["id_b"]),
            ).fetchone()["cnt"]

            min_total = min(count_a, count_b) if min(count_a, count_b) > 0 else 1
            overlap_ratio = pair["shared_count"] / min_total

            results.append({
                "slug_a": pair["slug_a"],
                "slug_b": pair["slug_b"],
                "topic_a": pair["topic_a"],
                "topic_b": pair["topic_b"],
                "shared_count": pair["shared_count"],
                "total_shared_impressions": pair["total_shared_impressions"],
                "traffic_share_a": round(traffic_share_a, 3),
                "overlap_ratio": round(overlap_ratio, 3),
                "shared_keywords": [
                    {
                        "keyword": kw["keyword"],
                        "imp_a": kw["imp_a"],
                        "imp_b": kw["imp_b"],
                        "pos_a": kw["pos_a"],
                        "pos_b": kw["pos_b"],
                    }
                    for kw in keywords
                ],
            })

        return results


def db_summary(topic: str = None, lang: str = "",
               docs_dir: Path = None) -> dict:
    """Quick stats for GSC data in the database.

    Args:
        topic: Filter to this topic. None = all topics (cross-topic unique counts).
        lang: Language filter. Empty string = single-language site.

    Returns dict with:
        pages_with_data: int
        pages_without_data: int (pages in Content table with 0 snapshots)
        total_keywords: int (unique keywords, not double-counted across topics)
        latest_date: str or None
        stale_pages: int (pages with latest snapshot > 28 days old)
    """
    from datetime import datetime, timedelta
    lang = _resolve_lang(lang)

    with get_db(docs_dir) as conn:
        # Build WHERE clauses
        where_parts = []
        params = []
        if topic:
            where_parts.append("c.topic = ?")
            params.append(topic)
        if lang:
            where_parts.append("c.lang = ?")
            params.append(lang)
        topic_where = ("WHERE " + " AND ".join(where_parts)) if where_parts else ""
        topic_params = tuple(params)

        # Pages with snapshot data
        pages_with = conn.execute(
            f"""SELECT COUNT(DISTINCT c.id) as cnt
               FROM Content c
               JOIN Snapshot s ON s.content_id = c.id
               {topic_where}""",
            topic_params,
        ).fetchone()["cnt"]

        # Pages in Content table with no snapshots
        no_snap_where = topic_where + (" AND" if where_parts else " WHERE") + " c.id NOT IN (SELECT DISTINCT content_id FROM Snapshot)"
        pages_without = conn.execute(
            f"""SELECT COUNT(*) as cnt
               FROM Content c
               {no_snap_where}""",
            topic_params,
        ).fetchone()["cnt"]

        # Total unique keywords
        need_join = bool(where_parts)
        total_kw = conn.execute(
            f"""SELECT COUNT(DISTINCT s.keyword_id) as cnt
               FROM Snapshot s
               {'JOIN Content c ON s.content_id = c.id' if need_join else ''}
               {topic_where}""",
            topic_params,
        ).fetchone()["cnt"]

        # Latest snapshot date
        latest = conn.execute(
            f"""SELECT MAX(s.date) as latest
               FROM Snapshot s
               {'JOIN Content c ON s.content_id = c.id' if need_join else ''}
               {topic_where}""",
            topic_params,
        ).fetchone()["latest"]

        # Pages with stale data (latest snapshot > 28 days old)
        cutoff = (datetime.now() - timedelta(days=28)).strftime('%Y-%m-%d')
        stale = conn.execute(
            f"""SELECT COUNT(*) as cnt FROM (
                SELECT c.id
                FROM Content c
                JOIN Snapshot s ON s.content_id = c.id
                {topic_where}
                GROUP BY c.id
                HAVING MAX(s.date) < ?
            )""",
            (*topic_params, cutoff),
        ).fetchone()["cnt"]

    return {
        "pages_with_data": pages_with,
        "pages_without_data": pages_without,
        "total_keywords": total_kw,
        "latest_date": latest,
        "stale_pages": stale,
    }


def find_content_gaps(topic: str = None, min_pages: int = 3,
                      position_threshold: float = 20.0,
                      min_impressions: int = 50,
                      lang: str = "", docs_dir: Path = None) -> list[dict]:
    """Find keywords with search demand but no focused page.

    A content gap is a keyword where:
    - Multiple pages rank for it (Google spreading traffic)
    - No page ranks well (best position > position_threshold)
    - No existing page's slug matches the keyword

    Args:
        topic: Filter to this topic. None = all topics.
        min_pages: Minimum pages ranking for the keyword.
        position_threshold: Best-ranking page must be worse than this.
            Position 1 = best. Default 20 = nobody on pages 1-2.
        min_impressions: Minimum total impressions across all ranking pages.

    Returns list sorted by total_impressions desc, each with:
        keyword, page_count, total_impressions, best_position,
        ranking_pages: [{slug, topic, position, impressions}]
    """
    lang = _resolve_lang(lang)
    with get_db(docs_dir) as conn:
        where_parts = []
        topic_params_list = []
        if topic:
            where_parts.append("c.topic = ?")
            topic_params_list.append(topic)
        if lang:
            where_parts.append("c.lang = ?")
            topic_params_list.append(lang)
        topic_where = ("AND " + " AND ".join(where_parts)) if where_parts else ""
        topic_params = tuple(topic_params_list)

        # Step 1: Keywords on multiple pages, none ranking well
        candidates = conn.execute(
            f"""
            SELECT
                k.keyword,
                k.id as keyword_id,
                COUNT(DISTINCT s.content_id) as page_count,
                SUM(s.impressions) as total_impressions,
                MIN(s.position) as best_position
            FROM Snapshot s
            JOIN Keyword k ON s.keyword_id = k.id
            JOIN Content c ON s.content_id = c.id
            WHERE s.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = s.content_id)
              {topic_where}
            GROUP BY k.id
            HAVING page_count >= ?
               AND MIN(s.position) > ?
               AND SUM(s.impressions) >= ?
            ORDER BY total_impressions DESC
            """,
            (*topic_params, min_pages, position_threshold, min_impressions),
        ).fetchall()

        if not candidates:
            return []

        # Step 2: Get all slugs for matching
        slug_where_parts = []
        slug_params_list = []
        if topic:
            slug_where_parts.append("topic = ?")
            slug_params_list.append(topic)
        if lang:
            slug_where_parts.append("lang = ?")
            slug_params_list.append(lang)
        if slug_where_parts:
            slugs = conn.execute(
                f"SELECT DISTINCT slug FROM Content WHERE {' AND '.join(slug_where_parts)}",
                tuple(slug_params_list),
            ).fetchall()
        else:
            slugs = conn.execute("SELECT DISTINCT slug FROM Content").fetchall()

        slug_word_sets = {}
        for row in slugs:
            slug = row["slug"]
            words = set(slug.replace("-", " ").lower().split())
            slug_word_sets[slug] = words

        # Step 3: Filter out keywords that match a slug, enrich with pages
        gaps = []
        for cand in candidates:
            keyword = cand["keyword"]
            kw_words = set(keyword.lower().split())

            # Skip if any slug "covers" this keyword
            has_home = False
            for slug, words in slug_word_sets.items():
                if not words:
                    continue
                overlap = len(words & kw_words)
                # 1-word slug: 1 match enough. 2+ word slug: need 2+ matches.
                if overlap >= min(len(words), 2):
                    has_home = True
                    break

            if has_home:
                continue

            # Get ranking pages for this keyword
            page_details = conn.execute(
                f"""
                SELECT c.slug, c.topic, s.position, s.impressions
                FROM Snapshot s
                JOIN Content c ON s.content_id = c.id
                WHERE s.keyword_id = ?
                  AND s.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = s.content_id)
                  {topic_where}
                ORDER BY s.position ASC
                """,
                (cand["keyword_id"], *topic_params),
            ).fetchall()

            gaps.append({
                "keyword": keyword,
                "page_count": cand["page_count"],
                "total_impressions": cand["total_impressions"],
                "best_position": round(cand["best_position"], 1),
                "ranking_pages": [
                    {
                        "slug": p["slug"],
                        "topic": p["topic"],
                        "position": round(p["position"], 1),
                        "impressions": p["impressions"],
                    }
                    for p in page_details
                ],
            })

        return gaps


def find_dead_pages(topic: str = None, max_impressions: int = 5,
                    min_age_days: int = 90, lang: str = "",
                    docs_dir: Path = None,
                    redirects: list[dict] = None) -> list[dict]:
    """Find near-zero-impression pages and zero-data pages.

    Two types of dead pages:

    Type 1 (low-data): Has some keywords but total impressions <= max_impressions,
        and other pages rank for the SAME keywords (joined on keyword_id).

    Type 2 (zero-data): Registered in Content table via search_data but GSC
        returned nothing — zero Snapshot rows. Google doesn't show this page
        for any query at all.

    Age-gating uses the frontmatter ``created`` date (stored in Content.created)
    so pages that were published long ago are flagged immediately, even if
    tracking just started. Falls back to first_checked / first Snapshot date
    when ``created`` is not available.

    Pages whose path is a known redirect source are excluded — their data
    will migrate on the next ``data`` fetch via ``_find_redirect_sources``.

    Args:
        topic: Filter to this topic. None = all topics.
        max_impressions: Pages with total impressions <= this are "dead".
        min_age_days: Minimum age before flagging (default: 90).
        docs_dir: Override DOCS_DIR for testing.
        redirects: Known redirects [{'from': ..., 'to': ...}]. Pages whose
            path matches a redirect source are excluded from dead results.

    Returns list sorted by covering impressions desc, each with:
        dead_slug, dead_topic, total_impressions, first_seen,
        covered_by: [{slug, topic, keyword, impressions, position}]
        (covered_by is empty list for type 2 zero-data pages)
    """
    from datetime import datetime, timedelta
    lang = _resolve_lang(lang)

    # Build set of redirect source paths for exclusion
    redirect_sources = set()
    if redirects:
        for r in redirects:
            src = r.get("from", "")
            if src:
                redirect_sources.add(src)

    with get_db(docs_dir) as conn:
        where_parts = []
        topic_params_list = []
        if topic:
            where_parts.append("c.topic = ?")
            topic_params_list.append(topic)
        if lang:
            where_parts.append("c.lang = ?")
            topic_params_list.append(lang)
        topic_where = ("WHERE " + " AND ".join(where_parts)) if where_parts else ""
        topic_params = tuple(topic_params_list)

        # Type 1: pages with low impressions
        pages = conn.execute(
            f"""SELECT c.id, c.slug, c.topic, c.path, c.first_checked, c.created,
                       COALESCE(SUM(s.impressions), 0) as total_imp,
                       (SELECT MIN(date) FROM Snapshot WHERE content_id = c.id) as first_seen
                FROM Content c
                LEFT JOIN Snapshot s ON s.content_id = c.id
                    AND s.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = c.id)
                {topic_where}
                GROUP BY c.id""",
            topic_params,
        ).fetchall()

        min_date = (datetime.now() - timedelta(days=min_age_days)).strftime('%Y-%m-%d')

        def _is_old_enough(page):
            """Check age using created (frontmatter) > first_seen > first_checked."""
            age_date = page["created"] or page["first_seen"] or page["first_checked"]
            return age_date is not None and age_date <= min_date

        def _is_redirected(page):
            """Check if this page's path is a redirect source."""
            if not redirect_sources:
                return False
            path = page["path"] or f"/{page['topic']}/{page['slug']}/"
            return path in redirect_sources

        # Type 1 candidates: has snapshot data but low impressions
        low_data = [
            p for p in pages
            if p["total_imp"] <= max_impressions
            and p["first_seen"] is not None
            and _is_old_enough(p)
            and not _is_redirected(p)
        ]

        # Type 2 candidates: no snapshot data at all, but registered via search_data
        zero_data = [
            p for p in pages
            if p["first_seen"] is None
            and (p["first_checked"] is not None or p["created"] is not None)
            and _is_old_enough(p)
            and not _is_redirected(p)
        ]

        results = []

        # Process type 1: find covering pages via keyword joins
        for dead in low_data:
            covering = conn.execute(
                """SELECT k.keyword, s2.impressions, s2.position,
                          c2.slug, c2.topic
                   FROM Snapshot s1
                   JOIN Snapshot s2 ON s1.keyword_id = s2.keyword_id
                                   AND s1.content_id != s2.content_id
                   JOIN Keyword k ON s1.keyword_id = k.id
                   JOIN Content c2 ON s2.content_id = c2.id
                   WHERE s1.content_id = ?
                     AND s1.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = s1.content_id)
                     AND s2.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = s2.content_id)
                     AND s2.impressions > 0
                   ORDER BY s2.impressions DESC
                   LIMIT 20""",
                (dead["id"],),
            ).fetchall()

            if not covering:
                continue

            best_per_page = {}
            for c in covering:
                if (c["slug"] not in best_per_page
                        or c["impressions"] > best_per_page[c["slug"]]["impressions"]):
                    best_per_page[c["slug"]] = {
                        "slug": c["slug"],
                        "topic": c["topic"],
                        "keyword": c["keyword"],
                        "impressions": c["impressions"],
                        "position": round(c["position"], 1),
                    }

            results.append({
                "dead_slug": dead["slug"],
                "dead_topic": dead["topic"],
                "total_impressions": dead["total_imp"],
                "first_seen": dead["first_seen"],
                "covered_by": sorted(
                    best_per_page.values(),
                    key=lambda x: x["impressions"],
                    reverse=True,
                ),
            })

        # Process type 2: zero-data pages (no keywords to join on)
        for dead in zero_data:
            results.append({
                "dead_slug": dead["slug"],
                "dead_topic": dead["topic"],
                "total_impressions": 0,
                "first_seen": dead["first_checked"],
                "covered_by": [],
            })

        # Sort: type 1 (with covering data) first, then type 2
        results.sort(
            key=lambda r: sum(c["impressions"] for c in r["covered_by"]),
            reverse=True,
        )

        return results


def site_median_impressions(topic: str = None, lang: str = "",
                            docs_dir: Path = None) -> float:
    """Median page impressions across pages that have GSC data.

    Only considers pages with at least one Snapshot row (nonzero data),
    so untracked stubs don't drag the median down.
    Used for relative thresholds — e.g., dead page = median * 0.10.
    Returns 0.0 if no data.
    """
    lang = _resolve_lang(lang)
    with get_db(docs_dir) as conn:
        where_parts = ["1=1"]
        topic_params_list = []
        if topic:
            where_parts.append("c.topic = ?")
            topic_params_list.append(topic)
        if lang:
            where_parts.append("c.lang = ?")
            topic_params_list.append(lang)
        topic_where = "AND " + " AND ".join(where_parts[1:]) if len(where_parts) > 1 else ""
        topic_params = tuple(topic_params_list)

        rows = conn.execute(
            f"""SELECT SUM(s.impressions) as total_imp
                FROM Content c
                JOIN Snapshot s ON s.content_id = c.id
                    AND s.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = c.id)
                WHERE 1=1 {topic_where}
                GROUP BY c.id
                HAVING total_imp > 0
                ORDER BY total_imp""",
            topic_params,
        ).fetchall()

        if not rows:
            return 0.0

        n = len(rows)
        if n % 2 == 1:
            return float(rows[n // 2]["total_imp"])
        else:
            return (rows[n // 2 - 1]["total_imp"] + rows[n // 2]["total_imp"]) / 2.0


def trending_keywords(min_impressions: int = 100, limit: int = 50,
                      lang: str = "", docs_dir: Path = None) -> list[dict]:
    """Top keywords across ALL topics by impressions.

    Returns: [{keyword, impressions, clicks, page_count, avg_position, top_page}, ...]
    Sorted by impressions desc. top_page shows which page ranks best.
    """
    lang = _resolve_lang(lang)
    with get_db(docs_dir) as conn:
        if lang:
            lang_join = "JOIN Content c ON s.content_id = c.id"
            lang_where = "AND c.lang = ?"
            lang_params = (lang,)
        else:
            lang_join = ""
            lang_where = ""
            lang_params = ()

        rows = conn.execute(
            f"""
            SELECT
                k.keyword,
                SUM(s.impressions) as impressions,
                SUM(s.clicks) as clicks,
                COUNT(DISTINCT s.content_id) as page_count,
                AVG(s.position) as avg_position
            FROM Snapshot s
            JOIN Keyword k ON s.keyword_id = k.id
            {lang_join}
            WHERE s.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = s.content_id)
            {lang_where}
            GROUP BY k.id
            HAVING SUM(s.impressions) >= ?
            ORDER BY impressions DESC
            LIMIT ?
            """,
            (*lang_params, min_impressions, limit),
        ).fetchall()

        results = []
        for row in rows:
            # Find the best-ranking page for this keyword
            top = conn.execute(
                """
                SELECT c.slug, c.topic, s.position
                FROM Snapshot s
                JOIN Keyword k ON s.keyword_id = k.id
                JOIN Content c ON s.content_id = c.id
                WHERE k.keyword = ?
                  AND s.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = s.content_id)
                ORDER BY s.position ASC
                LIMIT 1
                """,
                (row["keyword"],),
            ).fetchone()

            results.append({
                "keyword": row["keyword"],
                "impressions": row["impressions"],
                "clicks": row["clicks"],
                "page_count": row["page_count"],
                "avg_position": round(row["avg_position"], 1),
                "top_page": f"/{top['topic']}/{top['slug']}/" if top else None,
            })

        return results


def keyword_ownership_batch(keywords: list[str], topic: str = None,
                            lang: str = "",
                            docs_dir: Path = None) -> dict[str, list[dict]]:
    """Find all pages ranking for multiple keywords in one query.

    Args:
        keywords: List of keyword strings to look up.
        topic: Filter to this topic. None = all topics.
        lang: Language filter. Empty string = single-language site.
        docs_dir: Override for testing.

    Returns:
        {keyword: [{slug, topic, position, impressions}]} sorted by position ASC.
        Keywords with no ranking pages are omitted from the dict.
    """
    if not keywords:
        return {}

    lang = _resolve_lang(lang)
    with get_db(docs_dir) as conn:
        placeholders = ",".join("?" * len(keywords))
        extra_where = []
        extra_params = []
        if topic:
            extra_where.append("AND c.topic = ?")
            extra_params.append(topic)
        if lang:
            extra_where.append("AND c.lang = ?")
            extra_params.append(lang)
        topic_where = " ".join(extra_where)
        topic_params = tuple(extra_params)

        rows = conn.execute(
            f"""SELECT k.keyword, c.slug, c.topic, s.position, s.impressions
                FROM Snapshot s
                JOIN Keyword k ON s.keyword_id = k.id
                JOIN Content c ON s.content_id = c.id
                WHERE k.keyword IN ({placeholders})
                  AND s.date = (SELECT MAX(date) FROM Snapshot
                                WHERE content_id = s.content_id)
                  {topic_where}
                ORDER BY k.keyword, s.position ASC""",
            (*keywords, *topic_params),
        ).fetchall()

        result = {}
        for row in rows:
            kw = row["keyword"]
            result.setdefault(kw, []).append({
                "slug": row["slug"],
                "topic": row["topic"],
                "position": round(row["position"], 1),
                "impressions": row["impressions"],
            })

        return result


def keyword_impression_ratio(keyword: str, slug: str, topic: str,
                             lang: str = "",
                             docs_dir: Path = None) -> float:
    """Ratio of keyword impressions to the page's top keyword impressions.

    Returns 0.0 if no data. Can exceed 1.0 if this keyword has more
    impressions than the page's strongest keyword.
    """
    lang = _resolve_lang(lang)
    with get_db(docs_dir) as conn:
        # This keyword's impressions on this page
        kw_row = conn.execute(
            """SELECT s.impressions
               FROM Snapshot s
               JOIN Keyword k ON s.keyword_id = k.id
               JOIN Content c ON s.content_id = c.id
               WHERE k.keyword = ? AND c.lang = ? AND c.slug = ? AND c.topic = ?
                 AND s.date = (SELECT MAX(date) FROM Snapshot
                               WHERE content_id = s.content_id)""",
            (keyword, lang, slug, topic),
        ).fetchone()

        if not kw_row or not kw_row["impressions"]:
            return 0.0

        # Page's top keyword impressions
        max_row = conn.execute(
            """SELECT MAX(s.impressions) as max_imp
               FROM Snapshot s
               JOIN Content c ON s.content_id = c.id
               WHERE c.lang = ? AND c.slug = ? AND c.topic = ?
                 AND s.date = (SELECT MAX(date) FROM Snapshot
                               WHERE content_id = s.content_id)""",
            (lang, slug, topic),
        ).fetchone()

        if not max_row or not max_row["max_imp"]:
            return 0.0

        return round(kw_row["impressions"] / max_row["max_imp"], 3)


def keeper_score(topic: str, slug: str, lang: str = "",
                 docs_dir: Path = None) -> float:
    """Composite SEO strength score from database.

    Components normalized to 0-1 before weighting:
      40% impressions — demand signal (how often Google shows the page)
      30% position    — ranking strength (best/avg, inverted so pos 1 = 1.0)
      20% clicks      — user preference (validates impressions aren't wasted)
      10% keyword count — topical breadth (tiebreaker, broad pages survive merges)

    Normalization: each component divided by the max across all pages
    in the same topic, so the strongest page scores ~1.0.
    """
    lang = _resolve_lang(lang)
    with get_db(docs_dir) as conn:
        # Build lang filter
        lang_where = "AND c.lang = ?" if lang else ""
        lang_params = (lang,) if lang else ()

        # Get this page's stats
        row = conn.execute(
            f"""SELECT
                SUM(s.impressions) as total_imp,
                SUM(s.clicks) as total_clicks,
                AVG(s.position) as avg_pos,
                COUNT(DISTINCT s.keyword_id) as kw_count
               FROM Snapshot s
               JOIN Content c ON s.content_id = c.id
               WHERE c.topic = ? AND c.slug = ? {lang_where}
                 AND s.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = s.content_id)""",
            (topic, slug, *lang_params),
        ).fetchone()

        if not row or row["total_imp"] is None:
            return 0.0

        total_imp = row["total_imp"] or 0
        total_clicks = row["total_clicks"] or 0
        avg_pos = row["avg_pos"] or 100.0
        kw_count = row["kw_count"] or 0

        # Get max values across all pages in this topic for normalization
        maxes = conn.execute(
            f"""SELECT
                MAX(page_imp) as max_imp,
                MAX(page_clicks) as max_clicks,
                MIN(page_pos) as best_pos,
                MAX(page_kw) as max_kw
               FROM (
                   SELECT
                       SUM(s.impressions) as page_imp,
                       SUM(s.clicks) as page_clicks,
                       AVG(s.position) as page_pos,
                       COUNT(DISTINCT s.keyword_id) as page_kw
                   FROM Snapshot s
                   JOIN Content c ON s.content_id = c.id
                   WHERE c.topic = ? {lang_where}
                     AND s.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = s.content_id)
                   GROUP BY c.id
               )""",
            (topic, *lang_params),
        ).fetchone()

        max_imp = maxes["max_imp"] or 1
        max_clicks = maxes["max_clicks"] or 1
        max_kw = maxes["max_kw"] or 1
        best_pos = maxes["best_pos"] or 1.0

        # Normalize to 0-1
        norm_imp = total_imp / max_imp
        norm_clicks = total_clicks / max_clicks
        norm_kw = kw_count / max_kw
        # Position: 1 = best (score 1.0), 100 = worst (score ~0)
        norm_pos = best_pos / avg_pos if avg_pos > 0 else 0.0

        return round(
            0.4 * norm_imp
            + 0.3 * norm_pos
            + 0.2 * norm_clicks
            + 0.1 * norm_kw,
            4,
        )


def rekey_from_redirects(redirects: list[dict],
                         docs_dir: Path = None) -> int:
    """Update Content rows whose path matches a redirect source.

    After a site restructure with redirects, GSC data is keyed to old
    topic/slug/path. This function reads redirect entries and re-keys
    Content rows to match the new URL structure.

    Each redirect dict needs 'from' and 'to' keys (URL paths like
    '/old-topic/old-slug/').

    If the target Content row already exists (e.g. from a recent fetch),
    merges snapshots from old row into the target and deletes the old row.

    Returns the number of Content rows rekeyed or merged.
    """
    count = 0

    with get_db(docs_dir) as conn:
        for redir in redirects:
            old_path = redir.get("from", "")
            new_path = redir.get("to", "")
            if not old_path or not new_path:
                continue

            store_path = new_path

            # Find Content row matching old path
            old_row = conn.execute(
                "SELECT id, topic, slug FROM Content WHERE path = ?",
                (old_path,),
            ).fetchone()
            if not old_row:
                continue

            # Parse new topic/slug from target path (e.g. /topic/slug/)
            parts = [p for p in store_path.strip("/").split("/") if p]
            if len(parts) < 2:
                logger.warning(
                    f"rekey: skip redirect {old_path} -> {new_path} "
                    f"(target must have topic/slug)")
                continue

            new_topic = parts[-2]
            new_slug = parts[-1]

            # Check if target Content row already exists
            target_row = conn.execute(
                "SELECT id FROM Content WHERE topic = ? AND slug = ?",
                (new_topic, new_slug),
            ).fetchone()

            if target_row and target_row["id"] != old_row["id"]:
                # Merge: move snapshots from old to target, delete old
                conn.execute(
                    "UPDATE Snapshot SET content_id = ? WHERE content_id = ?",
                    (target_row["id"], old_row["id"]),
                )
                conn.execute(
                    "DELETE FROM Content WHERE id = ?",
                    (old_row["id"],),
                )
                logger.info(
                    f"rekey: merged {old_row['topic']}/{old_row['slug']} "
                    f"-> {new_topic}/{new_slug}")
            else:
                # Simple rekey: update topic, slug, path
                conn.execute(
                    "UPDATE Content SET topic = ?, slug = ?, path = ? WHERE id = ?",
                    (new_topic, new_slug, store_path, old_row["id"]),
                )
                logger.info(
                    f"rekey: {old_row['topic']}/{old_row['slug']} "
                    f"-> {new_topic}/{new_slug}")

            count += 1

    logger.info(f"rekey: {count} Content row(s) updated from {len(redirects)} redirect(s)")
    return count



def find_missing_redirects(redirects: list[dict],
                           docs_dir: Path = None,
                           page_paths: set = None) -> list[dict]:
    """Find Content rows with GSC data whose path has no page and no redirect.

    These are URLs Google indexed but are now 404s after a restructure.
    Each needs a redirect to preserve SEO value.

    Args:
        redirects: Known redirects [{'from': old, 'to': new}].
        docs_dir: Override for testing.
        page_paths: Set of known page paths (e.g. {'/guides/setup/'}).

    Returns [{path, slug, topic, total_impressions}] sorted by impressions desc.
    """
    redirect_sources = {r.get("from", "") for r in redirects}
    page_paths = page_paths or set()

    with get_db(docs_dir) as conn:
        rows = conn.execute(
            """SELECT c.path, c.slug, c.topic,
                      COALESCE(SUM(s.impressions), 0) as total_imp
               FROM Content c
               LEFT JOIN Snapshot s ON s.content_id = c.id
                   AND s.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = c.id)
               GROUP BY c.id
               HAVING total_imp > 0"""
        ).fetchall()

    missing = []
    for row in rows:
        path = row["path"] or f"/{row['topic']}/{row['slug']}/"
        # Strip anchor fragments — GSC tracks /path/#section but
        # pages and redirects match on /path/ only (#248)
        base_path = path.split("#")[0]
        # Skip if path matches a known page or a redirect source
        if base_path in page_paths or base_path in redirect_sources:
            continue
        missing.append({
            "path": path,
            "slug": row["slug"],
            "topic": row["topic"],
            "total_impressions": row["total_imp"],
        })

    return sorted(missing, key=lambda x: x["total_impressions"], reverse=True)


# =============================================================================
# GscUrl — bulk URL discovery from GSC Search Analytics API
# =============================================================================

def store_gsc_urls(urls: list[dict], date_str: str,
                   docs_dir: Path = None):
    """Store discovered GSC URLs in the GscUrl table.

    Replaces all entries for the given date (full refresh per fetch).
    Each url dict has: url, impressions, clicks.
    """
    with get_db(docs_dir) as conn:
        conn.execute("DELETE FROM GscUrl WHERE discovery_date = ?", (date_str,))
        for u in urls:
            conn.execute(
                """INSERT INTO GscUrl (url, impressions, clicks, discovery_date)
                   VALUES (?, ?, ?, ?)""",
                (u["url"], u.get("impressions", 0), u.get("clicks", 0), date_str),
            )
    logger.info(f"Stored {len(urls)} GSC URLs ({date_str})")


def get_gsc_urls(docs_dir: Path = None) -> list[dict] | None:
    """Load discovered GSC URLs from the most recent fetch.

    Returns None if no data exists or data is older than 28 days.
    Returns list of {url, impressions, clicks, discovery_date}.
    """
    from datetime import datetime, timedelta

    latest = get_gsc_urls_discovery_date(docs_dir)
    if not latest:
        return None

    try:
        fetch_date = datetime.strptime(latest, '%Y-%m-%d')
        if (datetime.now() - fetch_date).days > 28:
            return None
    except ValueError:
        return None

    with get_db(docs_dir) as conn:
        rows = conn.execute(
            """SELECT url, impressions, clicks, discovery_date
               FROM GscUrl WHERE discovery_date = ?
               ORDER BY impressions DESC""",
            (latest,),
        ).fetchall()

    if not rows:
        return None

    return [
        {
            "url": row["url"],
            "impressions": row["impressions"],
            "clicks": row["clicks"],
            "discovery_date": row["discovery_date"],
        }
        for row in rows
    ]


def get_gsc_urls_discovery_date(docs_dir: Path = None) -> str | None:
    """Return the most recent GscUrl discovery date, or None."""
    with get_db(docs_dir) as conn:
        row = conn.execute(
            "SELECT MAX(discovery_date) as latest FROM GscUrl"
        ).fetchone()
        return row["latest"] if row and row["latest"] else None


def find_gsc_coverage_gaps(page_paths: set, redirects: list[dict],
                           exclude_prefixes: list = None,
                           gsc_urls: list[dict] = None,
                           docs_dir: Path = None) -> list[dict]:
    """Find GscUrl entries with impressions that have no page and no redirect.

    Single source of truth for both ``audit`` and ``redirects`` commands.
    Uses the GscUrl table (bulk URL discovery) — the complete picture of
    what Google knows about.

    Args:
        page_paths: Set of known page paths (e.g. {'/', '/guides/setup/'}).
        redirects: Known redirects [{'from': old, 'to': new}].
        exclude_prefixes: Path prefixes to skip (e.g. ['/tools/']).
        gsc_urls: Pre-fetched GscUrl data. If None, reads from DB.
        docs_dir: Override for testing.

    Returns [{path, impressions}] sorted by impressions desc.
    """
    if gsc_urls is None:
        gsc_urls = get_gsc_urls(docs_dir=docs_dir)
    if not gsc_urls:
        return []

    redirect_sources = {r.get("from", "").rstrip("/") + "/"
                        for r in redirects}

    # Asset extensions to skip
    _ASSET_EXTS = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg",
                   ".css", ".js")

    gaps = []
    for entry in gsc_urls:
        url = entry["url"]
        impressions = entry.get("impressions", 0)
        if impressions == 0:
            continue

        # Extract path (handles both relative paths and full URLs)
        from urllib.parse import urlparse as _urlparse
        parsed = _urlparse(url)
        path = parsed.path if parsed.scheme else url
        if not path:
            continue

        # Skip assets (check before trailing-slash normalization)
        if any(path.endswith(ext) for ext in _ASSET_EXTS):
            continue

        norm = path.rstrip("/") + "/"

        # Skip excluded paths
        if exclude_prefixes and any(norm.startswith(p)
                                    for p in exclude_prefixes):
            continue

        # Check coverage: page exists OR redirect exists
        if norm in page_paths or norm in redirect_sources:
            continue
        # Also check without trailing slash
        if norm.rstrip("/") in page_paths or norm.rstrip("/") in redirect_sources:
            continue

        gaps.append({"path": norm, "impressions": impressions})

    return sorted(gaps, key=lambda x: x["impressions"], reverse=True)
