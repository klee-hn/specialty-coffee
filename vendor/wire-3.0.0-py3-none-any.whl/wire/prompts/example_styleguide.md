# Example Styleguide — How to Customize Wire for Your Site

This file shows the patterns you can use in your `docs/_styleguide.md`.
Wire prepends the styleguide to every prompt, so these rules shape all
generated content. Every section below is optional: include only what
matters for your site.

All examples are drawn from real Wire-powered sites.

---

## 1. Role Definition

Tell Claude who it is writing as. This sets the entire frame.

```markdown
## Your Role: Content Strategist for LobOut
You write for lobout.com, a competitive pitch marketplace where companies
post projects and pre-configured teams (human, agentic, or hybrid) apply
with their approach.
```

```markdown
## Deine Rolle: KI-Berater für Helm & Nagel
Du schreibst für helm-nagel.com, eine KI-Beratung, die Unternehmen bei
der Implementierung von KI-Lösungen berät: Strategie, Agenten-Systeme
und Enablement.
```

```markdown
## Your Role: Content Strategist for Konfuzio
You write for konfuzio.com, the website of the Konfuzio Document AI
Platform. Konfuzio is an AI platform for intelligent document processing.
```

**Pattern**: Role + site name + one-sentence positioning. German sites
use German role definitions. The role controls whether Claude writes as
an advisor, analyst, product marketer, or journalist.

---

## 2. Audience Definition

Define who reads the content and what they care about.

**C-suite consulting** (helm-nagel.com):
```markdown
## Zielgruppe
**C-Suite-Entscheider im DACH-Mittelstand.** CEOs, COOs, CMOs und CISOs
in Unternehmen mit 50-5.000 Mitarbeitern, die KI evaluieren oder
implementieren wollen.

Diese Leser:
- Treffen Investitionsentscheidungen im sechs- bis siebenstelligen Bereich
- Haben wenig Zeit und null Toleranz für Buzzwords
- Wollen wissen: "Was bringt mir das?" und "Was kostet es?"
```

**Dual-audience marketplace** (lobout.com):
```markdown
## Audience
**Two sides. Every page speaks to both.**

1. **Buyers**: Mid-market and enterprise ops leaders, VPs, department heads.
   They need a function handled and don't care if it's humans or AI.

2. **Teams**: Consulting firms, dev shops, agentic AI companies, hybrid
   operators. They need clients and want to prove their quality through
   competitive outcomes, not cold outreach.
```

**Product evaluators** (konfuzio.com):
```markdown
## Audience
**Business users and decision-makers who want to automate document
processes.** Operations managers, process owners, IT leads in industries
with high document volume: insurance, banking, logistics, healthcare.

These readers:
- Process hundreds to thousands of documents manually every day
- Actively compare Konfuzio with competitors (ABBYY, Kofax, Rossum)
- Want to understand what Konfuzio does better and where it fits
```

**Pattern**: Name the job titles, describe what they care about, list
what they reject. The audience shapes tone, depth, and vocabulary.

---

## 3. Brand Voice and Tone

How should the writing sound? Define the spectrum, not just the target.

**Advisory consulting** (helm-nagel.com):
```markdown
## Markenstimme: Autorität durch Klarheit
- **Beratend, nicht belehrend.** "In unserer Projekterfahrung..." nicht "Sie müssen..."
- **Direkt, nicht aggressiv.** Klare Einordnung: "Das funktioniert in der Praxis nicht"
- **Pragmatisch, nicht akademisch.** Theorie nur zur Entscheidungsbegründung
```

**Fair marketplace** (lobout.com):
```markdown
## Brand Voice: Direct, Practical, Fair
- **Direct, not aggressive.** "Hidden criteria prevent gaming" not "We believe
  our approach may help reduce certain optimization behaviors."
- **Fair, not promotional.** Human teams, agentic teams, hybrid teams. No bias.
  If a service area favors one composition, say so honestly.
- **Specific, not generic.** Numbers, examples, mechanics. Not "innovative solution."
```

**B2B agency** (wise-relations.com):
```markdown
## Markenstimme: "Wise"
Der Name ist Programm. Jeder Text transportiert Weisheit durch Klarheit.
- **Kompetent, nicht belehrend.** Du teilst Wissen auf Augenhöhe.
- **Direkt, nicht aggressiv.** "Das bringt nichts" statt "Man könnte argumentieren..."
- **Substanz vor Umfang.** Ein kurzer Artikel mit klaren Aussagen schlägt
  einen langen mit Fülltext.
```

**Pattern**: Use "X, not Y" pairs. Each pair defines a spectrum the writer
can calibrate against. Three to four pairs are enough.

---

## 4. Banned Words and Patterns

Every site has its own buzzword list. Be explicit.

```markdown
### Style Rules
1. **No buzzwords.** Forbidden: "innovative", "cutting-edge", "seamless",
   "holistic", "robust" (unless actual), "synergies", "leverage" (verb),
   "solution" (buzzword), "disruptive", "game-changing"
2. **No "agentic" in buyer-facing copy.** Say "teams" and let the
   composition speak. Business people don't care about AI taxonomy.
3. **No filler words.** Cut: "basically", "actually", "essentially",
   "in terms of", "at the end of the day"
4. **No emdashes (—).** Known AI writing pattern. Use periods, semicolons,
   colons, or commas. Also ban `&mdash;` in HTML.
```

German equivalent (helm-nagel.com):
```markdown
1. **Kein Marketing-Deutsch.** Verboten: "ganzheitlich", "nachhaltig",
   "state-of-the-art", "Synergien", "Mehrwert", "Lösung" (als Buzzword)
5. **Keine Füllwörter.** Streiche: "grundsätzlich", "sozusagen", "quasi",
   "eigentlich", "gewissermaßen"
```

---

## 5. Content Boundaries (What Belongs Where)

When you run multiple sites, define what content goes where.

```markdown
## VERBOTEN — Konfuzio und Produkt-Sprache
Helm & Nagel ist eine **Beratung**, kein Software-Vendor. Niemals:
- Konfuzio erwähnen oder beschreiben (gehört auf konfuzio.com)
- Feature-Listen oder Produktvergleiche (gehört auf idp-software.com)
- Technische Architektur beschreiben (Pipeline, Extraction Agent, etc.)
Stattdessen: Geschäftsergebnisse, ROI, Entscheidungshilfen, Strategie.
```

```markdown
## Sister Sites
- **helm-nagel.com** — AI strategy. Cross-industry AI topics belong there.
- **idp-software.com** — neutral vendor comparison.
- **konfuzio.com** — everything Konfuzio: features, use cases, comparisons.

**Rule of thumb:** If the content could come from McKinsey, it belongs on
helm-nagel.com. If it sounds like a product changelog, it belongs on
konfuzio.com or idp-software.com.
```

**Pattern**: Explicit "belongs here / belongs there" rules prevent content
drift when Wire runs on multiple related sites.

---

## 6. Core Narrative Concepts

Define 3-5 concepts that should appear naturally across all pages.

```markdown
## Core Narrative Concepts
1. **AI reviews every submission (the wall).** Briefs come back with
   questions if vague. Pitches come back if thin. Only work that passes
   goes live.
2. **Hidden criteria prevent gaming.** Buyers define scoring that teams
   never see. Structural answer to Goodhart's Law.
3. **Composition-agnostic.** Human, AI, hybrid compete equally.
4. **LobOut connects, never runs.** Evaluates text, never executes code.

Don't force all into every paragraph. Weave where they fit.
```

**Pattern**: Number them. Add the instruction "weave where they fit" to
prevent forced insertion.

---

## 7. Call-to-Action Template

Define placement, tone, and text. Every site's CTA is different.

**Consulting** (helm-nagel.com):
```markdown
> **Wo liegt Ihr größter Hebel?** Wir bewerten Ihre Prozesse und zeigen,
> wo KI messbaren Impact liefert. [Potenzial bewerten lassen](/de/kontakt/)
```

**Agency** (wise-relations.com):
```markdown
> **Kostenlose Erstanalyse.** Wie steht Ihr Unternehmen im digitalen
> Wettbewerb? Wir analysieren Ihre Position datenbasiert und zeigen
> konkrete Handlungsempfehlungen. [Jetzt Analyse anfordern](/kontakt/)
```

**Marketplace** (lobout.com):
```markdown
> **Post your project**: Describe what you need. AI reviews it. Add
> hidden scoring criteria. Get scored pitches from competing teams.
> [Post a Project](/dashboard/)
```

**Rules** (common across all sites):
- Place at ~60% of content, never at the end
- No aggressive sales, no urgency, no scarcity
- No CTAs on topic index pages

---

## 8. Content Clusters / Silos

Map your topic structure so Claude knows the information architecture.

```markdown
| Topic | Audience | Core Question |
|-------|----------|---------------|
| KI-Strategie | CEO | "Lohnt sich KI? Was kostet es?" |
| KI verstehen | CMO/CTO | "Was kann KI?" |
| Automatisierung | COO | "Wie automatisiere ich?" |
| Compliance | CISO/Legal | "EU AI Act, DSGVO?" |

## Internal Linking
- 2-4 internal links per article
- Min 1 link within the silo, 1 cross-silo
- Pillar pages: /de/ki-strategie/, /de/ki-verstehen/, etc.
```

---

## 9. Visual Components

If your site has custom CSS components, document them so Claude can use
them in generated content.

```markdown
### Stat-Boxen (3er-Grid)
<div class="wr-stats-grid" markdown>
<div class="wr-stat-box" markdown>
<div class="wr-stat-value">90%</div>
<div class="wr-stat-label">Label</div>
<div class="wr-stat-desc">One sentence explanation</div>
</div>
</div>
```

```markdown
### Mid-CTA
<div class="hn-mid-cta">
<h3>Wo liegt Ihr größter Hebel?</h3>
<p>Description.</p>
<a href="/de/kontakt/" class="hn-btn">CTA text</a>
</div>
```

**Pattern**: Show the HTML template with class names. Add a "when to use"
table mapping component to page type:

```markdown
| Page type | Typical components |
|-----------|-------------------|
| Pillar page | stats-bar + card-grid + mid-cta |
| Article | markdown content + mid-cta after 60% |
| Case study | hero + stats + card-grid + cta-section |
```

---

## 10. Writing Process Rules

Teach Claude how to think, not just what to write.

**Thesis first** (idp-software.com):
```markdown
State the claim in the first sentence of each section. Evidence follows.
Everything after the claim is proof.
```

**Numbers in pairs** (idp-software.com):
```markdown
Never present a metric for one item without the corresponding metric for
the other. Include a word that tells the reader what the pair means:
"faster," "trails," "neck-and-neck."
```

**Data first, personality second** (idp-software.com):
```markdown
Numbers establish credibility. Experiential language communicates what
numbers cannot. The sequence matters: evidence first, then interpretation.

BAD: "It feels like a premium product."
GOOD: "It clocked 5,456 pounds. We never thought about the weight during
our week with it. There is something almost British about the way it drives."
```

**Don't overwrite, integrate** (idp-software.com):
```markdown
You found one news link and then rewrote the entire intro around it.
Keep the existing general intro and weave the news in briefly.
```

**ROI language** (helm-nagel.com):
```markdown
Every article must contain at least one concrete number or KPI.
```

---

## 11. Year Date Handling

```markdown
## Jahreszahlen und Aktualität
Wenn ein Titel eine Jahreszahl enthält (z.B. "Leitfaden für 2025"),
aktualisiere sie IMMER auf das aktuelle Jahr.
- Titel mit "2024" oder "2025" auf das aktuelle Jahr ändern
- Ausnahme: Historische Fakten ("Gründung 2016") bleiben unverändert
```

---

## Minimal Styleguide (Starter Template)

A working styleguide can be as short as this:

```markdown
## Your Role: [Role] for [Site Name]
You write for [domain], a [one-line positioning].

## Audience
[Job titles]. They care about [X] and reject [Y].

## Tone
- [Positive trait], not [negative trait]
- [Positive trait], not [negative trait]

## Banned Words
[List of buzzwords to avoid]

## No Emdashes
Never use — or &mdash;. Use periods, semicolons, or commas.

## Call-to-Action
After ~60% of content:
> **[Headline].** [One sentence]. [Link text](/contact/)
```

This is enough for Wire to produce on-brand content. Add sections as you
discover what Claude gets wrong.
