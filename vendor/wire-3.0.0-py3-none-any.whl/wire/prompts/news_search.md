*Context in >>markers<< is auto-resolved from site configuration. Do not reproduce markers in output.*

SITE: >>{site.title}<< | SITE DESCRIPTION: >>{site.description}<<
TOPIC: >>{topic.title}<<
ITEM: >>{item.title}<<
SEARCH PERIOD: >>{from_date}<< to >>{to_date}<<
{language_instruction}

Search for RECENT news and articles about {item.title} in the context of {topic.title}.

**Date range: {from_date} to {to_date}** — ONLY find articles published in this period.
Add the year (e.g., "2026") to your search queries to filter for recent results.
Reject articles from previous years or older periods.

{search_hints}

If search hints are listed above: Google Search Console shows real users search
for these terms about "{item.title}". Each represents a topic our page doesn't
cover well yet. Prioritize finding articles about the highest-scored terms.

{source_gaps}

If source gaps are listed above: this article over-relies on a few domains.
Use the anchor texts as SEARCH QUERIES — each anchor describes a specific
aspect that needs a better source. Search for that exact aspect + "{item.title}"
to find authoritative alternatives (research papers, official documentation, case studies,
industry reports). Do NOT search generically for "{item.title}" — that returns
the same aggregator content. Search for the SPECIFIC claims and topics listed.

Look for:
- News articles about ITEM {item.title} from the date range above
- Product reviews, tutorials, and comparisons published recently
- Key people and leadership news
- Blog posts and niche sources
- Research papers, benchmarks, and analyst coverage
- **Primary sources with original data** — research firms publishing their own
  studies, companies announcing their own results, standards bodies issuing
  guidelines. These are higher value than aggregator summaries.
- **Articles with direct quotes** from named people (CEOs, analysts, researchers)
- **Regulatory or standards changes** — new laws, certifications, compliance updates

Return the {max_results} most relevant and diverse URLs.
EXCLUDE these domains (they block scraping): {exclude_domains}
If possible, include one or two personal blogs or smaller niche pages.
AVOID: opinion pieces without named sources, aggregator summaries without
original links, prediction-heavy articles light on evidence.
