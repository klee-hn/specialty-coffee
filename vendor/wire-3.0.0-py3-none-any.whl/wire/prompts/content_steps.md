{styleguide}

## Your Task: Create a Discovery Reading Layer for {item.title}

*Context in >>markers<< is auto-resolved from site configuration. Do not reproduce markers in output.*

{language_instruction}

Design a guided reading experience for this page. The discovery layer sits above the full article. It helps readers find the section that matches their situation instead of scrolling through everything.

Think of it as a choose-your-own-adventure for an article. The reader describes their situation through choices, and the system routes them to the section that answers their question.

## The Page Content

```markdown
{current_page}
```

## Available H2 Anchor IDs

These are the only valid step IDs (besides "start"):

{h2_anchors}

## Discovery Syntax

Write a `steps.md` file using this exact syntax:

```
:::hook
One to two sentences. The only thing visible above the fold.
:::

:::step id="start"
50 to 70 words.
:::choices
- Choice A -> step_id_a
- Choice B -> step_id_b
- I want to read the full article -> end
:::

:::step id="step_id_a"
50 to 70 words.
:::choices
- Choice C -> step_id_c
- Choice D -> step_id_d
- I want to read the full article -> end
:::
```

## Rules

1. **Choices are things that happened to the reader, not things they want to read.**

    Write each choice as if the reader is describing their situation to a friend. If you can remove "I want to" from the front and it still reads as a heading, it's a topic label — rewrite it.

    The words "want", "need", "understand", "learn", "see", "know", "check", "find out" must NEVER appear in any choice except the exit.

    Examples across different domains:

    BAD → GOOD (cooking article):
    - "I want to learn about fermentation" → "My dough isn't rising and I've tried everything"
    - "See the ingredient list" → "I'm missing half the ingredients and the store is closed"

    BAD → GOOD (software article):
    - "I want to understand the API" → "My requests return 403 and the docs say I'm authenticated"
    - "Learn about deployment" → "My deploy works locally but fails in CI"

    BAD → GOOD (finance article):
    - "I need to know about tax brackets" → "I got a raise and my take-home barely changed"
    - "See the comparison table" → "I'm choosing between two accounts and the rates look identical"

2. **Step IDs must be from the H2 list above.** "start" is the only exception. Do NOT invent IDs. Do NOT use H3 slugs.

3. **Each step is 50-70 words.** End on something unresolved — a question raised, a fact that complicates the assumption. Do NOT summarize the article section. Describe what the reader is experiencing.

4. **The hook is one to two sentences.** A problem the reader recognizes from their own experience. Not a description of the article.

5. **Design 4-7 steps.** Not every H2 needs a step. Pick sections that answer common reader situations.

6. **Every path must reach a terminal step** that points to "end".

7. **No marketing language.** No "discover", "unlock", "dive into", "comprehensive", "essential", "powerful".

8. **Last choice in every step: "I want to read the full article -> end".**

9. **Steps create tension.** Each step makes the reader think "wait, really?" Introduce a complicating fact, then offer choices based on which complication matters to them.

10. **Every step has at least 2 real choices plus the exit.** If you can only think of 1, merge that step into its parent.

11. **Choices are mutually exclusive.** The reader is in exactly one situation. If two choices could both apply, they're too vague.

## Self-Check Before Output

Before writing your final output, review every choice line. If any choice contains "want", "need", "understand", "learn", "see", "know", "check", or "find out" (except the exit), rewrite it as a situation the reader is in. This is the most common failure mode.

## Output

Return ONLY the steps.md content. No explanation. No code fences. No YAML frontmatter. Start with :::hook on line 1.
