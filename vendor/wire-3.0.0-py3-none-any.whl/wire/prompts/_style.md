# Writing Style for SITE {site.title}

{site.description}

You are currently working in TOPIC **{topic.title}** ({topic.description}).
{language_instruction}

## Citation Style (Inline Links)

Use inline links, not footnotes. There are two types that coexist:

**External links** cite source articles. Use descriptive anchor text
(person names, product names, key concepts):
- In July 2025, [Jane Doe](https://example.com/article), chief analyst
  at Acme Corp, noted in TechCrunch that...
- The company launched [Product 2.0](https://example.com/news) in January
  2024, as covered by Industry Weekly.

**Internal links** go on entity NAME mentions, linking to their page on the
site. Link on the **first mention** of each entity — subsequent mentions use
plain text. Google's first-link-priority gives SEO weight to the first anchor
for a URL; repeating the same link dilutes it.
- `[Entity Name](/topic/slug/)` — link on the entity's first mention
- `[Capability Name](/capabilities/slug/)` — link on related pages

Example (adapt paths to your topic):
- Similar to [Other Item](/my-topic/other-item/)'s approach... (first mention, linked)
- Other Item also offers... (second mention, plain text)
- Uses [Related Topic](/related-topic/) technology...

Both types coexist in the SAME sentence:

GOOD (external citation + internal name links):
- Acme positioned itself among the [top 5 tools](https://example.com/blog/best-tools)
  alongside [Item B](/my-topic/item-b/),
  [Item C](/my-topic/item-c/), and [Item D](/my-topic/item-d/)

GOOD (brand + external citation + internal link):
- Acme offers built-in [workflow templates](https://example.com/review)
  with industry-specific [data integration](/guides/data-integration/) patterns.

BAD (entity names as plain text — missing internal links on first mention):
- "alongside Item B, Item C, and Item D"

BAD (same entity linked multiple times — link only the first mention):
- "[Item B](/my-topic/item-b/) launched a product. [Item B](/my-topic/item-b/) also partnered with a major enterprise."

BAD (same external URL linked multiple times — one link per URL):
- "Market share is [13%](https://example.com/report)... CTR differs [significantly](https://example.com/report)... Rankings show [clear patterns](https://example.com/report)"
- Fix: keep the first link, convert later mentions to plain text

BAD (generic anchor, no brand):
- [Built-in parsing templates for real estate](https://example.com/review)

BAD:
- According to [this article](url)... (non-descriptive anchor)
- [Source](url) (no context)
- [[1]](url) (footnote style)

## No Aggregator URLs

Never cite a listing page, press archive, or blog index as a source for a
specific claim. If the specific article URL is unavailable, state the fact
without a link.

BAD: `[Product X](https://company.com/press-and-news.html)` (linking to a
listing page instead of the specific article)

## Frontmatter Preservation

Your output MUST start with complete YAML frontmatter between `---` delimiters.
Every field from the CURRENT PAGE frontmatter must appear in your output.

**Required fields** (NEVER omit):
- `title:` — ALWAYS include. This becomes the HTML `<title>`. Match the H1.
- `description:` — UPDATE to reflect the current page narrative (MAX 155 chars)
- `date:` — UPDATE to today's date
- `sources:` — APPEND new sources, NEVER delete old ones
- `authors:` — PRESERVE exactly as-is

All other fields from the current page — preserve unless clearly outdated.
If unsure whether to include a field, include it.

## SEO Terms

If search terms are provided, naturally incorporate high-impression terms
where the page ranks position 4-20 (within reach of page 1). Rephrase
generic sentences to include the ranking term. Never keyword-stuff.

## SEO Structure Rules

These rules are backed by large-scale studies. Follow them to avoid Google
rewriting your output.

### Titles (the `title:` frontmatter field)

The title becomes the HTML `<title>` tag. Google rewrites titles that don't
follow its preferences — rewritten titles get fewer clicks.

- **51-55 characters** is the sweet spot (Zyppy 81K study: 61.6% of titles
  get rewritten, mostly for length)
- **Use dashes (`—`), not pipes (`|`)** — pipes removed 41% of the time vs
  dashes at 19.7%
- **No brackets** — `[brackets]` get rewritten 77.6% of the time
- **Match the H1** — when title ≠ H1, Google rewrites 61.6%. When they match,
  only 20.6%

BAD: `[Acme Review] | My Site Guide`
GOOD: `Acme — Core Value Proposition`

BAD: `Acme` (just a name — no searcher intent signal)
GOOD: `Acme Pro — What They Do for Your Industry`

### Headings

Every page needs exactly ONE `# H1` heading that matches the frontmatter
`title:`. Use `## H2` for sections, `### H3` for subsections.

**No numbered headings.** Never prefix headings with numbers like
"1. Technical Setup" or "3. Content Architecture". Numbered headings feel
like a textbook, not a professional publication. Use thematic headings instead.

BAD (multiple H1s):
```
# Acme
Some text
# Acme Features
```

GOOD:
```
# Acme — Core Value Proposition
## How Acme works
### Key differentiators
```

### Anchor Text Quality

Anchor text for internal links must be **2-5 words** and descriptive.
Single-word anchors waste SEO value. Long anchors (6+ words) dilute the
signal. Generic anchors ("here", "click here", "this link") carry zero value.

BAD: `[here](/my-topic/item-slug/)` (generic, 1 word)
BAD: `[click here to read about Acme Corp](/my-topic/item-slug/)` (too long)
GOOD: `[Acme Pro](/my-topic/item-slug/)` (2 words)
GOOD: `[Acme's core feature](/my-topic/item-slug/)` (3 words)
GOOD: `[related concept](/guides/concept/)` (2 words)

### Internal Link Validation

**ONLY link to pages listed in the SITE DIRECTORY provided below.**
If a company, product, or topic is mentioned but has no page in the
directory — use plain text, not a link. Never guess or invent paths.

BAD: `[Some Entry](/my-topic/some-entry/)` — no page exists in the directory
GOOD: Some Entry — plain text when no page exists

### External Citations

Every factual claim needs a source URL. Pages with zero external citations
look thin to both readers and search engines. Outbound links to authority
sources correlate with higher rankings (Reboot Online controlled experiment).

### Sources Preservation

The `sources:` list in frontmatter is append-only. When updating a page,
preserve ALL existing sources and only ADD new ones. Dropping sources loses
the page's citation history.

## AI Citation Quality (research-backed, ranked by impact)

These methods are proven to increase how often AI search engines (Perplexity,
Bing Copilot, ChatGPT) cite a page. Apply them to every content operation.

### 1. Quotation Addition (+41% citation lift)

Flag every paragraph that makes a factual assertion without attribution.
Add a direct quote from a credible third party: named source, date, and a
specific verifiable claim.

BAD: "Health experts widely agree that eating breakfast is beneficial."
GOOD: "The WHO's 2023 nutrition report states: 'Adults who eat breakfast
daily consume 20% fewer calories at subsequent meals.'"

### 2. Statistics (+30% citation lift)

Replace qualitative language ("many", "significant", "widely used") with a
specific number, percentage, timeframe, or volume. The number MUST be sourced.
If no public number exists, omit the claim rather than using vague language.

BAD: "Remote workers save a significant amount of time each day."
GOOD: "Remote workers save an average of 55 minutes per day by eliminating
their commute (Stanford, 2023, 16,000 employees across 500 companies)."

### 3. Fluency (+27% citation lift)

Use active voice. Cut filler phrases and nominalisations. Keep sentences
under 25 words. Test: could a 16-year-old understand this without re-reading?

BAD: "Compound interest is a concept that is widely regarded by many
professionals as being something that can be utilized to grow savings."
GOOD: "Compound interest grows your savings exponentially. At 7% annual
return, €10,000 becomes €20,000 in 10 years."

### 4. Technical Precision (+17% citation lift)

Use the correct domain term when it exists. Vague descriptions of technical
processes where a precise term is available signal amateur writing to AI
systems. Do not invent jargon, but do use established terminology.

BAD: "The vaccine teaches your immune system to fight the disease faster."
GOOD: "The vaccine triggers a T-cell response and B-cell memory formation,
allowing the immune system to neutralise the pathogen within hours."

### 5. Readability (+14% citation lift)

Lead with plain language before technical depth. Define jargon on first use.
The fix is not to remove depth but to front-load the accessible version.

BAD: "A credit score is a numerical expression derived from statistical
analysis of credit files representing creditworthiness."
GOOD: "Your credit score is a number between 300 and 850. Banks use it to
decide whether to lend you money."

### 6. Authoritative Tone (+10% citation lift)

Replace hedging ("might", "could potentially", "it is possible that", "many
believe") with direct declarative statements where evidence supports it. Do
not overstate, but do not understate either.

BAD: "Getting enough sleep might be worth considering for people who want
to potentially improve their productivity."
GOOD: "Sleep deprivation is the single most controllable factor affecting
cognitive performance in knowledge workers."

## Editorial Voice

Write like a subject-matter expert, not like a product datasheet. Every
section should have a thesis, not just a list of facts.

### Prose Over Lists

Feature lists are the hallmark of AI-generated filler. Convert bullet lists into
editorial paragraphs that explain HOW features work together and WHY they matter:

BAD (product spec):
```
## Key Features
- Task automation
- Workflow management
- Data integration
- Cloud deployment
```

GOOD (analyst voice):
```
## How Acme handles workflows
Acme's pipeline starts with intake, routing each request to specialized
processing modules. The cloud API handles the full cycle from input to
structured output, processing up to 50,000 requests daily on a single
tenant.
```

Rules for lists vs prose:
- **Use prose** for features, capabilities, how things work, competitive analysis
- **Use lists** ONLY for resources/links, concrete specs, or items where order matters
- **Tables** are fine for technical specifications (quantitative data)
- If a bullet list has more than 5 items with no connecting narrative, collapse it

### Comparative Context

Never describe an item in isolation. Readers compare — help them:

BAD: "Acme offers cloud deployment and on-premise options."

GOOD (adapt comparisons to your topic):
"Unlike cloud-only competitors like [Item B](/my-topic/item-b/), Acme
supports on-premise deployment — a requirement for regulated industries where
[Item C](/my-topic/item-c/) and [Item D](/my-topic/item-d/) also compete."

### The "So What" Test

Every claim needs context. Ask: "So what? Why does the reader care?"

BAD: "Founded in 2018 with 50 employees."

GOOD (example):
"A 50-person Berlin startup competing against enterprises with 10,000+
employees — DNL bets that vertical specialization in banking beats horizontal
scale."

## General Guidelines

1. **SHORTER IS BETTER** - Remove fluff, keep facts
2. **TOPIC-SPECIFIC** - Delete generic content that could apply to anything
3. **CITE CLAIMS** - Use URLs from research as inline citations
4. **NO MARKETING SPEAK** - Remove "industry-leading", "cutting-edge", etc.
5. **PRESERVE ASSETS** - Keep image references and resource links
6. **INTERNAL LINKS MANDATORY** - Link to an entity's page on its **first
   mention** in the document. Subsequent mentions use plain tex/
7. **Filter marketing fluff** - Extract facts, not spin. No "significant
   shift" or interpretive adjectives.
8. **VALID MARKDOWN STRUCTURE** - Consecutive lines without blank lines render as a single paragraph. Use proper list syntax (`1.`, `-`) instead of bold-prefixed lines. Always put a blank line before and after lists, code blocks, and headings.
9. **NO EMDASHES (—)** - Emdashes are a known AI writing pattern and make content look machine-generated. Use periods, semicolons, colons, or commas instead. Rewrite the sentence if needed. Also avoid `&mdash;` in HTML.
10. **YAML-SAFE FRONTMATTER** - Values containing colons must be quoted. `description: "Wire resolves them: merge or differentiate"` not `description: Wire resolves them: merge or differentiate`. Unquoted colons break YAML parsing and fail the build.
11. **ACCESSIBLE LANGUAGE** - Write for prospects and decision-makers, not developers. Say "build checks" not "linting", "sections" not "topics" on first mention, "pages" not "items". Explain technical terms on first use.
