# Prompt Authoring Guide

How to write and maintain prompt templates in `/prompts/`. These rules are
extracted from patterns across all 16 production prompts and the styleguide.

## How Prompts Are Loaded

`load_prompt(topic, action, output, **variables)` does three things:

1. Prepends the **styleguide** (`_style.md`) — its rules apply to every prompt
2. Loads the **topic prompt** from `{docs_dir}/{topic}/_{action}.md` or falls
   back to `prompts/{action}.md`
3. Calls `.format(**variables)` with auto-injected `{topic}` and `{site}`

Auto-injected variables (never pass these manually):
- `{topic}` — `Topic` object (has `.title`, `.description`)
- `{site}` — `Site` object (has `.title`, `.url`, `.description`)

Exception: newsweek prompts use `_load_newsweek_prompt()` which injects
`{site}` only (no `{topic}`) and does NOT prepend the styleguide automatically.

## Variable Naming

Use **object access** (`{item.title}`) when the variable is a dataclass.
Use **plain names** (`{item_name}`) when the variable is a string.

| Pattern | When to use | Example prompts |
|---------|------------|-----------------|
| `{item.title}` | Content object available | content_update, content_expand, content_seo, content_seo_light, content_create |
| `{item_name}` | String passed by caller | content_consolidate, news_evaluate, news_combine |
| `{item_a}`, `{item_b}` | Two items being compared | content_compare |

Never mix patterns in the same prompt. If you use `{item.title}`, do not also
reference `{item_name}` for the same entity.

### Escaping

Python `.format()` treats `{` and `}` as variable delimiters. Literal braces
must be doubled:

- `{{#vs-slug}}` for HTML anchor IDs like `{#vs-slug}`
- `{{Brand}} — {{What They Do}}` for title patterns shown as examples

## Prompt Structure

Every prompt follows this skeleton:

```markdown
## Your Role: [Specific Role] for [Context]

[1-2 sentences: what this prompt accomplishes and who the audience is]

## [Instructions / Rules / Guidelines]

[Numbered or prose rules — see Rules section below]

## [DATA SECTION] [Label: {variable}]

{variable_content}
```

### Role Definition (required)

Open with `## Your Role:` followed by a specific role title. The role frames
Claude's expertise and voice.

| Good | Bad |
|------|-----|
| `Your Role: SEO Copy Editor` | `You are an AI assistant` |
| `Your Role: Senior {topic.title} Analyst` | `Your Role: Helper` |
| `Your Role: News Intelligence Analyst` | (no role defined) |

The role line MUST reference the scope — either `{topic.title}`, `{site.title}`,
or the specific item being worked on.

### Data Sections (required for prompts that receive context)

Use `##` headers with a consistent labeling pattern:

```
## CURRENT PAGE [Item: {item.title}]
## NEWS RESEARCH [About: {item.title}]
## SEARCH TERMS [Item: {item.title}]
## SITE DIRECTORY [Site: {site.title}]
## RESEARCH [About: {item.title}]
## COMPARISONS [Item: {item_name}] ({comparison_count} total)
```

Rules:
- Header label in brackets identifies what the data is about
- Use `[Item: ...]` for item-specific data, `[Site: ...]` for site-wide data
- Wrap page content in markdown code fences when the content is a full page:
  ````
  ```markdown
  {current_page}
  ```
  ````
- Do NOT fence data that is structured metadata (search terms, site directory)

### SITE DIRECTORY (include when cross-linking is needed)

Most content prompts include a site directory section so Claude can create
valid internal links. Include it unless the prompt explicitly does not need
cross-linking (e.g., `content_seo_light.md` which only edits title/description).

## Rules for Rules

When writing instruction rules in prompts:

1. **Number the rules** — numbered lists are easier to reference and test against
2. **Lead with the verb** — "Reword existing sentences", not "You should reword"
3. **Include BAD/GOOD examples** — concrete examples prevent misinterpretation
4. **State the boundary** — "do NOT add new sections" is clearer than "be careful"
5. **Explain the why** — "Headlines matter most — H2/H3 carry SEO weight" beats
   "Optimize headlines"

### Rules That Belong in `_style.md` vs. in the Prompt

`_style.md` is prepended to every prompt loaded via `load_prompt()`. Put rules
there if they apply universally:

- Citation style (inline links, no footnotes)
- Editorial voice (analyst, not datasheet)
- Prose over lists
- "So What" test
- Frontmatter preservation
- No marketing speak

Put rules in the specific prompt if they are action-specific:
- SEO character limits (content_seo.md)
- Star rating rubric (newsweek_extract.md)
- Source memory format (content_update.md)
- Output structure templates (content_consolidate.md)

**Do NOT duplicate `_style.md` rules in individual prompts.** Since the
styleguide is prepended automatically, duplicated rules waste tokens and risk
drift when one copy is updated but not the other.

Exception: newsweek prompts load via `_load_newsweek_prompt()` which does NOT
prepend the styleguide. If a newsweek prompt needs styleguide rules, it must
either inject `{styleguide}` explicitly (as `newsweek_synthesize.md` does) or
include the rules inline.

## Output Format

The `output` parameter in `load_prompt()` appends format instructions:

- `"markdown_file"` — instructs Claude to output frontmatter + body only
- `"decision"` — instructs Claude to prefix its decision with `WHY: RELEVANT`
  or `WHY: NOT_RELEVANT`
- `"none"` — no format instructions appended

Match the output type to the prompt's purpose:
- Content creation/editing → `"markdown_file"`
- Article evaluation → `"decision"`
- Search context → `"none"`

## Client Abstraction

Prompts must work for any site, not just idp-software.com.

- Reference `{site.title}`, `{topic.title}` — never hardcode a domain or site name
- Use `{item.title}` — never write a literal vendor name as a placeholder
- Examples in prompts should use generic placeholders or be clearly marked
  as examples: "Example (from a vendor directory — adapt to your topic):"
- Path examples should use `/{topic}/slug/` with variables, not `/vendors/acme/`

Exception: `newsweek_synthesize.md` includes specific path examples
(`/capabilities/ocr/`, `/guides/accounts-payable-automation/`) because the
newsweek prompt needs concrete patterns. These are marked as examples.

## Special-Case Prompts

Two prompts deviate from the standard structure by design:

- `news_search.md` — a minimal search context prompt injected into `web_search()`.
  No `## Your Role:`, no data sections. This is not a full content prompt.
- `example.md` — a reference document for writing techniques, not a production
  prompt. No template variables.

## Search Terms Block

Two prompts inject GSC search data: `content_update.md` and `content_expand.md`.
Both include an identical "How to use this data" explanation block:

```markdown
### How to use this data

**Page queries** — terms this page already ranks for:
- **Position 4-20** = within reach of page 1.
- High **score** = high impressions but few clicks — biggest opportunity.

**Opportunities** — brand queries that rank on a DIFFERENT page:
- Cross-link to the ranking page.
- Add content so THIS page can also rank for those queries.

Do NOT keyword-stuff. Only use terms that fit naturally.
```

If this block changes, update it in BOTH prompts. A future improvement would
extract this into a shared partial.

## Checklist for New Prompts

Before committing a new prompt:

- [ ] Starts with `## Your Role:` and a specific role title
- [ ] References `{site.title}` or `{topic.title}` in the role line
- [ ] Uses consistent variable pattern (`{item.title}` or `{item_name}`, not both)
- [ ] All literal braces escaped as `{{` and `}}`
- [ ] Data sections use `## LABEL [Context: {variable}]` headers
- [ ] SITE DIRECTORY included if cross-linking is needed
- [ ] Current page wrapped in markdown code fences
- [ ] No rules duplicated from `_style.md`
- [ ] No hardcoded site names, domains, or vendor names
- [ ] BAD/GOOD examples for non-obvious rules
- [ ] Output format matches the action (`markdown_file`, `decision`, or `none`)
