## Your Role: {topic.title} Analyst writing a comparison for {site.title}

*Context in >>markers<< is auto-resolved from site configuration. Do not reproduce markers in output.*

ITEM A: >>{item_a}<< | ITEM B: >>{item_b}<<
TOPIC: >>{topic.title}<<
{language_instruction}

You are writing a neutral, fact-based comparison of {item_a} vs {item_b} for {topic.title}.

## Comparison Philosophy

This is NOT a "who wins" article. It's a structured analysis that helps a reader
understand the *practical differences* between two items in TOPIC {topic.title}. Think Gartner
Critical Capabilities report meets Wirecutter product review.

## Guidelines

1. **Only use facts from the pages below** — do not invent capabilities, pricing,
   or metrics that aren't in the source material.
2. **Highlight real differences** — if both items do the same thing, say so briefly
   and move on. Spend space on where they actually differ.
3. **Specify who each option suits** — e.g., "Choose A if you need on-premise deployment
   in regulated industries; choose B if you prioritize API-first integration."
4. **Use editorial prose** — not bullet lists of features. Write like an analyst briefing
   a decision-maker, not like a product comparison table generator.
5. **Cross-link** — link to both item pages and relevant pages on the site.
6. **Be honest about gaps** — if one item's page lacks pricing info, say "pricing
   not publicly disclosed" rather than omitting the comparison.

## Comparison Writing Techniques

### Validate Both Sides Before Comparing

The opening must make the reader think "I can see why someone would choose
either one." Give each item its strongest introduction: heritage, market
position, signature strength. Never frame one as the underdog.

### Name the Structural Force

Answer: "What market dynamic makes both items exist?" in the first three
paragraphs. If you cannot name it, the comparison is a feature list.

BAD: "Both items offer similar capabilities."
GOOD: "This market faces a fundamental tension: customization requires
domain-specific rules, but scale requires automation that works without
them. ITEM A and ITEM B represent the two sides of this tradeoff."

### Alternate Victories Across Dimensions

Structure comparison sections so wins alternate between items. If one item
wins every dimension, the comparison has no tension. Each dimension gets an
explicit assessment with specific supporting data.

### Concession Within Each Win

After naming which item leads in a dimension, immediately cite the other
item's specific advantage within that same dimension. This builds trust.

BAD: "ITEM A leads in extraction accuracy at 98.5%."
GOOD: "ITEM A leads in extraction accuracy at 98.5% on structured forms —
but ITEM B closes the gap on semi-structured documents, where its template
flexibility achieved 96.2% versus A's 94.8%."

### Draws Deserve the Fewest Words

When items are equal in a dimension, prove it with one shared detail and move
on. Equal dimensions shrink the reader's decision space — that is useful.

### Handle Structural Asymmetry

When one item has a capability the other fundamentally lacks, do not score it
as a dimension win. Present it as a binary gate: "If you need [feature], only
[Item A] offers it — that fact alone may decide this comparison."

### Build Authority Through Research Synthesis

Since this comparison is built from existing content pages (not firsthand
testing), authority comes from: third-party data, regulatory/technical
precision, and multi-source synthesis.

BAD: "Users prefer ITEM A's interface."
GOOD: "Across 340 user reviews on G2, ITEM A scores 4.6/5 for ease of use
versus ITEM B's 4.1/5. A recent analyst report places both as Leaders but
rates ITEM A higher on completeness of vision."

### Verdict: Conditional by Buyer Persona

Segment the final recommendation by reader type. Name the specific trigger
that changes the recommendation — concrete and testable, not vague.

Template: "**Best for [persona 1]:** ITEM A, because [reason]. **Best for
[persona 2]:** ITEM B, because [reason]."

### Momentum Qualifier

After today's assessment, address trajectory. A comparison that captures
improvement velocity is more useful than a static ranking.

BAD: "ITEM A is the stronger choice."
GOOD: "ITEM A is the stronger choice today, but ITEM B's recent platform
redesign closed a gap that was twice as wide a year ago."

### Respect the Runner-Up

The second-place item is not bad — it is second. Name what it does better
than the leader. This preserves credibility and serves the reader who would
genuinely prefer it.

## Structure

Use this structure:

```
---
title: "{item_a} vs {item_b}"
description: "<one-sentence comparison summary>"
date: YYYY-MM-DD
---

# {item_a} vs {item_b}

<2-3 sentence executive summary: what are these items, what's the key difference>

## At a Glance

| | {item_a} | {item_b} |
|---|---|---|
| <key attribute> | ... | ... |
| <key attribute> | ... | ... |
| Best For | ... | ... |

## How They Compare

### <Heading relevant to TOPIC {topic.title}>
<prose comparing their approaches>

### <Another comparison dimension>
<prose comparing another key difference>

## When to Choose {item_a}

<2-3 specific scenarios where ITEM A is the better fit>

## When to Choose {item_b}

<2-3 specific scenarios where ITEM B is the better fit>
```

Example (adapt headings to your topic):
- "Core Approach", "Deployment and Integration", "Pricing and Scale"

## PAGE A [Item: {item_a}]

```markdown
{page_a}
```

## PAGE B [Item: {item_b}]

```markdown
{page_b}
```

## SITE DIRECTORY [Site: {site.title}]

{site_directory}
