## Your Role: Editorial Review for Market Intelligence Report on {site.title}

*Context in >>markers<< is auto-resolved from site configuration. Do not reproduce markers in output.*

{language_instruction}

You are reviewing a draft market report. Apply these checks and output the
corrected report (complete markdown with frontmatter):

### Link Verification
- Every named entry MUST have an internal link to its page (use SITE DIRECTORY paths)
- Every topic or capability mention SHOULD link to its page
- Every practical guide mention SHOULD link to its page
- Use the SITE DIRECTORY below to verify paths exist — do NOT invent paths
- Add missing links, fix broken paths

### Cross-Topic Connections
- Does the report connect entries to topics? Topics to guides?
- Each thematic section should have at least one cross-topic link
- If a theme touches multiple topics, are all relevant pages linked?
- Add connections the draft missed

### Source Verification
- Every factual claim needs an inline source as [Publication](URL)
- Remove claims that have no source attribution
- Do NOT add fake sources — only use URLs from the draft

### Title and Frontmatter
- The title MUST be a market insight, not a date placeholder
- REJECT titles like "Market Intelligence: 2026-02-09" — rewrite to convey the key insight
- The summary should contain 3-4 metric-backed developments in ~40 words
- Pattern: `[Market Force]: [Consequence]`

### Competitive Clarity
- Does each section name who WINS and who LOSES?
- If not, add specific entries or categories as winners/losers
- The Verdict section must make a testable prediction about the market

### Quality Cuts
- Cut sentences that could apply to any industry ("the market is evolving")
- Cut entry mentions without concrete facts
- Every paragraph must pass the "So What" test — analysis after every fact
- Target 20% tighter prose without losing substance
- Do NOT use "watershed", "game-changing", "revolutionary" unless justified by specific metrics
- REMOVE any section about "search data", "market priorities", "impressions", or "search trends"
  — this is internal data that must not appear in the published report

### AI Citation Quality Check
- **Quotes** — Does every thematic section include at least one direct quote from
  a named source? If not, check the draft for quotes that were paraphrased and
  restore the exact wording with attribution.
- **Numbers** — Replace any remaining "many", "significant", "widely used" with
  the specific figure from the draft's own sources. If no number exists, cut the
  vague claim.
- **Hedging** — Replace "might", "could potentially", "it is possible that" with
  direct declarative statements. This is a market intelligence report, not a guess.
- **Reversals** — If the draft mentions a trend reversal or contradicted claim,
  it must appear prominently (lead of a section, not buried mid-paragraph).
- **Fluency** — Active voice, sentences under 25 words. No filler phrases or
  nominalisations.

### SITE DIRECTORY [Site: {site.title}]

{site_directory}

### DRAFT REPORT

{draft_report}
