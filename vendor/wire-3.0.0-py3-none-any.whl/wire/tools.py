#!/usr/bin/env python3
"""
Shared Tools for Newsgen

Infrastructure utilities used across the wire:
- Centralized logging (wire.log)
- Claude API calls with retry logic
- API key management
"""

import os
import re
import json
import shutil
import subprocess
import time
import logging
from pathlib import Path
from functools import lru_cache
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Optional, List, Dict
from urllib.parse import urlparse
import yaml
import frontmatter

from dotenv import load_dotenv
load_dotenv()

import anthropic
import trafilatura
from curl_cffi import requests


# =============================================================================
# CENTRALIZED LOGGING - all wire modules use this
# =============================================================================

def setup_logging():
    """Configure logging for the entire wire. Call once at startup."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - [%(name)s] - %(message)s',
        handlers=[
            logging.FileHandler('wire.log', encoding='utf-8'),
            logging.StreamHandler()
        ]
    )

# Auto-setup on import
setup_logging()

# Suppress noisy HTTP client logs (after anthropic import)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
logging.getLogger("googleapiclient.discovery_cache").setLevel(logging.WARNING)

logger = logging.getLogger(__name__)
_warned_topics = set()  # Track which topics already logged skip warnings


# =============================================================================
# PROMPT LOADING - styleguide + topic prompt, project-first with wire fallback
# =============================================================================

FALLBACK_PROMPTS_DIR = Path(__file__).parent / "prompts"

# Output format instructions appended by code — prompt authors never write these
OUTPUT_INSTRUCTIONS = {
    "markdown_file": "\n\nOutput ONLY the complete markdown (YAML frontmatter + body). No explanations, no wrapping.",
    "decision": "\n\nStart your response with: WHY: [your one-line decision]\nThen provide your content below.",
}


class _MkDocsLoader(yaml.SafeLoader):
    """SafeLoader that ignores MkDocs-specific !ENV tags."""
    pass

_MkDocsLoader.add_constructor('!ENV', lambda loader, node: None)


def _load_mkdocs_config() -> dict:
    """Read site config from wire.yml (preferred) or mkdocs.yml (legacy).

    Returns empty dict if neither is found.
    """
    wire_path = Path("wire.yml")
    if wire_path.exists():
        return yaml.load(wire_path.read_text(encoding='utf-8'), Loader=_MkDocsLoader) or {}
    mkdocs_path = Path("mkdocs.yml")
    if mkdocs_path.exists():
        logger.warning("Using mkdocs.yml (legacy). "
                       "Run: python -m wire.chief init  to create wire.yml")
        return yaml.load(mkdocs_path.read_text(encoding='utf-8'), Loader=_MkDocsLoader) or {}
    logger.warning(f"No wire.yml found in {Path.cwd()}\n"
                   f"Run: python -m wire.chief init  (to create one from mkdocs.yml)\n"
                   f"Or create wire.yml manually — see docs/guides/getting-started/")
    return {}


def _resolve_docs_dir(config: dict = None) -> Path:
    """Get docs_dir from mkdocs config, fall back to 'docs'."""
    if config is None:
        config = _load_mkdocs_config()
    return Path(config.get("docs_dir", "docs"))


def _build_component_reference() -> str:
    """Build a concise component reference for prompt injection.

    Returns a short syntax guide for all Wire shortcodes so Claude
    knows what components are available when generating/editing content.
    """
    return """## Available Components

Wire ships these markdown shortcodes. Use them where they add value — don't force them.

| Component | Syntax | Purpose |
|-----------|--------|---------|
| Stats | `:::stats` | Exactly 4 metrics. Each line: `value \\| label` |
| Cards | `:::cards` | Grid of cards split by `###` headings. Include a link for clickable cards |
| Split | `:::split` | Two columns separated by `---`. Add `comparison` for before/after highlight |
| Banner | `:::banner VALUE` | Big number callout. Value max 6 chars, body is explanation |
| Progress | `:::progress` | Horizontal bar chart. Each line: `label \\| value%` (0-100) |
| CTA | `:::cta` | Button group from markdown links. `{primary}` marks the main action |
| Badges | `:::badges` | Inline tag list, pipe-separated |
| Tabs | `:::tabs` | Tabbed panels split by `###` headings |
| FAQ | `:::faq` | Collapsible accordion split by `###` headings |
| Testimonial | `:::testimonial` | Customer quote. Last line starting with `—` is attribution |
| Logos | `:::logos` | Logo cloud from `![alt](src)` images |
| Pricing | `:::pricing` | Pricing plans split by `###`. `{primary}` marks featured plan |
| Steps | `:::steps` | Numbered workflow steps split by `###` (3-4 max) |
| Alert | `:::alert info/success/warning/error` | Callout box |
| Visual | `:::visual LABEL` | Brand card break. First body line = title, rest = description |
| Section | `:::section light` | Full-width background band |
| YouTube | `!yt[VIDEO_ID]` | Privacy-safe embed. No raw iframes |
| AI Image | `!makeIMG[slug]` or `!makeIMG[slug]{wide\\|square}` | Generated image by slug |

All shortcodes close with `:::` on its own line. They use the site's theme colors automatically.

You can use markdown within to style your text.
"""


def _generate_draft(path: Path, action: str, variable_names):
    """Generate a draft prompt so the user knows what to fill in."""
    variables_doc = "\n".join(f"  {v}" for v in variable_names)
    draft = f"""<!-- DRAFT — edit this prompt for your topic, then re-run -->
<!-- Available variables (auto-injected by wire):
{variables_doc}
-->

Describe what the "{action}" output should look like for this topic.
"""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(draft, encoding='utf-8')


def load_prompt(topic: str, action: str, output: str = "markdown_file", **variables) -> str:
    """
    Load and compose prompt: styleguide + topic prompt, formatted with variables.

    Topic prompt resolution:
    1. Project: {DOCS_DIR}/{topic}/_{action}.md
    2. Wire built-in: prompts/{action}.md
    3. Neither → generate draft, raise FileNotFoundError

    Args:
        topic: Topic directory name (e.g., "vendors", "capabilities")
        action: Prompt action (e.g., "content_create", "news_evaluate")
        output: Output format key from OUTPUT_INSTRUCTIONS (default "markdown_file")
        **variables: Template variables to format into the prompt

    Returns:
        Formatted prompt string ready for Claude
    """
    docs_dir = DOCS_DIR

    # Styleguide: base layer (_style.md) ALWAYS loads, customer expands
    styleguide_parts = []
    styleguide_path = docs_dir / "_styleguide.md"
    builtin_style_path = FALLBACK_PROMPTS_DIR / "_style.md"
    # Base layer — Wire's universal quality rules
    if builtin_style_path.exists():
        styleguide_parts.append(builtin_style_path.read_text(encoding='utf-8'))
        logger.debug(f"Styleguide: {builtin_style_path} (wire base layer)")
    # Customer layer — brand voice, expands base
    if styleguide_path.exists():
        styleguide_parts.append(styleguide_path.read_text(encoding='utf-8'))
        logger.debug(f"Styleguide: {styleguide_path} (customer layer)")
    styleguide = "\n\n".join(styleguide_parts)
    if not styleguide:
        logger.warning(
            f"No styleguide found. Content will be generated without style rules.\n"
            f"  Create: {styleguide_path}\n"
            f"  See: https://wire.wise-relations.com/guides/adding-a-site/"
        )

    # Topic prompt (project-first, wire fallback)
    project_path = docs_dir / topic / f"_{action}.md"
    builtin_path = FALLBACK_PROMPTS_DIR / f"{action}.md"

    if project_path.exists():
        topic_prompt = project_path.read_text(encoding='utf-8')
        source_path = project_path
        logger.info(f"Prompt: {action} <- {project_path} (project override)")
    elif builtin_path.exists():
        topic_prompt = builtin_path.read_text(encoding='utf-8')
        source_path = builtin_path
        logger.info(f"Prompt: {action} <- {builtin_path} (wire builtin)")
    else:
        _generate_draft(project_path, action, variables.keys())
        raise FileNotFoundError(
            f"No prompt found. Draft created at {project_path} — edit it and retry."
        )

    # Compose: styleguide + topic prompt
    # If topic prompt has {styleguide} placeholder, inject there (sandwich structure).
    # Otherwise prepend (backward-compatible with built-in fallbacks).
    if styleguide and "{styleguide}" in topic_prompt:
        topic_prompt = topic_prompt.replace("{styleguide}", styleguide)
        template = topic_prompt
    elif styleguide:
        template = f"{styleguide}\n\n{topic_prompt}".strip()
    else:
        template = topic_prompt

    # Append output format instruction (from code, not prompt)
    if output in OUTPUT_INSTRUCTIONS:
        template += OUTPUT_INSTRUCTIONS[output]

    # Auto-inject site, topic, and language so prompts can use {site.title}, {language}, etc.
    variables.setdefault("site", SITE)
    variables.setdefault("topic", Topic(topic))
    # Language: per-topic (multilingual) > site-wide (single-language) > empty
    language = TOPIC_LANGUAGES.get(topic, "") or SITE_LANGUAGE
    variables.setdefault("language", language)
    if language and "language_instruction" not in variables:
        variables["language_instruction"] = (
            f"\n**Language: {language}** — Write ALL output (title, description, "
            f"headings, body) in {language}. Match the language and cultural tone "
            f"of the existing page content."
        )
    else:
        variables.setdefault("language_instruction", "")

    # Auto-inject component reference so content prompts know available shortcodes
    variables.setdefault("components", _build_component_reference())

    # Format with variables
    try:
        return template.format(**variables)
    except KeyError as e:
        available = ", ".join(sorted(variables.keys()))
        raise ValueError(
            f"Prompt {source_path} uses variable {e} which the caller "
            f"doesn't provide.\n"
            f"  Available variables: {available}\n"
            f"  If this is a project-level prompt override, use only the "
            f"variables listed above."
        )


def parse_decision(response: str) -> tuple:
    """Parse 'WHY: ...' first line + remaining content."""
    lines = response.strip().split('\n')
    why_line = lines[0] if lines else ""
    if not why_line.startswith("WHY:"):
        return "", response
    return why_line[4:].strip(), '\n'.join(lines[1:]).strip()


# =============================================================================
# CLI EXECUTION — single entry point for Claude CLI subprocess calls
# =============================================================================

def _run_cli(prompt: str, description: str = "Claude CLI",
             tools: list = None, timeout: int = None,
             retries: int = 1, model: str = "") -> Optional[str]:
    """Single entry point for all CLI-based AI calls.

    Strips API keys from the subprocess environment so the CLI uses its
    own stored login session (claude login) rather than falling back to
    the API under the hood.

    Args:
        prompt:      Full prompt text, passed via stdin to avoid
                     command-line length limits on Windows.
        description: Human-readable label for log output.
        tools:       CLI tool names to enable, e.g. ["WebSearch"].
        timeout:     Subprocess timeout in seconds. If None, scales with
                     prompt length: max(120, len(prompt) // 200 + 60).
        retries:     Number of retries on short output (default 1).
                     Only triggers when prompt > 20KB and output < 5% of
                     prompt length.

    Returns:
        Extracted text string, or None on any failure.
    """
    if not shutil.which("claude"):
        logger.debug("Claude CLI not found — skipping CLI attempt")
        return None

    cmd = ["claude", "-p", "--output-format", "json"]
    if model:
        cmd += ["--model", model]
    if tools:
        tool_str = ",".join(tools)
        cmd += ["--tools", tool_str, "--allowedTools", tool_str]

    # Remove API keys: forces CLI to use stored login session.
    env = {
        k: v for k, v in os.environ.items()
        if k not in ("ANTHROPIC_API_KEY", "CLAUDE_API_KEY")
    }

    # Proportional timeout: large prompts need more time
    if timeout is None:
        timeout = max(120, len(prompt) // 200 + 60)

    for attempt in range(1 + retries):
        try:
            result = subprocess.run(
                cmd,
                input=prompt,
                capture_output=True,
                text=True,
                encoding="utf-8",
                timeout=timeout,
                env=env,
            )
            if result.returncode != 0:
                logger.warning(
                    f"CLI failed ({description}): {result.stderr.strip()[:200]}"
                )
                return None

            data = json.loads(result.stdout)
            text = (
                data.get("result")
                or data.get("response")
                or data.get("content")
                or ""
            ).strip()

            # Strip markdown fences (CLI behaves like API here)
            if text.startswith("```markdown"):
                text = text[len("```markdown"):].strip()
            if text.startswith("```"):
                text = text[3:].strip()
            if text.endswith("```"):
                text = text[:-3].strip()

            if not text:
                return None

            # Short output detection: retry if prompt is large and output is tiny
            if (len(prompt) > 20_000
                    and len(text) < len(prompt) * 0.05
                    and attempt < retries):
                logger.warning(
                    f"CLI output short ({len(text)} chars for "
                    f"{len(prompt)} prompt) — retry {attempt + 1}/{retries}"
                )
                continue

            logger.info(f"Claude CLI: {description} ({len(text)} chars)")
            return text

        except subprocess.TimeoutExpired:
            logger.warning(
                f"CLI timeout after {timeout}s ({description})")
            return None
        except json.JSONDecodeError as e:
            logger.warning(f"CLI JSON parse error ({description}): {e}")
            return None
        except Exception as e:
            logger.warning(f"CLI subprocess error ({description}): {e}")
            return None

    return None


# DO NOT use bare anthropic.Anthropic() — it only checks ANTHROPIC_API_KEY.
# We support both ANTHROPIC_API_KEY and CLAUDE_API_KEY (.env varies per project).
# DO NOT add @lru_cache — if the client is ever built with api_key=None
# (e.g. wrong .env found by load_dotenv), the broken client is cached forever
# and every API call silently fails with "Could not resolve authentication method".
# Explicit key + no cache = loud failure + always recoverable.
CLAUDE_API_KEY = os.getenv('ANTHROPIC_API_KEY') or os.getenv('CLAUDE_API_KEY')


def get_claude_client() -> anthropic.Anthropic:
    """Get configured Claude client. Checks ANTHROPIC_API_KEY then CLAUDE_API_KEY."""
    if not CLAUDE_API_KEY:
        raise ValueError("No ANTHROPIC_API_KEY or CLAUDE_API_KEY found in environment")
    return anthropic.Anthropic(api_key=CLAUDE_API_KEY)


CLAUDE_MODEL = "claude-sonnet-4-6"


def _claude_via_api(
    prompt: str,
    description: str,
    max_tokens: int,
    temperature: float,
    model: str = "",
) -> Optional[str]:
    """Fallback: Anthropic API (requires ANTHROPIC_API_KEY / CLAUDE_API_KEY)."""
    MAX_RETRIES = 2
    STREAM_PROMPT_THRESHOLD = 50_000
    STREAM_TOKEN_THRESHOLD = 16_000

    if not CLAUDE_API_KEY:
        logger.error(f"No API key for fallback ({description})")
        return None

    logger.info(f"Claude API fallback: {description} ({len(prompt)} chars)")
    client = get_claude_client()

    use_streaming = (len(prompt) > STREAM_PROMPT_THRESHOLD
                     or max_tokens > STREAM_TOKEN_THRESHOLD)

    use_model = model or CLAUDE_MODEL
    for attempt in range(MAX_RETRIES):
        try:
            if use_streaming:
                with client.messages.stream(
                    model=use_model,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    messages=[{"role": "user", "content": prompt}]
                ) as stream:
                    response = stream.get_final_message()
            else:
                response = client.messages.create(
                    model=use_model,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    messages=[{"role": "user", "content": prompt}]
                )

            if not response or not response.content:
                logger.error(f"Empty response for {description}")
                return None

            text = response.content[0].text.strip()

            if text.startswith('```markdown'):
                text = text[len('```markdown'):].strip()
            if text.startswith('```'):
                text = text[3:].strip()
            if text.endswith('```'):
                text = text[:-3].strip()

            return text

        except anthropic.RateLimitError as e:
            if attempt < MAX_RETRIES - 1:
                wait_time = 15 * (attempt + 1)
                logger.warning(
                    f"Rate limit hit for {description}, "
                    f"waiting {wait_time}s before retry {attempt + 1}/{MAX_RETRIES}..."
                )
                time.sleep(wait_time)
            else:
                logger.error(f"API call failed for {description}: {e}")
                return None
        except anthropic.APIError as e:
            logger.error(f"API call failed for {description}: {e}")
            return None

    return None


def claude_text(
    prompt: str,
    description: str = "Claude call",
    max_tokens: int = 2000,
    temperature: float = 0.3,
    model: str = "",
) -> Optional[str]:
    """CLI-first text generation. API is the fallback.

    Tries Claude CLI first (uses Max subscription, no API costs).
    Falls back to Anthropic API if CLI is unavailable or fails.

    Args:
        model: Override model ID (e.g. "claude-haiku-4-5-20251001" for cheap
               mechanical work). Empty = default (Sonnet for API, user's
               default for CLI). Passed to both CLI --model and API.

    Limitation: max_tokens and temperature are not forwarded to the CLI.
    """
    logger.info(f"Claude: {description} ({len(prompt)} chars)")

    # 1. CLI first
    result = _run_cli(prompt, description, model=model)
    if result is not None:
        return result

    # 2. API fallback
    logger.info(f"CLI unavailable — API fallback: {description}")
    return _claude_via_api(prompt, description, max_tokens, temperature,
                           model=model)


# =============================================================================
# BLOCKED DOMAINS - sites that require JS/login, not worth fetching
# =============================================================================

# Sites that block all scraping (require JavaScript execution or login)
BLOCKED_DOMAINS = [
    'crunchbase.com',   # Heavy Cloudflare + requires login for data
    'g2.com',           # Cloudflare turnstile
    'zoominfo.com',     # Login wall
    'linkedin.com',     # Login wall
]


def is_blocked_domain(url: str) -> bool:
    """Check if URL is from a blocked domain that can't be scraped."""
    domain = urlparse(url).netloc.lower()
    return any(blocked in domain for blocked in BLOCKED_DOMAINS)


# =============================================================================
# HTML FETCHING - normal request with impersonation fallback
# =============================================================================

FETCH_TIMEOUT = 30


def fetch_html(url: str, timeout: int = FETCH_TIMEOUT) -> Optional[str]:
    """
    Fetch URL and return raw HTML string.

    Uses curl_cffi with browser impersonation for all requests — handles
    both normal sites and Cloudflare-protected ones in a single call.

    Returns:
        HTML string or None on failure.
    """
    if is_blocked_domain(url):
        logger.info(f"Skipping blocked domain: {url}")
        return None

    try:
        response = requests.get(
            url,
            impersonate='safari17_0',
            timeout=timeout,
            headers={
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'accept-language': 'en-US,en;q=0.9',
                'accept-encoding': 'gzip, deflate, br',
            }
        )
        response.raise_for_status()
        logger.info(f"Fetched {url} ({len(response.text)} chars)")
        return response.text
    except (requests.errors.RequestsError, OSError) as e:
        logger.warning(f"Fetch failed for {url}: {e}")
        return None


# =============================================================================
# DOMAIN UTILITIES - ownership comparison for news sourcing
# =============================================================================

def fetch_page(url: str) -> str:
    """
    Fetch URL and extract article text as markdown with inline links.

    Returns empty string on any failure (blocked domain, HTTP error,
    extraction failure). Failures are logged with reason.
    """
    html = fetch_html(url)
    if not html:
        logger.info(f"No HTML fetched from {url}")
        return ""

    try:
        text = trafilatura.extract(
            html, url=url,
            output_format="markdown",
            include_links=True, include_formatting=True
        )
    except Exception as e:
        logger.warning(f"Extraction failed for {url}: {e}")
        return ""

    if not text:
        logger.info(f"No content extracted from {url}")
        return ""

    return text


def get_root_domain(domain: str) -> str:
    """
    Extract root domain for ownership comparison.

    Handles country-code TLDs (e.g., .co.uk, .com.au, .co.jp).

    Examples:
        www.abbyy.com -> abbyy.com
        docs.abbyy.com -> abbyy.com
        help.uipath.com -> uipath.com
        www.example.co.uk -> example.co.uk
        blog.example.com.au -> example.com.au
    """
    # Remove protocol if present
    if '://' in domain:
        domain = domain.split('://')[1]
    # Remove path if present
    domain = domain.split('/')[0]

    parts = domain.split('.')
    if len(parts) < 2:
        return domain

    # Country-code second-level domains: .co.uk, .com.au, .co.jp, .org.uk, etc.
    cc_slds = {'co', 'com', 'org', 'net', 'ac', 'gov', 'edu'}
    if (len(parts) >= 3
            and len(parts[-1]) == 2  # country code TLD (2 chars)
            and parts[-2] in cc_slds):
        # Return last 3 parts: example.co.uk
        return '.'.join(parts[-3:])

    # Standard TLD: return last 2 parts
    return '.'.join(parts[-2:])


def same_owner(domain1: str, domain2: str) -> bool:
    """
    Check if two domains have the same owner (root domain).

    Internal from ownership perspective, even if technically different subdomains.

    Examples:
        same_owner("www.abbyy.com", "docs.abbyy.com") -> True
        same_owner("www.abbyy.com", "www.uipath.com") -> False
    """
    return get_root_domain(domain1) == get_root_domain(domain2)


def _extract_and_filter_urls(text: str, max_results: int,
                              exclude_domains: list) -> list[str]:
    """Shared URL extraction used by both CLI and API web search paths."""
    urls = re.findall(r'https?://[^\s\)\]<>"]+', text)
    urls = [re.sub(r'[\*\#`\)]+$', '', u) for u in urls]
    urls = list(dict.fromkeys(urls))  # dedupe, preserve order
    filtered = [
        u for u in urls
        if not any(excl in urlparse(u).netloc.lower() for excl in exclude_domains)
    ]
    return filtered[:max_results]


def _web_search_via_api(query: str, max_results: int, context: Optional[str],
                         exclude_domains: list) -> list[str]:
    """Fallback: Anthropic API with web_search Tool-Use."""
    MAX_RETRIES = 2

    if not CLAUDE_API_KEY:
        logger.error("No API key for web search fallback")
        return []

    client = get_claude_client()

    exclude_note = f"\nEXCLUDE these domains: {', '.join(exclude_domains)}" if exclude_domains else ""
    if context:
        prompt = f"{context}\n\nSearch for: {query}\n\nReturn the most relevant URLs you find.{exclude_note}"
    else:
        prompt = f"Search for: {query}\n\nReturn the most relevant URLs you find.{exclude_note}"

    for attempt in range(MAX_RETRIES):
        try:
            response = client.messages.create(
                model=CLAUDE_MODEL,
                max_tokens=1024,
                tools=[{
                    "type": "web_search_20250305",
                    "name": "web_search",
                    "max_uses": 3
                }],
                messages=[{"role": "user", "content": prompt}]
            )

            urls = []
            for block in response.content:
                if hasattr(block, 'text'):
                    found = re.findall(r'https?://[^\s\)\]<>"]+', block.text)
                    urls.extend(found)

            urls = [re.sub(r'[\*\#`\)]+$', '', u) for u in urls]
            urls = list(dict.fromkeys(urls))
            filtered = [
                u for u in urls
                if not any(excl in urlparse(u).netloc.lower() for excl in exclude_domains)
            ]

            filtered = filtered[:max_results]
            logger.info(f"Web search API found {len(filtered)} URLs")
            return filtered

        except anthropic.RateLimitError as e:
            if attempt < MAX_RETRIES - 1:
                wait_time = 15 * (attempt + 1)
                logger.warning(f"Rate limit hit for web search, waiting {wait_time}s...")
                time.sleep(wait_time)
            else:
                logger.error(f"Web search failed: {e}")
                return []
        except anthropic.APIError as e:
            logger.error(f"Web search failed: {e}")
            return []

    return []


def web_search(query: str, max_results: int = 5, context: Optional[str] = None,
               exclude_domains: Optional[List[str]] = None) -> list[str]:
    """CLI-first web search. API Tool-Use is the fallback.

    Returns:
        List of relevant URLs found, empty list on failure.
    """
    if exclude_domains is None:
        own_domain = get_root_domain(SITE.url) if SITE and SITE.url else None
        exclude_domains = BLOCKED_DOMAINS + ([own_domain] if own_domain else [])

    logger.info(f"Web search: {query}")

    # Build prompt for CLI path
    exclude_note = f"\nEXCLUDE these domains: {', '.join(exclude_domains)}" if exclude_domains else ""
    if context:
        prompt = f"{context}\n\nSearch for: {query}\n\nReturn the most relevant URLs you find.{exclude_note}"
    else:
        prompt = f"Search for: {query}\n\nReturn the most relevant URLs you find.{exclude_note}"

    # 1. CLI first (with WebSearch tool)
    raw = _run_cli(prompt, f"web_search: {query}", tools=["WebSearch"])
    if raw is not None:
        return _extract_and_filter_urls(raw, max_results, exclude_domains)

    # 2. API fallback
    logger.info(f"CLI unavailable — API fallback for web search: {query}")
    return _web_search_via_api(query, max_results, context, exclude_domains)


# =============================================================================
# NEWS SEARCH - web search based article discovery
# =============================================================================

# Default search window (days back)
NEWS_API_MAX_DAYS_BACK = 30


def news_search(
    item,
    from_date: Optional[datetime] = None,
    to_date: Optional[datetime] = None,
    max_results: int = 20,
    search_hints: Optional[str] = None,
    source_gaps: Optional[str] = None
) -> List[Dict]:
    """
    Search for news articles about a Content item using Claude's web search.

    Returns:
        List of {"url": ..., "title": ...} dicts
    """
    if to_date is None:
        to_date = datetime.now()
    if from_date is None:
        from_date = to_date - timedelta(days=NEWS_API_MAX_DAYS_BACK)

    from_str = from_date.strftime('%Y-%m-%d')
    to_str = to_date.strftime('%Y-%m-%d')

    logger.info(f"News search: '{item.title}' from {from_str} to {to_str}")

    # Exclude the site's own domain to avoid self-referential results
    own_domain = get_root_domain(SITE.url) if SITE and SITE.url else None
    excluded = ([own_domain] if own_domain else []) + BLOCKED_DOMAINS

    context = load_prompt(
        item.topic, "news_search", output="none",
        item=item,
        from_date=from_str,
        to_date=to_str,
        max_results=max_results,
        search_hints=search_hints or "",
        source_gaps=source_gaps or "",
        exclude_domains=', '.join(excluded)
    )

    # Include year in query for better date filtering by search engines
    # Include language for multi-language sites to source language-appropriate results
    year = to_date.strftime('%Y')
    language = TOPIC_LANGUAGES.get(item.topic, "") or SITE_LANGUAGE
    lang_suffix = f" {language}" if language and language != "English" else ""
    urls = web_search(f"{item.title} news {year}{lang_suffix}", max_results=max_results, context=context)
    logger.info(f"Web search found {len(urls)} URLs")

    result = []
    for url in urls:
        domain = urlparse(url).netloc.replace('www.', '')
        if any(ex in domain for ex in excluded):
            logger.info(f"Excluding blocked domain: {url}")
            continue
        result.append({"url": url, "title": f"[{domain}]"})

    return result[:max_results]


# =============================================================================
# CONTENT UTILITIES - content item discovery and indexing
# =============================================================================

@dataclass
class Site:
    """Site-level metadata from wire.yml."""
    title: str
    url: str
    description: str

    def __str__(self):
        return self.title

_LANG_CODES = {
    "de": "Deutsch", "en": "English", "fr": "Français", "es": "Español",
    "it": "Italiano", "pt": "Português", "nl": "Nederlands", "pl": "Polski",
    "ja": "日本語", "zh": "中文", "ko": "한국어", "ru": "Русский",
    "ar": "العربية", "tr": "Türkçe", "sv": "Svenska", "da": "Dansk",
    "no": "Norsk", "fi": "Suomi", "cs": "Čeština", "ro": "Română",
}


def _build_topic_language_map(config: dict) -> tuple[dict[str, str], str]:
    """Build {topic_dir: language_name} from wire.yml.

    Strategy:
    1. Multilingual sites: extra.alternate maps topic dirs to languages.
       Example: extra.alternate: [{name: Deutsch, link: /de/, lang: de}]
       → {"de": "Deutsch"}
    2. Single-language sites: theme.language is the site-wide default.
       Example: theme: {language: de} → site_language = "Deutsch"

    Returns (per_topic_map, site_default_language).
    """
    if not config:
        return {}, ""

    # Per-topic from extra.alternate (multilingual sites with directory-based i18n)
    alternate = config.get("extra", {}).get("alternate", [])
    mapping = {}
    for entry in alternate:
        link = entry.get("link", "").strip("/")
        name = entry.get("name", "")
        if link and name:
            mapping[link] = name

    # Site-wide default from theme.language (single-language sites)
    theme_lang = config.get("theme", {})
    if isinstance(theme_lang, dict):
        theme_lang = theme_lang.get("language", "")
    else:
        theme_lang = ""
    site_language = _LANG_CODES.get(theme_lang, theme_lang.title() if theme_lang else "")

    return mapping, site_language


def _init_site_config():
    """Read wire.yml (or mkdocs.yml legacy), derive DOCS_DIR, SITE, WIRE_CONFIG, and TOPIC_LANGUAGES."""
    config = _load_mkdocs_config()
    docs_dir = _resolve_docs_dir(config)
    site = Site(
        title=config.get("site_name", ""),
        url=config.get("site_url", ""),
        description=config.get("description", "") or config.get("site_description", ""),
    )
    # Wire-specific config from extra.wire section
    wire_config = config.get("extra", {}).get("wire", {}) if config else {}
    topic_languages, site_language = _build_topic_language_map(config)
    return docs_dir, site, wire_config, topic_languages, site_language


DOCS_DIR, SITE, WIRE_CONFIG, TOPIC_LANGUAGES, SITE_LANGUAGE = _init_site_config()

# issues_repo: public repo for filing issues via skills (/issue, /feature).
# Configured in wire.yml as extra.wire.issues_repo (e.g. "atraining/support").
# Default: None (skills use the current repo).
ISSUES_REPO = WIRE_CONFIG.get("issues_repo")

# Multi-language support: SITE_DIR is where wire.yml lives (never changes),
# _ACTIVE_LANG is set by override_docs_dir() when --lang is used.
SITE_DIR = Path.cwd()
_ACTIVE_LANG = ""


def override_docs_dir(lang: str) -> Path:
    """Switch DOCS_DIR to a specific language's docs directory.

    Reads languages from wire.yml, finds the matching entry by code,
    sets DOCS_DIR and _ACTIVE_LANG globally.

    Returns the new DOCS_DIR.
    Raises ValueError if lang code is not found in wire.yml languages.
    """
    global DOCS_DIR, _ACTIVE_LANG

    config = _load_mkdocs_config()
    languages = config.get("languages", [])
    if not languages:
        logger.warning(f"--lang {lang} ignored: no languages configured in wire.yml")
        return DOCS_DIR

    codes = [l["code"] for l in languages]
    match = next((l for l in languages if l["code"] == lang), None)
    if not match:
        raise ValueError(
            f"Unknown language '{lang}'. "
            f"Available: {', '.join(codes)}"
        )

    DOCS_DIR = Path(match["docs_dir"]).resolve()
    _ACTIVE_LANG = lang
    logger.info(f"Language override: {lang} → {DOCS_DIR}")
    return DOCS_DIR


def write_md(filepath: Path, metadata: dict, body: str) -> None:
    """Write a markdown file with YAML frontmatter + body."""
    filepath.parent.mkdir(parents=True, exist_ok=True)
    post = frontmatter.Post(body, **metadata)
    frontmatter.dump(post, filepath)


def add_redirect(from_url: str, to_url: str, reason: str = "",
                  status: int = 301) -> None:
    """Append a redirect entry to .wire/redirects.yml.

    Central redirect map maintained by Wire. Build systems read this
    to generate redirects (server config, _redirects file, etc.).
    """
    import yaml
    redirects_dir = Path(".wire")
    redirects_dir.mkdir(exist_ok=True)
    redirects_file = redirects_dir / "redirects.yml"

    redirects = []
    if redirects_file.exists():
        content = redirects_file.read_text(encoding="utf-8")
        redirects = yaml.safe_load(content) or []

    # Avoid duplicates
    for r in redirects:
        if r.get("from") == from_url:
            r["to"] = to_url
            r["reason"] = reason
            r["status"] = status
            r["date"] = str(date.today())
            break
    else:
        redirects.append({
            "from": from_url,
            "to": to_url,
            "reason": reason,
            "status": status,
            "date": str(date.today()),
        })

    redirects_file.write_text(
        yaml.dump(redirects, default_flow_style=False, allow_unicode=True),
        encoding="utf-8"
    )
    logger.info(f"Redirect ({status}): {from_url} -> {to_url}")


def load_redirects(site_dir: Path = None) -> list[dict]:
    """Load redirects from both .wire/redirects.yml AND wire.yml redirects:.

    Returns [{'from': path, 'to': path, 'status': int, ...}].
    Every entry has 'status' (default 301 for entries with 'to').
    wire.yml supports list format [{from, to, status}] or dict format {old: new}.
    De-duplicates by 'from' key (wire.yml wins on conflict).
    """
    import yaml
    site_dir = site_dir or Path.cwd()
    by_from = {}

    # Source 1: .wire/redirects.yml (Wire-internal moves)
    wire_file = site_dir / ".wire" / "redirects.yml"
    if wire_file.exists():
        try:
            entries = yaml.safe_load(wire_file.read_text(encoding="utf-8")) or []
            for r in entries:
                if r.get("from"):
                    by_from[r["from"]] = r
        except Exception as e:
            logger.warning(f"Failed to read {wire_file}: {e}")

    # Source 2: wire.yml redirects: key (user-configured)
    wire_yml = site_dir / "wire.yml"
    if wire_yml.exists():
        try:
            config = yaml.safe_load(wire_yml.read_text(encoding="utf-8")) or {}
            user_redirects = config.get("redirects")
            if isinstance(user_redirects, dict):
                # Old dict format: {old_path: new_path}
                for from_url, to_url in user_redirects.items():
                    by_from[from_url] = {"from": from_url, "to": to_url}
            elif isinstance(user_redirects, list):
                # New list format: [{from, to, status}]
                for r in user_redirects:
                    if isinstance(r, dict) and r.get("from"):
                        by_from[r["from"]] = r
        except Exception as e:
            logger.warning(f"Failed to read redirects from {wire_yml}: {e}")

    # Normalize: ensure every entry has 'status'
    for entry in by_from.values():
        if "status" not in entry:
            entry["status"] = 301 if entry.get("to") else 410

    # Validate redirects — fail loud on bad config
    for entry in by_from.values():
        src = entry.get("from", "")
        dst = entry.get("to", "")

        # Self-redirect: from == to after trailing-slash normalization
        if dst and src.rstrip("/") == dst.rstrip("/"):
            raise SystemExit(
                f"BUILD REFUSED: self-redirect {src} → {dst} "
                f"(would cause infinite redirect loop in browser)")

        # Query params in redirect source — not a valid filesystem path
        if "?" in src or "=" in src:
            raise SystemExit(
                f"BUILD REFUSED: query parameter in redirect source '{src}' "
                f"(redirects must be clean paths, not query strings)")

    # Warn about redirect chains (A→B where B is also a redirect source)
    sources = {e["from"] for e in by_from.values()}
    for entry in by_from.values():
        dst = entry.get("to", "")
        if dst and dst in sources:
            logger.warning(
                f"Redirect chain detected: {entry['from']} → {dst} → ... "
                f"(multi-hop redirects hurt SEO and slow page loads)")

    return list(by_from.values())


def _find_slug_fix(target_slug: str, existing_slugs: set[str]) -> str | None:
    """Match after hyphen normalization: tungsten-automation → tungstenautomation."""
    normalized = target_slug.replace("-", "")
    for existing in existing_slugs:
        if existing.replace("-", "") == normalized and existing != target_slug:
            return existing
    return None


@lru_cache(maxsize=1)
def _get_valid_internal_paths() -> tuple[frozenset, dict]:
    """Build set of valid paths + per-topic slug sets from site directory.

    Returns (valid_paths frozenset, {topic: set of slugs}).
    Returns (frozenset(), {}) if DOCS_DIR doesn't exist.
    """
    if not DOCS_DIR.exists():
        return frozenset(), {}

    valid = set()
    by_topic = {}
    for tname in list_topics():
        # Include topic index page itself (e.g. /kontakt/, /services/)
        valid.add(f"/{tname}/")
        topic_slugs = set()
        try:
            topic_obj = Topic(tname)
            for item in topic_obj.list():
                valid.add(item.path.rstrip("/") + "/")
                topic_slugs.add(item.slug)
        except (FileNotFoundError, ValueError):
            pass
        if topic_slugs:
            by_topic[tname] = topic_slugs
    return frozenset(valid), by_topic


def _strip_embedded_frontmatter(body: str) -> tuple[str, bool]:
    """Strip YAML frontmatter blocks embedded in the markdown body.

    Claude sometimes echoes the vendor page's frontmatter into news output,
    producing a second --- ... --- block after the real frontmatter.

    Returns (cleaned_body, was_stripped).
    """
    # Match a YAML frontmatter block (---\n...---\n) that appears after some content.
    # The pattern: newline, ---, YAML-like lines (key: value), closing ---.
    # We only strip blocks that look like YAML (contain "key: value" lines).
    pattern = re.compile(
        r'\n---\s*\n'           # opening ---
        r'((?:[^\n]*\n)*?)'    # YAML content (non-greedy)
        r'---\s*\n',           # closing ---
    )

    stripped = False
    for match in reversed(list(pattern.finditer(body))):
        yaml_block = match.group(1)
        # Only strip if it looks like YAML frontmatter (has key: value lines)
        yaml_lines = [l for l in yaml_block.strip().splitlines() if l.strip()]
        if not yaml_lines:
            continue
        kv_lines = [l for l in yaml_lines if re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*\s*:', l)]
        if len(kv_lines) >= 2:
            # This looks like embedded frontmatter — strip it
            body = body[:match.start()] + "\n" + body[match.end():]
            stripped = True

    return body, stripped


def _sanitize_content(post: frontmatter.Post, old_post: frontmatter.Post = None) -> list:
    """Auto-fix structural SEO issues in content. Modifies post in-place.

    12 auto-fixes:
      1. Pipe in title → em dash
      2. Brackets in title → stripped
      3. Missing H1 → insert from title
      4. H1 ≠ title → align H1 to title
      5. Multiple H1s → downgrade extras to H2
      6. Dedup internal links (same target, keep first)
      7. Restore external sources removed by Claude (append-only)
      8. Dedup external links (same URL 3+ times → keep first, strip rest)
      9. Broken internal links → try slug fix, else strip to plain text
     10. Redirect links → rewrite to target (410 → strip to plain text)
     11. Cross-language links → strip to plain text
     12. Embedded YAML frontmatter in body → strip (Claude echo artifact)

    Returns list of fix descriptions (logged as warnings by caller).
    """
    fixes = []
    title = post.get("title", "")
    body = post.content

    # 1. Pipe in title → em dash
    if "|" in title:
        post["title"] = title.replace("|", "\u2014").strip()
        fixes.append(f"Title: replaced pipe with dash")
        title = post["title"]

    # 2. Brackets in title
    if "[" in title or "]" in title:
        post["title"] = title.replace("[", "").replace("]", "").strip()
        fixes.append(f"Title: stripped brackets")
        title = post["title"]

    # 3-5. H1 alignment
    # Template renders H1 from frontmatter, but markdown should also have one
    # for readability (stripped at build time). Insert if missing, align if mismatched.
    h1_pattern = re.compile(r'^# (.+)$', re.MULTILINE)
    h1_matches = list(h1_pattern.finditer(body))

    if len(h1_matches) == 0:
        # No H1 → insert as first line (markdown should be a complete document)
        post.content = f"# {title}\n\n{body}"
        fixes.append("Inserted missing H1")
    elif len(h1_matches) == 1:
        # One H1 — align to title if mismatched
        if h1_matches[0].group(1).strip() != title:
            post.content = body[:h1_matches[0].start()] + f"# {title}" + body[h1_matches[0].end():]
            fixes.append(f"H1 aligned to title")
    else:
        # Multiple H1s → keep first (aligned), downgrade rest
        lines = body.split('\n')
        first_seen = False
        for i, line in enumerate(lines):
            if re.match(r'^# (?!#)', line):
                if not first_seen:
                    first_seen = True
                    if line[2:].strip() != title:
                        lines[i] = f"# {title}"
                        fixes.append(f"H1 aligned to title")
                else:
                    lines[i] = '#' + line  # # → ##
                    fixes.append(f"Downgraded extra H1 to H2: '{line[2:].strip()}'")
        post.content = '\n'.join(lines)

    # 6. Duplicate internal links → keep first per URL, strip rest to plain text
    seen_urls = set()
    logged_urls = set()

    def _dedup_link(match):
        text, url = match.group(1), match.group(2)
        if url in seen_urls:
            if url not in logged_urls:
                fixes.append(f"Deduped internal link: {url}")
                logged_urls.add(url)
            return text  # plain text
        seen_urls.add(url)
        return match.group(0)

    post.content = re.sub(r'\[([^\]]+)\]\((/[^)]+)\)', _dedup_link, post.content)

    # 7. Sources preservation (append-only)
    if old_post and "sources" in old_post.metadata:
        old_sources = old_post.get("sources") or []
        new_sources = post.get("sources") or []
        if isinstance(old_sources, list) and isinstance(new_sources, list):
            old_set = set(old_sources)
            new_set = set(new_sources)
            dropped = old_set - new_set
            if dropped:
                post["sources"] = sorted(set(new_sources) | old_set)
                fixes.append(f"Restored {len(dropped)} dropped source(s)")

    # 8. Duplicate external links → keep first per URL, strip rest to plain text
    seen_ext_urls = set()
    logged_ext_urls = set()

    def _dedup_ext_link(match):
        text, url = match.group(1), match.group(2)
        if url in seen_ext_urls:
            if url not in logged_ext_urls:
                fixes.append(f"Deduped external link: {url}")
                logged_ext_urls.add(url)
            return text  # plain text
        seen_ext_urls.add(url)
        return match.group(0)

    post.content = re.sub(r'\[([^\]]+)\]\((https?://[^)]+)\)', _dedup_ext_link, post.content)

    # 10. Links to redirect sources → rewrite to target (410 → strip to plain text)
    try:
        redirects = load_redirects()
    except Exception:
        redirects = []
    if redirects:
        redirect_map = {}
        for r in redirects:
            src = r.get("from", "").rstrip("/") + "/"
            dst = r.get("to", "")
            status = r.get("status", 301)
            redirect_map[src] = (dst, status)

        def _fix_redirect_link(match):
            text, url = match.group(1), match.group(2)
            norm = url.rstrip("/") + "/"
            if norm in redirect_map:
                target, status = redirect_map[norm]
                if status == 410 or not target:
                    fixes.append(f"Stripped link to 410 (Gone): {url}")
                    return text  # plain text
                fixes.append(f"Rewrote redirect link: {url} -> {target}")
                return f"[{text}]({target})"
            return match.group(0)
        post.content = re.sub(r'\[([^\]]+)\]\((/[^)]+)\)', _fix_redirect_link, post.content)

    # 11. Cross-language links → strip to plain text (can't auto-resolve target)
    if _ACTIVE_LANG:
        def _fix_cross_lang_link(match):
            text, url = match.group(1), match.group(2)
            # Check if link starts with a language prefix that isn't the active one
            lang_match = re.match(r'^/([a-z]{2})/', url)
            if lang_match and lang_match.group(1) != _ACTIVE_LANG:
                fixes.append(
                    f"Stripped cross-language link: {url} "
                    f"(page is /{_ACTIVE_LANG}/, link goes to /{lang_match.group(1)}/)"
                )
                return text  # strip to plain text
            return match.group(0)
        post.content = re.sub(r'\[([^\]]+)\]\((/[^)]+)\)', _fix_cross_lang_link, post.content)

    # 9. Broken internal links → fix slug or strip to plain text
    valid_paths, paths_by_topic = _get_valid_internal_paths()
    if valid_paths:
        def _fix_broken_link(match):
            text, url = match.group(1), match.group(2)
            norm = url.rstrip("/") + "/"
            if norm in valid_paths:
                return match.group(0)  # link is valid
            # Try slug fix (hyphen normalization)
            parts = norm.strip("/").split("/")
            if len(parts) >= 2:
                topic, slug = parts[0], parts[1]
                fixed = _find_slug_fix(slug, paths_by_topic.get(topic, set()))
                if fixed:
                    fixes.append(f"Fixed link: {url} -> /{topic}/{fixed}/")
                    return f"[{text}](/{topic}/{fixed}/)"
            # No fix → strip to plain text
            fixes.append(f"Removed broken link: {url}")
            return text
        post.content = re.sub(r'\[([^\]]+)\]\((/[^)]+)\)', _fix_broken_link, post.content)

    # 12. Embedded YAML frontmatter in body → strip (Claude echo artifact)
    post.content, was_stripped = _strip_embedded_frontmatter(post.content)
    if was_stripped:
        fixes.append("Stripped embedded YAML frontmatter from body")

    return fixes


def _warn_content_quality(post: frontmatter.Post, old_post: frontmatter.Post, slug: str) -> None:
    """Log warnings for content quality issues that need human judgment."""
    title = post.get("title", "")
    desc = post.get("description", "")
    body = post.content

    # Title length (sweet spot 51-55, warn outside 30-60)
    if len(title) > 60:
        logger.warning(f"SEO [{slug}]: title {len(title)} chars (target 51-55, max 60)")
    elif title and len(title) < 30:
        logger.warning(f"SEO [{slug}]: title only {len(title)} chars (target 51-55)")

    # Description length (target 140-155, warn >160)
    if desc and len(desc) > 160:
        logger.warning(f"SEO [{slug}]: description {len(desc)} chars (target 140-155, max 160)")

    # Generic anchors
    generic = re.findall(r'\[(here|click here|this link|read more|this article|link)\]\(', body, re.I)
    if generic:
        logger.warning(f"SEO [{slug}]: {len(generic)} generic anchor(s): {[g.lower() for g in generic[:3]]}")

    # Anchor text length (2-5 words optimal, warn >6) — internal links only
    long_anchors = []
    for match in re.finditer(r'\[([^\]]+)\]\((/[^)]+)\)', body):
        anchor = match.group(1)
        word_count = len(anchor.split())
        if word_count > 6:
            long_anchors.append(anchor[:50])
    if long_anchors:
        logger.warning(f"SEO [{slug}]: {len(long_anchors)} long anchor(s) (>6 words): {long_anchors[:2]}")

    # Zero external citations
    external_links = re.findall(r'\[[^\]]+\]\(https?://[^)]+\)', body)
    if not external_links:
        logger.warning(f"SEO [{slug}]: no external citations in body")

    # Body shrinkage (>30% content loss)
    if old_post:
        old_len = len(old_post.content)
        new_len = len(body)
        if old_len > 500 and new_len < old_len * 0.7:
            pct = round((1 - new_len / old_len) * 100)
            logger.warning(f"Content [{slug}]: body shrank {pct}% ({old_len} → {new_len} chars)")

    # Excessive internal links (traffic declines after ~45-50 to same URL)
    internal_links = re.findall(r'\[[^\]]+\]\(/[^)]+\)', body)
    if len(internal_links) > 50:
        logger.warning(f"SEO [{slug}]: {len(internal_links)} internal links (traffic declines after ~45-50)")


def _fix_yaml_quoting(content: str) -> str:
    """Quote unquoted YAML values that contain colons (common LLM output issue)."""
    lines = content.split('\n')
    in_frontmatter = False
    result = []
    for i, line in enumerate(lines):
        if line.strip() == '---':
            in_frontmatter = not in_frontmatter
            result.append(line)
            continue
        if in_frontmatter and ':' in line and not line.startswith(' '):
            # Top-level key: value — check if value has unquoted colon
            key_end = line.index(':')
            key = line[:key_end]
            value = line[key_end + 1:].strip()
            if value and not value.startswith(("'", '"', '|', '>', '[', '{')):
                # Check if there's a second colon in the value
                if ':' in value:
                    value = f"'{value.replace(chr(39), chr(39)+chr(39))}'"
                    line = f"{key}: {value}"
        result.append(line)
    return '\n'.join(result)


def validate_frontmatter(content: str) -> frontmatter.Post:
    """Parse and validate markdown content has frontmatter with title.

    Raises:
        ValueError: If content has no YAML frontmatter, invalid YAML, or missing title.
    """
    try:
        post = frontmatter.loads(content)
    except Exception:
        # Retry with YAML quoting fix (LLM often produces unquoted colons)
        try:
            content = _fix_yaml_quoting(content)
            post = frontmatter.loads(content)
        except Exception as e:
            raise ValueError(f"Invalid YAML frontmatter: {e}")
    if not post.metadata:
        raise ValueError(f"Content missing YAML frontmatter (no --- delimiters found)")
    if not post.get('title'):
        raise ValueError(f"Frontmatter missing required 'title'. Found keys: {list(post.metadata.keys())}")
    return post


@dataclass
class Content:
    """
    ONE content item (vendor, capability, etc.).

    Knows its filesystem location and can access its own files.
    """
    slug: str      # "abbyy" - folder name
    title: str     # "ABBYY" - H1 from index.md
    path: str      # "/vendors/abbyy/" - absolute link for MkDocs
    summary: str   # First paragraph - SEO description

    @property
    def topic(self) -> str:
        """Topic directory name (e.g., 'vendors', 'capabilities')."""
        return self.path.strip("/").split("/")[0]

    @property
    def fs_path(self) -> Path:
        """Filesystem path for this item."""
        return DOCS_DIR / self.path.strip("/")

    @property
    def index_path(self) -> Path:
        """Path to this item's index.md."""
        return self.fs_path / "index.md"

    def read_index(self) -> str:
        """Read this item's index.md content."""
        return self.index_path.read_text(encoding='utf-8')

    def save_index(self, content: str) -> None:
        """Validate, sanitize, and save content. Preserves created + wire_* fields.

        Three-step quality pipeline:
        1. validate_frontmatter() — structural validity
        2. _sanitize_content() — auto-fix SEO issues (H1, links, title chars)
        3. _warn_content_quality() — log warnings for human judgment items

        Args:
            content: Markdown with frontmatter to save.
        """
        preserved = {}
        old_post = None
        if self.index_path.exists():
            old_post = frontmatter.load(self.index_path)
            for key in old_post.metadata:
                if key == "created" or key.startswith("wire_"):
                    preserved[key] = old_post[key]

        # Auto-restore title if Claude dropped it
        if old_post and old_post.get("title"):
            temp = frontmatter.loads(content)
            if not temp.get("title"):
                temp["title"] = old_post["title"]
                content = frontmatter.dumps(temp)
                logger.warning(f"Auto-fix [{self.slug}]: Restored dropped title '{old_post['title']}'")

        post = validate_frontmatter(content)
        # Safety net: Claude sometimes appends site title suffix despite prompt rules
        if SITE and SITE.title and "title" in post.metadata:
            suffix = f" | {SITE.title}"
            if post["title"].endswith(suffix):
                post["title"] = post["title"][:-len(suffix)]
                logger.info(f"Stripped site suffix from title: '{post['title']}'")

        # Auto-fix structural SEO issues
        fixes = _sanitize_content(post, old_post)
        for fix in fixes:
            logger.warning(f"Auto-fix [{self.slug}]: {fix}")

        # Log quality warnings
        _warn_content_quality(post, old_post, self.slug)

        # Hard reject: body shrinkage >80% — refuse to save, keep original
        if old_post:
            old_len = len(old_post.content)
            new_len = len(post.content)
            if old_len > 500 and new_len < old_len * 0.2:
                pct = round((1 - new_len / old_len) * 100)
                logger.error(
                    f"REJECTED [{self.slug}]: body shrank {pct}% "
                    f"({old_len} -> {new_len} chars) — original preserved. "
                    f"Use git to inspect the change.")
                return  # Refuse to save

        self.fs_path.mkdir(parents=True, exist_ok=True)

        for key, value in preserved.items():
            if key not in post.metadata:
                post[key] = value
                logger.info(f"Preserved {key} (dropped by Claude)")

        frontmatter.dump(post, self.index_path)

    def stamp(self, **fields) -> None:
        """Unified metadata finalizer — call after save_index().

        Always updates date. Sets created from git on first call.
        Merges tracking kwargs (e.g., wire_action, wire_reworded).
        """
        post = frontmatter.load(self.index_path)
        today = datetime.now().strftime("%Y-%m-%d")

        if "created" not in post.metadata:
            post["created"] = self._git_created_date() or post.get("date", today)
        post["date"] = today

        for key, value in fields.items():
            post[key] = value
        frontmatter.dump(post, self.index_path)

    def _git_created_date(self) -> str | None:
        """First commit date for this file from git history."""
        try:
            result = subprocess.run(
                ["git", "log", "--follow", "--diff-filter=A",
                 "--format=%aI", "--", str(self.index_path)],
                capture_output=True, text=True, timeout=5
            )
            if result.stdout.strip():
                return result.stdout.strip().split("\n")[-1][:10]
        except subprocess.TimeoutExpired:
            logger.debug(f"Git history lookup timed out for {self.index_path}")
        except FileNotFoundError:
            logger.debug("Git not available — using fallback date")
        except subprocess.SubprocessError as e:
            logger.debug(f"Git history lookup failed for {self.index_path}: {e}")
        return None

    def get_stamp(self, key: str) -> str | None:
        """Read a tracking field from frontmatter. File must exist."""
        post = frontmatter.load(self.index_path)
        value = post.get(key)
        return str(value) if value is not None else None

    def news_files(self, archived=False, date: str = None) -> List[Path]:
        """
        News .md files for this item (not index.md).

        Args:
            archived: If True, also include news/ subfolder.
            date: If set, only return files matching this YYYY-MM-DD stem.
        """
        if not self.fs_path.exists():
            return []

        files = [
            f for f in self.fs_path.iterdir()
            if f.is_file() and f.suffix == '.md'
            and f.name not in ('index.md', 'steps.md')
        ]

        if archived:
            news_subdir = self.fs_path / "news"
            if news_subdir.exists():
                files.extend(
                    f for f in news_subdir.iterdir()
                    if f.is_file() and f.suffix == '.md'
                )

        if date:
            files = [f for f in files if f.stem == date]

        return sorted(files)

    def save_news(self, body: str, from_date: datetime = None, to_date: datetime = None) -> Path:
        """Save news content as YYYY-MM-DD.md with frontmatter."""
        today = datetime.now()
        filepath = self.fs_path / f"{today.strftime('%Y-%m-%d')}.md"

        # Strip embedded YAML frontmatter (Claude echo artifact, bug #72)
        body, was_stripped = _strip_embedded_frontmatter(body)
        if was_stripped:
            logger.warning(f"Stripped embedded frontmatter from news body for {self.title}")

        fm = {'date': today.strftime('%Y-%m-%d')}
        if from_date and to_date:
            fm['title'] = f"{from_date.strftime('%Y-%m-%d')} to {to_date.strftime('%Y-%m-%d')}"
            fm['summary'] = f"Recent news and updates about {self.title}"
            body = f"# {self.title} News: {from_date.strftime('%B %d')} to {to_date.strftime('%B %d, %Y')}\n\n{body}"

        write_md(filepath, fm, body)
        return filepath

    def save_tracker(self) -> Path:
        """Save no-news tracker as YYYY-MM-DD.md."""
        today = datetime.now()
        filepath = self.fs_path / f"{today.strftime('%Y-%m-%d')}.md"

        write_md(filepath, {
            'title': 'No news found',
            'date': today.strftime('%Y-%m-%d'),
            'type': 'tracker',
        }, f"No recent news articles were found for **{self.title}**.")

        return filepath

    def news_age(self) -> Optional[int]:
        """Days since last news file, or None if no news ever."""
        files = self.news_files(archived=True)
        if not files:
            return None
        latest = max(files, key=lambda f: f.stat().st_ctime)
        return (datetime.now() - datetime.fromtimestamp(latest.stat().st_ctime)).days

    @classmethod
    def from_path(cls, directory: str, item_path: Path) -> 'Content':
        """
        Create Content from filesystem path.

        Args:
            directory: Topic directory name (e.g., "vendors")
            item_path: Path to item folder

        Raises:
            FileNotFoundError: If index.md doesn't exist
            ValueError: If index.md has no title
        """
        index_file = item_path / "index.md"
        if not index_file.exists():
            raise FileNotFoundError(f"Missing index.md: {item_path}")

        fm = frontmatter.load(index_file)

        if not fm.get('title'):
            raise ValueError(f"No title in frontmatter: {index_file}")

        return cls(
            slug=item_path.name,
            title=fm['title'],
            path=f"/{directory}/{item_path.name}/",
            summary=fm.get('description', '')
        )

    @staticmethod
    def make_slug(name: str) -> str:
        """Convert display name to folder slug: 'ABBYY Inc.' → 'abbyy-inc'"""
        return name.lower().replace(' ', '-').replace('.', '')

    @classmethod
    def from_location(cls, location: str) -> 'Content':
        """
        Create Content from location string.

        Examples:
            Content.from_location("vendors/abbyy") → Content(slug="abbyy", ...)
            Content.from_location("capabilities/ocr") → Content(slug="ocr", ...)
        """
        location = location.strip('/')
        if '/' not in location:
            raise ValueError(f"Location must be 'directory/slug' format, got: {location}")
        directory, slug = location.split('/', 1)
        return Topic(directory).get(slug)


class Topic:
    """
    A content directory (vendors, capabilities, etc.).

    Handles directory-level operations:
        topic = Topic("vendors")
        topic.list()                    # All items
        topic.get("abbyy")              # Single item
        topic.needing_news(days=21)     # Items that need news gathering
        topic.find_news("2024-01-01")   # News files for a date
    """

    def __init__(self, directory: str):
        self.directory = directory
        self.path = DOCS_DIR / directory
        index_file = self.path / "index.md"
        if not index_file.exists():
            available = ", ".join(list_topics()) if DOCS_DIR.exists() else "none"
            raise FileNotFoundError(
                f"Topic '{directory}' not found at {index_file}. "
                f"Available topics: {available}")
        meta = frontmatter.load(index_file)
        self.title = meta.get('title', '')
        self.description = meta.get('description', '')

    def __str__(self):
        return self.directory

    def fs_path(self, item_slug: str) -> Path:
        """Get filesystem path for an item in this topic."""
        return self.path / item_slug

    def get(self, item_slug: str) -> Content:
        """Get a single content item by slug."""
        return Content.from_path(self.directory, self.path / item_slug)

    def list(self) -> List[Content]:
        """List all content items (directories with index.md)."""
        if not self.path.exists():
            logger.warning(f"Directory not found: {self.path}")
            return []

        items = []
        skipped = []
        for item_path in sorted(self.path.iterdir()):
            if not item_path.is_dir() or item_path.name.startswith('.'):
                continue
            if not (item_path / "index.md").exists():
                continue
            try:
                items.append(Content.from_path(self.directory, item_path))
            except Exception as e:
                skipped.append(item_path.name)
                logger.debug(f"Skipping {self.directory}/{item_path.name}: {e}")
        if skipped and self.directory not in _warned_topics:
            _warned_topics.add(self.directory)
            logger.warning(
                f"{self.directory}: {len(skipped)} items skipped (bad frontmatter)")
        return items

    def needing_news(self, days: int = 21) -> List[Content]:
        """
        Items that need news gathering (no recent news within N days).

        Used by NewsChief to decide what to process.
        """
        results = []
        for item in self.list():
            age = item.news_age()
            if age is None or age >= days:
                results.append(item)
        return results

    def find_news(self, date_str: str) -> List[Content]:
        """Items that have a news file for this date (checks archived too)."""
        return [
            item for item in self.list()
            if item.news_files(archived=True, date=date_str)
        ]

    def index(self) -> str:
        """
        Generate llms.txt style index.

        Returns markdown like:
            # Vendors

            [ABBYY](/vendors/abbyy/): Leader in intelligent document processing...
        """
        items = self.list()
        lines = [f"# {self.directory.title()}", ""]
        for item in items:
            lines.append(f"[{item.title}]({item.path}): {item.summary}")
        return "\n".join(lines)


def list_topics() -> list[str]:
    """Return all valid topic directory names under DOCS_DIR."""
    if not DOCS_DIR.exists():
        return []
    return sorted([
        d.name for d in DOCS_DIR.iterdir()
        if d.is_dir() and (d / "index.md").exists()
        and not d.name.startswith(".")
    ])


_STOPWORDS = frozenset({
    "the", "a", "an", "and", "or", "for", "of", "in", "to", "is", "with",
    "by", "on", "at", "from", "as", "its", "it", "that", "this", "are",
    "was", "be", "has", "have", "been", "not", "but", "if", "no", "so",
    "we", "our", "your", "their", "can", "do", "how", "what", "which",
    "all", "any", "each", "than", "into", "about", "up", "out", "new",
    "one", "two", "more", "most", "also", "just", "over", "such",
})


def _extract_keywords(text: str) -> set[str]:
    """Extract meaningful lowercase words from text, removing stopwords."""
    words = set(re.findall(r'[a-z]+', text.lower()))
    return words - _STOPWORDS


def analyze_source_diversity(body: str, own_domain: str = None) -> dict:
    """Detect external source concentration in article body.

    Args:
        body: Markdown body text (after frontmatter).
        own_domain: Root domain to exclude (e.g. "wise-relations.com").
            Auto-detected from SITE.url if None.

    Returns:
        dict with keys:
            domains: {domain: count} for all external domains
            total_external: total external link count
            concentrated: list of {domain, count, pct, anchors} for
                domains with >3 links OR >40% of external links
    """
    if own_domain is None:
        own_domain = get_root_domain(SITE.url) if SITE and SITE.url else ""

    # Extract all markdown links: [anchor](url)
    links = re.findall(r'\[([^\]]+)\]\((https?://[^)]+)\)', body)

    domain_links: Dict[str, list] = {}  # domain -> [(anchor, url), ...]
    for anchor, url in links:
        domain = urlparse(url).netloc.lower().replace('www.', '')
        root = get_root_domain(domain)
        if own_domain and root == own_domain:
            continue
        domain_links.setdefault(root, []).append((anchor, url))

    total = sum(len(entries) for entries in domain_links.values())
    domains = {d: len(entries) for d, entries in domain_links.items()}

    concentrated = []
    if total > 0:
        for domain, entries in domain_links.items():
            count = len(entries)
            pct = count / total * 100
            if (count > 3 and pct > 20) or (pct > 40 and total >= 5):
                concentrated.append({
                    "domain": domain,
                    "count": count,
                    "pct": round(pct, 1),
                    "anchors": [a for a, u in entries],
                    "urls": list(dict.fromkeys(u for a, u in entries)),
                })
        concentrated.sort(key=lambda x: -x["count"])

    return {"domains": domains, "total_external": total, "concentrated": concentrated}


def format_source_diversity(diversity: dict) -> str:
    """Format source concentration data for prompt injection.

    Returns empty string if no concentration issues — keeps prompts clean
    for the majority of articles that are fine.
    """
    if not diversity.get("concentrated"):
        return ""

    lines = ["This article has source concentration issues:\n"]
    for c in diversity["concentrated"]:
        lines.append(f"- **{c['domain']}** appears {c['count']} times "
                     f"({c['pct']:.0f}% of {diversity['total_external']} external links)")
        # Show what topics are sourced from this domain
        unique_anchors = list(dict.fromkeys(c["anchors"]))[:5]
        for anchor in unique_anchors:
            lines.append(f"  - \"{anchor}\"")

    lines.append(f"\nMax 2-3 links per external domain. Replace concentrated "
                 f"sources with diverse, authoritative alternatives.")
    return "\n".join(lines)


# Domains to filter from citation chain results (navigation, social, tracking)
NOISE_DOMAINS = {
    "facebook.com", "twitter.com", "x.com", "linkedin.com", "instagram.com",
    "youtube.com", "pinterest.com", "tiktok.com", "reddit.com",
    "googleapis.com", "gstatic.com", "cloudflare.com",
    "googletagmanager.com", "doubleclick.net",
    "bit.ly", "t.co", "ow.ly", "buff.ly", "lnkd.in",
    "apps.apple.com", "play.google.com",
}


def find_primary_sources(diversity: dict, own_domain: str = None,
                         max_urls: int = 3, max_aspects: int = 3) -> str:
    """Follow citation chain + run aspect searches for concentrated domains.

    Strategy A (citation chain): fetch aggregator pages, extract their outbound
    links — these are the primary sources behind the claims.

    Strategy B (aspect search): use anchor texts as targeted web search queries
    to find independent sources covering the same specific aspects.

    Args:
        diversity: Result from analyze_source_diversity()
        own_domain: Root domain to exclude. Auto-detected if None.
        max_urls: Max aggregator URLs to fetch per domain (citation chain)
        max_aspects: Max anchor texts to search per domain (aspect search)

    Returns:
        Formatted markdown for prompt injection, or empty string if nothing found.
    """
    if not diversity.get("concentrated"):
        return ""

    if own_domain is None:
        own_domain = get_root_domain(SITE.url) if SITE and SITE.url else ""

    sections = []

    for conc in diversity["concentrated"][:2]:  # max 2 concentrated domains
        domain = conc["domain"]
        urls = conc.get("urls", [])[:max_urls]
        anchors = conc.get("anchors", [])[:max_aspects]

        chain_sources = {}  # domain -> [url, ...]
        aspect_sources = {}  # anchor -> [url, ...]

        # Strategy A: citation chain
        for url in urls:
            try:
                content = fetch_page(url)
                if not content:
                    continue
                # Extract outbound links from fetched page
                found_links = re.findall(r'\[([^\]]+)\]\((https?://[^)]+)\)', content)
                for _anchor, found_url in found_links:
                    found_domain = get_root_domain(
                        urlparse(found_url).netloc.lower().replace('www.', ''))
                    # Filter: own domain, concentrated domain, noise
                    if found_domain == own_domain:
                        continue
                    if found_domain == domain:
                        continue
                    if found_domain in NOISE_DOMAINS:
                        continue
                    chain_sources.setdefault(found_domain, []).append(found_url)
            except Exception as e:
                logger.debug(f"Citation chain fetch failed for {url}: {e}")

        # Strategy B: aspect search
        # Use unique anchors as targeted search queries
        unique_anchors = list(dict.fromkeys(anchors))[:max_aspects]
        exclude = [own_domain, domain] + BLOCKED_DOMAINS if own_domain else [domain] + BLOCKED_DOMAINS
        for anchor in unique_anchors:
            try:
                found_urls = web_search(
                    anchor, max_results=3,
                    exclude_domains=exclude + list(NOISE_DOMAINS)
                )
                if found_urls:
                    aspect_sources[anchor] = found_urls
            except Exception as e:
                logger.debug(f"Aspect search failed for '{anchor}': {e}")

        # Format results
        if not chain_sources and not aspect_sources:
            continue

        lines = [f"### Primary sources behind {domain}\n"]

        if chain_sources:
            lines.append("**Citation chain** (sources cited by the aggregator):")
            # Deduplicate and show top sources by frequency
            top_chain = sorted(
                chain_sources.items(), key=lambda x: -len(x[1]))[:8]
            for src_domain, src_urls in top_chain:
                unique_url = list(dict.fromkeys(src_urls))[0]
                lines.append(f"- {src_domain}: {unique_url}")

        if aspect_sources:
            lines.append("\n**Aspect search** (independent sources per topic):")
            for anchor, found_urls in aspect_sources.items():
                url_list = ", ".join(
                    get_root_domain(urlparse(u).netloc.replace('www.', ''))
                    for u in found_urls[:3]
                )
                lines.append(f"- \"{anchor}\" -> {url_list}")
                for u in found_urls[:2]:
                    lines.append(f"  - {u}")

        sections.append("\n".join(lines))

    return "\n\n".join(sections)


def generate_link_context(item: Content) -> str:
    """Generate focused link context for a specific content item.

    Instead of dumping all pages, produces a curated directory:
    1. Same-topic pages (all siblings in the item's topic)
    2. Cross-topic pages matching item keywords
    3. Overlap warnings (if GSC data available)

    ~15-20KB instead of 113KB. Saves tokens and improves link quality.
    """
    lines = ["# Site Directory\n",
             "**ONLY link to pages listed below. If a company, product, or "
             "topic is mentioned but has no page here — use plain text, not a link.**\n"]

    item_keywords = _extract_keywords(f"{item.title} {item.summary}")

    # 1. Same-topic siblings
    try:
        topic_obj = Topic(item.topic)
        siblings = topic_obj.list()
        if siblings:
            lines.append(f"\n## {topic_obj.title or item.topic.title()} (/{item.topic}/)\n")
            for sibling in siblings:
                if sibling.slug == item.slug:
                    continue
                lines.append(f"[{sibling.title}]({sibling.path}): {sibling.summary}")
    except (FileNotFoundError, ValueError):
        pass

    # 2. Cross-topic keyword matches
    for tname in list_topics():
        if tname == item.topic:
            continue
        try:
            other_topic = Topic(tname)
            matches = []
            for other in other_topic.list():
                other_keywords = _extract_keywords(f"{other.title} {other.summary}")
                overlap = item_keywords & other_keywords
                if len(overlap) >= 2:
                    matches.append(other)
            if matches:
                lines.append(f"\n## {other_topic.title or tname.title()} (/{tname}/)\n")
                for m in matches:
                    lines.append(f"[{m.title}]({m.path}): {m.summary}")
        except (FileNotFoundError, ValueError):
            continue

    # 3. Overlap warnings from GSC (optional)
    try:
        from wire.db import find_overlaps
        overlaps = find_overlaps(item.topic, min_shared=2)
        warnings = []
        for ov in overlaps:
            if item.slug in (ov["slug_a"], ov["slug_b"]):
                other_slug = ov["slug_b"] if ov["slug_a"] == item.slug else ov["slug_a"]
                shared = ov.get("shared_count", 0)
                warnings.append(f"  - /{item.topic}/{other_slug}/ shares {shared} keywords — cross-link, don't compete")
        if warnings:
            lines.append("\n## Overlap Warnings\n")
            lines.extend(warnings)
    except Exception:
        pass

    return "\n".join(lines)


@lru_cache
def generate_site_directory(full: bool = False) -> str:
    """Generate markdown directory of all topics and items.

    Auto-discovers topics from DOCS_DIR. Lists all items per topic
    so Claude can create accurate internal links.

    The ``full`` parameter is accepted for backward compatibility
    but both modes now produce the same output.
    """
    lines = ["# Site Directory\n"]
    for tname in list_topics():
        try:
            topic = Topic(tname)
            items = topic.list()
            if not items:
                continue
            lines.append(f"\n## {topic.title or tname.title()} (/{tname}/)\n")
            for item in items:
                lines.append(f"[{item.title}]({item.path}): {item.summary}")
        except Exception as e:
            logger.warning(f"Site directory: skipping topic {tname}: {e}")
            continue

    return "\n".join(lines)
