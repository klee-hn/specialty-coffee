#!/usr/bin/env python3
"""
wire.clients — Cross-client registry and status overview.

Reads ~/.wire/clients.yml and provides quick status across all managed sites.

Usage:
    python -m wire.clients list          # Show all registered clients
    python -m wire.clients status        # Git status + page count per client
"""

import sys
import subprocess
from pathlib import Path

import yaml


REGISTRY = Path.home() / ".wire" / "clients.yml"


def load_clients() -> list[dict]:
    """Load client registry from ~/.wire/clients.yml."""
    if not REGISTRY.exists():
        print(f"No client registry found at {REGISTRY}")
        print("Create one with 'clients:' list entries (name, path, platform, deploy, url)")
        return []
    with open(REGISTRY, encoding="utf-8") as f:
        data = yaml.safe_load(f)
    return data.get("clients", [])


def _count_pages(path: Path) -> int:
    """Count markdown content pages in a site directory."""
    docs_dir = path / "docs"
    if not docs_dir.exists():
        return 0
    return sum(1 for f in docs_dir.rglob("index.md")
               if not f.name.startswith("_"))


def _git_status(path: Path) -> str:
    """Get short git status for a directory."""
    if not (path / ".git").exists():
        return "no git"
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=str(path), capture_output=True, text=True, timeout=10)
        lines = [l for l in result.stdout.strip().splitlines() if l.strip()]
        if not lines:
            return "clean"
        return f"{len(lines)} changed"
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return "error"


def _has_styleguide(path: Path) -> bool:
    """Check if site has a Wire styleguide."""
    return (path / "docs" / "_styleguide.md").exists()


def _has_gsc(path: Path) -> bool:
    """Check if site has GSC data."""
    return (path / ".wire" / "gsc.db").exists()


def cmd_list(clients: list[dict]):
    """Print all registered clients."""
    print(f"{'Name':<20} {'Platform':<10} {'Deploy':<15} {'URL'}")
    print("-" * 75)
    for c in clients:
        name = c.get("name", "?")
        platform = c.get("platform", "?")
        deploy = c.get("deploy", "?")
        url = c.get("url", "")
        print(f"{name:<20} {platform:<10} {deploy:<15} {url}")
    print(f"\n{len(clients)} clients registered")


def cmd_status(clients: list[dict]):
    """Print status overview for all clients."""
    print(f"{'Name':<20} {'Pages':>6} {'Git':<14} {'Style':>5} {'GSC':>5}")
    print("-" * 60)

    total_pages = 0
    content_sites = 0

    for c in clients:
        name = c.get("name", "?")
        path = Path(c.get("path", ""))

        if not path.exists():
            print(f"{name:<20} {'—':>6} {'missing':<14} {'—':>5} {'—':>5}")
            continue

        pages = _count_pages(path)
        git = _git_status(path)
        style = "yes" if _has_styleguide(path) else "—"
        gsc = "yes" if _has_gsc(path) else "—"

        total_pages += pages
        if pages > 0:
            content_sites += 1

        print(f"{name:<20} {pages:>6} {git:<14} {style:>5} {gsc:>5}")

    print("-" * 60)
    print(f"{'Total':<20} {total_pages:>6} {'':14} {content_sites} content sites")


def main():
    clients = load_clients()
    if not clients:
        return

    cmd = sys.argv[1] if len(sys.argv) > 1 else "list"

    if cmd == "list":
        cmd_list(clients)
    elif cmd == "status":
        cmd_status(clients)
    else:
        print(f"Unknown command: {cmd}")
        print("Usage: python -m wire.clients list|status")
        sys.exit(1)


if __name__ == "__main__":
    main()
