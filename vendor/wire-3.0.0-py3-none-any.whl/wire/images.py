#!/usr/bin/env python3
"""
BFL (Black Forest Labs) image generation for Wire sites.

Generates AI images from descriptive slugs using FLUX models.
Images are normal project files in docs/assets/images/ — no cache layer.

Usage:
    from wire.images import generate_all
    stats = generate_all(docs_dir, config, force=False)
"""

import json
import logging
import os
import re
import time
import urllib.parse
import urllib.request
from pathlib import Path

logger = logging.getLogger(__name__)

# Default image sizes (width, height) for each preset
DEFAULT_SIZES = {
    "default": (1024, 576),
    "wide": (1440, 480),
    "square": (512, 512),
}

# Cost per megapixel for flux-pro-1.1 (approximate)
_COST_PER_MEGAPIXEL = 0.04

_MAKEIMG_PATTERN = re.compile(r'!makeIMG\[([^\]]+)\](?:\{(\w+)\})?')


def _slugify(text: str) -> str:
    """Normalize text to a valid filename slug."""
    return re.sub(r'[^a-z0-9]+', '-', text.lower()).strip('-')


def _build_prompt(slug: str, config: dict) -> str:
    """Assemble BFL prompt from slug + site style.

    Layer 1: slug (hyphens → spaces) — the content description.
    Layer 2: image_style from wire.yml — the brand instruction.
    """
    words = slug.replace('-', ' ')
    style = config.get('image_style', '')
    if not style:
        return words
    return f"{words}. {style}"


def _estimate_cost(width: int, height: int) -> float:
    """Estimate generation cost for given dimensions."""
    megapixels = (width * height) / 1_000_000
    return round(megapixels * _COST_PER_MEGAPIXEL, 4)


def _poll_result(polling_url: str, api_key: str, timeout: int = 300) -> str:
    """Poll BFL API until image is ready. Returns image URL.

    Raises TimeoutError if not ready within timeout seconds.
    Raises RuntimeError on API error status.
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        req = urllib.request.Request(
            polling_url,
            headers={"x-key": api_key, "User-Agent": "Wire/3.9"},
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())

        status = data.get("status")
        if status == "Ready":
            return data["result"]["sample"]
        if status in ("Error", "Failed"):
            raise RuntimeError(f"BFL generation failed: {data}")

        time.sleep(2)

    raise TimeoutError(f"BFL image not ready after {timeout}s")


def _download_image(url: str, dest_path: Path) -> None:
    """Download image from URL to local path."""
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": "Wire/3.9"})
    with urllib.request.urlopen(req, timeout=60) as resp:
        dest_path.write_bytes(resp.read())


def generate_image(slug: str, style_prompt: str, width: int, height: int,
                   model: str, api_key: str, output_path: Path) -> Path:
    """Generate a single image via BFL API.

    Returns the output path on success.
    Raises on failure after one retry.
    """
    prompt = f"{slug.replace('-', ' ')}. {style_prompt}" if style_prompt else slug.replace('-', ' ')

    payload = json.dumps({
        "prompt": prompt,
        "width": width,
        "height": height,
    }).encode()

    url = f"https://api.bfl.ai/v1/{model}"

    last_err = None
    for attempt in range(2):  # retry once on network error
        try:
            req = urllib.request.Request(
                url,
                data=payload,
                headers={
                    "x-key": api_key,
                    "Content-Type": "application/json",
                    "User-Agent": "Wire/3.9",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.loads(resp.read())

            polling_url = result.get("polling_url") or result.get("id")
            if not polling_url:
                raise RuntimeError(f"No polling URL in BFL response: {result}")

            image_url = _poll_result(polling_url, api_key)
            _download_image(image_url, output_path)
            return output_path

        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            last_err = exc
            if attempt == 0:
                logger.warning(f"  Retry: {slug} ({exc})")
                time.sleep(2)

    raise last_err


def scan_makeimg_refs(docs_dir: Path) -> list:
    """Walk all markdown files and find !makeIMG[slug]{preset} references.

    Returns list of dicts: {slug, preset, file, line}.
    """
    refs = []
    for md_file in sorted(docs_dir.rglob("*.md")):
        try:
            text = md_file.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        for m in _MAKEIMG_PATTERN.finditer(text):
            line_no = text[:m.start()].count('\n') + 1
            refs.append({
                "slug": m.group(1),
                "preset": m.group(2) or "default",
                "file": str(md_file),
                "line": line_no,
            })
    return refs


def generate_all(docs_dir: Path, config: dict, force: bool = False,
                 prune: bool = False) -> dict:
    """Generate all missing images referenced by !makeIMG[...] in docs.

    Args:
        docs_dir: Path to docs directory.
        config: Wire config dict (from wire.yml extra.wire).
        force: Regenerate even if file exists.
        prune: Remove orphan images not referenced by any !makeIMG.

    Returns dict with stats: generated, cached, errors, pruned, cost.
    """
    api_key = os.environ.get("BFL_API_KEY", "")
    model = config.get("image_model", "flux-pro-1.1")
    image_style = config.get("image_style", "")
    sizes = config.get("image_sizes", DEFAULT_SIZES)
    images_dir = docs_dir / "assets" / "images"

    refs = scan_makeimg_refs(docs_dir)

    # Deduplicate by slug (same slug may appear in multiple files)
    unique_slugs = {}
    for ref in refs:
        slug = ref["slug"]
        if slug not in unique_slugs:
            unique_slugs[slug] = ref["preset"]

    stats = {"generated": 0, "cached": 0, "errors": 0, "pruned": 0,
             "cost": 0.0}

    if prune:
        return _prune_orphans(images_dir, unique_slugs, stats)

    if not unique_slugs:
        logger.info("No !makeIMG[...] references found.")
        return stats

    needs_generation = False
    for slug, preset in unique_slugs.items():
        dest = images_dir / f"{slug}.png"
        size = sizes.get(preset, sizes.get("default", DEFAULT_SIZES["default"]))
        if isinstance(size, (list, tuple)):
            w, h = size
        else:
            w, h = DEFAULT_SIZES["default"]
        cost = _estimate_cost(w, h)

        if dest.exists() and not force:
            logger.info(f"  + {slug} (cached)")
            stats["cached"] += 1
            continue

        needs_generation = True

        if not api_key:
            raise RuntimeError(
                "BFL_API_KEY not set in .env — cannot generate images.\n"
                "Get your key at https://api.bfl.ai"
            )

        try:
            generate_image(slug, image_style, w, h, model, api_key, dest)
            stats["generated"] += 1
            stats["cost"] += cost
            logger.info(f"  ✓ {slug} (generated, ${cost:.3f})")
        except Exception as exc:
            stats["errors"] += 1
            logger.warning(f"  ✗ {slug}: {exc}")

    summary = (f"Images: {stats['generated']} generated, "
               f"{stats['cached']} cached, {stats['errors']} errors")
    if stats["cost"] > 0:
        summary += f" (~${stats['cost']:.2f})"
    logger.info(summary)

    return stats


def _prune_orphans(images_dir: Path, referenced_slugs: dict,
                   stats: dict) -> dict:
    """Remove images in docs/assets/images/ not referenced by any !makeIMG."""
    if not images_dir.exists():
        logger.info("No images directory found.")
        return stats

    for img_file in sorted(images_dir.glob("*.png")):
        slug = img_file.stem
        if slug not in referenced_slugs:
            img_file.unlink()
            logger.info(f"  Pruned {slug}.png")
            stats["pruned"] += 1

    logger.info(f"Pruned: {stats['pruned']} orphan images")
    return stats
