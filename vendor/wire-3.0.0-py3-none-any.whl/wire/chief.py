#!/usr/bin/env python3
"""
Chief (chief.py)

Orchestrates news gathering, content refinement, and SEO for a Topic.

Recommended workflow:
    1. python -m wire.chief data                         # Pull GSC metrics into local DB
    2. python -m wire.chief audit [vendors]              # SEO audit: opportunities, gaps, overlaps, dead pages
    3. python -m wire.chief deduplicate vendors          # Merge/differentiate overlapping pages
    4. python -m wire.chief news vendors                 # Gather news for all vendors
    5. python -m wire.chief refine vendors               # Integrate pending news into pages
    6. python -m wire.chief reword vendors               # Rewrite pages for GSC keywords
    7. python -m wire.chief consolidate                  # Create hub pages from comparisons
    8. python -m wire.chief newsweek                     # Weekly market intelligence report
"""

from datetime import date, datetime, timedelta
import calendar
import re
import subprocess
import time
import logging
import argparse
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

from pathlib import Path
import frontmatter as fm

from wire import tools
from wire.tools import (NEWS_API_MAX_DAYS_BACK, Topic, Content, SITE,
                        WIRE_CONFIG, FALLBACK_PROMPTS_DIR, claude_text,
                        validate_frontmatter, write_md, generate_site_directory,
                        list_topics, _find_slug_fix,
                        analyze_source_diversity, format_source_diversity,
                        web_search, fetch_page, override_docs_dir,
                        load_redirects, _load_mkdocs_config)
from wire.build import build, load_config
from wire.lint import lint_site
from wire.news import NewsReporter
from wire.content import ContentEditor, _format_search_terms
from wire.gsc import (get_search_terms, fetch_and_store, SNAPSHOT_MAX_AGE_DAYS,
                      _site_origin, _site_url, get_search_console_service)
from wire.db import (init_db, find_overlaps, keeper_score, db_summary,
                     get_snapshot_date, has_snapshot_data,
                     find_content_gaps, find_dead_pages,
                     site_median_impressions, register_content,
                     keyword_ownership_batch, trending_keywords,
                     find_missing_redirects, get_gsc_urls,
                     find_gsc_coverage_gaps,
                     rekey_from_redirects)
from wire.analyze import (build_amendment_brief, bm25_semantic_fit,
                          HIGH_RATIO_THRESHOLD)
import json
import shutil
from collections import Counter, defaultdict

logger = logging.getLogger(__name__)


def _validate_topic(topic_name: str) -> None:
    """Raise ValueError if topic_name is not a valid topic directory.

    Call at the top of any command that accepts a topic_name argument.
    main() catches ValueError and shows it cleanly.
    """
    available = list_topics()
    if topic_name not in available:
        raise ValueError(
            f"Unknown topic '{topic_name}'. "
            f"Available: {', '.join(available)}"
        )


def _preflight_gsc_check() -> list[str]:
    """Check GSC coverage before destructive operations.

    Returns list of error messages for uncovered URLs. Empty = all clear.
    Silently returns empty if no GSC data exists.
    """
    from wire.build import check_gsc_coverage

    # Build page URLs from filesystem (same source as _get_valid_internal_paths)
    page_urls = set()
    # Include homepage and root-level pages (#257)
    if (tools.DOCS_DIR / "index.md").exists():
        page_urls.add("/")
    for md_file in tools.DOCS_DIR.glob("*.md"):
        if md_file.name.startswith("_") or md_file.name == "index.md":
            continue
        page_urls.add(f"/{md_file.stem}/")
    for tname in list_topics():
        page_urls.add(f"/{tname}/")
        try:
            topic = Topic(tname)
            for item in topic.list():
                page_urls.add(item.path.rstrip("/") + "/")
        except (FileNotFoundError, ValueError):
            pass

    redirects = load_redirects()
    config = _load_mkdocs_config()
    exclude = config.get("exclude_gsc_data_for_path", [])
    return check_gsc_coverage(page_urls, redirects,
                              exclude_gsc_data_for_path=exclude)


# Layouts that should NOT be processed by content commands (news, refine, reword)
_SKIP_LAYOUTS = {"landing", "raw", "home"}


def _filter_editable(items: list) -> tuple[list, int]:
    """Filter content items to only those that are editable (not landing/raw/home).

    Returns (editable_items, skipped_count).
    """
    editable = []
    skipped = 0
    for item in items:
        try:
            post = fm.load(item.index_path)
            layout = post.get("layout", "")
            if layout in _SKIP_LAYOUTS:
                skipped += 1
                continue
        except Exception:
            pass
        editable.append(item)
    return editable, skipped


def _check_git_clean() -> None:
    """Refuse if docs/ has uncommitted changes — prevents data loss from content commands.

    Only checks docs/ directory. Skipped if not in a git repo.
    """
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain", str(tools.DOCS_DIR)],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0:
            return  # Not a git repo or git not available — skip check
        dirty = result.stdout.strip()
        if dirty:
            dirty_count = len(dirty.splitlines())
            logger.error(
                f"REFUSED: {dirty_count} uncommitted change(s) in {tools.DOCS_DIR}/.\n"
                f"  Commit your work first: git add {tools.DOCS_DIR}/ && git commit\n"
                f"  Wire modifies files during content operations. Uncommitted work may be lost."
            )
            raise SystemExit(1)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass  # git not installed or timeout — skip check


def _check_styleguide() -> None:
    """Refuse content generation if no project styleguide exists.

    Every site must have docs/_styleguide.md — the built-in fallback
    produces generic content that doesn't match the site's voice.
    """
    styleguide_path = tools.DOCS_DIR / "_styleguide.md"
    if not styleguide_path.exists():
        raise ValueError(
            "Content generation refused: no project styleguide found at "
            f"docs/_styleguide.md\n"
            f"  Create one based on: wire/prompts/example_styleguide.md\n"
            f"  See: https://wire.wise-relations.com/guides/adding-a-site/"
        )


# WordPress artifact patterns -> 410 Gone
_WP_CRUFT_PATTERNS = (
    "/wp-content/", "/wp-admin/", "/wp-includes/", "/wp-json/",
    "/author/", "/category/", "/tag/", "/feed/",
    "/?p=", "/?page_id=", "/xmlrpc.php",
)


def _match_redirect(url: str, page_paths: set,
                    default_lang: str = "") -> str | None:
    """Try to match a GSC URL to an existing page. Returns target or None.

    Matching strategies (strict only, no guessing):
      1. WordPress cruft -> "410"
      2. Exact slug match with language prefix added
      3. Exact path match in page_paths (already covered, shouldn't reach here)

    Returns:
      - Target path string for auto-redirect
      - "410" for Gone entries
      - None if no match (requires manual resolution)
    """
    # 1. WordPress cruft -> 410
    if any(pattern in url for pattern in _WP_CRUFT_PATTERNS):
        return "410"

    # 2. Exact slug match: /topic/slug/ -> /lang/topic/slug/
    if default_lang:
        candidate = f"/{default_lang}{url}" if not url.startswith(f"/{default_lang}/") else None
        if candidate and candidate in page_paths:
            return candidate

    # 3. Direct match (shouldn't need this, but defensive)
    if url in page_paths:
        return url

    return None


def _flip_overlap(ov: dict) -> dict:
    """Flip an overlap dict so A↔B become B↔A.

    Used when the caller's 'item' is slug_b (not slug_a).
    Swaps slug, topic, traffic_share, and per-keyword imp/pos.
    """
    return {
        **ov,
        "slug_a": ov["slug_b"],
        "slug_b": ov["slug_a"],
        "topic_a": ov.get("topic_b"),
        "topic_b": ov.get("topic_a"),
        "traffic_share_a": round(1 - ov["traffic_share_a"], 3),
        "shared_keywords": [
            {
                "keyword": kw["keyword"],
                "imp_a": kw["imp_b"],
                "imp_b": kw["imp_a"],
                "pos_a": kw["pos_b"],
                "pos_b": kw["pos_a"],
            }
            for kw in ov.get("shared_keywords", [])
        ],
    }


def _classify_overlap(ov: dict) -> str:
    """Classify an overlap pair as 'merge', 'differentiate', or 'monitor'.

    merge: ratio > 0.4, traffic skew > 0.7, same topic
    differentiate: ratio > 0.15
    monitor: everything else
    """
    ratio = ov["overlap_ratio"]
    skew = max(ov["traffic_share_a"], 1 - ov["traffic_share_a"])
    cross_topic = ov.get("topic_a") != ov.get("topic_b")
    if ratio > 0.4 and skew > 0.7 and not cross_topic:
        return "merge"
    elif ratio > 0.15:
        return "differentiate"
    return "monitor"



def _reword_tiers(total: int) -> tuple[int, int]:
    """Compute tier cutoffs for reword operation.

    Returns (full_cutoff, light_cutoff) — indices into a sorted opportunity list.
    Configurable via mkdocs.yml: extra.wire.reword_tiers: {full: 20, light: 30}
    """
    tiers = WIRE_CONFIG.get("reword_tiers", {})
    full_pct = tiers.get("full", 20)
    light_pct = tiers.get("light", 30)
    full_cutoff = max(1, total * full_pct // 100)
    light_cutoff = max(full_cutoff, total * (full_pct + light_pct) // 100)
    return full_cutoff, light_cutoff


# News gathering settings — topic-specific freshness intervals
# Configurable via mkdocs.yml: extra.wire.refresh_days: {vendors: 21, ...}
# Unknown topics fall back to REFRESH_NEWS_AFTER_DAYS (default: 21 days)
REFRESH_DAYS = WIRE_CONFIG.get("refresh_days", {})
REFRESH_NEWS_AFTER_DAYS = WIRE_CONFIG.get("default_refresh_days", 21)
MAX_ARTICLES = WIRE_CONFIG.get("max_articles", 20)
RATE_LIMIT_DELAY = WIRE_CONFIG.get("rate_limit_delay", 1)
MIN_OPPORTUNITY_SCORE = WIRE_CONFIG.get("min_opportunity_score", 15.0)
NEWSWEEK_BATCH_CHARS = WIRE_CONFIG.get("newsweek_batch_chars", 150000)
NEWSWEEK_MAX_NEWS_AGE_DAYS = WIRE_CONFIG.get("newsweek_max_news_age_days", 14)


def _get_exclude_prefixes() -> list:
    """Read exclude_gsc_data_for_path from wire.yml (top-level key)."""
    import yaml
    wire_yml = tools.SITE_DIR / "wire.yml"
    if not wire_yml.exists():
        return []
    try:
        config = yaml.safe_load(wire_yml.read_text(encoding="utf-8")) or {}
        return config.get("exclude_gsc_data_for_path", [])
    except Exception:
        return []


def _get_languages() -> list:
    """Read languages config from wire.yml. Returns [] for single-lang sites."""
    import yaml
    wire_yml = tools.SITE_DIR / "wire.yml"
    if not wire_yml.exists():
        return []
    try:
        config = yaml.safe_load(wire_yml.read_text(encoding="utf-8")) or {}
        return config.get("languages", [])
    except Exception:
        return []


# =============================================================================
# BATCH PROGRESS TRACKING — resume interrupted runs
# =============================================================================

def _progress_path(command: str, topic: str = "all") -> Path:
    """Path to progress file for a batch operation.

    Multi-language sites: .wire/{lang}/progress-*.json when _ACTIVE_LANG is set.
    """
    wire_dir = tools.SITE_DIR / ".wire"
    if tools._ACTIVE_LANG:
        wire_dir = wire_dir / tools._ACTIVE_LANG
    wire_dir.mkdir(parents=True, exist_ok=True)
    return wire_dir / f"progress-{command}-{topic}.json"


def _load_progress(command: str, topic: str = "all") -> set:
    """Load completed slugs from progress file. Returns empty set if none."""
    path = _progress_path(command, topic)
    if not path.exists():
        return set()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return set(data.get("completed", []))
    except (json.JSONDecodeError, KeyError) as e:
        logger.warning(f"Corrupted progress file {path}: {e} — starting fresh")
        return set()


def _save_progress(command: str, topic: str, completed_slugs: set) -> None:
    """Save completed slugs to progress file."""
    path = _progress_path(command, topic)
    data = {"command": command, "topic": topic,
            "completed": sorted(completed_slugs),
            "updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def _clear_progress(command: str, topic: str = "all") -> None:
    """Remove progress file when batch completes."""
    path = _progress_path(command, topic)
    path.unlink(missing_ok=True)


# =============================================================================
# CONCURRENT BATCH PROCESSING
# =============================================================================

def _run_batch(items, process_fn, *, command, topic, workers=1, completed=None):
    """Process items with optional concurrency.

    Args:
        items: Iterable of objects with a .slug attribute.
        process_fn: Callable(item) -> (message: str, success: bool).
            Encapsulates all per-item logic including logging.
        command: Progress file command key (e.g. "news").
        topic: Progress file topic key.
        workers: Number of concurrent workers (1 = sequential).
        completed: Set of already-completed slugs (for resume). Mutated in-place.

    Returns:
        The final completed set.
    """
    if completed is None:
        completed = set()

    total = len(items)
    if total == 0:
        return completed

    lock = threading.Lock()

    def _worker(idx, item):
        """Run process_fn, handle errors, update progress."""
        try:
            message, success = process_fn(item)
        except Exception as e:
            logger.error(f"  [{idx}/{total}] {item.slug}: exception — {e}")
            return item.slug, False

        if success:
            with lock:
                completed.add(item.slug)
                _save_progress(command, topic, completed)

        time.sleep(RATE_LIMIT_DELAY)
        return item.slug, success

    if workers <= 1:
        # Sequential — identical to old behavior
        for idx, item in enumerate(items, 1):
            if item.slug in completed:
                continue
            _worker(idx, item)
    else:
        # Concurrent
        pending = [(idx, item) for idx, item in enumerate(items, 1)
                   if item.slug not in completed]
        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {
                executor.submit(_worker, idx, item): item.slug
                for idx, item in pending
            }
            for future in as_completed(futures):
                slug = futures[future]
                try:
                    future.result()
                except Exception as e:
                    logger.error(f"  {slug}: unhandled worker error — {e}")

    return completed


# =============================================================================
# NEWSWEEK — weekly market intelligence report helpers
# =============================================================================

def _collect_news(from_date: str, to_date: str) -> list[dict]:
    """Collect news files across ALL topics for a date range.

    Walks tools.DOCS_DIR subdirs that have index.md (= valid Topics).
    For each item: news_files(archived=True), filter by date stem.
    Reads content, skips tracker files and tiny files (<200 chars).
    Returns: [{topic, slug, title, content, path}, ...]
    """

    results = []
    if not tools.DOCS_DIR.exists():
        return results

    topic_dirs = list_topics()

    for tname in topic_dirs:
        try:
            topic = Topic(tname)
        except Exception as e:
            logger.debug(f"Newsweek: skipping topic {tname}: {e}")
            continue
        for item in topic.list():
            for nf in item.news_files(archived=True):
                stem = nf.stem  # YYYY-MM-DD
                if stem < from_date or stem > to_date:
                    continue
                try:
                    post = fm.load(nf)
                except Exception as e:
                    logger.debug(f"Newsweek: could not read {nf}: {e}")
                    continue
                # Skip tracker entries
                if post.get("type") == "tracker":
                    continue
                content = post.content.strip()
                if len(content) < 200:
                    continue
                results.append({
                    "topic": tname,
                    "slug": item.slug,
                    "title": item.title,
                    "content": content,
                    "path": str(nf),
                })

    return results


def _check_newsweek_prerequisites(from_date: str, to_date: str) -> None:
    """Validate that news has been gathered recently enough for newsweek.

    Raises ValueError if the most recent news file across all topics is older
    than NEWSWEEK_MAX_NEWS_AGE_DAYS (default: 14 days).
    """
    most_recent = None
    topic_dirs = list_topics()

    for tname in topic_dirs:
        try:
            topic = Topic(tname)
        except Exception:
            continue
        for item in topic.list():
            for nf in item.news_files(archived=True):
                stem = nf.stem  # YYYY-MM-DD
                try:
                    datetime.strptime(stem, '%Y-%m-%d')
                except ValueError:
                    continue
                if most_recent is None or stem > most_recent:
                    most_recent = stem

    if most_recent is None:
        raise ValueError(
            "Newsweek refused: no news files found. "
            "Run: python -m wire.chief news <topic>"
        )

    cutoff = (datetime.now() - timedelta(days=NEWSWEEK_MAX_NEWS_AGE_DAYS)).strftime('%Y-%m-%d')
    if most_recent < cutoff:
        raise ValueError(
            f"Newsweek refused: no news gathered since {most_recent}. "
            "Run: python -m wire.chief news <topic>"
        )


def _batch_news(news_files: list[dict], max_chars: int = NEWSWEEK_BATCH_CHARS) -> list[list[dict]]:
    """Group by topic first, then chunk by size.

    Same-topic files stay together for better theme extraction.
    Returns: [[file_dict, ...], ...]
    """
    # Group by topic
    by_topic = defaultdict(list)
    for nf in news_files:
        by_topic[nf["topic"]].append(nf)

    batches = []
    current_batch = []
    current_size = 0

    for topic_files in by_topic.values():
        for nf in topic_files:
            file_size = len(nf["content"]) + len(nf["title"]) + 100  # header overhead
            if current_batch and current_size + file_size > max_chars:
                batches.append(current_batch)
                current_batch = []
                current_size = 0
            current_batch.append(nf)
            current_size += file_size

    if current_batch:
        batches.append(current_batch)

    return batches


def _detect_stale_dates(content: str, report_year: int, report_month: int) -> list[str]:
    """Detect date references in content that predate the report period.

    Returns list of stale date strings found (e.g., ["July 2025", "2024"]).
    """
    stale = []
    month_names = [m for m in calendar.month_name if m]  # Jan-Dec
    month_abbrs = [m for m in calendar.month_abbr if m]

    # Check "Month YYYY" patterns (e.g., "July 2025")
    for names in [month_names, month_abbrs]:
        for i, name in enumerate(names, 1):
            for year in range(report_year - 3, report_year + 1):
                pattern = f"{name} {year}"
                if pattern.lower() in content.lower():
                    if year < report_year or (year == report_year and i < report_month):
                        stale.append(pattern)

    # Check bare year references that are clearly old
    for year in range(report_year - 3, report_year - 1):
        if f" {year}" in content and f"({year}" not in content:
            stale.append(str(year))

    return list(dict.fromkeys(stale))[:5]  # max 5 unique matches


def _format_batch(batch: list[dict], from_date: str = "") -> str:
    """Format batch as markdown for extraction prompt.

    Annotates items with stale date warnings when old dates are detected.
    """
    report_year = int(from_date[:4]) if from_date else datetime.now().year
    report_month = int(from_date[5:7]) if from_date else datetime.now().month

    parts = []
    for nf in batch:
        stale = _detect_stale_dates(nf['content'], report_year, report_month)
        stale_note = ""
        if stale:
            stale_note = f"\n\n**⚠ STALE DATES DETECTED: {', '.join(stale)}** — rate ★ if events are from before the report period.\n"
        parts.append(f"### {nf['title']} ({nf['topic']}/{nf['slug']}){stale_note}\n\n{nf['content']}\n\n---")
    return "\n\n".join(parts)


def _format_trending(keywords: list[dict]) -> str:
    """Format trending keywords as markdown table."""
    lines = ["| Keyword | Impressions | Pages | Avg Position | Top Page |",
             "|---------|------------|-------|-------------|----------|"]
    for kw in keywords:
        lines.append(
            f"| {kw['keyword']} | {kw['impressions']:,} | {kw['page_count']} "
            f"| {kw['avg_position']:.1f} | {kw.get('top_page', '')} |"
        )
    return "\n".join(lines)


def _load_previous_newsweek() -> str:
    """Load most recent docs/news/*/index.md for tone reference.

    Sorts by parent directory name, returns content of latest.
    Returns empty string if no reports exist.
    """
    news_dir = tools.DOCS_DIR / "news"
    if not news_dir.exists():
        return ""
    reports = sorted(news_dir.glob("*-news/index.md"))
    if not reports:
        return ""
    try:
        return reports[-1].read_text(encoding="utf-8")
    except Exception as e:
        logger.warning(f"Could not read previous newsweek {reports[-1]}: {e}")
        return ""


class _NewsweekTopic:
    """Minimal Topic-like object for styleguide formatting in newsweek context."""
    title = "Market Intelligence"
    description = "Cross-topic market analysis and weekly reports"
    directory = "news"

    def __str__(self):
        return self.directory


def _load_styleguide() -> str:
    """Load and pre-format styleguide for newsweek context.

    Base layer (_style.md) ALWAYS loads. Customer _styleguide.md expands it.
    The styleguide template uses {site.title}, {topic.title}, etc.
    We format with SITE and a generic newsweek Topic.
    """
    builtin_path = FALLBACK_PROMPTS_DIR / "_style.md"
    styleguide_path = tools.DOCS_DIR / "_styleguide.md"

    parts = []
    # Base layer — Wire's universal quality rules
    if builtin_path.exists():
        parts.append(builtin_path.read_text(encoding="utf-8"))
    # Customer layer — brand voice, expands base
    if styleguide_path.exists():
        parts.append(styleguide_path.read_text(encoding="utf-8"))

    if not parts:
        return ""
    text = "\n\n".join(parts)
    # Build language instruction for newsweek context
    language = tools.TOPIC_LANGUAGES.get("news", "") or tools.SITE_LANGUAGE
    if language:
        language_instruction = (
            f"\n**Language: {language}** — Write ALL output (title, description, "
            f"headings, body) in {language}. Match the language and cultural tone "
            f"of the existing page content."
        )
    else:
        language_instruction = ""
    try:
        return text.format(site=SITE, topic=_NewsweekTopic(),
                           language=language, language_instruction=language_instruction)
    except (KeyError, AttributeError, IndexError):
        return text


def _load_newsweek_prompt(action: str, **variables) -> str:
    """Load newsweek prompt from prompts/{action}.md and format.

    No Topic auto-injection. site and language are auto-injected.
    """
    prompt_path = FALLBACK_PROMPTS_DIR / f"{action}.md"
    if not prompt_path.exists():
        raise FileNotFoundError(f"Missing prompt: {prompt_path}")
    template = prompt_path.read_text(encoding="utf-8")
    variables.setdefault("site", SITE)
    # Auto-inject language for newsweek prompts
    language = tools.TOPIC_LANGUAGES.get("news", "") or tools.SITE_LANGUAGE
    variables.setdefault("language", language)
    if language and "language_instruction" not in variables:
        variables["language_instruction"] = (
            f"\n**Language: {language}** — Write ALL output (title, description, "
            f"headings, body) in {language}. Match the language and cultural tone "
            f"of the existing page content."
        )
    else:
        variables.setdefault("language_instruction", "")
    return template.format(**variables)


def _extracts_cache_path(to_date: str) -> Path:
    """Path for cached Phase 1 extracts."""
    wire_dir = tools.DOCS_DIR.parent / ".wire"
    wire_dir.mkdir(parents=True, exist_ok=True)
    return wire_dir / f"newsweek_extracts_{to_date}.md"


def _save_extracts(extracts: list[str], to_date: str) -> Path:
    """Cache Phase 1 extracts for re-synthesis."""
    path = _extracts_cache_path(to_date)
    path.write_text("\n\n---BATCH_SEPARATOR---\n\n".join(extracts), encoding="utf-8")
    return path


def _load_cached_extracts(to_date: str) -> list[str] | None:
    """Load cached Phase 1 extracts if available."""
    path = _extracts_cache_path(to_date)
    if not path.exists():
        return None
    text = path.read_text(encoding="utf-8")
    return text.split("\n\n---BATCH_SEPARATOR---\n\n")


def _strip_gsc_sections(content: str) -> str:
    """Remove any sections that expose internal GSC/search data.

    Safety net: even if prompts fail to suppress search data sections,
    this ensures raw impressions/keywords never reach the published report.
    """
    # Match markdown sections (## or ###) containing search data keywords
    # Pattern: header line with search data terms -> everything until next same-level header or end
    patterns = [
        r'#{2,3}\s+.*?(?:search\s+data|market\s+priorities|trending\s+keywords?|impression).*?\n'
        r'(?:(?!#{2,3}\s).|\n)*',
    ]
    cleaned = content
    for pattern in patterns:
        cleaned = re.sub(pattern, '', cleaned, flags=re.IGNORECASE)
    # Remove orphaned double blank lines from removed sections
    cleaned = re.sub(r'\n{3,}', '\n\n', cleaned)
    return cleaned


def _filter_extracts(extracts: list[str]) -> list[str]:
    """Filter Phase 1 extracts to keep only ★★★+ structured entries.

    Phase 1 output contains:
    1. Preamble/analysis text ("Looking at this batch...", "CRITICAL: Recency Check")
    2. Detailed ★★★+ entries with FACTS, THEME, QUOTES, SIGNAL lines
    3. One-liner ★/★★ entries

    Phase 2 should only receive (2). All preamble and low-rated entries are removed
    to prevent Claude from mimicking Phase 1 analysis behavior.

    Returns filtered extracts with only ★★★+ entries.
    """
    filtered = []
    for batch in extracts:
        lines = batch.split('\n')
        result_lines = []
        in_good_entry = False  # Start outside any entry — preamble is dropped

        for line in lines:
            # Check if this line starts a new entry (e.g., **VENDOR** (topic) ★★★★)
            entry_match = re.match(r'\*\*[^*]+\*\*\s*\([^)]*\)\s*(★+)', line)
            if entry_match:
                stars = len(entry_match.group(1))
                in_good_entry = stars >= 3
                if in_good_entry:
                    result_lines.append(line)
            elif in_good_entry:
                result_lines.append(line)

        filtered_batch = '\n'.join(result_lines).strip()
        if filtered_batch:
            filtered.append(filtered_batch)

    return filtered


def _save_newsweek(content: str, to_date: str) -> Path:
    """Save to docs/news/YYYY-MM-DD-news/index.md with frontmatter.

    Creates news/{slug}/ dir if needed. Strips any leaked GSC sections.
    If Claude's output is missing frontmatter, constructs it automatically.
    Returns output Path.
    """

    content = _strip_gsc_sections(content)

    report_dir = tools.DOCS_DIR / "news" / f"{to_date}-news"
    report_dir.mkdir(parents=True, exist_ok=True)
    output_path = report_dir / "index.md"

    try:
        post = validate_frontmatter(content)
    except ValueError:
        # Claude didn't include frontmatter — construct it from content
        title_match = re.search(r'^#\s+(.+)', content, re.MULTILINE)
        title = title_match.group(1).strip() if title_match else f"Market Intelligence: {to_date}"
        post = fm.Post(content, **{"title": title, "date": to_date, "draft": False})
        logger.info(f"Newsweek: added missing frontmatter (title: {title})")

    fm.dump(post, output_path)

    return output_path


def _audit_content_quality(report_topics: list[str] | None = None) -> dict:
    """Scan ALL pages for site-wide content quality issues.

    Always scans the full site (all topics) so orphan/broken-link detection
    sees cross-topic links. The report_topics filter controls which pages
    appear in the output — None means report everything.

    Returns dict with keys:
        duplicate_titles: [{title, pages}]
        duplicate_descriptions: [{description, pages}]
        orphan_pages: [path, ...]
        broken_links: [{source, target, target_topic, target_slug}]
        slug_fixes: [{target, suggestion}]
        source_concentration: [(slug, worst_domain, pct)]
        long_titles: [(slug, title, len)]
        long_descriptions: [(slug, len)]
        no_citations: [slug, ...]
        underlinked_pages: [(slug, inbound_count)]
        h1_issues: [(slug, issue_type)]  — issue_type: "missing", "multiple", "mismatch"
        thin_pages: [(slug, word_count)]
        heading_issues: [(slug, issue_type)]  — issue_type: "numbered", "skipped_level"
        pages_scanned: int
    """
    result = {
        "duplicate_titles": [],
        "duplicate_descriptions": [],
        "orphan_pages": [],
        "broken_links": [],
        "slug_fixes": [],
        "source_concentration": [],
        "pages_scanned": 0,
    }
    all_topics = list_topics()
    report_filter = set(report_topics) if report_topics else None

    # Collect all pages across the full site
    pages = {}  # path → metadata dict (content items — checked for quality)
    all_link_targets = {}  # internal link URL → [source pages] (for orphan detection)

    for tname in all_topics:
        try:
            topic_obj = Topic(tname)
        except (FileNotFoundError, ValueError):
            continue

        # Scan topic-level index.md for links (not a content item, but links count)
        topic_index = tools.DOCS_DIR / tname / "index.md"
        if topic_index.exists():
            try:
                topic_post = fm.load(topic_index)
                topic_body = topic_post.content or ""
                for link_url in re.findall(r'\[[^\]]+\]\((/[^)]+)\)', topic_body):
                    norm = link_url.rstrip("/") + "/"
                    all_link_targets.setdefault(norm, []).append(f"/{tname}/")
            except Exception:
                pass

        for item in topic_obj.list():
            if not item.index_path.exists():
                continue
            try:
                post = fm.load(item.index_path)
            except Exception:
                continue
            title = post.get("title", "")
            desc = post.get("description", "")
            body = post.content or ""

            internal_links = re.findall(r'\[[^\]]+\]\((/[^)]+)\)', body)
            pages[item.path] = {
                "title": title,
                "description": desc,
                "links_out": internal_links,
                "body": body,
                "topic": tname,
                "slug": item.slug,
            }
            for link_url in internal_links:
                norm = link_url.rstrip("/") + "/"
                all_link_targets.setdefault(norm, []).append(item.path)

    if not pages:
        return result

    result["pages_scanned"] = len(pages)

    def _in_scope(path):
        """Check if a page path belongs to the report filter."""
        if report_filter is None:
            return True
        topic = path.strip("/").split("/")[0]
        return topic in report_filter

    # 1. Duplicate titles (report both if either is in scope)
    title_groups = {}
    for path, meta in pages.items():
        t = meta["title"].strip().lower()
        if t:
            title_groups.setdefault(t, []).append(path)
    for title_lower, paths in title_groups.items():
        if len(paths) > 1 and any(_in_scope(p) for p in paths):
            result["duplicate_titles"].append({
                "title": pages[paths[0]]["title"],
                "pages": paths,
            })

    # 2. Duplicate descriptions
    desc_groups = {}
    for path, meta in pages.items():
        d = meta["description"].strip().lower()
        if d and len(d) > 20:
            desc_groups.setdefault(d, []).append(path)
    for desc_lower, paths in desc_groups.items():
        if len(paths) > 1 and any(_in_scope(p) for p in paths):
            result["duplicate_descriptions"].append({
                "description": pages[paths[0]]["description"],
                "pages": paths,
            })

    # 3. Orphan pages — check against ALL links site-wide, report only in-scope
    all_page_paths = set()
    for path in pages:
        all_page_paths.add(path.rstrip("/") + "/")

    linked_pages = set(all_link_targets.keys())
    orphans = all_page_paths - linked_pages
    for orphan in sorted(orphans):
        if _in_scope(orphan):
            result["orphan_pages"].append(orphan)

    # 4. Broken internal links — deduplicate per source page
    # Build per-topic slug sets for slug fix suggestions
    slugs_by_topic = {}
    for path in pages:
        parts = path.strip("/").split("/")
        if len(parts) >= 2:
            slugs_by_topic.setdefault(parts[0], set()).add(parts[1])

    seen_broken = set()
    seen_slug_fixes = set()
    for path, meta in pages.items():
        if not _in_scope(path):
            continue
        for link_url in meta["links_out"]:
            norm = link_url.rstrip("/") + "/"
            pair = (path, norm)
            if pair in seen_broken:
                continue
            seen_broken.add(pair)
            target_path = tools.DOCS_DIR / norm.strip("/")
            target_index = target_path / "index.md"
            if norm not in all_page_paths and not target_index.exists():
                parts = norm.strip("/").split("/")
                target_topic = parts[0] if len(parts) >= 2 else ""
                target_slug = parts[1] if len(parts) >= 2 else norm.strip("/")
                result["broken_links"].append({
                    "source": path,
                    "target": link_url,
                    "target_topic": target_topic,
                    "target_slug": target_slug,
                })
                # Check for slug fix suggestion
                if target_topic and target_slug and target_slug not in seen_slug_fixes:
                    fix = _find_slug_fix(target_slug, slugs_by_topic.get(target_topic, set()))
                    if fix:
                        seen_slug_fixes.add(target_slug)
                        result["slug_fixes"].append({
                            "target": f"/{target_topic}/{target_slug}/",
                            "suggestion": f"/{target_topic}/{fix}/",
                        })

    # 5. Source concentration — external links dominated by single domains
    for path, meta in pages.items():
        if not _in_scope(path):
            continue
        diversity = analyze_source_diversity(meta.get("body", ""))
        for c in diversity["concentrated"]:
            result["source_concentration"].append({
                "path": path,
                "slug": meta["slug"],
                "topic": meta["topic"],
                "domain": c["domain"],
                "count": c["count"],
                "total": diversity["total_external"],
                "pct": c["pct"],
            })

    # 6. Underlinked pages — fewer than 3 inbound internal links
    inbound_counts = {}
    for path in pages:
        norm = path.rstrip("/") + "/"
        sources = all_link_targets.get(norm, [])
        inbound_counts[norm] = len(sources)

    result["underlinked_pages"] = []
    for path, count in sorted(inbound_counts.items(), key=lambda x: x[1]):
        if count < 3 and _in_scope(path):
            parts = path.strip("/").split("/")
            result["underlinked_pages"].append({
                "path": path,
                "slug": parts[1] if len(parts) >= 2 else path.strip("/"),
                "topic": parts[0] if len(parts) >= 2 else "",
                "inbound_count": count,
            })

    # 7. Title/description length + missing citations
    result["long_titles"] = []
    result["long_descriptions"] = []
    result["no_citations"] = []
    # 8. H1 validation
    result["h1_issues"] = []
    # 9. Thin content
    result["thin_pages"] = []
    # 10. Heading hierarchy issues
    result["heading_issues"] = []

    for page_path in pages:
        full = tools.DOCS_DIR / page_path.strip("/") / "index.md"
        if not full.exists():
            continue
        try:
            post = fm.load(str(full))
            title = post.get("title", "")
            desc = post.get("description", "")
            body = post.content
            parts = page_path.strip("/").split("/")
            info = {
                "path": page_path,
                "slug": parts[1] if len(parts) >= 2 else page_path.strip("/"),
                "topic": parts[0] if len(parts) >= 2 else "",
            }
            if len(title) > 60:
                result["long_titles"].append({**info, "length": len(title)})
            if desc and len(desc) > 160:
                result["long_descriptions"].append({**info, "length": len(desc)})
            if body and not re.search(r'\[[^\]]+\]\(https?://[^)]+\)', body):
                result["no_citations"].append(info)

            # Strip code blocks before heading analysis (avoid false positives)
            if body and _in_scope(page_path):
                clean_body = re.sub(r'```[\s\S]*?```', '', body)

                # H1 validation — markdown should have exactly one H1 matching title.
                # Template strips it at build time, but the source must be complete.
                # Missing H1 also catches broken template overrides.
                h1_lines = re.findall(r'^# (.+)$', clean_body, re.MULTILINE)
                if not h1_lines:
                    result["h1_issues"].append((info["slug"], "missing"))
                elif len(h1_lines) > 1:
                    result["h1_issues"].append((info["slug"], "multiple"))
                elif title and h1_lines[0].strip() != title.strip():
                    result["h1_issues"].append((info["slug"], "mismatch"))

                # Thin content (<200 words)
                word_count = len(body.split())
                if word_count < 200:
                    result["thin_pages"].append((info["slug"], word_count))

                # Heading hierarchy issues
                # Numbered headings (## 1. Something, ### 3) Topic)
                if re.search(r'^#{1,6}\s+\d+[\.\)]\s', clean_body, re.MULTILINE):
                    result["heading_issues"].append((info["slug"], "numbered"))
                # Skipped heading levels (H1 → H3 without H2, H2 → H4 without H3, etc.)
                heading_levels = [len(m) for m in re.findall(r'^(#{1,6})\s', clean_body, re.MULTILINE)]
                for i in range(1, len(heading_levels)):
                    if heading_levels[i] > heading_levels[i - 1] + 1:
                        result["heading_issues"].append((info["slug"], "skipped_level"))
                        break
        except Exception:
            pass

    return result


def _categorize_broken_links(broken_links: list[dict]) -> dict[str, list]:
    """Group broken links by target_topic, aggregate by target_slug.

    Returns dict: {topic: [{slug, count, sources}]} sorted by count desc.
    """
    by_topic = {}
    for bl in broken_links:
        topic = bl["target_topic"]
        slug = bl["target_slug"]
        by_topic.setdefault(topic, {})
        by_topic[topic].setdefault(slug, {"slug": slug, "count": 0, "sources": []})
        by_topic[topic][slug]["count"] += 1
        if bl["source"] not in by_topic[topic][slug]["sources"]:
            by_topic[topic][slug]["sources"].append(bl["source"])

    result = {}
    for topic, slugs in sorted(by_topic.items()):
        result[topic] = sorted(slugs.values(), key=lambda x: -x["count"])
    return result


class Chief:
    """
    Orchestrates news gathering and content refinement for a Topic.

    Usage:
        chief = Chief()
        chief.gather_news("vendors")      # News cycle
        chief.refine_content("vendors")   # Content cycle
    """

    def __init__(self, nogsc: bool = False, workers: int = 1):
        self.reporter = NewsReporter()
        self.editor = ContentEditor(nogsc=nogsc)
        self.nogsc = nogsc
        self.workers = max(1, workers)

    def _overlap_slugs(self, topic_name, min_shared=3, min_impressions=100):
        """Slugs that have actionable overlaps (need merge or differentiate)."""
        merge_slugs, diff_slugs = set(), set()
        overlaps = find_overlaps(topic_name, min_shared=min_shared)
        for ov in overlaps:
            if ov["total_shared_impressions"] < min_impressions:
                continue
            action = _classify_overlap(ov)
            if action == "merge":
                merge_slugs.update([ov["slug_a"], ov["slug_b"]])
            elif action == "differentiate":
                diff_slugs.update([ov["slug_a"], ov["slug_b"]])
        return merge_slugs, diff_slugs

    def gather_news(self, topic_name: str, resume: bool = False) -> None:
        """Gather news for all items in a Topic that need it."""
        _check_git_clean()
        _check_styleguide()
        _validate_topic(topic_name)
        topic = Topic(topic_name)
        refresh_days = REFRESH_DAYS.get(topic_name, REFRESH_NEWS_AFTER_DAYS)
        if refresh_days == 0:
            logger.info(f"Gathering news for {topic_name}: news disabled (refresh_days=0)")
            return
        items = topic.needing_news(days=refresh_days)
        items, skipped = _filter_editable(items)
        if skipped:
            logger.info(f"Gathering news for {topic_name}: skipped {skipped} non-article pages (landing/raw/home)")

        if not items:
            logger.info(f"Gathering news for {topic_name}: no items due")
            return

        # Resume support: skip already-completed items
        completed = _load_progress("news", topic_name) if resume else set()
        if completed:
            before = len(items)
            items = [it for it in items if it.slug not in completed]
            logger.info(f"Gathering news for {topic_name}: resuming ({before - len(items)} done, {len(items)} remaining)")
        else:
            logger.info(f"Gathering news for {topic_name}: {len(items)} items due")

        to_date = datetime.now()
        from_date = to_date - timedelta(days=NEWS_API_MAX_DAYS_BACK)
        reporter = self.reporter
        editor = self.editor

        def process(item):
            # Analyze source diversity before searching
            try:
                body = item.read_index()
                diversity = analyze_source_diversity(body)
                source_gaps = format_source_diversity(diversity)
            except Exception:
                source_gaps = ""
            result = reporter.cover_item(item, from_date, to_date, MAX_ARTICLES,
                                         source_gaps=source_gaps)
            logger.info(f"  {item.slug} -> {result}")
            if result != "no news":
                refine_result = editor.refine(item)
                logger.info(f"  {item.slug} -> {refine_result}")
                if refine_result.startswith("failed"):
                    return refine_result, False
            return result, True

        _run_batch(items, process, command="news", topic=topic_name,
                   workers=self.workers, completed=completed)

        _clear_progress("news", topic_name)
        logger.info(f"Done: gathered news for {len(items)} {topic_name}")

    def refine_content(self, topic_name: str, resume: bool = False) -> None:
        """Refine all items in a Topic (editor skips items without pending news)."""
        _check_git_clean()
        _check_styleguide()
        _validate_topic(topic_name)
        topic = Topic(topic_name)
        items = topic.list()
        items, skipped = _filter_editable(items)
        if skipped:
            logger.info(f"Refining {topic_name}: skipped {skipped} non-article pages (landing/raw/home)")

        if not items:
            logger.info(f"Refining {topic_name}: no items found")
            return

        # Gate: skip pages that need differentiation first (requires GSC DB)
        if getattr(self, 'nogsc', False):
            diff_slugs = set()
        else:
            try:
                _, diff_slugs = self._overlap_slugs(topic_name)
            except Exception as e:
                logger.warning(f"Overlap check failed for {topic_name}: {e} — cannot enforce gates")
                raise

        # Resume support
        completed = _load_progress("refine", topic_name) if resume else set()
        if completed:
            logger.info(f"Refining {topic_name}: resuming ({len(completed)} done)")
        else:
            logger.info(f"Refining {topic_name}: {len(items)} items")

        editor = self.editor

        def process(item):
            if item.slug in diff_slugs:
                logger.info(f"  {item.slug}: has overlaps -> differentiate first, skipping")
                return "skipped (overlaps)", False
            result = editor.refine(item)
            logger.info(f"  {item.slug} -> {result}")
            return result, not result.startswith("failed")

        _run_batch(items, process, command="refine", topic=topic_name,
                   workers=self.workers, completed=completed)

        _clear_progress("refine", topic_name)
        logger.info(f"Done: refined {topic_name}")

    def _scan_opportunities(self, topic_name: str, min_score: float = MIN_OPPORTUNITY_SCORE,
                            top_n: int = 5, verbose: bool = True) -> list[dict]:
        """Scan all items in a topic via GSC and return ranked expansion opportunities.

        Each opportunity dict has: item, queries (top N), total_score, count.

        Scoring logic:
        - Position 4-30: top 3 is good enough, 30+ is unreachable via content alone
        - Score = impressions * (1 - CTR): high demand + low clickthrough = biggest opportunity
        """
        topic = Topic(topic_name)
        items = topic.list()
        items, skipped = _filter_editable(items)
        if skipped and verbose:
            logger.info(f"Reword {topic_name}: skipped {skipped} non-article pages (landing/raw/home)")

        if not items:
            if verbose:
                logger.info(f"Opportunities for {topic_name}: no items found")
            return []

        if verbose:
            logger.info(f"Scanning {len(items)} {topic_name} for GSC opportunities...")

        all_opportunities = []

        for i, item in enumerate(items, 1):
            try:
                data = get_search_terms(item.slug, item.title, item.topic)
            except Exception as e:
                if verbose:
                    logger.warning(f"  [{i}/{len(items)}] {item.topic}/{item.slug} — GSC failed: {e}")
                continue

            if not data:
                if verbose:
                    logger.info(f"  [{i}/{len(items)}] {item.topic}/{item.slug} — no GSC data")
                continue

            # Filter: position 4-30 (top 3 = already good, 30+ = unreachable via content)
            candidates = [
                q for q in data["page_queries"]
                if 3 < q["position"] <= 30 and q["score"] >= min_score
            ]
            candidates.sort(key=lambda q: q["score"], reverse=True)

            if candidates:
                best = candidates[:top_n]
                total_score = sum(q["score"] for q in candidates)
                all_opportunities.append({
                    "item": item,
                    "queries": best,
                    "total_score": total_score,
                    "count": len(candidates),
                    "gsc_data": data,
                })
                if verbose:
                    top_kw = ", ".join(q["query"] for q in best)
                    logger.info(f"  [{i}/{len(items)}] {item.topic}/{item.slug} — {len(candidates)} opportunities: {top_kw}")
            else:
                if verbose:
                    logger.info(f"  [{i}/{len(items)}] {item.topic}/{item.slug} — no opportunities above {min_score}")

        # Rank pages by total opportunity score (highest first)
        all_opportunities.sort(key=lambda x: x["total_score"], reverse=True)
        return all_opportunities

    def _check_db(self, topic_name: str) -> bool:
        """Check that GSC data exists in the database. Returns True if OK."""
        try:
            init_db()
            summary = db_summary(topic_name)
            if summary["pages_with_data"] == 0:
                logger.info(f"No GSC data in database for {topic_name}.")
                logger.info(f"Run first:  python -m wire.chief data")
                return False
        except Exception as e:
            logger.info(f"No GSC database found: {e}")
            logger.info(f"Run first:  python -m wire.chief data")
            return False
        return True

    def audit(self, topic_name: str = None, min_shared: int = 3,
              min_impressions: int = 100) -> None:
        """Workflow preview — read-only analysis of what each command will work on.

        Output structured as: HEALTH → ACTION → SEO → INFO.
        Does not modify any files.
        """
        if topic_name:
            _validate_topic(topic_name)

        init_db()
        scope = topic_name or "all topics"
        dot = " | "

        # Discover topics
        if topic_name:
            topics = [topic_name]
        else:
            topics = list_topics()

        logger.info(f"*** AUDIT: {scope} ***")

        # ── Collect all data ──

        # DATA
        summary = None
        try:
            summary = db_summary(topic_name)
        except Exception:
            pass

        # REDIRECTS (for redirect-aware dead page detection)
        all_redirects = load_redirects()

        # DEAD PAGES
        median_imp = site_median_impressions(topic_name)
        dead_threshold = int(median_imp * 0.10)
        dead = find_dead_pages(topic_name, max_impressions=dead_threshold,
                               redirects=all_redirects)

        # MISSING REDIRECTS — use GscUrl table (same logic as redirects command)
        page_paths = set()
        # Include root-level pages (homepage, legal pages, etc.)
        if (tools.DOCS_DIR / "index.md").exists():
            page_paths.add("/")
        for md_file in tools.DOCS_DIR.glob("*.md"):
            if md_file.name.startswith("_") or md_file.name == "index.md":
                continue
            page_paths.add(f"/{md_file.stem}/")
        for tname in topics:
            page_paths.add(f"/{tname}/")
            try:
                topic_obj = Topic(tname)
                for item in topic_obj.list():
                    page_paths.add(item.path.rstrip("/") + "/")
            except Exception:
                pass
        exclude_prefixes = _get_exclude_prefixes()
        missing_redirects = find_gsc_coverage_gaps(
            page_paths, all_redirects,
            exclude_prefixes=exclude_prefixes or None)

        # OVERLAPS
        overlaps = find_overlaps(topic_name, min_shared=min_shared)
        overlaps = [ov for ov in overlaps
                    if ov["total_shared_impressions"] >= min_impressions]

        hard, soft = [], []
        for ov in overlaps:
            action = _classify_overlap(ov)
            if action == "merge":
                hard.append(ov)
            elif action == "differentiate":
                soft.append(ov)

        # Blocked slugs cascade
        merge_slugs = set()
        diff_slugs = set()
        for ov in hard:
            merge_slugs.update([ov["slug_a"], ov["slug_b"]])
        for ov in soft:
            diff_slugs.update([ov["slug_a"], ov["slug_b"]])
        dedup_blocked = merge_slugs | diff_slugs

        # NEWS
        news_counts = {}
        news_blocked = 0
        for tname in topics:
            try:
                refresh_days = REFRESH_DAYS.get(tname, REFRESH_NEWS_AFTER_DAYS)
                if refresh_days == 0:
                    continue
                topic_obj = Topic(tname)
                needing = topic_obj.needing_news(days=refresh_days)
                actionable = [it for it in needing if it.slug not in merge_slugs]
                blocked_here = len(needing) - len(actionable)
                news_blocked += blocked_here
                if actionable:
                    news_counts[tname] = len(actionable)
            except Exception as e:
                logger.warning(f"NEWS: failed to scan topic {tname}: {e}")

        # REFINE
        all_refine_items = []
        tracker_count = 0
        for tname in topics:
            try:
                topic_obj = Topic(tname)
                for item in topic_obj.list():
                    news = item.news_files()
                    if news:
                        all_refine_items.append(item)
                        all_trackers = all(
                            fm.load(f).get('type') == 'tracker' for f in news
                        )
                        if all_trackers:
                            tracker_count += 1
            except Exception as e:
                logger.warning(f"REFINE: failed to scan topic {tname}: {e}")

        refine_items = [it for it in all_refine_items if it.slug not in dedup_blocked]
        refine_blocked = len(all_refine_items) - len(refine_items)
        refine_slugs = {item.slug for item in all_refine_items}

        # CONTENT QUALITY
        quality = _audit_content_quality([topic_name] if topic_name else None)

        # CONTENT GAPS
        gaps = find_content_gaps(topic_name)

        # ARCHIVED
        if topic_name:
            search_dir = tools.DOCS_DIR / topic_name
        else:
            search_dir = tools.DOCS_DIR
        archived = sorted(search_dir.glob("**/index.md.archived")) if search_dir.exists() else []

        # STALENESS — content age vs refresh_days threshold
        stale_pages = []
        on_schedule = 0
        today = date.today()
        for tname in topics:
            threshold = REFRESH_DAYS.get(tname, REFRESH_NEWS_AFTER_DAYS)
            if threshold == 0:
                continue
            try:
                topic_obj = Topic(tname)
                for item in topic_obj.list():
                    page_date_str = item.get_stamp("date")
                    if not page_date_str:
                        continue
                    try:
                        page_date = date.fromisoformat(page_date_str[:10])
                    except (ValueError, TypeError):
                        continue
                    age_days = (today - page_date).days
                    if age_days > threshold:
                        stale_pages.append({
                            "topic": tname,
                            "slug": item.slug,
                            "last_updated": page_date_str[:10],
                            "age_days": age_days,
                            "threshold": threshold,
                        })
                    else:
                        on_schedule += 1
            except Exception:
                pass

        # ═══════════════════════════════════════════════════════════════
        # SITE — big picture overview
        # ═══════════════════════════════════════════════════════════════
        logger.info("")
        logger.info("-- SITE --")
        # Count pages
        if topic_name:
            page_dir = tools.DOCS_DIR / topic_name
        else:
            page_dir = tools.DOCS_DIR
        page_count = len(list(page_dir.glob("**/index.md"))) if page_dir.exists() else 0
        page_label = f"{page_count} page{'s' if page_count != 1 else ''}"

        site_languages = _get_languages()
        gsc_urls = get_gsc_urls()

        # Filter GscUrl data by active language when --lang is set
        active_lang = tools._ACTIVE_LANG
        if gsc_urls and active_lang:
            from urllib.parse import urlparse as _urlparse
            gsc_urls = [
                u for u in gsc_urls
                if _urlparse(u["url"]).path.startswith(f"/{active_lang}/")
            ]

        # Apply exclude_gsc_data_for_path filter
        exclude_prefixes = _get_exclude_prefixes()
        if gsc_urls and exclude_prefixes:
            from urllib.parse import urlparse as _urlparse
            gsc_urls = [
                u for u in gsc_urls
                if not any(
                    _urlparse(u["url"]).path.startswith(prefix)
                    for prefix in exclude_prefixes
                )
            ]

        total_imp = sum(u.get("impressions", 0) for u in gsc_urls) if gsc_urls else 0
        total_clicks = sum(u.get("clicks", 0) for u in gsc_urls) if gsc_urls else 0

        parts = [page_label]
        if site_languages:
            parts.append(f"{len(site_languages)} languages")
        if summary and summary.get("total_keywords", 0) > 0:
            parts.append(f"{summary['total_keywords']:,} keywords")
        if total_imp > 0:
            parts.append(f"{total_imp:,} imp")
        if total_clicks > 0:
            parts.append(f"{total_clicks:,} clicks")
        logger.info(dot.join(parts))
        if summary and summary.get("latest_date"):
            logger.info(f"Latest data: {summary['latest_date']}")

        # ═══════════════════════════════════════════════════════════════
        # HEALTH — pass/fail indicators for each check
        # ═══════════════════════════════════════════════════════════════
        logger.info("")
        logger.info("-- HEALTH --")

        # Data status
        if summary and summary["pages_with_data"] > 0:
            parts = [f"{summary['pages_with_data']} pages tracked",
                     f"{summary['total_keywords']:,} keywords",
                     f"(latest: {summary['latest_date'] or 'none'})"]
            logger.info(f"+ {dot.join(parts)}")
        elif summary and summary.get("pages_without_data", 0) > 0:
            n = summary["pages_without_data"]
            logger.info(
                f"- {n} pages in GSC database but none have search data "
                f"— not indexed by Google yet")
        else:
            logger.info("- No GSC data (run: python -m wire.chief data)")

        # Excluded traffic warning — show what exclude_gsc_data_for_path hides
        exclude_prefixes = _get_exclude_prefixes()
        if exclude_prefixes:
            from wire.build import summarize_excluded_traffic
            excluded = summarize_excluded_traffic(exclude_prefixes)
            if excluded:
                total_imp = sum(e["impressions"] for e in excluded)
                total_clicks = sum(e["clicks"] for e in excluded)
                logger.warning(
                    f"! Excluded traffic (exclude_gsc_data_for_path): "
                    f"{total_imp:,} impressions, {total_clicks:,} clicks hidden")
                for e in excluded:
                    logger.warning(
                        f"  {e['prefix']}: {e['impressions']:,} imp, "
                        f"{e['clicks']:,} clicks")

        # Dead pages
        if not dead:
            if median_imp > 0:
                logger.info(f"+ No dead pages (median: {median_imp:.0f} imp, threshold: <={dead_threshold})")
            else:
                logger.info("+ No dead pages")
        else:
            logger.info(f"- {len(dead)} dead page(s) (<={dead_threshold} imp, median: {median_imp:.0f})")

        # Redirect health — chains and dead ends
        if all_redirects:
            sources = {r["from"] for r in all_redirects}
            targets = {r["to"] for r in all_redirects if r.get("to")}
            # Detect chains: A->B where B is also a redirect source
            chains = []
            for r in all_redirects:
                dst = r.get("to", "")
                if dst and dst in sources:
                    chains.append(f"{r['from']} -> {dst}")
            # Detect dead ends: target doesn't exist as a page
            # Build set of known page paths
            all_page_paths = set()
            if tools.DOCS_DIR.exists():
                for md in tools.DOCS_DIR.glob("**/index.md"):
                    rel = md.relative_to(tools.DOCS_DIR)
                    parts = rel.parts[:-1]  # strip index.md
                    if parts:
                        all_page_paths.add("/" + "/".join(parts) + "/")
                    else:
                        all_page_paths.add("/")
            dead_ends = []
            for r in all_redirects:
                dst = r.get("to", "")
                status = r.get("status", 301)
                if status == 410 or not dst:
                    continue  # 410 is intentional, no target
                # Normalize
                clean_dst = dst.rstrip("/") + "/" if dst and not dst.endswith("/") else dst
                if clean_dst not in all_page_paths and clean_dst not in sources:
                    dead_ends.append(f"{r['from']} -> {dst}")

            if chains:
                logger.info(
                    f"- {len(chains)} redirect chain(s) "
                    f"(multi-hop slows page loads)")
                for c in chains[:5]:
                    logger.info(f"    {c}")
            if dead_ends:
                logger.info(
                    f"- {len(dead_ends)} dead-end redirect(s) "
                    f"(target does not exist)")
                for d in dead_ends[:5]:
                    logger.info(f"    {d}")
            if not chains and not dead_ends:
                logger.info(
                    f"+ Redirects healthy ({len(all_redirects)} configured)")
        elif not all_redirects:
            logger.info("+ No redirects configured")

        # Missing redirects
        if missing_redirects:
            total_imp = sum(m["impressions"] for m in missing_redirects)
            logger.info(
                f"- {len(missing_redirects)} missing redirect(s) "
                f"({total_imp:,} total impressions at risk)")
        else:
            logger.info("+ No missing redirects")

        # Keyword cannibalization
        if not hard and not soft:
            logger.info("+ No keyword cannibalization")
        else:
            parts = []
            if hard:
                parts.append(f"{len(hard)} merge")
            if soft:
                parts.append(f"{len(soft)} differentiate")
            logger.info(f"- Keyword cannibalization: {', '.join(parts)}")

        # Duplicate titles
        if not quality["duplicate_titles"]:
            logger.info("+ No duplicate titles")
        else:
            logger.info(f"- {len(quality['duplicate_titles'])} duplicate title(s)")

        # Duplicate descriptions
        if not quality["duplicate_descriptions"]:
            logger.info("+ No duplicate descriptions")
        else:
            logger.info(f"- {len(quality['duplicate_descriptions'])} duplicate description(s)")

        # News status
        if not news_counts:
            logger.info("+ News up to date")
        else:
            total_news = sum(news_counts.values())
            logger.info(f"- {total_news} page(s) need news update")

        # Refine status
        if not refine_items and not refine_blocked:
            logger.info("+ No pending refinements")
        else:
            logger.info(f"- {len(refine_items)} page(s) with pending news to integrate")

        # Orphan pages
        if not quality["orphan_pages"]:
            logger.info("+ No orphan pages")
        else:
            logger.info(f"- {len(quality['orphan_pages'])} orphan page(s) (no inbound links)")

        # Broken links
        if not quality["broken_links"]:
            logger.info("+ No broken links")
        else:
            broken_sources = set(bl["source"] for bl in quality["broken_links"])
            logger.info(f"- {len(quality['broken_links'])} broken link(s) across {len(broken_sources)} page(s)")

        # Source concentration
        concentrated_articles = quality.get("source_concentration", [])
        concentrated_slugs = set(c["slug"] for c in concentrated_articles)
        if not concentrated_articles:
            logger.info("+ Source diversity")
        else:
            logger.info(f"- Source concentration ({len(concentrated_slugs)} article(s))")

        # Underlinked pages
        underlinked = quality.get("underlinked_pages", [])
        if not underlinked:
            logger.info("+ Internal linking healthy")
        else:
            logger.info(f"- {len(underlinked)} underlinked page(s) (<3 inbound links)")

        # Title/description length
        long_titles = quality.get("long_titles", [])
        long_descs = quality.get("long_descriptions", [])
        seo_meta_issues = len(long_titles) + len(long_descs)
        if not seo_meta_issues:
            logger.info("+ Titles and descriptions within limits")
        else:
            parts = []
            if long_titles:
                parts.append(f"{len(long_titles)} long title(s)")
            if long_descs:
                parts.append(f"{len(long_descs)} long description(s)")
            logger.info(f"- {', '.join(parts)}")

        # External citations
        no_citations = quality.get("no_citations", [])
        if not no_citations:
            logger.info("+ All pages have external citations")
        else:
            logger.info(f"- {len(no_citations)} page(s) without external citations")

        # H1 issues
        h1_issues = quality.get("h1_issues", [])
        if not h1_issues:
            logger.info("+ H1 tags healthy")
        else:
            logger.info(f"- {len(h1_issues)} H1 issue(s)")

        # Thin content
        thin_pages = quality.get("thin_pages", [])
        if not thin_pages:
            logger.info("+ No thin pages")
        else:
            logger.info(f"- {len(thin_pages)} thin page(s) (<200 words)")

        # Heading hierarchy
        heading_issues = quality.get("heading_issues", [])
        if not heading_issues:
            logger.info("+ Heading structure healthy")
        else:
            logger.info(f"- {len(heading_issues)} heading issue(s)")

        # Content staleness
        if not stale_pages:
            logger.info("+ Content freshness on schedule")
        else:
            logger.info(f"- {len(stale_pages)} stale page(s) overdue for refresh")

        # ═══════════════════════════════════════════════════════════════
        # STALENESS — content age and refresh schedule
        # ═══════════════════════════════════════════════════════════════
        if stale_pages or on_schedule:
            logger.info("")
            logger.info("-- STALENESS --")
            if stale_pages:
                logger.info(
                    f"  {len(stale_pages)} page(s) overdue "
                    f"(last updated > refresh_days threshold)")
                stale_sorted = sorted(stale_pages,
                                      key=lambda p: p["age_days"],
                                      reverse=True)
                for sp in stale_sorted[:15]:
                    logger.info(
                        f"    /{sp['topic']}/{sp['slug']}/   "
                        f"last: {sp['last_updated']}  "
                        f"({sp['age_days']} days, threshold: {sp['threshold']})")
                if len(stale_pages) > 15:
                    logger.info(f"    ... {len(stale_pages) - 15} more")
            if on_schedule > 0:
                logger.info(f"  {on_schedule} page(s) on schedule")

        # ═══════════════════════════════════════════════════════════════
        # TOP PERFORMERS — what's working (only when GSC URL data exists)
        # ═══════════════════════════════════════════════════════════════
        if gsc_urls:
            # Sort by clicks descending
            sorted_urls = sorted(gsc_urls, key=lambda u: u.get("clicks", 0), reverse=True)
            top_n = 10
            top = sorted_urls[:top_n]
            top_clicks = sum(u.get("clicks", 0) for u in top)

            if top_clicks > 0:
                logger.info("")
                logger.info("-- TOP PERFORMERS --")
                for u in top:
                    clicks = u.get("clicks", 0)
                    imp = u.get("impressions", 0)
                    ctr = (clicks / imp * 100) if imp > 0 else 0
                    logger.info(
                        f"  {u['url']}: {imp:,} imp, {clicks:,} clicks ({ctr:.1f}% CTR)")
                pct = (top_clicks / total_clicks * 100) if total_clicks > 0 else 0
                logger.info(
                    f"  Top {len(top)}: {top_clicks:,} clicks "
                    f"({pct:.0f}% of {total_clicks:,} total)")
                if pct > 50 and len(top) <= 5:
                    logger.warning(
                        f"  ! Traffic concentration: {pct:.0f}% of clicks from "
                        f"top {len(top)} pages. Protect these pages.")

        # ═══════════════════════════════════════════════════════════════
        # LANGUAGES — per-language breakdown (multi-language sites only)
        # ═══════════════════════════════════════════════════════════════
        if site_languages and gsc_urls:
            from urllib.parse import urlparse
            # Group GSC URLs by language prefix
            lang_stats = {}
            for lang_entry in site_languages:
                code = lang_entry["code"]
                lang_stats[code] = {"impressions": 0, "clicks": 0, "urls": 0}
            lang_stats["other"] = {"impressions": 0, "clicks": 0, "urls": 0}

            for u in gsc_urls:
                url = u["url"]
                imp = u.get("impressions", 0)
                clicks = u.get("clicks", 0)
                # Extract path from full URL
                parsed = urlparse(url)
                path = parsed.path
                matched = False
                for lang_entry in site_languages:
                    code = lang_entry["code"]
                    if path.startswith(f"/{code}/"):
                        lang_stats[code]["impressions"] += imp
                        lang_stats[code]["clicks"] += clicks
                        lang_stats[code]["urls"] += 1
                        matched = True
                        break
                if not matched:
                    lang_stats["other"]["impressions"] += imp
                    lang_stats["other"]["clicks"] += clicks
                    lang_stats["other"]["urls"] += 1

            # Count pages per language from docs dirs
            for lang_entry in site_languages:
                code = lang_entry["code"]
                docs_dir = lang_entry.get("docs_dir", f"docs/{code}")
                lang_docs = tools.SITE_DIR / docs_dir
                if lang_docs.exists():
                    pages = list(lang_docs.glob("**/index.md"))
                    lang_stats[code]["pages"] = len(pages)
                else:
                    lang_stats[code]["pages"] = 0
            lang_stats["other"]["pages"] = 0

            # Only show if there's actual data
            has_lang_data = any(
                s["impressions"] > 0 or s["clicks"] > 0
                for s in lang_stats.values()
            )
            if has_lang_data:
                logger.info("")
                logger.info("-- LANGUAGES --")
                for code, stats in lang_stats.items():
                    if stats["impressions"] == 0 and stats["clicks"] == 0:
                        continue
                    imp = stats["impressions"]
                    clicks = stats["clicks"]
                    urls = stats["urls"]
                    ctr = (clicks / imp * 100) if imp > 0 else 0
                    pages = stats.get("pages", 0)
                    warn = ""
                    if pages == 0 and (imp > 0 or clicks > 0):
                        warn = " ⚠"
                    logger.info(
                        f"  {code}:  {imp:>10,} imp  {clicks:>6,} clicks  "
                        f"{urls:>5,} URLs  {ctr:.2f}% CTR  {pages:>4} pages{warn}")

        # ═══════════════════════════════════════════════════════════════
        # ACTION — problems that need fixing (only if problems exist)
        # ═══════════════════════════════════════════════════════════════
        has_actions = (dead or hard or soft or quality["broken_links"]
                       or quality["orphan_pages"] or news_counts
                       or refine_items or refine_blocked
                       or concentrated_articles or underlinked
                       or long_titles or long_descs or no_citations
                       or h1_issues or thin_pages or heading_issues)

        if has_actions:
            logger.info("")
            logger.info("-- ACTION --")

            # Dead pages
            if dead:
                logger.info(f"DEAD PAGES: {len(dead)} (<={dead_threshold} imp, site median: {median_imp:.0f})")
                if topic_name:
                    for i, dp in enumerate(dead, 1):
                        top = dp["covered_by"][0] if dp["covered_by"] else None
                        if top:
                            logger.info(
                                f"  {i}. /{dp['dead_topic']}/{dp['dead_slug']}/ "
                                f"-- {dp['total_impressions']} imp, "
                                f"since {dp.get('first_seen', '?')} "
                                f"-> expand /{top['topic']}/{top['slug']}/ "
                                f"\"{top['keyword']}\" (#{top['position']:.0f})")
                        else:
                            logger.info(
                                f"  {i}. /{dp['dead_topic']}/{dp['dead_slug']}/ "
                                f"-- 0 data, since {dp.get('first_seen', '?')}")

            # Missing redirects
            if missing_redirects:
                logger.info(
                    f"MISSING REDIRECTS: {len(missing_redirects)} URL(s) "
                    f"with GSC data but no page or redirect")
                for m in missing_redirects[:10]:
                    logger.info(
                        f"  {m['path']} ({m['impressions']:,} imp)")
                if len(missing_redirects) > 10:
                    logger.info(f"  ... and {len(missing_redirects) - 10} more")
                logger.info(
                    "  Fix: add redirects in wire.yml:\n"
                    "    redirects:\n"
                    "      /old/path/: /new/path/\n"
                    "  Then run: python -m wire.chief migrate-gsc")

            # Merge
            run_dedup = f"  | RUN: python -m wire.chief deduplicate {topic_name or ''}"
            if hard:
                pairs_word = "pair" if len(hard) == 1 else "pairs"
                logger.info(f"MERGE: {len(hard)} {pairs_word}{run_dedup}")
                for i, ov in enumerate(hard, 1):
                    skew = max(ov['traffic_share_a'], 1 - ov['traffic_share_a'])
                    ov_topic = ov.get('topic_a', topic_name or '')
                    score_a = keeper_score(ov_topic, ov["slug_a"])
                    score_b = keeper_score(ov_topic, ov["slug_b"])
                    if score_a >= score_b:
                        donor, keeper_slug = ov["slug_a"], ov["slug_b"]
                    else:
                        donor, keeper_slug = ov["slug_b"], ov["slug_a"]
                    logger.info(f"  {i}. /{ov_topic}/{donor}/ -> /{ov_topic}/{keeper_slug}/ "
                                f"-- {ov['shared_count']} shared kw, "
                                f"ratio={ov['overlap_ratio']:.0%}, "
                                f"skew={skew:.0%}, "
                                f"{ov['total_shared_impressions']:,} imp")

            # Differentiate
            if soft:
                pairs_word = "pair" if len(soft) == 1 else "pairs"
                logger.info(f"DIFFERENTIATE: {len(soft)} {pairs_word}{run_dedup}")
                for i, ov in enumerate(soft, 1):
                    topic_a = ov.get('topic_a', topic_name or '')
                    topic_b = ov.get('topic_b', topic_name or '')
                    annotation = ""
                    if topic_name:
                        try:
                            item_a = Content.from_location(f"{topic_a}/{ov['slug_a']}")
                            diff_date = item_a.get_stamp("wire_differentiated")
                            diff_from = item_a.get_stamp("wire_differentiated_from")
                            if diff_from == ov["slug_b"] and diff_date:
                                annotation = f" (done {diff_date})"
                        except Exception as e:
                            logger.debug(f"Could not check diff status for {ov['slug_a']}: {e}")
                    logger.info(f"  {i}. /{topic_a}/{ov['slug_a']}/ \u2194 "
                                f"/{topic_b}/{ov['slug_b']}/ -- "
                                f"{ov['shared_count']} shared kw, "
                                f"ratio={ov['overlap_ratio']:.0%}, "
                                f"{ov['total_shared_impressions']:,} imp{annotation}")
                    if topic_name and ov.get("shared_keywords"):
                        a_wins = [kw for kw in ov["shared_keywords"]
                                  if kw["pos_a"] < kw["pos_b"]]
                        b_wins = [kw for kw in ov["shared_keywords"]
                                  if kw["pos_b"] < kw["pos_a"]]
                        if a_wins:
                            kw_str = dot.join(
                                f"\"{k['keyword']}\" (A:#{k['pos_a']:.0f}, B:#{k['pos_b']:.0f})"
                                for k in a_wins
                            )
                            logger.info(f"   A wins: {kw_str} -> link from B to A")
                        if b_wins:
                            kw_str = dot.join(
                                f"\"{k['keyword']}\" (A:#{k['pos_a']:.0f}, B:#{k['pos_b']:.0f})"
                                for k in b_wins
                            )
                            logger.info(f"   B wins: {kw_str} -> link from A to B")

            # Broken links (categorized)
            if quality["broken_links"]:
                categorized = _categorize_broken_links(quality["broken_links"])
                broken_sources = set(bl["source"] for bl in quality["broken_links"])
                logger.info(f"BROKEN LINKS: {len(quality['broken_links'])} links in {len(broken_sources)} pages")
                for topic_cat, slugs in categorized.items():
                    total_in_topic = sum(s["count"] for s in slugs)
                    logger.info(f"  Missing {topic_cat} ({total_in_topic} links, {len(slugs)} slugs):"
                                f"  -> run: python -m wire.chief sanitize {topic_cat}")
                    slug_parts = [f"{s['slug']} ({s['count']})" if s['count'] > 1 else s['slug']
                                  for s in slugs[:10]]
                    logger.info(f"    {', '.join(slug_parts)}")
                if quality["slug_fixes"]:
                    for sf in quality["slug_fixes"]:
                        logger.info(f"  Slug fix: {sf['target']} -> {sf['suggestion']}"
                                    f"  (auto-corrected by sanitize)")

            # Orphan pages
            if quality["orphan_pages"]:
                logger.info(f"ORPHAN PAGES: {len(quality['orphan_pages'])} pages with zero inbound links")
                if topic_name:
                    for i, orphan in enumerate(quality["orphan_pages"], 1):
                        logger.info(f"  {i}. {orphan}")

            # News
            if news_counts:
                total_news = sum(news_counts.values())
                run_news = f"  | RUN: python -m wire.chief news {topic_name or '<topic>'}"
                blocked_note = f" ({news_blocked} blocked by merge)" if news_blocked else ""
                logger.info(f"NEWS: {total_news} pages need update{blocked_note}{run_news}")
                breakdown = dot.join(f"/{t}/: {c}" for t, c in sorted(news_counts.items()))
                logger.info(f"  {breakdown}")

            # Refine
            if refine_items or refine_blocked:
                run_refine = f"  | RUN: python -m wire.chief refine {topic_name or '<topic>'}"
                blocked_note = f" ({refine_blocked} blocked by overlaps)" if refine_blocked else ""
                tracker_note = f" ({tracker_count} tracker-only, auto-archive)" if tracker_count else ""
                logger.info(f"REFINE: {len(refine_items)} pages with pending news"
                            f"{blocked_note}{tracker_note}{run_refine}")
                if topic_name:
                    for i, item in enumerate(refine_items, 1):
                        logger.info(f"  {i}. /{item.topic}/{item.slug}/")
                    for item in all_refine_items:
                        if item.slug in dedup_blocked:
                            logger.info(f"  /{item.topic}/{item.slug}/ (blocked: deduplicate first)")
                else:
                    refine_counts = {}
                    for item in refine_items:
                        refine_counts[item.topic] = refine_counts.get(item.topic, 0) + 1
                    breakdown = dot.join(f"/{t}/: {c}" for t, c in sorted(refine_counts.items()))
                    logger.info(f"  {breakdown}")

            # Source concentration
            if concentrated_articles:
                run_news = f"  | RUN: python -m wire.chief news {topic_name or '<topic>'}"
                logger.info(f"SOURCE CONCENTRATION: {len(concentrated_slugs)} article(s){run_news}")
                # Group by slug, show worst domain per slug
                seen_slugs = {}
                for c in concentrated_articles:
                    key = c["slug"]
                    if key not in seen_slugs or c["pct"] > seen_slugs[key]["pct"]:
                        seen_slugs[key] = c
                for i, (slug, c) in enumerate(sorted(seen_slugs.items(),
                                                      key=lambda x: -x[1]["pct"]), 1):
                    logger.info(f"  {i}. /{c['topic']}/{slug}/ "
                                f"-- {c['domain']} ({c['count']}/{c['total']} links, "
                                f"{c['pct']:.0f}%)")

            # Underlinked pages
            if underlinked:
                logger.info(f"UNDERLINKED: {len(underlinked)} page(s) with <3 inbound internal links")
                for i, u in enumerate(underlinked[:10], 1):
                    logger.info(f"  {i}. /{u['topic']}/{u['slug']}/ ({u['inbound_count']} inbound)")
                if len(underlinked) > 10:
                    logger.info(f"  ... {len(underlinked) - 10} more")

            if long_titles or long_descs:
                all_meta = []
                for t in long_titles:
                    all_meta.append(f"  /{t['topic']}/{t['slug']}/ — title {t['length']} chars (max 60)")
                for d in long_descs:
                    all_meta.append(f"  /{d['topic']}/{d['slug']}/ — description {d['length']} chars (max 160)")
                logger.info(f"META LENGTH: {len(all_meta)} issue(s)")
                for line in all_meta[:10]:
                    logger.info(line)
                if len(all_meta) > 10:
                    logger.info(f"  ... {len(all_meta) - 10} more")

            if no_citations:
                logger.info(f"NO CITATIONS: {len(no_citations)} page(s) without external sources  | RUN: python -m wire.content update <topic/slug>")
                for i, nc in enumerate(no_citations[:10], 1):
                    logger.info(f"  {i}. /{nc['topic']}/{nc['slug']}/")
                if len(no_citations) > 10:
                    logger.info(f"  ... {len(no_citations) - 10} more")

            # H1 issues
            if h1_issues:
                logger.info(f"H1 ISSUES: {len(h1_issues)} page(s) (auto-fixed on next content command, not sanitize)")
                h1_labels = {
                    "missing": "no # Title in markdown (template has H1, but source must be complete)",
                    "multiple": "multiple # headings (only one H1 allowed)",
                    "mismatch": "# heading doesn't match frontmatter title",
                }
                for i, (slug, issue) in enumerate(h1_issues[:10], 1):
                    logger.info(f"  {i}. {slug} — {h1_labels.get(issue, issue)}")
                if len(h1_issues) > 10:
                    logger.info(f"  ... {len(h1_issues) - 10} more")

            # Thin content
            if thin_pages:
                logger.info(f"THIN CONTENT: {len(thin_pages)} page(s) with <200 words")
                for i, (slug, wc) in enumerate(thin_pages[:10], 1):
                    logger.info(f"  {i}. {slug} — {wc} words")
                if len(thin_pages) > 10:
                    logger.info(f"  ... {len(thin_pages) - 10} more")

            # Heading issues
            if heading_issues:
                logger.info(f"HEADING ISSUES: {len(heading_issues)} page(s)")
                for i, (slug, issue) in enumerate(heading_issues[:10], 1):
                    label = "numbered headings" if issue == "numbered" else "skipped heading level"
                    logger.info(f"  {i}. {slug} — {label}")
                if len(heading_issues) > 10:
                    logger.info(f"  ... {len(heading_issues) - 10} more")

        # ═══════════════════════════════════════════════════════════════
        # SEO — reword opportunities and content gaps
        # ═══════════════════════════════════════════════════════════════
        logger.info("")
        logger.info("-- SEO --")

        if topic_name:
            all_opportunities = self._scan_opportunities(topic_name, verbose=False)
            if all_opportunities:
                blocked_count = sum(
                    1 for o in all_opportunities
                    if o["item"].slug in dedup_blocked or o["item"].slug in refine_slugs
                )
                actionable_count = len(all_opportunities) - blocked_count
                total = len(all_opportunities)
                full_cutoff, light_cutoff = _reword_tiers(total)

                run_reword = f"  | RUN: python -m wire.chief reword {topic_name}"
                blocked_note = f" ({blocked_count} blocked)" if blocked_count else ""
                logger.info(f"REWORD: {actionable_count} actionable of {total} "
                            f"pages with SEO opportunities{blocked_note}"
                            f" ({full_cutoff} full + {light_cutoff - full_cutoff} light)"
                            f"{run_reword}")

                max_score = max(o["total_score"] for o in all_opportunities) if all_opportunities else 1
                for i, opp in enumerate(all_opportunities[:light_cutoff], 1):
                    item = opp["item"]
                    path = f"/{item.topic}/{item.slug}/"
                    pq = opp["gsc_data"]["page_queries"]
                    total_imp = sum(q["impressions"] for q in pq)
                    avg_pos = (sum(q["position"] * q["impressions"] for q in pq)
                               / total_imp) if total_imp else 0
                    norm_score = int(opp["total_score"] / max_score * 100) if max_score else 0
                    tier_label = "full" if i <= full_cutoff else "light"
                    annotation = ""
                    reworded = item.get_stamp("wire_reworded")
                    if item.slug in merge_slugs:
                        annotation = " (blocked: merge)"
                    elif item.slug in diff_slugs:
                        annotation = " (blocked: differentiate)"
                    elif item.slug in refine_slugs:
                        annotation = " (blocked: pending news)"
                    elif reworded:
                        annotation = f" (reworded {reworded})"
                    logger.info(f"  {i}. [{tier_label:<5}] {path:<32} score={norm_score:>3}  "
                                f"{opp['count']:>2} kw  {total_imp:>6,} imp  "
                                f"pos {avg_pos:>4.1f}{annotation}")
                remaining = total - light_cutoff
                if remaining > 0:
                    skip_pct = 100 * remaining // total if total else 0
                    logger.info(f"  ... {remaining} more (bottom {skip_pct}% skipped)")
            else:
                logger.info(f"REWORD: no SEO opportunities")
        else:
            logger.info(f"REWORD: run 'audit <topic>' for details")

        # Content gaps
        if gaps:
            if topic_name:
                logger.info(f"CONTENT GAPS: {len(gaps)} (keyword on 3+ pages, none in top 20)")
                for i, gap in enumerate(gaps[:15], 1):
                    pages_str = dot.join(
                        f"/{p['topic']}/{p['slug']}/ (#{p['position']:.0f}, {p['impressions']} imp)"
                        for p in gap["ranking_pages"][:3]
                    )
                    logger.info(f"  {i}. \"{gap['keyword']}\" -- "
                                f"{gap['page_count']} pages, best #{gap['best_position']:.0f} "
                                f"{dot}{pages_str}")
                remaining = len(gaps) - 15
                if remaining > 0:
                    logger.info(f"  ... {remaining} more")
            else:
                logger.info(f"CONTENT GAPS: {len(gaps)}")
        else:
            logger.info(f"CONTENT GAPS: none")

        # ═══════════════════════════════════════════════════════════════
        # INFO — summary counts and archived
        # ═══════════════════════════════════════════════════════════════
        logger.info("")
        logger.info("-- INFO --")

        if summary and summary.get("pages_without_data"):
            logger.info(f"{summary['pages_without_data']} pages untracked (no GSC data yet)")

        if archived:
            logger.info(f"ARCHIVED: {len(archived)} merged pages on disk")
            if topic_name:
                for i, path in enumerate(archived, 1):
                    rel = path.relative_to(tools.DOCS_DIR)
                    logger.info(f"  {i}. /{rel}")
        else:
            logger.info(f"ARCHIVED: none")

        if not topic_name:
            logger.info(f"Run 'audit <topic>' for detailed report.")

    def enrich(self, topic_name: str, resume: bool = False) -> None:
        """Analyze all pages locally, then improve actionable ones.

        Phase 1: Build amendment briefs (free, no API calls).
        Phase 2: Filter to actionable pages, report summary.
        Phase 3: Web research for expand keywords (targeted).
        Phase 4: Call improve() for each actionable page.
        """
        _check_git_clean()
        _check_styleguide()
        _validate_topic(topic_name)
        init_db()

        # Pre-flight: check GSC data quality (init_db() guarantees DB exists)
        summary = db_summary(topic_name)

        if not summary or summary.get("pages_with_data", 0) == 0:
            logger.error(f"No GSC data for {topic_name}. "
                         f"Run: python -m wire.chief data")
            return

        latest = summary.get("latest_date")
        if latest:
            age = (date.today() - date.fromisoformat(latest)).days
            if age > 28:
                logger.warning(f"GSC data is {age} days old. "
                               f"Consider: python -m wire.chief data")

        topic_obj = Topic(topic_name)
        items = topic_obj.list()
        if not items:
            logger.info(f"No items in {topic_name}")
            return

        # Compute overlap gates (init_db() guarantees DB exists)
        merge_slugs, diff_slugs = set(), set()
        overlaps = find_overlaps(topic_name, min_shared=3)
        for ov in overlaps:
            action = _classify_overlap(ov)
            if action == "merge":
                merge_slugs.update([ov["slug_a"], ov["slug_b"]])
            elif action == "differentiate":
                diff_slugs.update([ov["slug_a"], ov["slug_b"]])
        overlap_slugs = merge_slugs | diff_slugs

        # Resume support
        completed = _load_progress("enrich", topic_name) if resume else set()

        # ── Phase 1: Analyze all pages (free) ──
        logger.info(f"ENRICH: analyzing {len(items)} pages in {topic_name}...")

        # Batch-fetch all opportunity keywords for ownership lookup
        all_opportunity_kws = set()
        page_search_data = {}
        for item in items:
            if item.slug in completed:
                continue
            sd = get_search_terms(item.slug, item.title, item.topic)
            if sd:
                page_search_data[item.slug] = sd
                for q in sd.get("page_queries", []):
                    if 5 < q.get("position", 0) <= 30 and q.get("score", 0) >= MIN_OPPORTUNITY_SCORE:
                        all_opportunity_kws.add(q["query"])

        ownership_map = {}
        if all_opportunity_kws:
            ownership_map = keyword_ownership_batch(
                list(all_opportunity_kws), topic_name)

        briefs = {}  # slug → brief
        for item in items:
            if item.slug in completed:
                continue
            sd = page_search_data.get(item.slug)
            brief = build_amendment_brief(
                item, sd, topic_name,
                overlap_slugs=overlap_slugs,
                ownership_map=ownership_map,
                min_opportunity_score=MIN_OPPORTUNITY_SCORE,
            )
            briefs[item.slug] = brief

        # ── Phase 2: Filter + Report ──
        actionable = {s: b for s, b in briefs.items() if b["skip_reason"] is None}
        skipped = {s: b for s, b in briefs.items() if b["skip_reason"] is not None}

        # Count skip reasons
        skip_reasons = {}
        for s, b in skipped.items():
            reason = b["skip_reason"]
            skip_reasons[reason] = skip_reasons.get(reason, 0) + 1

        # Count action types
        expand_count = sum(1 for b in actionable.values() if b["expand_keywords"])
        heading_count = sum(1 for b in actionable.values()
                           if b["heading_promotions"] and not b["expand_keywords"])
        link_count = sum(1 for b in actionable.values()
                        if b["link_targets"] and not b["expand_keywords"]
                        and not b["heading_promotions"])
        news_count = sum(1 for b in actionable.values()
                        if b["news_files"] and not b["expand_keywords"]
                        and not b["heading_promotions"] and not b["link_targets"])

        # Create suggestions
        all_creates = []
        for b in briefs.values():
            all_creates.extend(b.get("create_suggestions", []))

        logger.info(f"")
        logger.info(f"ENRICH: {topic_name} ({len(items)} pages)")
        logger.info(f"  GSC data: {summary['pages_with_data']} tracked "
                    f"(latest: {latest or 'none'})")
        logger.info(f"")
        logger.info(f"  Actionable: {len(actionable)} pages")
        if expand_count:
            logger.info(f"    {expand_count} need keyword expansion (web research + Claude)")
        if heading_count:
            logger.info(f"    {heading_count} need heading promotion only (Claude)")
        if link_count:
            logger.info(f"    {link_count} need internal links only (Claude)")
        if news_count:
            logger.info(f"    {news_count} need news integration only (Claude)")

        logger.info(f"")
        logger.info(f"  Skipped: {len(skipped)} pages")
        for reason, count in sorted(skip_reasons.items()):
            logger.info(f"    {count} {reason}")

        if all_creates:
            logger.info(f"")
            logger.info(f"  Create suggestions (not auto-executed):")
            for cs in all_creates[:5]:
                logger.info(f"    \"{cs['keyword']}\" — {cs['impressions']} imp")

        if completed:
            logger.info(f"  Resumed: {len(completed)} already completed")

        if not actionable:
            logger.info(f"\n  Nothing to do.")
            _clear_progress("enrich", topic_name)
            return

        # Estimate cost
        est_calls = len(actionable)
        est_cost = est_calls * 0.06  # ~$0.06 per improve call
        logger.info(f"\n  Estimated: {est_calls} Claude calls, ~${est_cost:.2f}")

        # ── Phase 3: Web research for expand keywords + BM25 refinement ──
        research_by_slug = {}
        for slug, brief in actionable.items():
            if not brief["expand_keywords"]:
                continue
            item = next((i for i in items if i.slug == slug), None)
            if item is None:
                logger.warning(f"  {slug}: not found in items, skipping")
                continue
            page_body = item.read_index() or ""
            research_parts = []
            # Track competitor texts per keyword for BM25
            kw_competitor_texts = {}
            for kw_data in brief["expand_keywords"][:3]:  # cap at 3 per page
                kw = kw_data["keyword"]
                query = f"{item.title} {kw}"
                urls = web_search(query, max_results=3)
                texts_for_kw = []
                for url in urls:
                    text = fetch_page(url)
                    if text:
                        research_parts.append(
                            f"## Source: {url}\n\n{text[:5000]}")
                        texts_for_kw.append(text[:5000])
                if texts_for_kw:
                    kw_competitor_texts[kw] = texts_for_kw
                time.sleep(RATE_LIMIT_DELAY)
            if research_parts:
                research_by_slug[slug] = "\n\n---\n\n".join(research_parts)

            # BM25 refinement: re-route high-ratio keywords based on semantic fit
            refined_expand = []
            for kw_data in brief["expand_keywords"]:
                kw = kw_data["keyword"]
                imp_ratio = kw_data["impressions"] / max(
                    max(q.get("impressions", 0)
                        for q in page_search_data.get(slug, {}).get("page_queries", [{"impressions": 1}])),
                    1)
                competitor_texts = kw_competitor_texts.get(kw)
                if imp_ratio > HIGH_RATIO_THRESHOLD and competitor_texts:
                    fit = bm25_semantic_fit(kw, page_body, competitor_texts)
                    if fit == "distant":
                        # Demote: move from expand to create suggestion
                        brief["create_suggestions"].append({
                            "keyword": kw,
                            "impressions": kw_data["impressions"],
                            "reason": f"ratio={imp_ratio:.0%}, BM25={fit}",
                        })
                        logger.info(f"  {slug}: '{kw}' re-routed to create (BM25 distant)")
                        continue
                elif imp_ratio <= HIGH_RATIO_THRESHOLD and competitor_texts:
                    fit = bm25_semantic_fit(kw, page_body, competitor_texts)
                    if fit == "distant":
                        # Downgrade: add_section → mention_link
                        kw_data["routing"] = "mention_link"
                        logger.info(f"  {slug}: '{kw}' downgraded to mention_link (BM25 distant)")
                refined_expand.append(kw_data)
            brief["expand_keywords"] = refined_expand

        # ── Phase 4: Improve each page ──
        editor = ContentEditor()

        def _process_enrich(item):
            brief = actionable.get(item.slug)
            if not brief:
                return "skipped", False

            research = research_by_slug.get(item.slug, "")
            news_text = ""
            if brief["news_files"]:
                news_parts = [f.read_text(encoding="utf-8")
                              for f in brief["news_files"]]
                news_text = "\n\n".join(news_parts)

            sd = page_search_data.get(item.slug)
            result = editor.improve(item, brief, research=research,
                                    news=news_text, search_data=sd)
            return result, not result.startswith("failed")

        actionable_items = [i for i in items if i.slug in actionable]
        _run_batch(actionable_items, _process_enrich,
                   command="enrich", topic=topic_name,
                   completed=completed)

        _clear_progress("enrich", topic_name)
        logger.info(f"\nENRICH: complete ({len(actionable)} pages processed)")

    def reword(self, topic_name: str, resume: bool = False) -> None:
        """Tiered SEO rewrite based on opportunity score.

        Tier 1 (top 20%): Full SEO rewrite — headings, body, title, description.
        Tier 2 (next 30%): Light rewrite — title and description only.
        Bottom 50%: Skipped.

        Configurable via mkdocs.yml extra.wire:
            reword_tiers: {full: 20, light: 30}

        Requires GSC data in the DB — run `data` command first.

        Gates (skips page if):
        - Needs merge or differentiate (run deduplicate first)
        - Has pending news files (run refine first)
        - Already reworded and no new data or content changes
        """
        _check_git_clean()
        _check_styleguide()
        _validate_topic(topic_name)
        if not self._check_db(topic_name):
            _clear_progress("reword", topic_name)
            return

        all_opportunities = self._scan_opportunities(topic_name)

        if not all_opportunities:
            logger.info(f"\nNo reword opportunities found for {topic_name}.")
            _clear_progress("reword", topic_name)
            return

        # Tier boundaries — configurable via WIRE_CONFIG
        total = len(all_opportunities)
        full_cutoff, light_cutoff = _reword_tiers(total)

        tier1 = all_opportunities[:full_cutoff]
        tier2 = all_opportunities[full_cutoff:light_cutoff]

        # Pre-compute overlap sets for gate checks
        try:
            merge_slugs, diff_slugs = self._overlap_slugs(topic_name)
        except Exception as e:
            logger.warning(f"Overlap check failed for {topic_name}: {e} — cannot enforce gates")
            raise
        blocked = merge_slugs | diff_slugs

        # Resume support
        completed = _load_progress("reword", topic_name) if resume else set()
        if completed:
            logger.info(f"\nReword: resuming ({len(completed)} done, "
                        f"{len(tier1)} full + {len(tier2)} light)")
        else:
            logger.info(f"\nReword: {len(tier1)} full + {len(tier2)} light "
                        f"of {total} pages (bottom {total - light_cutoff} skipped)")

        def _apply_gates(item):
            """Check gates; returns skip reason or None."""
            if item.slug in blocked:
                logger.info(f"  {item.slug}: overlaps -> deduplicate first, skipping")
                return "skipped (overlaps)"
            if item.news_files():
                logger.info(f"  {item.slug}: pending news -> refine first, skipping")
                return "skipped (pending news)"
            reworded = item.get_stamp("wire_reworded")
            if reworded:
                snap_date = get_snapshot_date(item.topic, item.slug)
                page_date = item.get_stamp("date")
                stale_data = snap_date and snap_date > reworded
                stale_content = page_date and page_date > reworded
                if not stale_data and not stale_content:
                    logger.info(f"  {item.slug}: reworded {reworded}, no changes -> skipping")
                    return "skipped (already reworded)"
            return None

        # Build unified list with tier label
        class _RewordItem:
            """Wrapper carrying tier info + opportunity data alongside .slug."""
            def __init__(self, opp, tier):
                self.opp = opp
                self.tier = tier
                self.slug = opp["item"].slug

        batch_items = [_RewordItem(opp, "full") for opp in tier1] + \
                      [_RewordItem(opp, "light") for opp in tier2]

        editor = self.editor

        def process(ritem):
            item = ritem.opp["item"]
            skip = _apply_gates(item)
            if skip:
                return skip, True  # gated items count as "completed" for progress

            keywords = ", ".join(q["query"] for q in ritem.opp["queries"])
            search_terms = _format_search_terms(ritem.opp["gsc_data"])

            if ritem.tier == "full":
                logger.info(f"  reword {item.slug}: {keywords}")
                result = editor.seo(item, target_keywords=keywords, search_terms=search_terms)
            else:
                logger.info(f"  seo-light {item.slug}: {keywords}")
                result = editor.seo_light(item, target_keywords=keywords, search_terms=search_terms)

            logger.info(f"  {item.slug} -> {result}")
            return result, not result.startswith("failed")

        _run_batch(batch_items, process, command="reword", topic=topic_name,
                   workers=self.workers, completed=completed)

        _clear_progress("reword", topic_name)

    def consolidate_comparisons(self, topic_name: str = "vendors",
                                min_comparisons: int = 3) -> None:
        """Consolidate individual comparison pages into per-vendor hub pages.

        Scans comparisons/ for {slug}-vs-* directories, counts per vendor,
        and consolidates vendors with >= min_comparisons into hub pages.
        Skips vendors that already have a hub page at comparisons/{slug}/index.md.
        """
        _check_styleguide()
        comparisons_dir = tools.DOCS_DIR / "comparisons"
        if not comparisons_dir.exists():
            logger.info("No comparisons directory found")
            return

        # Count primary comparisons per vendor slug
        vendor_counts = Counter()
        for d in comparisons_dir.iterdir():
            if d.is_dir() and "-vs-" in d.name:
                primary_slug = d.name.split("-vs-")[0]
                vendor_counts[primary_slug] += 1

        # Filter by min_comparisons, sort by count descending
        eligible = [
            (slug, count) for slug, count in vendor_counts.items()
            if count >= min_comparisons
        ]
        eligible.sort(key=lambda x: x[1], reverse=True)

        if not eligible:
            logger.info(f"\nNo vendors with >= {min_comparisons} primary comparisons.")
            return

        # Skip vendors that already have a hub page
        to_process = []
        for slug, count in eligible:
            hub_path = tools.DOCS_DIR / "evaluate" / slug / "index.md"
            if hub_path.exists():
                logger.info(f"  {slug} — already has hub page, skipping")
            else:
                to_process.append((slug, count))

        if not to_process:
            logger.info(f"\nAll {len(eligible)} eligible vendors already have hub pages.")
            return

        logger.info(f"\nConsolidating: {len(to_process)} vendors "
              f"(of {len(eligible)} with >= {min_comparisons} comparisons)\n")

        class _ConsolidateItem:
            """Wrapper for (slug, count) tuples with .slug attribute."""
            def __init__(self, slug, count):
                self.slug = slug
                self.count = count

        items = [_ConsolidateItem(slug, count) for slug, count in to_process]
        editor = self.editor

        def process(citem):
            logger.info(f"  Consolidating {citem.slug} ({citem.count} comparisons)")
            result = editor.consolidate(citem.slug, topic_name=topic_name)
            logger.info(f"  {citem.slug} ({citem.count}) -> {result}")
            return result, not str(result).startswith("failed")

        _run_batch(items, process, command="consolidate", topic=topic_name,
                   workers=self.workers, completed=set())

        logger.info(f"\nDone: consolidated {len(to_process)} vendors")

    def search_data(self, force: bool = False) -> None:
        """Fetch and store GSC search data for all topics.

        Discovers all topic directories under tools.DOCS_DIR and fetches
        GSC data for every page.

        Smart behavior:
        - Stale data (>28 days) → re-fetches those pages
        - Fresh data → skips (unless --force)
        - Always prints DB summary at the end
        """
        # Validate site_url before doing anything
        try:
            origin = _site_origin()
            logger.info(f"GSC target: {origin}")
        except ValueError as e:
            raise ValueError(str(e))

        # Validate GSC auth + property upfront — fail loud, don't silently skip pages
        try:
            get_search_console_service()  # Raises on auth failure
            _site_url()  # Raises if property not found (auto-detects from GSC)
        except ValueError:
            raise
        except Exception as e:
            raise ValueError(
                f"GSC authentication failed: {e}\n"
                f"Checklist:\n"
                f"  1. GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET set in .env\n"
                f"  2. token.json exists in site directory (or symlinked)\n"
                f"  3. Token not expired — re-copy from laptop if needed"
            )

        init_db()

        # Bulk URL discovery — find ALL URLs Google knows about
        try:
            from wire.gsc import discover_urls
            discovered = discover_urls()
            if discovered:
                logger.info(f"GSC URL discovery: {len(discovered)} URLs known to Google")
        except Exception as e:
            logger.warning(f"GSC URL discovery failed: {e}")

        # Discover all topics
        topics_to_scan = list_topics()
        if not topics_to_scan:
            logger.info("No topics found under docs directory.")
            return
        logger.info(f"\nScanning topics: {', '.join(topics_to_scan)}")

        all_items = []
        for tname in topics_to_scan:
            topic = Topic(tname)
            items = topic.list()
            all_items.extend(items)

        if not all_items:
            logger.info("No items found across any topic.")
            return

        logger.info(f"Search data: {len(all_items)} pages total")

        counters_lock = threading.Lock()
        counters = {"fetched": 0, "cached": 0, "no_data": 0}

        def process(item):
            # Always register the page — even for cached pages.
            created = item.get_meta("created") if hasattr(item, 'get_meta') else None
            register_content(item.topic, item.slug, created=created)

            # Check freshness unless forced
            if not force:
                snap_date = get_snapshot_date(item.topic, item.slug)
                if snap_date:
                    age = (datetime.now() - datetime.strptime(snap_date, '%Y-%m-%d')).days
                    if age <= SNAPSHOT_MAX_AGE_DAYS and has_snapshot_data(item.topic, item.slug):
                        logger.info(f"  {item.topic}/{item.slug} — cached ({age}d old)")
                        with counters_lock:
                            counters["cached"] += 1
                        return "cached", True

            try:
                result = fetch_and_store(item.slug, item.title, item.topic)
                if result:
                    n_queries = len(result.get("page_queries", []))
                    logger.info(f"  {item.topic}/{item.slug} — {n_queries} queries")
                    with counters_lock:
                        counters["fetched"] += 1
                else:
                    logger.info(f"  {item.topic}/{item.slug} — no data")
                    with counters_lock:
                        counters["no_data"] += 1
            except Exception as e:
                logger.warning(f"  {item.topic}/{item.slug} — error: {e}")
                with counters_lock:
                    counters["no_data"] += 1
            return "done", True

        _run_batch(all_items, process, command="data", topic="all",
                   workers=self.workers, completed=set())

        # DB summary
        logger.info(f"\n{'=' * 50}")
        logger.info(f"Fetch: {counters['fetched']} fetched, {counters['cached']} cached, {counters['no_data']} no data")
        for tname in topics_to_scan:
            summary = db_summary(tname)
            logger.info(f"\nDatabase: {tname}")
            logger.info(f"  Pages with data:    {summary['pages_with_data']}")
            logger.info(f"  Total keywords:     {summary['total_keywords']}")
            logger.info(f"  Latest snapshot:    {summary['latest_date'] or 'none'}")

    def deduplicate(self, topic_name: str = None, min_shared: int = 3,
                    min_impressions: int = 100) -> None:
        """Merge/differentiate keyword-cannibalizing pages.

        Run `audit` first to see what will happen. This command acts.

        Hard overlap (ratio > 0.4, skew > 0.7) → merge (works cross-topic)
        Soft overlap (ratio > 0.15) → differentiate both pages
        """
        _check_git_clean()
        if topic_name:
            _validate_topic(topic_name)
        init_db()

        # Resolve old GSC paths via redirect map before overlap detection
        redirects = load_redirects()
        if redirects:
            rekeyed = rekey_from_redirects(redirects)
            if rekeyed:
                logger.info(f"Rekeyed {rekeyed} GSC content row(s) from redirects")

        # Preflight: refuse if GSC URLs are uncovered
        gsc_errors = _preflight_gsc_check()
        if gsc_errors:
            for err in gsc_errors[:5]:
                logger.error(err)
            if len(gsc_errors) > 5:
                logger.error(f"... and {len(gsc_errors) - 5} more")
            logger.error(
                "Fix redirects before deduplicating. "
                "Add missing redirects in wire.yml or .wire/redirects.yml."
            )
            raise SystemExit(1)

        scope = topic_name or "all topics"
        overlaps = find_overlaps(topic_name, min_shared=min_shared)
        overlaps = [ov for ov in overlaps
                    if ov["total_shared_impressions"] >= min_impressions]

        if not overlaps:
            logger.info(f"\nNo actionable overlaps found for {scope}.")
            return

        # Filter out overlaps involving non-editable pages (landing/raw/home)
        def _is_editable_slug(topic, slug):
            try:
                item_path = tools.DOCS_DIR / topic / slug / "index.md"
                if item_path.exists():
                    post = fm.load(item_path)
                    return post.get("layout", "") not in _SKIP_LAYOUTS
            except Exception:
                pass
            return True  # default to editable if can't read

        filtered_overlaps = []
        for ov in overlaps:
            t_a = ov.get("topic_a", topic_name)
            t_b = ov.get("topic_b", topic_name)
            if not _is_editable_slug(t_a, ov["slug_a"]):
                logger.info(f"  Skipping overlap {ov['slug_a']}: non-article layout")
                continue
            if not _is_editable_slug(t_b, ov["slug_b"]):
                logger.info(f"  Skipping overlap {ov['slug_b']}: non-article layout")
                continue
            filtered_overlaps.append(ov)
        overlaps = filtered_overlaps

        # Classify
        hard = []
        soft = []
        for ov in overlaps:
            action = _classify_overlap(ov)
            if action == "merge":
                hard.append(ov)
            elif action == "differentiate":
                soft.append(ov)

        if not hard and not soft:
            logger.info(f"\nNo hard or soft overlaps to act on for {scope}.")
            return

        logger.info(f"\nDeduplicate: {scope}")
        logger.info(f"  {len(hard)} merges, {len(soft)} differentiations")

        # Execute hard overlaps (merge) — same topic only
        for i, ov in enumerate(hard, 1):
            ov_topic = ov.get("topic_a", topic_name)
            score_a = keeper_score(ov_topic, ov["slug_a"])
            score_b = keeper_score(ov_topic, ov["slug_b"])

            if score_a >= score_b:
                keeper_slug, donor_slug = ov["slug_a"], ov["slug_b"]
                merge_ov = ov
            else:
                keeper_slug, donor_slug = ov["slug_b"], ov["slug_a"]
                merge_ov = _flip_overlap(ov)

            try:
                keeper_item = Content.from_location(f"{ov_topic}/{keeper_slug}")
                donor_item = Content.from_location(f"{ov_topic}/{donor_slug}")
            except (FileNotFoundError, ValueError) as e:
                logger.warning(f"  [{i}/{len(hard)}] Skipping merge {keeper_slug}+{donor_slug}: {e}")
                continue

            logger.info(f"  [{i}/{len(hard)}] Merging {donor_slug} → {keeper_slug}")
            result = self.editor.merge(keeper_item, donor_item, merge_ov)
            logger.info(f"  [{i}/{len(hard)}] {result}")

        # Execute soft overlaps (differentiate BOTH sides)
        for i, ov in enumerate(soft, 1):
            topic_a = ov.get("topic_a", topic_name)
            topic_b = ov.get("topic_b", topic_name)
            try:
                item_a = Content.from_location(f"{topic_a}/{ov['slug_a']}")
                item_b = Content.from_location(f"{topic_b}/{ov['slug_b']}")
            except (FileNotFoundError, ValueError) as e:
                logger.warning(f"  [{i}/{len(soft)}] Skipping differentiate "
                               f"{ov['slug_a']}+{ov['slug_b']}: {e}")
                continue

            # Idempotency: skip if already differentiated and no new data/content
            diff_from = item_a.get_stamp("wire_differentiated_from")
            diff_date = item_a.get_stamp("wire_differentiated")
            if diff_from == ov["slug_b"] and diff_date:
                snap_date = get_snapshot_date(topic_a, ov["slug_a"])
                page_date = item_a.get_stamp("date")
                stale_data = snap_date and snap_date > diff_date
                stale_content = page_date and page_date > diff_date
                if not stale_data and not stale_content:
                    logger.info(f"  [{i}/{len(soft)}] {ov['slug_a']} <-> {ov['slug_b']}: done {diff_date} -> skipping")
                    continue

            logger.info(f"  [{i}/{len(soft)}] Differentiating {ov['slug_a']} from {ov['slug_b']}")
            result_a = self.editor.differentiate(item_a, item_b, ov)
            logger.info(f"  [{i}/{len(soft)}] {result_a}")

            flipped = _flip_overlap(ov)
            logger.info(f"  [{i}/{len(soft)}] Differentiating {ov['slug_b']} from {ov['slug_a']}")
            result_b = self.editor.differentiate(item_b, item_a, flipped)
            logger.info(f"  [{i}/{len(soft)}] {result_b}")

    def download(self, topic_name: str = None, force: bool = False,
                 resume: bool = False) -> None:
        """Download WordPress pages as markdown for all topics (or one).

        Fetches HTML from the live site, extracts content + metadata,
        converts to clean markdown, downloads images. Only processes
        stub pages (<50 chars body) unless force=True.
        """
        from wire.wp import download_page

        site_url = SITE.url
        if not site_url:
            raise ValueError("No site_url in mkdocs.yml — cannot download pages")

        if topic_name:
            _validate_topic(topic_name)
            topics = [topic_name]
        else:
            topics = list_topics()

        for tname in topics:
            topic = Topic(tname)
            items = topic.list()

            if not items:
                logger.info(f"Download {tname}: no items")
                continue

            completed = _load_progress("download", tname) if resume else set()
            if completed:
                before = len(items)
                items = [it for it in items if it.slug not in completed]
                logger.info(f"Download {tname}: resuming "
                            f"({before - len(items)} done, {len(items)} remaining)")
            else:
                logger.info(f"Download {tname}: {len(items)} items")

            def process(item):
                msg, ok = download_page(
                    item.slug, tname, site_url, tools.DOCS_DIR, force=force)
                logger.info(f"  {item.slug} -> {msg}")
                return msg, ok

            _run_batch(items, process, command="download", topic=tname,
                       workers=self.workers, completed=completed)

            _clear_progress("download", tname)
            logger.info(f"Done: downloaded {tname}")

    def crosslink(self, topic_name: str = None, resume: bool = False) -> None:
        """Add internal links to underlinked pages from their siblings.

        For each topic, identifies pages with <3 inbound internal links,
        then processes well-linked pages to add natural cross-links to
        the underlinked targets.
        """
        _check_git_clean()
        if topic_name:
            _validate_topic(topic_name)

        # Get underlinked pages
        topics = [topic_name] if topic_name else None
        quality = _audit_content_quality(topics)
        underlinked = quality.get("underlinked_pages", [])

        if not underlinked:
            logger.info("No underlinked pages found.")
            return

        # Group underlinked by topic
        by_topic = defaultdict(list)
        for u in underlinked:
            by_topic[u["topic"]].append(u)

        logger.info(f"Crosslinking: {len(underlinked)} underlinked pages across "
                     f"{len(by_topic)} topic(s)")

        editor = ContentEditor()
        rate_delay = WIRE_CONFIG.get("rate_limit_delay", 1)

        for tname, targets in sorted(by_topic.items()):
            if topic_name and tname != topic_name:
                continue

            # Build target info with title/summary
            target_info = []
            underlinked_slugs = set()
            for u in targets:
                underlinked_slugs.add(u["slug"])
                try:
                    item = Content.from_location(f"{tname}/{u['slug']}")
                    target_info.append({
                        "path": item.path,
                        "title": item.title,
                        "summary": item.summary,
                        "inbound_count": u["inbound_count"],
                    })
                except (FileNotFoundError, ValueError):
                    continue

            if not target_info:
                continue

            # Process all pages in topic (except underlinked ones themselves)
            try:
                topic_obj = Topic(tname)
                all_items = topic_obj.list()
            except (FileNotFoundError, ValueError):
                continue

            # Only process pages that are well-linked (>= 3 inbound)
            candidates = [item for item in all_items
                          if item.slug not in underlinked_slugs]

            logger.info(f"\n{tname}: {len(targets)} underlinked, "
                         f"{len(candidates)} candidates")

            completed = _load_progress("crosslink", tname) if resume else set()

            for i, item in enumerate(candidates, 1):
                if item.slug in completed:
                    continue

                time.sleep(rate_delay)
                result = editor.crosslink(item, target_info)
                logger.info(f"  [{i}/{len(candidates)}] {item.slug} -> {result}")

                if result not in ("failed (API error)",):
                    completed.add(item.slug)
                    _save_progress("crosslink", tname, completed)

            _clear_progress("crosslink", tname)
            logger.info(f"Done: crosslinked {tname}")

    def sanitize(self, topic_name: str = None) -> None:
        """Re-save pages with broken internal links to trigger auto-fix.

        No Claude API calls. Loads each page and calls save_index()
        which runs _sanitize_content() (fix #8: broken link strip/fix).
        """
        _check_git_clean()
        if topic_name:
            _validate_topic(topic_name)

        # Reuse _audit_content_quality to find pages with broken links
        quality = _audit_content_quality([topic_name] if topic_name else None)
        broken = quality["broken_links"]
        if not broken:
            logger.info("No broken links found.")
            return

        # Unique source pages
        sources = sorted(set(bl["source"] for bl in broken))
        logger.info(f"Sanitizing {len(sources)} pages with broken links...")

        fixed = 0
        for i, source_path in enumerate(sources, 1):
            parts = source_path.strip("/").split("/")
            if len(parts) < 2:
                continue
            try:
                item = Content.from_location(f"{parts[0]}/{parts[1]}")
                raw = item.index_path.read_text(encoding="utf-8")
                item.save_index(raw)
                fixed += 1
                logger.info(f"  [{i}/{len(sources)}] {source_path}")
            except Exception as e:
                logger.warning(f"  [{i}/{len(sources)}] {source_path}: {e}")

        logger.info(f"Done: sanitized {fixed} pages")

    def lint_fix(self, topic_name: str = None) -> dict:
        """Fix ALL lint issues: redirect links (free) then content via AI (~$0.01/page).

        Wire is opinionated: lint-fix fixes everything. No flags needed.
        1. Rewrites redirect links (free, no API)
        2. Builds site, lints, dispatches AI per page for remaining issues
        """
        # Step 1: fix redirect links first (free, no API)
        redirect_stats = self._lint_fix_redirects(topic_name)

        # Step 2: AI-powered content fixes for ALL remaining lint issues
        content_stats = self._lint_fix_content(topic_name)

        return {
            "redirect_fixes": redirect_stats.get("fixed", 0),
            "content_fixes": content_stats.get("fixed", 0),
            "pages": content_stats.get("pages", 0),
        }

    def _lint_fix_redirects(self, topic_name: str = None) -> dict:
        """Fix redirect links in markdown source files (no API calls)."""
        import re as _re
        if topic_name:
            _validate_topic(topic_name)

        redirects = load_redirects()
        if not redirects:
            logger.info("No redirects configured — nothing to fix.")
            return {"fixed": 0, "files": 0}

        # Build redirect map: source → {to, status}
        redirect_map = {}
        for r in redirects:
            src = r.get("from", "")
            if not src:
                continue
            # Normalize trailing slash
            if not src.endswith("/"):
                src += "/"
            redirect_map[src] = {
                "to": r.get("to", ""),
                "status": r.get("status", 301),
            }

        # Find all markdown files
        if topic_name:
            search_dir = tools.DOCS_DIR / topic_name
        else:
            search_dir = tools.DOCS_DIR

        if not search_dir.exists():
            logger.warning(f"Directory not found: {search_dir}")
            return {"fixed": 0, "files": 0}

        md_files = sorted(search_dir.glob("**/index.md"))
        total_fixed = 0
        files_fixed = 0

        # Regex for markdown links: [text](url)
        link_pattern = _re.compile(r'\[([^\]]*)\]\((/[^)]+)\)')

        for md_file in md_files:
            content = md_file.read_text(encoding="utf-8")
            original = content
            file_fixes = 0

            def replace_link(match):
                nonlocal file_fixes
                text = match.group(1)
                href = match.group(2)
                # Normalize for lookup
                clean = href.split("#")[0]
                if not clean.endswith("/"):
                    clean += "/"
                if clean in redirect_map:
                    entry = redirect_map[clean]
                    file_fixes += 1
                    if entry["status"] == 410 or not entry["to"]:
                        # Gone — strip to plain text
                        return text
                    # Rewrite to target, preserve anchor
                    anchor = ""
                    if "#" in href:
                        anchor = "#" + href.split("#", 1)[1]
                    return f"[{text}]({entry['to']}{anchor})"
                return match.group(0)

            content = link_pattern.sub(replace_link, content)

            if file_fixes > 0:
                total_fixed += file_fixes
                files_fixed += 1
                rel = md_file.relative_to(tools.DOCS_DIR)
                md_file.write_text(content, encoding="utf-8")
                logger.info(f"  Fixed {file_fixes} link(s) in {rel}")

        if total_fixed > 0:
            logger.info(
                f"Fixed {total_fixed} redirect link(s) across "
                f"{files_fixed} file(s)")
        else:
            logger.info("No redirect links found — all links are clean.")

        return {"fixed": total_fixed, "files": files_fixed}

    def _lint_fix_content(self, topic_name: str = None) -> dict:
        """AI-powered lint fix: dispatch Claude per page for ALL lint issues (#183).

        Builds the site, lints, groups ALL issues by page, sends each affected
        page to Claude with its specific lint issues and guard-rails.
        Sequential processing — no parallel agents (they clobber each other).

        Uses Haiku for mechanical work (cheap, fast, sufficient for 80% of rules).
        """
        import frontmatter as fm

        LINT_FIX_MODEL = "claude-haiku-4-5-20251001"

        # 1. Build site to get HTML for linting
        site_dir = Path.cwd()
        logger.info("lint-fix: building site for lint analysis...")
        result = build(str(site_dir), run_lint=False, run_qa=False)
        if result["errors"]:
            logger.error("Build has gate errors. Fix those first.")
            return {"fixed": 0, "pages": 0, "errors": result["errors"]}

        output_dir = site_dir / "site"
        config = load_config(site_dir)

        # 2. Lint the built site
        lint_results = lint_site(str(output_dir),
                                 site_url=config.get("site_url"))
        if not lint_results:
            logger.info("Lint clean. Nothing to fix.")
            return {"fixed": 0, "pages": 0}

        # 3. Group ALL issues by page URL (no filtering — fix everything)
        by_page = {}
        for r in lint_results:
            if r.url not in by_page:
                by_page[r.url] = []
            by_page[r.url].append(r)

        if not by_page:
            logger.info("No fixable issues found.")
            return {"fixed": 0, "pages": 0}

        # Count rules for startup message
        rule_counts = {}
        for issues in by_page.values():
            for r in issues:
                rule_counts[r.rule_id] = rule_counts.get(r.rule_id, 0) + 1
        rule_summary = ", ".join(f"{rid}: {cnt}" for rid, cnt in
                                 sorted(rule_counts.items()))
        logger.info(
            f"lint-fix: {sum(len(v) for v in by_page.values())} issue(s) "
            f"across {len(by_page)} page(s)\n"
            f"  Rules: {rule_summary}\n"
            f"  Model: {LINT_FIX_MODEL} (API fallback)\n"
            f"  Cost: $0 via CLI (Max subscription), "
            f"~${len(by_page) * 0.01:.2f} via API fallback")

        # 4. Map page URLs back to markdown source files
        docs_dir = config["docs_dir"]
        if topic_name:
            search_dir = docs_dir / topic_name
        else:
            search_dir = docs_dir

        # Build URL → source file mapping
        url_to_source = {}
        for md_file in search_dir.rglob("index.md"):
            rel = md_file.relative_to(docs_dir)
            parent = rel.parent
            parent_str = str(parent).replace("\\", "/")
            url = f"/{parent_str}/" if parent_str != "." else "/"
            url_to_source[url] = md_file

        # 5. Process each page sequentially
        pages_fixed = 0
        total_issues = 0

        # Multi-language: lint URLs have lang prefix (/en/about/) but source
        # mapping has unprefixed URLs (/about/). Try stripping prefix. (#187)
        def _find_source(page_url):
            if page_url in url_to_source:
                return url_to_source[page_url]
            # Strip 2-letter lang prefix
            parts = page_url.strip("/").split("/", 1)
            if len(parts) >= 2 and len(parts[0]) == 2:
                stripped = "/" + parts[1]
                if not stripped.endswith("/"):
                    stripped += "/"
                if stripped in url_to_source:
                    return url_to_source[stripped]
            return None

        for page_url, issues in sorted(by_page.items()):
            source = _find_source(page_url)
            if not source or not source.exists():
                logger.warning(f"  Skip {page_url} — no source file found")
                continue

            content = source.read_text(encoding="utf-8")
            issue_lines = "\n".join(
                f"- [{r.rule_id}] {r.message}" for r in issues)

            # Build sibling list for link-adding rules
            # Detect lang prefix from the page URL (e.g. /en/ from /en/build/ai-agents/)
            _url_parts = page_url.strip("/").split("/")
            _lang_prefix = f"/{_url_parts[0]}" if len(_url_parts) >= 2 and len(_url_parts[0]) == 2 else ""

            siblings = ""
            if any(r.rule_id in ("RULE-71", "RULE-78", "RULE-85", "RULE-92")
                   for r in issues):
                parent = source.parent.parent
                sibs = []
                for d in sorted(parent.iterdir()):
                    if d.is_dir() and d != source.parent and (d / "index.md").exists():
                        sib_post = fm.load(d / "index.md")
                        sib_title = sib_post.get("title", d.name)
                        sib_rel = d.relative_to(docs_dir)
                        sib_url = f"/{str(sib_rel).replace(chr(92), '/')}/"
                        sibs.append(f"- {sib_url}")
                if sibs:
                    siblings = "\nSIBLING PAGES:\n" + "\n".join(sibs[:5])

            prompt = f"""Fix lint issues in this markdown file. Return the COMPLETE file (frontmatter + body).

URL: {page_url}

LINT ISSUES TO FIX:
{issue_lines}
{siblings}

CURRENT FILE CONTENT:
```
{content}
```

CRITICAL RULES:
- Use ONLY markdown [text](url), NEVER raw HTML <a> tags
- Do NOT add a links section at the bottom — add links inline on first mention
- Do NOT rewrite content beyond what is necessary to fix the listed issues
- NEVER delete frontmatter keys. Keep ALL original keys. Only modify values
- If you add a colon in a YAML value, wrap the entire value in quotes
- Do NOT change heading structure or heading text
- Do NOT remove existing internal or external links
- Do NOT use generic anchor text: "click here", "read more", "learn more"
- Do NOT add links with fragments like /page/#section
- Do NOT use em dashes (—), en dashes (–), or spaced hyphens ( - ) anywhere
- Do NOT add loading="lazy" to images

Return ONLY the complete file content. No explanation, no markdown fences."""

            logger.info(f"  Fixing {page_url} ({len(issues)} issue(s))...")
            fixed = claude_text(prompt, f"lint-fix {page_url}",
                                max_tokens=8000, model=LINT_FIX_MODEL)
            if not fixed:
                logger.warning(f"  No response for {page_url} — skipping")
                continue

            # Strip markdown fences and language prefixes from AI output (#195)
            for prefix in ("```markdown\n", "```yaml\n", "```md\n", "```\n"):
                if fixed.startswith(prefix):
                    fixed = fixed[len(prefix):]
                    if fixed.endswith("```"):
                        fixed = fixed[:-3]
            for prefix in ("yaml\n", "markdown\n", "md\n"):
                if fixed.startswith(prefix):
                    fixed = fixed[len(prefix):]

            # Validate: must still have frontmatter
            if "---" not in fixed[:10]:
                logger.warning(f"  Bad response for {page_url} — no frontmatter")
                continue

            # Validate YAML parses correctly before saving (#194)
            try:
                fixed_post = fm.loads(fixed.strip())
            except Exception as yaml_err:
                logger.warning(f"  Bad YAML in response for {page_url} — skipping ({yaml_err})")
                continue

            # Validate no frontmatter keys were deleted (#189)
            original_post = fm.loads(content)
            deleted_keys = set(original_post.metadata.keys()) - set(fixed_post.metadata.keys())
            if deleted_keys:
                logger.warning(
                    f"  Agent deleted frontmatter key(s) {deleted_keys} "
                    f"for {page_url} — skipping")
                continue

            source.write_text(fixed.strip() + "\n", encoding="utf-8")
            pages_fixed += 1
            total_issues += len(issues)
            logger.info(f"  Saved {page_url}")

        logger.info(f"Done: fixed {total_issues} issue(s) across {pages_fixed} page(s)")
        return {"fixed": total_issues, "pages": pages_fixed}

    def redirects(self) -> dict:
        """Analyze GSC coverage gaps and generate strict redirects.

        Finds every GSC URL with impressions that has no page and no redirect.
        Tries strict matching only (exact slug + lang prefix, WordPress cruft).
        Fails loud on unresolvable URLs — never falls back to homepage.

        No Claude API calls. Returns stats dict.
        """
        init_db()

        gsc_urls = get_gsc_urls()
        if not gsc_urls:
            logger.info("No GSC URL discovery data. Run `data` first.")
            return {"resolved": 0, "manual": 0, "total_gaps": 0}

        # Build page paths from filesystem
        page_paths = set()
        # Include root-level pages (homepage, legal pages, etc.)
        if (tools.DOCS_DIR / "index.md").exists():
            page_paths.add("/")
        for md_file in tools.DOCS_DIR.glob("*.md"):
            if md_file.name.startswith("_") or md_file.name == "index.md":
                continue
            page_paths.add(f"/{md_file.stem}/")
        for tname in list_topics():
            page_paths.add(f"/{tname}/")
            try:
                topic = Topic(tname)
                for item in topic.list():
                    page_paths.add(item.path.rstrip("/") + "/")
            except (FileNotFoundError, ValueError):
                pass

        existing_redirects = load_redirects()

        # Detect active language
        lang = tools._ACTIVE_LANG or ""

        # Find gaps using shared function (same as audit)
        exclude = WIRE_CONFIG.get("exclude_gsc_data_for_path", [])
        gaps = find_gsc_coverage_gaps(
            page_paths, existing_redirects,
            exclude_prefixes=exclude or None,
            gsc_urls=gsc_urls)

        if not gaps:
            logger.info("All GSC URLs are covered by pages or redirects.")
            return {"resolved": 0, "manual": 0, "total_gaps": 0}

        # Sort by impressions (highest first)
        gaps.sort(key=lambda g: g["impressions"], reverse=True)
        total_impressions = sum(g["impressions"] for g in gaps)
        logger.info(f"\n{len(gaps)} GSC URL(s) with {total_impressions:,} "
                    f"total impressions have no page or redirect.\n")

        # Try strict matching
        resolved = []
        manual = []
        for gap in gaps:
            target = _match_redirect(gap["path"], page_paths, lang)
            if target is not None:
                resolved.append({**gap, "target": target})
            else:
                manual.append(gap)

        # Apply resolved redirects
        if resolved:
            logger.info(f"Auto-resolved: {len(resolved)} redirect(s)")
            for r in resolved:
                status = 410 if r["target"] == "410" else 301
                to = "" if status == 410 else r["target"]
                from wire.tools import add_redirect
                add_redirect(r["path"], to,
                             reason="auto: GSC coverage gap",
                             status=status)
                logger.info(f"  {r['path']} -> {r['target']} "
                            f"({r['impressions']} imp)")

        # Fail loud on unresolvable
        if manual:
            manual_impressions = sum(m["impressions"] for m in manual)
            logger.error(
                f"\n{len(manual)} URL(s) with {manual_impressions:,} "
                f"impressions could not be auto-resolved.\n"
                f"Add redirects manually in wire.yml:\n"
                f"\n  redirects:"
            )
            for m in manual[:20]:
                logger.error(f"    {m['path']}: /target/path/  "
                             f"# {m['impressions']} impressions")
            if len(manual) > 20:
                logger.error(f"    # ... and {len(manual) - 20} more")
            logger.error(
                "\nWire does not guess redirect targets. "
                "Every URL above needs a specific destination "
                "or a 410 (Gone) entry."
            )
            raise SystemExit(1)

        return {"resolved": len(resolved), "manual": len(manual),
                "total_gaps": len(gaps)}

    def translate(self, topic_name: str = None,
                  resume: bool = False) -> dict:
        """Translate page bodies to match their language directory.

        Detects pages where body language doesn't match the expected language
        (via stopword analysis), then uses claude_text() to translate.

        Requires --lang to be set (determines target language).
        Uses prompts/translate.md with styleguide injection.

        Returns stats dict: {translated, skipped, failed}.
        """
        from wire.build import _detect_language

        if topic_name:
            _validate_topic(topic_name)

        # Determine target language from _ACTIVE_LANG
        try:
            from wire.tools import _ACTIVE_LANG
            target_lang = _ACTIVE_LANG
        except ImportError:
            target_lang = ""

        if not target_lang:
            raise SystemExit(
                "BUILD REFUSED: translate requires --lang. "
                "Example: python -m wire.chief translate --lang de")

        lang_names = {
            "de": "German", "en": "English", "es": "Spanish", "fr": "French",
        }
        target_name = lang_names.get(target_lang, target_lang)
        source_name = "English"  # default assumption

        # Load styleguide: base layer always, customer expands
        styleguide_parts = []
        builtin = FALLBACK_PROMPTS_DIR / "_style.md"
        if builtin.exists():
            styleguide_parts.append(builtin.read_text(encoding="utf-8"))
        styleguide_path = tools.DOCS_DIR / "_styleguide.md"
        if styleguide_path.exists():
            sg_content = styleguide_path.read_text(encoding="utf-8")
            # Refuse if styleguide language doesn't match target (#95).
            # Wrong-language styleguide → translations read like translated
            # English instead of native target language.
            sg_lang = _detect_language(sg_content)
            if sg_lang and sg_lang != target_lang:
                raise SystemExit(
                    f"BUILD REFUSED: styleguide at {styleguide_path} is in "
                    f"{lang_names.get(sg_lang, sg_lang)} but target language "
                    f"is {target_name}.\n"
                    f"  Fix: translate _styleguide.md to {target_name} first.\n"
                    f"  The styleguide teaches voice and tone — wrong language "
                    f"means all {target_name} translations will sound foreign.")
            styleguide_parts.append(sg_content)
        styleguide = "\n\n".join(styleguide_parts)

        # Load prompt template
        prompt_path = FALLBACK_PROMPTS_DIR / "translate.md"
        if not prompt_path.exists():
            raise SystemExit(
                f"Missing prompt template: {prompt_path}")
        prompt_template = prompt_path.read_text(encoding="utf-8")

        # Find pages needing translation
        if topic_name:
            search_dirs = [tools.DOCS_DIR / topic_name]
        else:
            search_dirs = [
                d for d in tools.DOCS_DIR.iterdir()
                if d.is_dir() and not d.name.startswith("_")
                and not d.name.startswith(".")
            ]

        pages_to_translate = []
        for search_dir in search_dirs:
            for md_file in sorted(search_dir.glob("**/index.md")):
                try:
                    post = fm.load(str(md_file))
                    body = post.content.strip()
                    if not body or len(body.split()) < 50:
                        continue
                    detected = _detect_language(body)
                    if detected and detected != target_lang:
                        rel = md_file.relative_to(tools.DOCS_DIR)
                        pages_to_translate.append({
                            "path": md_file,
                            "rel": str(rel),
                            "body": body,
                            "meta": dict(post.metadata),
                            "detected": detected,
                        })
                except Exception as e:
                    logger.warning(
                        f"Skipping {md_file}: {e}\n"
                        f"  Fix: check YAML frontmatter — colons in values "
                        f"need quoting (title: \"Value: with colon\")")

        if not pages_to_translate:
            logger.info(
                f"No untranslated pages found for '{target_lang}'. "
                f"All pages match their language directory.")
            return {"translated": 0, "skipped": 0, "failed": 0}

        TRANSLATE_MODEL = "claude-sonnet-4-6"
        logger.info(
            f"Found {len(pages_to_translate)} pages needing translation "
            f"to {target_name}\n"
            f"  Model: {TRANSLATE_MODEL} (subprocess, not your CLI default)\n"
            f"  Cost: ~${len(pages_to_translate) * 0.01:.2f}")

        # Resume support
        completed = _load_progress("translate", topic_name or "all") if resume else set()
        stats = {"translated": 0, "skipped": 0, "failed": 0}

        site_name = SITE.title if SITE else "the site"

        # Fields to translate in frontmatter (#229)
        _FM_TEXT_FIELDS = ("title", "description", "short_title")

        def _translate_body(body_text, desc, min_chars=50):
            """Translate a single body via Claude. Returns translated text or None."""
            prompt = prompt_template.format(
                site_name=site_name,
                source_lang=lang_names.get(page["detected"], page["detected"]),
                target_lang=target_name,
                target_lang_code=target_lang,
                styleguide=styleguide,
                content=body_text,
            )
            result = claude_text(
                prompt,
                description=desc,
                max_tokens=8000,
                temperature=0.3,
                model=TRANSLATE_MODEL,
            )
            if not result or len(result.strip()) < min_chars:
                return None
            return result

        def _translate_frontmatter(meta, desc):
            """Translate title/description/short_title via Claude (#229).

            Returns dict with translated text fields merged into meta.
            Non-text fields (created, wire_action, etc.) are preserved.
            """
            fields = {k: meta[k] for k in _FM_TEXT_FIELDS
                      if k in meta and isinstance(meta[k], str)}
            if not fields:
                return meta

            fm_block = "\n".join(f"{k}: {v}" for k, v in fields.items())
            prompt = (
                f"Translate these FRONTMATTER fields from "
                f"{lang_names.get(page['detected'], page['detected'])} "
                f"to {target_name}.\n\n"
                f"Rules:\n"
                f"- Return ONLY the translated fields in the same format\n"
                f"- One field per line: key: value\n"
                f"- Keep the exact key names (title, description, short_title)\n"
                f"- Brand names stay untranslated\n"
                f"- No explanations, no extra lines\n\n"
                f"{fm_block}"
            )
            result = claude_text(
                prompt,
                description=f"translate frontmatter {desc}",
                max_tokens=500,
                temperature=0.3,
                model=TRANSLATE_MODEL,
            )
            translated_meta = dict(meta)
            if result:
                for line in result.strip().splitlines():
                    line = line.strip()
                    if ": " in line:
                        key, _, value = line.partition(": ")
                        key = key.strip()
                        if key in _FM_TEXT_FIELDS:
                            translated_meta[key] = value.strip()
            return translated_meta

        for i, page in enumerate(pages_to_translate, 1):
            slug = page["rel"]
            if slug in completed:
                # #238: verify page is actually translated before skipping
                detected_now = _detect_language(page["body"])
                if detected_now and detected_now != target_lang:
                    logger.info(
                        f"  [{i}/{len(pages_to_translate)}] {slug} "
                        f"marked complete but still in {detected_now} — "
                        f"re-translating")
                else:
                    stats["skipped"] += 1
                    continue

            logger.info(
                f"  [{i}/{len(pages_to_translate)}] {slug} "
                f"({page['detected']} → {target_lang})")

            try:
                # 1. Translate index.md
                result = _translate_body(
                    page["body"], f"translate {slug}")

                if not result:
                    logger.warning(f"    Empty or too short translation — skipping")
                    stats["failed"] += 1
                    continue

                # Translate frontmatter text fields (#229)
                translated_meta = _translate_frontmatter(
                    page["meta"], slug)
                write_md(page["path"], translated_meta, result)

                # 2. Translate steps.md if present
                page_dir = page["path"].parent
                steps_path = page_dir / "steps.md"
                if steps_path.exists():
                    steps_body = steps_path.read_text(encoding="utf-8").strip()
                    if steps_body:
                        logger.info(f"    Translating steps.md")
                        steps_result = _translate_body(
                            steps_body, f"translate {slug}/steps.md",
                            min_chars=20)
                        if not steps_result:
                            raise RuntimeError(
                                f"Failed to translate steps.md for {slug} — "
                                f"refusing partial translation")
                        steps_path.write_text(steps_result, encoding="utf-8")

                # 3. Translate news files if present
                news_dir = page_dir / "news"
                if news_dir.exists() and news_dir.is_dir():
                    news_files = sorted(
                        f for f in news_dir.iterdir()
                        if f.is_file() and f.suffix == ".md"
                    )
                    for nf in news_files:
                        try:
                            news_post = fm.load(str(nf))
                            news_body = news_post.content.strip()
                            if not news_body or len(news_body.split()) < 10:
                                continue
                            logger.info(f"    Translating news/{nf.name}")
                            news_result = _translate_body(
                                news_body,
                                f"translate {slug}/news/{nf.name}",
                                min_chars=20)
                            if news_result:
                                # Translate news frontmatter too (#229)
                                news_meta = _translate_frontmatter(
                                    dict(news_post.metadata),
                                    f"{slug}/news/{nf.name}")
                                write_md(nf, news_meta, news_result)
                            else:
                                logger.warning(
                                    f"    News translation too short: {nf.name}")
                        except Exception as e:
                            logger.warning(
                                f"    Failed to translate news/{nf.name}: {e}")

                # 4. Copy assets directory if present
                assets_dir = page_dir / "assets"
                if assets_dir.exists() and assets_dir.is_dir():
                    logger.info(f"    Assets directory present (already in place)")

                stats["translated"] += 1
                completed.add(slug)
                _save_progress("translate", topic_name or "all", completed)

            except Exception as e:
                logger.error(f"    Translation failed: {e}")
                stats["failed"] += 1

        logger.info(
            f"Done: {stats['translated']} translated, "
            f"{stats['skipped']} skipped, {stats['failed']} failed")

        return stats

    def relink(self, topic_name: str = None) -> dict:
        """Rewrite internal link prefixes after translate (#234).

        Mechanically rewrites /en/foo/ → /de/foo/ (or whatever lang pair)
        in all markdown files. Zero AI calls, zero cost.

        Requires --lang to determine the target language prefix.
        """
        try:
            from wire.tools import _ACTIVE_LANG
            target_lang = _ACTIVE_LANG
        except ImportError:
            target_lang = ""

        if not target_lang:
            raise SystemExit(
                "BUILD REFUSED: relink requires --lang. "
                "Example: python -m wire.chief relink --lang de")

        # Determine which lang prefixes to rewrite FROM
        known_langs = {"de", "en", "es", "fr"}
        source_langs = known_langs - {target_lang}

        if topic_name:
            _validate_topic(topic_name)
            search_dirs = [tools.DOCS_DIR / topic_name]
        else:
            search_dirs = [
                d for d in tools.DOCS_DIR.iterdir()
                if d.is_dir() and not d.name.startswith("_")
                and not d.name.startswith(".")
            ]

        stats = {"rewritten": 0, "links_fixed": 0, "skipped": 0}
        link_pattern = re.compile(
            r'\]\((/(?:' + '|'.join(source_langs) + r')/)([^)]*)\)')

        for search_dir in search_dirs:
            for md_file in sorted(search_dir.glob("**/*.md")):
                try:
                    content = md_file.read_text(encoding="utf-8")
                except Exception:
                    stats["skipped"] += 1
                    continue

                matches = link_pattern.findall(content)
                if not matches:
                    stats["skipped"] += 1
                    continue

                # Rewrite all source lang prefixes to target
                new_content = link_pattern.sub(
                    rf'](/{target_lang}/\2)', content)

                if new_content != content:
                    md_file.write_text(new_content, encoding="utf-8")
                    link_count = len(matches)
                    stats["rewritten"] += 1
                    stats["links_fixed"] += link_count
                    logger.info(
                        f"  {md_file.relative_to(tools.DOCS_DIR)}: "
                        f"{link_count} link(s) rewritten")
                else:
                    stats["skipped"] += 1

        logger.info(
            f"Relink done: {stats['rewritten']} files updated, "
            f"{stats['links_fixed']} links fixed, "
            f"{stats['skipped']} skipped")

        return stats

    def generate_newsweek(self, from_date: str = None, to_date: str = None,
                          skip_review: bool = False,
                          resynth: bool = False) -> str:
        """Generate market intelligence report from news files.

        Default: last 7 days ending today.
        Three phases: extract -> synthesize -> review.
        Output: docs/news/YYYY-MM-DD-news/index.md

        resynth=True skips Phase 1 and re-uses cached extracts (saves ~$2 and 20 min).
        """
        _check_styleguide()
        # 1. Date range (default: last 7 days)
        today = datetime.now()
        if to_date is None:
            to_date = today.strftime('%Y-%m-%d')
        if from_date is None:
            from_date = (today - timedelta(days=7)).strftime('%Y-%m-%d')

        # Validate date format
        for label, date_str in [("from", from_date), ("to", to_date)]:
            try:
                datetime.strptime(date_str, '%Y-%m-%d')
            except ValueError:
                raise ValueError(f"Invalid --{label} date: '{date_str}'. Use YYYY-MM-DD format.")

        logger.info(f"Newsweek: {from_date} to {to_date}")

        # 2a. Prerequisite: check news freshness (skip when resynthesizing)
        if not resynth:
            _check_newsweek_prerequisites(from_date, to_date)

        # 2. Collect news files across all topics
        news_files = _collect_news(from_date, to_date)
        if not news_files:
            raise ValueError(
                f"Newsweek refused: no news files found for {from_date} to {to_date}. "
                "Run: python -m wire.chief news <topic>"
            )

        topics_found = set(f['topic'] for f in news_files)
        logger.info(f"Newsweek: {len(news_files)} news files across "
                     f"{len(topics_found)} topics ({', '.join(sorted(topics_found))})")

        # 3. Phase 1: Extract + Rate (batched) — or load from cache
        if resynth:
            extracts = _load_cached_extracts(to_date)
            if extracts:
                logger.info(f"Phase 1: loaded {len(extracts)} cached extract batches")
            else:
                logger.info("Newsweek: no cached extracts found, running Phase 1")
                resynth = False

        if not resynth:
            batches = _batch_news(news_files)
            logger.info(f"Phase 1: extracting from {len(batches)} batches...")

            # Thread-safe collection of (index, extract_text)
            extract_results = []
            extract_lock = threading.Lock()

            class _BatchItem:
                """Wrapper for batch with .slug for _run_batch compatibility."""
                def __init__(self, idx, batch):
                    self.slug = f"batch-{idx}"
                    self.idx = idx
                    self.batch = batch

            batch_items = [_BatchItem(i, b) for i, b in enumerate(batches, 1)]

            def process_batch(bitem):
                prompt = _load_newsweek_prompt(
                    "newsweek_extract",
                    batch_label=f"Batch {bitem.idx}/{len(batches)}",
                    batch_content=_format_batch(bitem.batch, from_date=from_date),
                    from_date=from_date, to_date=to_date)
                result = claude_text(prompt, f"Newsweek extract {bitem.idx}/{len(batches)}",
                                     max_tokens=4000, temperature=0.2)
                if result:
                    with extract_lock:
                        extract_results.append((bitem.idx, result))
                    return f"extracted ({len(result)} chars)", True
                return "no result", False

            _run_batch(batch_items, process_batch, command="newsweek_extract",
                       topic="all", workers=self.workers, completed=set())

            # Sort by batch index to preserve order
            extract_results.sort(key=lambda x: x[0])
            extracts = [text for _, text in extract_results]

            if not extracts:
                logger.info("Newsweek: Phase 1 failed (no extracts)")
                return "failed (no extracts)"

            # Cache extracts for re-synthesis
            cache_path = _save_extracts(extracts, to_date)
            logger.info(f"Phase 1 complete: {len(extracts)} extract batches "
                        f"(cached: {cache_path})")

        # 3b. Filter extracts to ★★★+ only for Phase 2
        raw_count = sum(len(e) for e in extracts)
        extracts = _filter_extracts(extracts)
        filtered_count = sum(len(e) for e in extracts)
        logger.info(f"Filtered extracts: {raw_count:,} → {filtered_count:,} chars "
                     f"({100 * filtered_count // max(raw_count, 1)}% kept)")

        # 4. GSC trending keywords (Chief's market intelligence)
        trending = ""
        kws = trending_keywords(limit=30)
        if kws:
            trending = _format_trending(kws)
            logger.info(f"GSC: {len(kws)} trending keywords loaded")

        # 5. Phase 2: Synthesize (Chief writes the report)
        styleguide = _load_styleguide()
        previous = _load_previous_newsweek()
        site_dir = generate_site_directory(full=True)

        combined_extracts = "\n\n---\n\n".join(extracts)
        unique_slugs = set(f['slug'] for f in news_files)

        logger.info(f"Phase 2: synthesizing report...")
        prompt = _load_newsweek_prompt(
            "newsweek_synthesize",
            styleguide=styleguide,
            trending_keywords=trending or "No GSC data available.",
            site_directory=site_dir,
            previous_report=previous or "No previous report available.",
            extracts=combined_extracts,
            total_items=len(unique_slugs),
            total_files=len(news_files),
            from_date=from_date, to_date=to_date)

        draft = claude_text(prompt, "Newsweek synthesize",
                            max_tokens=16000, temperature=0.3)
        if not draft:
            logger.info("Newsweek: Phase 2 failed (synthesis error)")
            return "failed (synthesis error)"

        logger.info(f"Phase 2 complete: {len(draft)} chars draft")

        # 6. Phase 3: Review (optional)
        if not skip_review:
            logger.info("Phase 3: editorial review...")
            review_prompt = _load_newsweek_prompt(
                "newsweek_review",
                site_directory=site_dir, draft_report=draft)
            reviewed = claude_text(review_prompt, "Newsweek review",
                                   max_tokens=16000, temperature=0.2)
            if reviewed:
                draft = reviewed
                logger.info(f"Phase 3 complete: {len(draft)} chars reviewed")
            else:
                logger.info("Phase 3: review failed, using draft")

        # 7. Save
        output_path = _save_newsweek(draft, to_date)
        logger.info(f"Newsweek saved: {output_path}")
        return f"newsweek saved: {output_path} ({len(news_files)} files, {len(topics_found)} topics)"


def migrate_lang(from_lang: str, add_langs: list[str]) -> dict:
    """Scaffold multi-language site from single-language.

    Moves docs/* → docs/{from_lang}/, creates stubs for each add_lang,
    updates wire.yml with languages config, generates redirects.

    Returns stats dict: {pages_moved, redirects_generated, langs_added}.
    Raises SystemExit if site is already multi-language.
    """
    import yaml

    cwd = Path.cwd()
    wire_yml = cwd / "wire.yml"

    if not wire_yml.exists():
        raise SystemExit(
            "BUILD REFUSED: No wire.yml found. "
            "Run from a site directory.")

    config = yaml.safe_load(wire_yml.read_text(encoding="utf-8")) or {}

    # Refuse if already multi-language
    if config.get("languages"):
        raise SystemExit(
            "BUILD REFUSED: Site already has languages configured in wire.yml.\n"
            "  migrate-lang is for converting single-language sites only.")

    docs_dir_name = config.get("docs_dir", "docs")
    docs_dir = cwd / docs_dir_name

    if not docs_dir.is_dir():
        raise SystemExit(
            f"BUILD REFUSED: docs_dir '{docs_dir}' does not exist.")

    # Validate from_lang isn't in add_langs
    if from_lang in add_langs:
        raise SystemExit(
            f"BUILD REFUSED: --from language '{from_lang}' cannot also be in --add list.")

    all_langs = [from_lang] + list(add_langs)

    # Collect all pages (markdown files) for redirect generation
    # Do this BEFORE moving files
    page_paths = []
    for md_file in sorted(docs_dir.rglob("*.md")):
        rel = md_file.relative_to(docs_dir)
        # Skip hidden/private files
        if any(part.startswith("_") or part.startswith(".") for part in rel.parts):
            continue
        # Convert file path to URL path
        rel_str = rel.as_posix()
        if rel_str == "index.md":
            page_paths.append("/")
        elif rel_str.endswith("/index.md"):
            page_paths.append("/" + rel_str[:-len("index.md")])
        else:
            page_paths.append("/" + rel_str[:-len(".md")] + "/")

    # Generate redirects: old path → /{from_lang}/path
    redirects = []
    for path in page_paths:
        if path == "/":
            new_path = f"/{from_lang}/"
        else:
            new_path = f"/{from_lang}{path}"

        # Filter query-param URLs (safety net)
        if "?" in path or "=" in path or path.startswith("http"):
            continue

        # No self-redirects
        if path.rstrip("/") == new_path.rstrip("/"):
            raise SystemExit(
                f"BUILD REFUSED: self-redirect detected: {path} → {new_path}")

        redirects.append({"from": path, "to": new_path, "status": 301})

    stats = {
        "pages_moved": len(page_paths),
        "redirects_generated": len(redirects),
        "langs_added": len(add_langs),
    }

    # Step 1: Move docs/* → docs/{from_lang}/
    from_dir = docs_dir / from_lang
    from_dir.mkdir(parents=True, exist_ok=True)

    # Move all contents of docs/ into docs/{from_lang}/
    for item in sorted(docs_dir.iterdir()):
        if item.name == from_lang:
            continue  # Don't move the target dir into itself
        if any(item.name == lang for lang in add_langs):
            continue  # Don't move existing lang dirs
        shutil.move(str(item), str(from_dir / item.name))

    logger.info(f"Moved {docs_dir}/* → {from_dir}/")

    # Step 2: Create stub directories for new languages
    _LANG_NAMES = {
        "de": "Deutsch", "en": "English", "es": "Español", "fr": "Français",
        "it": "Italiano", "pt": "Português", "nl": "Nederlands", "pl": "Polski",
        "ja": "日本語", "zh": "中文", "ko": "한국어", "ru": "Русский",
        "ar": "العربية", "tr": "Türkçe", "sv": "Svenska", "da": "Dansk",
    }

    site_name = config.get("site_name", "Site")
    for lang in add_langs:
        lang_dir = docs_dir / lang
        lang_dir.mkdir(parents=True, exist_ok=True)
        lang_name = _LANG_NAMES.get(lang, lang)
        (lang_dir / "index.md").write_text(
            f"---\ntitle: {site_name}\n"
            f"description: {site_name} — {lang_name}\n---\n\n"
            f"# {site_name}\n",
            encoding="utf-8")
        logger.info(f"Created {lang_dir}/ with homepage stub")

    # Step 3: Update wire.yml
    # Build languages config
    from_name = _LANG_NAMES.get(from_lang, from_lang)
    languages_config = []
    for lang in all_langs:
        lang_name = _LANG_NAMES.get(lang, lang)
        entry = {
            "code": lang,
            "name": lang_name,
            "docs_dir": f"{docs_dir_name}/{lang}",
        }
        if lang == from_lang:
            entry["default"] = True
        languages_config.append(entry)

    config["languages"] = languages_config
    # Remove single-language 'lang' key — replaced by languages block
    config.pop("lang", None)

    wire_yml.write_text(
        yaml.dump(config, default_flow_style=False,
                  allow_unicode=True, sort_keys=False),
        encoding="utf-8")
    logger.info(f"Updated wire.yml with {len(all_langs)} language(s)")

    # Step 4: Write redirects to .wire/redirects.yml
    if redirects:
        wire_dir = cwd / ".wire"
        wire_dir.mkdir(parents=True, exist_ok=True)
        redirects_file = wire_dir / "redirects.yml"

        # Merge with existing redirects (if any)
        existing = []
        if redirects_file.exists():
            try:
                existing = yaml.safe_load(
                    redirects_file.read_text(encoding="utf-8")) or []
            except Exception:
                pass

        existing_from = {r["from"] for r in existing if isinstance(r, dict)}
        for r in redirects:
            if r["from"] not in existing_from:
                existing.append(r)

        redirects_file.write_text(
            yaml.dump(existing, default_flow_style=False,
                      allow_unicode=True, sort_keys=False),
            encoding="utf-8")
        logger.info(f"Wrote {len(redirects)} redirect(s) to {redirects_file}")

    logger.info(f"migrate-lang complete: {stats['pages_moved']} pages moved, "
                f"{stats['redirects_generated']} redirects, "
                f"{stats['langs_added']} language(s) added")
    return stats


def init_site():
    """Initialize a Wire site in the current directory.

    Generates wire.yml, _styleguide.md, and topic index.md files.
    If mkdocs.yml exists, migrates relevant settings to wire.yml.
    Opinionated defaults — works out of the box with zero config.
    """
    import yaml

    cwd = Path.cwd()
    wire_yml = cwd / "wire.yml"
    mkdocs_yml = cwd / "mkdocs.yml"
    docs_dir = None
    config = {}

    # --- Step 1: Generate wire.yml ---
    if wire_yml.exists():
        logger.info(f"wire.yml already exists — skipping")
        config = yaml.safe_load(wire_yml.read_text(encoding="utf-8")) or {}
        docs_dir = Path(config.get("docs_dir", "docs"))
    elif mkdocs_yml.exists():
        logger.info(f"Found mkdocs.yml — migrating to wire.yml")
        mk = yaml.safe_load(mkdocs_yml.read_text(encoding="utf-8")) or {}
        config = {
            "site_name": mk.get("site_name", cwd.name),
            "site_url": mk.get("site_url", f"https://{cwd.name}"),
            "description": mk.get("site_description", ""),
            "docs_dir": mk.get("docs_dir", "docs"),
            "templates_dir": "templates",
            "output_dir": "site",
        }
        # Migrate wire config if present
        wire_extra = mk.get("extra", {}).get("wire", {})
        if wire_extra:
            config["extra"] = {"wire": wire_extra}
        # Migrate theme colors if present
        theme = mk.get("theme", {})
        palette = theme.get("palette", {})
        if isinstance(palette, list) and palette:
            palette = palette[0]
        if isinstance(palette, dict):
            primary = palette.get("primary", "")
            accent = palette.get("accent", "")
            if primary or accent:
                config["theme"] = {}
                if primary:
                    config["theme"]["primary_color"] = primary
                if accent:
                    config["theme"]["accent_color"] = accent
        wire_yml.write_text(yaml.dump(config, default_flow_style=False,
                                       allow_unicode=True, sort_keys=False),
                            encoding="utf-8")
        logger.info(f"  Created wire.yml (migrated from mkdocs.yml)")
        docs_dir = Path(config.get("docs_dir", "docs"))
    else:
        # Fresh site — generate from scratch
        site_name = cwd.name.replace("-", " ").replace(".", " ").title()
        config = {
            "site_name": site_name,
            "site_url": f"https://{cwd.name}",
            "description": f"{site_name} — managed by Wire.",
            "docs_dir": "docs",
            "templates_dir": "templates",
            "output_dir": "site",
            "extra": {
                "wire": {
                    "default_refresh_days": 30,
                }
            },
        }
        wire_yml.write_text(yaml.dump(config, default_flow_style=False,
                                       allow_unicode=True, sort_keys=False),
                            encoding="utf-8")
        logger.info(f"  Created wire.yml for '{config['site_name']}'")
        docs_dir = Path("docs")
        docs_dir.mkdir(exist_ok=True)

    if docs_dir is None:
        docs_dir = Path("docs")

    # --- Step 2: Generate _styleguide.md if missing ---
    styleguide_path = docs_dir / "_styleguide.md"
    if not styleguide_path.exists():
        site_name = config.get("site_name", cwd.name)
        styleguide = (
            f"## Your Role: Content Strategist for {site_name}\n\n"
            f"You write for {config.get('site_url', cwd.name)}. "
            f"Your content is authoritative, evidence-based, and actionable.\n\n"
            f"## Audience\n\n"
            f"Decision-makers evaluating solutions. They are time-poor and "
            f"skeptical of marketing language. Lead with specifics.\n\n"
            f"## Tone\n\n"
            f"- Professional but not corporate\n"
            f"- Direct — say what you mean in the first sentence\n"
            f"- No superlatives ('best', 'leading', 'revolutionary')\n"
            f"- No em-dashes\n"
            f"- Active voice preferred\n\n"
            f"## SEO Structure Rules\n\n"
            f"- Title: 50-60 characters, primary keyword near front\n"
            f"- Description: 140-155 characters\n"
            f"- One H1 per page matching the title\n"
            f"- Use H2 for major sections, H3 for subsections\n"
            f"- No numbered headings (## 1. Section)\n"
            f"- First-mention-only internal linking\n"
            f"- Anchor text: 2-5 descriptive words, never 'click here'\n"
            f"- At least one external citation per page\n"
        )
        styleguide_path.write_text(styleguide, encoding="utf-8")
        logger.info(f"  Created {styleguide_path} (edit to match your brand)")
    else:
        logger.info(f"  _styleguide.md already exists — skipping")

    # --- Step 3: Discover and fix topics ---
    if not docs_dir.exists():
        docs_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"  Created {docs_dir}/")

    # Find all directories that could be topics
    topics_found = []
    topics_created = []
    for d in sorted(docs_dir.iterdir()):
        if not d.is_dir():
            continue
        if d.name.startswith((".", "_")):
            continue
        # Check for content pages (any subdirectory with index.md)
        has_content = any(
            (sub / "index.md").exists()
            for sub in d.iterdir() if sub.is_dir() and not sub.name.startswith((".", "_"))
        )
        index_path = d / "index.md"
        if index_path.exists():
            topics_found.append(d.name)
        elif has_content:
            # Create topic index.md
            topic_title = d.name.replace("-", " ").replace("_", " ").title()
            index_path.write_text(
                f"---\ntitle: {topic_title}\n"
                f"description: {topic_title} managed by Wire.\n---\n\n"
                f"Overview of {topic_title.lower()} content.\n",
                encoding="utf-8"
            )
            topics_created.append(d.name)
            topics_found.append(d.name)

    # --- Step 4: Templates ---
    # Wire's built-in templates (wire/templates/) are complete: canonical, OG,
    # JSON-LD, header, footer, TOC, reading progress, etc. Generating minimal
    # scaffold templates would override these defaults and cause 78+ lint errors.
    # Customers only need a templates/ dir when they want to customize.
    templates_dir = cwd / config.get("templates_dir", "templates")
    if templates_dir.exists():
        logger.info(f"  Found {templates_dir}/ — custom templates will "
                     f"override Wire defaults")
    else:
        logger.info("  No templates/ dir — using Wire's built-in defaults "
                     "(recommended)")

    # --- Step 5: Create .env template if missing ---
    env_path = cwd / ".env"
    if not env_path.exists():
        env_path.write_text(
            "# Required for content generation\n"
            "ANTHROPIC_API_KEY=sk-ant-...\n\n"
            "# Optional for SEO features\n"
            "# GOOGLE_CLIENT_ID=\n"
            "# GOOGLE_CLIENT_SECRET=\n",
            encoding="utf-8"
        )
        logger.info(f"  Created .env template (add your API key)")

    # --- Report ---
    logger.info("")
    logger.info("=" * 50)
    logger.info(f"Wire initialized: {config.get('site_name', cwd.name)}")
    logger.info(f"  Config:     {wire_yml}")
    logger.info(f"  Docs:       {docs_dir}/")
    logger.info(f"  Styleguide: {styleguide_path}")
    if topics_found:
        logger.info(f"  Topics:     {', '.join(topics_found)}")
    if topics_created:
        logger.info(f"  Created:    {', '.join(topics_created)} (topic index.md)")

    # Page count
    total_pages = sum(1 for _ in docs_dir.rglob("index.md"))
    logger.info(f"  Pages:      {total_pages}")

    logger.info("")
    logger.info("Next steps:")
    logger.info(f"  1. Edit .env — add your ANTHROPIC_API_KEY")
    logger.info(f"  2. Edit {styleguide_path} — customize for your brand")
    if not topics_found:
        logger.info(f"  3. Create content: python -m wire.content create <topic>/<slug>")
    else:
        logger.info(f"  3. Run audit:  python -m wire.chief audit")
        logger.info(f"  4. Build site: python -m wire.build --site .")


def main():
    from wire import __version__
    parser = argparse.ArgumentParser(
        description="Wire CLI - content pipeline for static sites",
        epilog="Recommended workflow:\n"
               "  #  command              cost         what it does\n"
               "  0. download [topic]     free         WordPress -> markdown conversion\n"
               "  1. data                 free         Pull GSC metrics into local DB\n"
               "  2. audit [topic]        free         SEO audit (read-only analysis)\n"
               "  3. deduplicate [topic]  ~$0.04/page  Merge/differentiate overlapping pages\n"
               "  4. news <topic>         ~$0.08/page  Gather news for stale items (>21 days)\n"
               "  5. refine <topic>       ~$0.03/page  Integrate pending news into pages\n"
               "  6. reword <topic>       ~$0.04/page  Tiered SEO rewrite (20% full + 30% light)\n"
               "  7. consolidate          ~$0.04/page  Create hub pages from comparisons\n"
               "  8. newsweek             ~$1.00       Weekly market intelligence report\n"
               "\n"
               "Example full run for 300 vendors:\n"
               "  news + refine: ~$5   |  reword: ~$3   |  newsweek: ~$1   |  total: ~$9\n"
               "\n"
               "Tips:\n"
               "  --nogsc      skip GSC lookups (new sites without search data)\n"
               "  --resume     pick up where interrupted (news, refine, reword)\n"
               "  --resynth    reuse cached newsweek extracts (~$0.10 vs ~$1.00)\n"
               "\n"
               "Single-page operations: python -m wire.content -h",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument('--version', action='version', version=f'wire {__version__}')
    parser.add_argument('--nogsc', action='store_true',
                        help='Skip GSC database lookups (for new sites without search data)')
    parser.add_argument('--lang', type=str, default=None,
                        help='Language code for multi-language sites (e.g., de, en)')
    subparsers = parser.add_subparsers(dest='command', required=True)

    # Init: set up Wire in current directory
    subparsers.add_parser('init',
        help='Initialize Wire in current directory (generates wire.yml, styleguide, templates)')

    # Data: pull GSC metrics
    data_parser = subparsers.add_parser('data',
        help='Pull GSC search data into local database')
    data_parser.add_argument('--force', action='store_true',
        help='Force re-fetch even if data is fresh')
    data_parser.add_argument('--workers', type=int, default=1, metavar='N',
        help='Concurrent workers (default: 1, max: 8)')

    # Audit: read-only SEO analysis
    audit_parser = subparsers.add_parser('audit',
        help='SEO audit: opportunities, gaps, overlaps, dead pages')
    audit_parser.add_argument('topic', nargs='?', default=None,
        help='Topic name (e.g., vendors). Omit for all topics.')
    audit_parser.add_argument('--min', type=int, default=3, dest='min_shared',
        help='Minimum shared keywords to flag (default: 3)')
    audit_parser.add_argument('--min-impressions', type=int, default=100,
        dest='min_impressions',
        help='Minimum shared impressions to report (default: 100)')

    # Deduplicate: merge/differentiate overlapping pages
    dedup_parser = subparsers.add_parser('deduplicate',
        help='Merge/differentiate keyword-cannibalizing pages')
    dedup_parser.add_argument('topic', nargs='?', default=None,
        help='Topic name (e.g., vendors). Omit for all topics.')
    dedup_parser.add_argument('--min', type=int, default=3, dest='min_shared',
        help='Minimum shared keywords to act on (default: 3)')
    dedup_parser.add_argument('--min-impressions', type=int, default=100,
        dest='min_impressions',
        help='Minimum shared impressions to act on (default: 100)')

    # News: gather news
    news_parser = subparsers.add_parser('news',
        help='Gather news for a topic')
    news_parser.add_argument('topic', help='Topic name (e.g., vendors)')
    news_parser.add_argument('--resume', action='store_true',
        help='Resume interrupted run (skip already-completed items)')
    news_parser.add_argument('--workers', type=int, default=1, metavar='N',
        help='Concurrent workers (default: 1, max: 8)')

    # Refine: integrate pending news into pages
    refine_parser = subparsers.add_parser('refine',
        help='Integrate pending news into pages')
    refine_parser.add_argument('topic', help='Topic name (e.g., vendors)')
    refine_parser.add_argument('--resume', action='store_true',
        help='Resume interrupted run (skip already-completed items)')
    refine_parser.add_argument('--workers', type=int, default=1, metavar='N',
        help='Concurrent workers (default: 1, max: 8)')

    # Reword: rewrite pages for GSC keywords
    # Enrich: analyze locally + targeted improvement
    enrich_parser = subparsers.add_parser('enrich',
        help='Analyze pages locally, improve actionable ones')
    enrich_parser.add_argument('topic', help='Topic name (e.g., vendors)')
    enrich_parser.add_argument('--resume', action='store_true',
        help='Resume interrupted run')

    reword_parser = subparsers.add_parser('reword',
        help='Rewrite pages for GSC keyword opportunities')
    reword_parser.add_argument('topic', help='Topic name (e.g., vendors)')
    reword_parser.add_argument('--resume', action='store_true',
        help='Resume interrupted run (skip already-completed items)')
    reword_parser.add_argument('--workers', type=int, default=1, metavar='N',
        help='Concurrent workers (default: 1, max: 8)')

    # Consolidate: create hub pages
    consolidate_parser = subparsers.add_parser('consolidate',
        help='Create hub pages from comparison pages')
    consolidate_parser.add_argument('--topic', required=True,
        help='Topic containing the items to consolidate (e.g., vendors)')
    consolidate_parser.add_argument('--min', type=int, default=3, dest='min_comparisons',
        help='Minimum primary comparisons to consolidate (default: 3)')
    consolidate_parser.add_argument('--workers', type=int, default=1, metavar='N',
        help='Concurrent workers (default: 1, max: 8)')

    # Download: fetch WordPress pages as markdown
    download_parser = subparsers.add_parser('download',
        help='Download WordPress pages as clean markdown')
    download_parser.add_argument('topic', nargs='?', default=None,
        help='Topic name (e.g., de). Omit for all topics.')
    download_parser.add_argument('--force', action='store_true',
        help='Re-download even if page has content')
    download_parser.add_argument('--resume', action='store_true',
        help='Resume interrupted run (skip already-completed items)')
    download_parser.add_argument('--workers', type=int, default=1, metavar='N',
        help='Concurrent workers (default: 1, max: 8)')

    # Crosslink: add internal links to underlinked pages
    crosslink_parser = subparsers.add_parser('crosslink',
        help='Add internal links to underlinked pages')
    crosslink_parser.add_argument('topic', nargs='?', default=None,
        help='Topic name (e.g., content-strategie). Omit for all topics.')
    crosslink_parser.add_argument('--resume', action='store_true',
        help='Resume interrupted run (skip already-completed items)')

    # Sanitize: fix broken internal links
    sanitize_parser = subparsers.add_parser('sanitize',
        help='Fix broken internal links (no API calls)')
    sanitize_parser.add_argument('topic', nargs='?', default=None,
        help='Topic name (e.g., vendors). Omit for all topics.')

    # Lint-fix: rewrite redirect links in markdown source
    lint_fix_parser = subparsers.add_parser('lint-fix',
        help='Fix ALL lint issues: redirect links (free) + content via AI (~$0.01/page)')
    lint_fix_parser.add_argument('topic', nargs='?', default=None,
        help='Topic name (e.g., vendors). Omit for all topics.')

    # Redirects: analyze GSC gaps and generate strict redirects
    subparsers.add_parser('redirects',
        help='Analyze GSC coverage gaps, generate strict redirects (no API calls)')

    # Translate: translate page bodies to match language directory
    translate_parser = subparsers.add_parser('translate',
        help='Translate page bodies to match their language directory (~$0.01/page)')
    translate_parser.add_argument('topic', nargs='?', default=None,
        help='Topic name (e.g., build). Omit for all topics.')
    translate_parser.add_argument('--resume', action='store_true',
        help='Resume interrupted run (skip already-translated pages)')

    # Relink: fix internal link prefixes after translate (#234)
    relink_parser = subparsers.add_parser('relink',
        help='Rewrite internal link prefixes to match target language (zero AI, $0)')
    relink_parser.add_argument('topic', nargs='?', default=None,
        help='Topic name (e.g., build). Omit for all topics.')

    # Images: generate AI images via BFL
    images_parser = subparsers.add_parser('images',
        help='Generate missing AI images (BFL/FLUX)')
    images_parser.add_argument('--force', action='store_true',
        help='Regenerate all images, even cached ones')
    images_parser.add_argument('--prune', action='store_true',
        help='Remove orphan images not referenced by any !makeIMG')

    # Migrate GSC: rekey database after page restructure
    migrate_gsc_parser = subparsers.add_parser('migrate-gsc',
        help='Rekey GSC database after page restructure (reads .wire/redirects.yml + wire.yml redirects:)')

    # Migrate lang: scaffold multi-language from single-language
    migrate_lang_parser = subparsers.add_parser('migrate-lang',
        help='Scaffold multi-language site from single-language (moves docs, generates redirects)')
    migrate_lang_parser.add_argument('--from', dest='from_lang', required=True,
        help='Current site language code (e.g., en)')
    migrate_lang_parser.add_argument('--add', dest='add_langs', action='append', required=True,
        help='Language(s) to add (e.g., --add de --add fr)')

    # Newsweek: weekly market intelligence report
    newsweek_parser = subparsers.add_parser('newsweek',
        help='Generate weekly market intelligence report')
    newsweek_parser.add_argument('--from', dest='from_date',
        help='Start date YYYY-MM-DD (default: 7 days ago)')
    newsweek_parser.add_argument('--to', dest='to_date',
        help='End date YYYY-MM-DD (default: today)')
    newsweek_parser.add_argument('--skip-review', action='store_true',
        help='Skip Phase 3 editorial review')
    newsweek_parser.add_argument('--resynth', action='store_true',
        help='Skip Phase 1, reuse cached extracts (for prompt iteration)')
    newsweek_parser.add_argument('--workers', type=int, default=1, metavar='N',
        help='Concurrent workers (default: 1, max: 8)')

    args = parser.parse_args()

    if args.command == 'init':
        init_site()
        return

    if args.command == 'migrate-lang':
        stats = migrate_lang(
            from_lang=args.from_lang,
            add_langs=args.add_langs,
        )
        return

    # Fail loud if not in a site directory (except init)
    if not Path("wire.yml").exists() and not Path("mkdocs.yml").exists():
        logger.error(
            "No wire.yml or mkdocs.yml found in current directory.\n"
            "  You must run Wire from a site directory.\n"
            "  To create a new site: python -m wire.chief init\n"
            f"  Current directory: {Path.cwd()}"
        )
        raise SystemExit(1)

    # Multi-language handling: --lang required for multi-language sites
    # Exception: 'data' runs all languages automatically when --lang is omitted
    config = tools._load_mkdocs_config()
    site_languages = config.get("languages", [])
    if site_languages and not args.lang and args.command != 'data':
        codes = [l["code"] for l in site_languages]
        logger.error(
            f"Multi-language site. Use --lang <code>. "
            f"Available: {', '.join(codes)}"
        )
        raise SystemExit(1)
    if args.lang:
        override_docs_dir(args.lang)

    try:
        workers = min(getattr(args, 'workers', 1), 8)
        if workers > 4:
            logger.warning(f"Using {workers} workers — consider 3-4 for API rate limits")
        chief = Chief(nogsc=args.nogsc, workers=workers)
        if args.command == 'data':
            if site_languages and not args.lang:
                # Multi-language: run data for all languages automatically
                for lang_entry in site_languages:
                    code = lang_entry["code"]
                    logger.info(f"\n{'=' * 50}")
                    logger.info(f"Fetching GSC data for language: {code}")
                    override_docs_dir(code)
                    chief_lang = Chief(nogsc=args.nogsc,
                                       workers=workers)
                    chief_lang.search_data(force=args.force)
            else:
                chief.search_data(force=args.force)
        elif args.command == 'audit':
            chief.audit(args.topic, min_shared=args.min_shared,
                        min_impressions=args.min_impressions)
        elif args.command == 'deduplicate':
            chief.deduplicate(args.topic, min_shared=args.min_shared,
                              min_impressions=args.min_impressions)
        elif args.command == 'news':
            chief.gather_news(args.topic, resume=args.resume)
        elif args.command == 'refine':
            chief.refine_content(args.topic, resume=args.resume)
        elif args.command == 'enrich':
            chief.enrich(args.topic, resume=args.resume)
        elif args.command == 'reword':
            chief.reword(args.topic, resume=args.resume)
        elif args.command == 'consolidate':
            chief.consolidate_comparisons(args.topic, args.min_comparisons)
        elif args.command == 'download':
            chief.download(args.topic, force=args.force, resume=args.resume)
        elif args.command == 'crosslink':
            chief.crosslink(args.topic, resume=getattr(args, 'resume', False))
        elif args.command == 'sanitize':
            chief.sanitize(args.topic)
        elif args.command == 'lint-fix':
            chief.lint_fix(args.topic)
        elif args.command == 'redirects':
            chief.redirects()
        elif args.command == 'translate':
            chief.translate(args.topic, resume=getattr(args, 'resume', False))
        elif args.command == 'relink':
            chief.relink(args.topic)
        elif args.command == 'images':
            from wire.images import generate_all
            stats = generate_all(
                tools.DOCS_DIR, WIRE_CONFIG,
                force=args.force,
                prune=args.prune,
            )
        elif args.command == 'migrate-gsc':
            redirects = load_redirects()
            if not redirects:
                logger.error(
                    "No redirects found.\n"
                    "  Sources checked:\n"
                    "    1. .wire/redirects.yml (auto-created by Wire moves)\n"
                    "    2. wire.yml redirects: key (user-configured)\n"
                    "  Add redirects to wire.yml:\n"
                    "    redirects:\n"
                    "      /old/path/: /new/path/\n"
                    "  Or move pages with Wire commands (creates redirects automatically)."
                )
                raise SystemExit(1)
            init_db()
            from wire.db import rekey_from_redirects
            count = rekey_from_redirects(redirects)
            logger.info(f"migrate-gsc: {count} Content row(s) rekeyed from "
                        f"{len(redirects)} redirect(s).")
        elif args.command == 'newsweek':
            chief.generate_newsweek(from_date=args.from_date,
                                    to_date=args.to_date,
                                    skip_review=args.skip_review,
                                    resynth=args.resynth)
    except (ValueError, FileNotFoundError) as e:
        logger.error(str(e))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
