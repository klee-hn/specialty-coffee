"""
Wire: Content pipeline + static site generator for Claude-powered content sites.

Creates, updates, and optimizes markdown content using Claude.
Works with any site that has a wire.yml (or mkdocs.yml for migration).

Hierarchy:
    Chief            → orchestrates news + content for a Topic
        ├── NewsReporter → covers ONE item (search, analyze, save)
        └── ContentEditor → refines ONE page (institutional memory)

Data:
    Site    - site-level metadata from mkdocs.yml
    Topic   - directory-level operations (any docs subdirectory with index.md)
    Content - ONE item's metadata (slug, title, path, summary)
"""

__version__ = "4.0.0"
__author__ = "Newsroom Team"

__all__ = [
    "Chief", "NewsReporter", "ContentEditor",
    "claude_text", "load_prompt", "parse_decision", "setup_logging",
    "fetch_page", "Site", "SITE", "Content", "Topic",
    "get_root_domain", "same_owner", "web_search",
]

# Lazy imports via __getattr__ — avoids RuntimeWarning when running
# submodules with `python -m wire.chief` etc.
_LAZY_IMPORTS = {
    "Chief": "wire.chief",
    "NewsReporter": "wire.news",
    "ContentEditor": "wire.content",
    "claude_text": "wire.tools",
    "load_prompt": "wire.tools",
    "parse_decision": "wire.tools",
    "setup_logging": "wire.tools",
    "get_root_domain": "wire.tools",
    "same_owner": "wire.tools",
    "web_search": "wire.tools",
    "fetch_page": "wire.tools",
    "Content": "wire.tools",
    "Topic": "wire.tools",
    "Site": "wire.tools",
    "SITE": "wire.tools",
}


def __getattr__(name):
    if name in _LAZY_IMPORTS:
        import importlib
        module = importlib.import_module(_LAZY_IMPORTS[name])
        return getattr(module, name)
    raise AttributeError(f"module 'wire' has no attribute {name!r}")
