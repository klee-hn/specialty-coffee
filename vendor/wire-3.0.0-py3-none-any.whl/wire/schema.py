#!/usr/bin/env python3
"""
wire.schema — Source validation contract.

Single source of truth for required frontmatter fields AND source syntax
rules. Validates before build to catch issues early. Fails loud — Wire
customers depend on strictness.

Usage:
    from wire.schema import validate_frontmatter, validate_source_syntax

    validate_frontmatter(filepath, meta)  # raises FrontmatterError
    errors = validate_source_syntax(pages)  # returns list[str]
"""

import re
from datetime import date, datetime


REQUIRED_FIELDS = {
    "title": {
        "type": str,
        "purpose": "Page title for <title> tag and H1",
    },
    "description": {
        "type": str,
        "purpose": "Meta description for search results",
    },
}

# Required for content pages (topic + slug), not for index pages
CONTENT_REQUIRED_FIELDS = {
    "created": {
        "type": (str, date, datetime),
        "purpose": "First publication date — needed for JSON-LD, RSS, sitemap",
    },
}

OPTIONAL_FIELDS = {
    "date": {
        "type": (str, date, datetime),
        "purpose": "Last modification date (updated on every write)",
    },
    "template": {
        "type": str,
        "purpose": "Jinja2 template name (default: page.html)",
    },
    "og_type": {
        "type": str,
        "purpose": "Open Graph type (website, article)",
    },
    "image": {
        "type": str,
        "purpose": "Featured image path for OG tags",
    },
    "tags": {
        "type": list,
        "purpose": "Content tags for categorization",
    },
    "sources": {
        "type": list,
        "purpose": "External citation URLs (append-only)",
    },
    "wire_action": {
        "type": str,
        "purpose": "Last Wire action that modified the page",
    },
    "wire_reworded": {
        "type": (str, date, datetime),
        "purpose": "Date of last SEO reword",
    },
    "wire_differentiated": {
        "type": (str, date, datetime),
        "purpose": "Date of last differentiation",
    },
    "wire_differentiated_from": {
        "type": str,
        "purpose": "Slug of page this was differentiated from",
    },
    "author": {
        "type": str,
        "purpose": "Author slug (resolves to author page in docs/authors/)",
    },
    "reviewer": {
        "type": str,
        "purpose": "Reviewer slug — optional second author for transparency (#218)",
    },
    "role": {
        "type": str,
        "purpose": "Author role/title override for byline display",
    },
}

# Keys used by build.py / templates but not in REQUIRED/CONTENT_REQUIRED/OPTIONAL
_EXTRA_KNOWN_KEYS = {
    "short_title", "layout", "schema_type", "company", "product",
    "hide_title", "hide_meta", "extra_css", "extra_js", "alternate",
    "draft", "summary", "linkedin", "organization", "categories",
    "last_updated", "hide", "_overruled",
}

# Complete set of all known frontmatter keys
KNOWN_KEYS = (
    set(REQUIRED_FIELDS)
    | set(CONTENT_REQUIRED_FIELDS)
    | set(OPTIONAL_FIELDS)
    | _EXTRA_KNOWN_KEYS
)

# Keys that look like features but are NOT supported by Wire
_REJECTED_KEYS = {
    "redirect": (
        "'redirect:' in frontmatter is not supported. "
        "Add redirect to wire.yml instead:\n"
        "redirects:\n  /old/path/: /new/path/"
    ),
}


class FrontmatterError(Exception):
    """Raised when frontmatter fails validation."""
    pass


def validate_frontmatter(filepath, meta: dict,
                          is_content_page: bool = False) -> None:
    """Validate frontmatter metadata against schema.

    Fails loud. No silent fallbacks.

    Args:
        filepath: Path to the file (for error messages).
        meta: Frontmatter metadata dict.
        is_content_page: If True, also enforce content-page requirements
            (created date). Content pages have both topic and slug.

    Raises:
        FrontmatterError: If required fields are missing or wrong type.
    """
    errors = []

    # Gate 5: Reject keys that look like features but aren't
    for key, message in _REJECTED_KEYS.items():
        if key in meta:
            raise FrontmatterError(f"{filepath}:\n  {message}")

    # Gate 6: Reject unknown frontmatter keys
    unknown = set(meta.keys()) - KNOWN_KEYS
    if unknown:
        unknown_list = ", ".join(sorted(unknown))
        errors.append(
            f"unknown frontmatter key(s): {unknown_list}. "
            f"Wire only supports: {', '.join(sorted(KNOWN_KEYS))}")

    # Check universal required fields
    for field, spec in REQUIRED_FIELDS.items():
        if field not in meta or meta[field] is None:
            errors.append(
                f"missing required '{field}' — {spec['purpose']}")
            continue
        value = meta[field]
        expected = spec["type"]
        if not isinstance(value, expected):
            errors.append(
                f"'{field}' must be {expected.__name__}, "
                f"got {type(value).__name__}")
        elif isinstance(value, str) and not value.strip():
            errors.append(
                f"'{field}' is empty — {spec['purpose']}")

    # Check content-page requirements
    if is_content_page:
        for field, spec in CONTENT_REQUIRED_FIELDS.items():
            if field not in meta or meta[field] is None:
                errors.append(
                    f"missing '{field}' — {spec['purpose']}")

    if errors:
        error_list = "\n  ".join(errors)
        raise FrontmatterError(
            f"{filepath}:\n  {error_list}")


# MkDocs extension patterns — Wire does not support these.
# Each tuple: (compiled regex, short label, what to do instead)
_MKDOCS_PATTERNS = [
    (
        re.compile(r'\{[^}]*\.[a-zA-Z][\w-]*[^}]*\}'),
        "attr_list",
        "Use :::cta for buttons, or remove class annotation",
    ),
    (
        re.compile(r'<div[^>]*\bmarkdown\b(?=[>\s"\'=])', re.IGNORECASE),
        "md_in_html",
        "Use Wire shortcodes: :::stats, :::cards, :::split, :::banner",
    ),
    (
        re.compile(r'^!!!\ +\w+', re.MULTILINE),
        "admonition",
        "Use > blockquote instead",
    ),
    (
        re.compile(r'^\?\?\?\ +\w+', re.MULTILINE),
        "admonition",
        "Use > blockquote instead",
    ),
    (
        re.compile(r'^===\ +"', re.MULTILINE),
        "tabbed",
        "Use ## headings to organize content",
    ),
]

# Regex to strip fenced code blocks (``` or ~~~)
_FENCED_CODE = re.compile(
    r'^(`{3,}|~{3,})[^\n]*\n.*?\n\1\s*$', re.MULTILINE | re.DOTALL)

# Regex to strip inline code (`...`)
_INLINE_CODE = re.compile(r'`[^`\n]+`')

# Regex to strip HTML comments
_HTML_COMMENT = re.compile(r'<!--.*?-->', re.DOTALL)


def _strip_code(body: str) -> str:
    """Strip code blocks, inline code, and HTML comments from markdown.

    Returns body with code replaced by whitespace so line numbers stay
    roughly correct for error reporting.
    """
    text = _FENCED_CODE.sub(lambda m: '\n' * m.group().count('\n'), body)
    text = _HTML_COMMENT.sub(lambda m: '\n' * m.group().count('\n'), text)
    text = _INLINE_CODE.sub(lambda m: ' ' * len(m.group()), text)
    return text


def validate_source_syntax(pages) -> list[str]:
    """Scan pages for MkDocs extension syntax that Wire does not support.

    Returns list of error strings. Empty = all clean.
    """
    errors = []
    for page in pages:
        body = getattr(page, 'raw_body', '')
        if not body:
            continue
        stripped = _strip_code(body)
        lines = stripped.split('\n')
        for lineno, line in enumerate(lines, start=1):
            for pattern, label, suggestion in _MKDOCS_PATTERNS:
                match = pattern.search(line)
                if match:
                    snippet = match.group().strip()
                    if len(snippet) > 35:
                        snippet = snippet[:32] + "..."
                    errors.append(
                        f"{page.source}:{lineno}  {snippet:36s} "
                        f"{label} → {suggestion}")
    return errors


def validate_build_pages(pages) -> tuple[list[str], list[str]]:
    """Validate all pages for build.

    Returns (hard_errors, warnings).
    Hard errors = missing title/description. Build should refuse.
    Warnings = missing created date. Build proceeds but warns loud.
    """
    hard_errors = []
    warnings = []
    for page in pages:
        is_content = bool(page.topic and page.slug)
        # Check hard requirements (title, description)
        try:
            validate_frontmatter(page.source, page.meta,
                                  is_content_page=False)
        except FrontmatterError as e:
            hard_errors.append(str(e))
            continue
        # Content pages must have created date — hard error
        if is_content:
            try:
                validate_frontmatter(page.source, page.meta,
                                      is_content_page=True)
            except FrontmatterError as e:
                hard_errors.append(str(e))
        # Gate 12: Placeholder dates (Jan 1st = obvious placeholder)
        created = page.meta.get("created")
        if created:
            created_str = str(created)
            if not re.match(r'^\d{4}-\d{2}-\d{2}$', created_str):
                hard_errors.append(
                    f"{page.source}: created date '{created_str}' must be "
                    f"YYYY-MM-DD format.")
            elif created_str.endswith("-01-01"):
                hard_errors.append(
                    f"{page.source}: created date '{created_str}' looks like "
                    f"a placeholder (January 1st). Run `python -m wire.migrate` "
                    f"to backfill from git history.")
        # Gate 15: Future dates — cannot publish content dated in the future
        from datetime import date as _date
        _today = str(_date.today())
        for key in ("date", "created"):
            val = str(page.meta.get(key, ""))
            if val and re.match(r'^\d{4}-\d{2}-\d{2}$', val) and val > _today:
                hard_errors.append(
                    f"{page.source}: {key} '{val}' is in the future. "
                    f"Dates must not be ahead of today ({_today}).")
    return hard_errors, warnings
