#!/usr/bin/env python3
"""
Google Search Console integration for newsroom content optimization.

Database-read-only: get_search_terms() reads from .wire/gsc.db only.
API calls only happen via fetch_and_store() (called by search_data command).
No silent fallback — if no DB data exists, callers get None.

Adapted from contentconsole/tasks/snapshot.py auth pattern.
"""
import os
import logging
from datetime import datetime, timedelta
from urllib.parse import urlparse

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

logger = logging.getLogger(__name__)

SNAPSHOT_MAX_AGE_DAYS = 28


def _site_origin() -> str:
    """Site origin (scheme + domain) from wire.yml site_url."""
    from wire.tools import SITE
    url = SITE.url.rstrip("/") if SITE and SITE.url else ""
    if not url:
        raise ValueError(
            "site_url not set in wire.yml. "
            "GSC requires site_url to match your Search Console property. "
            "Example: site_url: https://example.com"
        )
    return url


def _site_url() -> str:
    """Resolve the GSC property URL by matching site_url against accessible properties.

    GSC has two property types:
      - Domain property: sc-domain:example.com (covers all subdomains + protocols)
      - URL prefix property: https://example.com/ (exact match)

    Wire auto-detects which one your site uses by listing all properties the
    token has access to and matching against site_url. If no match is found,
    Wire fails loud with the list of available properties.
    """
    origin = _site_origin()
    domain = urlparse(origin).netloc

    # Try to match against accessible GSC properties
    try:
        service = get_search_console_service()
        response = service.sites().list().execute()
        properties = response.get("siteEntry", [])

        # Build candidates to match (most specific first)
        candidates = [
            f"sc-domain:{domain}",           # domain property
            f"{origin}/",                     # URL prefix with trailing slash
            origin,                           # URL prefix without trailing slash
            f"https://{domain}/",             # force https
            f"https://{domain}",
            f"http://{domain}/",              # http fallback
            f"http://{domain}",
        ]

        available_urls = [p["siteUrl"] for p in properties]

        for candidate in candidates:
            if candidate in available_urls:
                logger.info(f"GSC property: {candidate}")
                return candidate

        # No match — fail loud with available properties
        prop_list = "\n".join(f"  - {u}" for u in available_urls) if available_urls else "  (none)"
        raise ValueError(
            f"No GSC property found matching '{origin}'.\n"
            f"Available properties in your Google account:\n{prop_list}\n\n"
            f"To fix:\n"
            f"  1. Add {origin} in Google Search Console\n"
            f"     https://search.google.com/search-console\n"
            f"  2. Verify ownership (DNS, HTML file, or meta tag)\n"
            f"  3. Re-run: python -m wire.chief data"
        )
    except ValueError:
        raise  # Re-raise our own ValueError
    except Exception as e:
        # Auth failed — fall back to sc-domain format and let caller handle
        logger.warning(f"Could not list GSC properties: {e}")
        return f"sc-domain:{domain}"


def get_search_console_service():
    """Get authenticated Google Search Console API service.

    Uses OAuth2 with client_id/client_secret from .env and token.json
    for refresh token. Auto-refreshes expired tokens.
    """
    SCOPES = ['https://www.googleapis.com/auth/webmasters.readonly']

    client_id = os.getenv('GOOGLE_CLIENT_ID')
    client_secret = os.getenv('GOOGLE_CLIENT_SECRET')

    if not client_id or not client_secret:
        raise Exception(
            "Google Search Console credentials not found. "
            "Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in .env"
        )

    creds = None
    # Look for token.json in site directory (cwd) first, then newsroom package root
    token_path = os.path.join(os.getcwd(), 'token.json')
    if not os.path.exists(token_path):
        token_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'token.json')

    if os.path.exists(token_path):
        creds = Credentials.from_authorized_user_file(token_path, SCOPES)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
            with open(token_path, 'w') as token:
                token.write(creds.to_json())
        else:
            raise Exception(
                "No valid OAuth2 token found. Copy token.json from contentconsole "
                "or run authorization flow first."
            )

    return build('searchconsole', 'v1', credentials=creds)


def _find_redirect_sources(target_url: str) -> list[str]:
    """Find old URLs that redirect to target_url via .wire/redirects.yml.

    Returns full URLs (with origin) for redirect sources whose 'to' path
    matches the target URL path. Used for redirect-aware GSC fallback.
    """
    from pathlib import Path
    redirects_file = Path(".wire") / "redirects.yml"
    if not redirects_file.exists():
        return []

    try:
        import yaml
        with open(redirects_file, encoding="utf-8") as f:
            redirects = yaml.safe_load(f) or []
    except Exception:
        return []

    origin = _site_origin()
    # Extract path from target URL
    target_path = target_url.replace(origin, "")

    sources = []
    for r in redirects:
        if r.get("to", "").rstrip("/") == target_path.rstrip("/"):
            old_path = r.get("from", "")
            if old_path:
                sources.append(f"{origin}{old_path}")

    return sources


def _fetch_from_api(slug: str, title: str, topic: str) -> list[dict] | None:
    """Raw GSC API fetch for a single page. Returns page_query rows.

    This is Call 1 only (page-filtered queries). Call 2 (brand queries)
    has been replaced by database cross-page computation.

    Returns list of dicts with query/impressions/clicks/position, or None on failure.
    """
    service = get_search_console_service()  # Raises on auth failure — fail loud

    end_date = datetime.now()
    start_date = end_date - timedelta(days=28)
    start_str = start_date.strftime('%Y-%m-%d')
    end_str = end_date.strftime('%Y-%m-%d')
    from wire.tools import _ACTIVE_LANG
    lang_prefix = f"/{_ACTIVE_LANG}" if _ACTIVE_LANG else ""
    page_url = f"{_site_origin()}{lang_prefix}/{topic}/{slug}/"

    try:
        request = {
            'startDate': start_str,
            'endDate': end_str,
            'dimensions': ['query'],
            'dimensionFilterGroups': [{'filters': [{
                'dimension': 'page',
                'expression': page_url
            }]}],
            'rowLimit': 25000
        }
        response = service.searchanalytics().query(
            siteUrl=_site_url(), body=request).execute()
        api_rows = response.get('rows', [])
    except HttpError as e:
        logger.warning(f"GSC API failed for {slug}: {e}")
        return None

    if not api_rows:
        # Redirect-aware fallback: try old URLs from .wire/redirects.yml
        old_urls = _find_redirect_sources(page_url)
        for old_url in old_urls:
            try:
                request['dimensionFilterGroups'] = [{'filters': [{
                    'dimension': 'page',
                    'expression': old_url,
                }]}]
                response = service.searchanalytics().query(
                    siteUrl=_site_url(), body=request).execute()
                api_rows = response.get('rows', [])
                if api_rows:
                    logger.info(f"GSC: {slug} has no data at new URL, "
                                f"using data from redirect source {old_url}")
                    break
            except HttpError:
                continue

    if not api_rows:
        return None

    return [
        {
            "query": row['keys'][0],
            "impressions": int(row.get('impressions', 0)),
            "clicks": int(row.get('clicks', 0)),
            "position": round(row.get('position', 0), 1),
        }
        for row in api_rows
    ]


def _store_page_queries(slug: str, topic: str, rows: list[dict]):
    """Store API response rows in database for this page."""
    from wire.db import store_snapshot, init_db
    init_db()
    date_str = datetime.now().strftime('%Y-%m-%d')
    store_snapshot(topic, slug, rows, date_str)


def _load_from_db(slug: str, topic: str) -> list[dict] | None:
    """Load cached page_queries from database.

    Returns list of query dicts, or None if no data or data older than
    SNAPSHOT_MAX_AGE_DAYS.
    """
    from wire.db import get_snapshot_date, get_db, _resolve_lang

    lang = _resolve_lang()
    latest = get_snapshot_date(topic, slug)
    if not latest:
        return None

    # Check freshness
    try:
        snap_date = datetime.strptime(latest, '%Y-%m-%d')
        age = (datetime.now() - snap_date).days
        if age > SNAPSHOT_MAX_AGE_DAYS:
            return None
    except ValueError:
        return None

    with get_db() as conn:
        rows = conn.execute(
            """SELECT k.keyword as query, s.impressions, s.clicks, s.position
               FROM Snapshot s
               JOIN Keyword k ON s.keyword_id = k.id
               JOIN Content c ON s.content_id = c.id
               WHERE c.lang = ? AND c.topic = ? AND c.slug = ? AND s.date = ?
               ORDER BY s.impressions DESC""",
            (lang, topic, slug, latest),
        ).fetchall()

    if not rows:
        return None

    return [
        {
            "query": row["query"],
            "impressions": row["impressions"],
            "clicks": row["clicks"],
            "position": row["position"],
        }
        for row in rows
    ]


def _compute_opportunities(slug: str, topic: str) -> list[dict]:
    """Compute brand-query opportunities from database cross-page data.

    Replaces Call 2 (brand filter). Now that all pages' queries are in the
    database, we can find brand queries ranking on other pages via SQL.

    Finds keywords containing the brand term (slug with hyphens→spaces)
    that rank on OTHER pages in the same topic.
    """
    from wire.db import get_db, _resolve_lang

    brand_term = slug.replace("-", " ")
    lang = _resolve_lang()

    try:
        with get_db() as conn:
            lang_where = "AND c.lang = ?" if lang else ""
            lang_params = (lang,) if lang else ()
            rows = conn.execute(
                f"""SELECT k.keyword as query, s.impressions,
                          c.path as ranking_page
                   FROM Snapshot s
                   JOIN Keyword k ON s.keyword_id = k.id
                   JOIN Content c ON s.content_id = c.id
                   WHERE c.topic = ?
                     AND c.slug != ?
                     AND k.keyword LIKE ?
                     {lang_where}
                     AND s.date = (SELECT MAX(date) FROM Snapshot WHERE content_id = s.content_id)
                   ORDER BY s.impressions DESC
                   LIMIT 50""",
                (topic, slug, f"%{brand_term}%", *lang_params),
            ).fetchall()

        return [
            {
                "query": row["query"],
                "impressions": row["impressions"],
                "ranking_page": row["ranking_page"],
            }
            for row in rows
        ]
    except Exception as e:
        logger.warning(f"Failed to compute opportunities for {slug}: {e}")
        return []


def _build_page_queries(rows: list[dict]) -> list[dict]:
    """Build page_queries list with opportunity scores from raw row data."""
    result = []
    for row in sorted(rows, key=lambda r: r.get('impressions', 0), reverse=True):
        impressions = int(row.get('impressions', 0))
        clicks = int(row.get('clicks', 0))
        ctr = clicks / impressions if impressions > 0 else 0
        score = round(impressions * (1 - ctr), 1)
        result.append({
            "query": row["query"],
            "impressions": impressions,
            "clicks": clicks,
            "position": round(row.get("position", 0), 1),
            "score": score,
        })
    return result


def get_search_terms(slug: str, title: str, topic: str) -> dict | None:
    """Load GSC search data for a page from the database.

    Database-read-only. Returns None if no data exists.
    To populate the database, run: python -m wire.chief search_data <topic>

    Returns dict with 'page_queries' and 'opportunities', or None.
    """
    rows = _load_from_db(slug, topic)
    if rows is None:
        return None

    logger.debug(f"GSC data loaded for {topic}/{slug}")
    page_queries = _build_page_queries(rows)
    opportunities = _compute_opportunities(slug, topic)

    return {
        "page_queries": page_queries,
        "opportunities": opportunities,
    }


def discover_urls() -> list[dict]:
    """Bulk-fetch ALL URLs Google knows about from GSC Search Analytics API.

    Uses dimensions=['page'] without filters to get every URL with impressions.
    Paginates in 25,000 chunks. Returns [{url, impressions, clicks}] with
    paths relative to site origin (e.g. '/guides/setup/').

    Stores results in the GscUrl table with 28-day caching.
    """
    from wire.db import store_gsc_urls, get_gsc_urls, get_gsc_urls_discovery_date, init_db
    init_db()

    # Check cache freshness
    cached = get_gsc_urls()
    if cached is not None:
        logger.info(f"GSC URL discovery: using cached data "
                    f"({len(cached)} URLs from {get_gsc_urls_discovery_date()})")
        return cached

    service = get_search_console_service()
    origin = _site_origin()
    end_date = datetime.now()
    start_date = end_date - timedelta(days=28)
    start_str = start_date.strftime('%Y-%m-%d')
    end_str = end_date.strftime('%Y-%m-%d')

    all_urls = []
    start_row = 0
    ROW_LIMIT = 25000
    fetch_complete = False

    while True:
        try:
            request = {
                'startDate': start_str,
                'endDate': end_str,
                'dimensions': ['page'],
                'rowLimit': ROW_LIMIT,
                'startRow': start_row,
            }
            response = service.searchanalytics().query(
                siteUrl=_site_url(), body=request).execute()
            rows = response.get('rows', [])
        except HttpError as e:
            logger.error(f"GSC URL discovery API failed at row {start_row}: {e}")
            break

        if not rows:
            fetch_complete = True
            break

        for row in rows:
            full_url = row['keys'][0]
            # Convert to relative path
            path = full_url.replace(origin, "") or "/"
            all_urls.append({
                "url": path,
                "impressions": int(row.get('impressions', 0)),
                "clicks": int(row.get('clicks', 0)),
            })

        if len(rows) < ROW_LIMIT:
            fetch_complete = True
            break
        start_row += ROW_LIMIT

    if not fetch_complete:
        logger.error(
            f"GSC URL discovery incomplete — fetched {len(all_urls)} URLs "
            f"before error. NOT saving to DB (would overwrite complete data)."
        )
        return []

    if all_urls:
        date_str = datetime.now().strftime('%Y-%m-%d')
        store_gsc_urls(all_urls, date_str)
        logger.info(f"GSC URL discovery: {len(all_urls)} URLs saved")

    return all_urls


def fetch_and_store(slug: str, title: str, topic: str) -> dict | None:
    """Fetch GSC data from the API and store in database.

    This is the ONLY function that hits the GSC API. Called by search_data.
    Returns dict with 'page_queries' and 'opportunities', or None on failure.
    """
    rows = _fetch_from_api(slug, title, topic)
    if rows is None:
        return None

    try:
        _store_page_queries(slug, topic, rows)
    except Exception as e:
        logger.error(f"Failed to store GSC data for {slug}: {e}")
        raise

    page_queries = _build_page_queries(rows)
    opportunities = _compute_opportunities(slug, topic)

    return {
        "page_queries": page_queries,
        "opportunities": opportunities,
    }
