#!/usr/bin/env python3
"""
WordPress → mkdocs-material Markdown Conversion

Downloads WordPress pages, extracts content + metadata, converts to clean
markdown with downloaded images. Designed for konfuzio.com (JSON-LD/Yoast)
and sites with OG tags only (no JSON-LD).

Usage:
    from wire.wp import download_page
    msg, ok = download_page("cv2", "de", "https://konfuzio.com", docs_dir)
"""

import html as html_lib
import json
import logging
import re
from pathlib import Path
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup, Tag

import frontmatter
import markdownify

from wire import tools
from wire.tools import fetch_html, SITE

logger = logging.getLogger(__name__)


# =============================================================================
# METADATA EXTRACTION
# =============================================================================

def extract_metadata(html: str, url: str) -> dict:
    """Extract page metadata from JSON-LD, OG tags, meta tags, and <time> elements.

    Args:
        html: Raw HTML string.
        url: Page URL (for logging).

    Returns:
        Dict with keys: title, description, created, modified, author,
        word_count, section, language, thumbnail. Missing keys omitted.
    """
    soup = BeautifulSoup(html, "lxml")
    meta = {}

    # Strategy 1: JSON-LD @graph (Yoast SEO on konfuzio.com)
    for script in soup.find_all("script", type="application/ld+json"):
        try:
            data = json.loads(script.string or "")
        except (json.JSONDecodeError, TypeError):
            continue

        graph = data.get("@graph", [data] if isinstance(data, dict) else [])
        for node in graph:
            ntype = node.get("@type", "")
            # Match Article, WebPage, BlogPosting, etc.
            if any(t in str(ntype) for t in ("Article", "WebPage", "Posting", "Page")):
                if "datePublished" in node and "created" not in meta:
                    meta["created"] = node["datePublished"][:10]
                if "dateModified" in node and "modified" not in meta:
                    meta["modified"] = node["dateModified"][:10]
                if "headline" in node and "title" not in meta:
                    meta["title"] = node["headline"]
                if "wordCount" in node:
                    meta["word_count"] = node["wordCount"]
                if "articleSection" in node:
                    sec = node["articleSection"]
                    meta["section"] = sec if isinstance(sec, str) else ", ".join(sec)
                if "inLanguage" in node:
                    lang = node["inLanguage"]
                    if isinstance(lang, dict):
                        lang = lang.get("name", lang.get("@id", ""))
                    meta["language"] = str(lang)[:5]
                if "thumbnailUrl" in node:
                    meta["thumbnail"] = node["thumbnailUrl"]

            # Author node
            if ntype == "Person" and "name" in node and "author" not in meta:
                meta["author"] = node["name"]
            # Nested author
            if "author" in node and "author" not in meta:
                author = node["author"]
                if isinstance(author, dict):
                    meta["author"] = author.get("name", "")
                elif isinstance(author, list) and author:
                    meta["author"] = author[0].get("name", "")

    # Strategy 2: OG tags (sites without JSON-LD/Yoast)
    if "title" not in meta:
        og_title = soup.find("meta", property="og:title")
        if og_title and og_title.get("content"):
            meta["title"] = og_title["content"]

    if "description" not in meta:
        # OG description first, then meta description
        og_desc = soup.find("meta", property="og:description")
        if og_desc and og_desc.get("content"):
            meta["description"] = og_desc["content"]
        else:
            meta_desc = soup.find("meta", attrs={"name": "description"})
            if meta_desc and meta_desc.get("content"):
                meta["description"] = meta_desc["content"]

    if "thumbnail" not in meta:
        og_img = soup.find("meta", property="og:image")
        if og_img and og_img.get("content"):
            meta["thumbnail"] = og_img["content"]

    if "language" not in meta:
        og_locale = soup.find("meta", property="og:locale")
        if og_locale and og_locale.get("content"):
            meta["language"] = og_locale["content"][:5]

    # Strategy 3: <time> tags for dates (WordPress themes without JSON-LD)
    if "created" not in meta:
        time_tag = soup.find("time", attrs={"datetime": True})
        if time_tag:
            meta["created"] = time_tag["datetime"][:10]

    # Strategy 4: Fallback title from <title> tag
    if "title" not in meta:
        title_tag = soup.find("title")
        if title_tag and title_tag.string:
            # Strip site name suffix: "Page Title - Site Name"
            meta["title"] = title_tag.string.split(" - ")[0].split(" | ")[0].strip()

    # Decode HTML entities in all string values
    for key in meta:
        if isinstance(meta[key], str):
            meta[key] = html_lib.unescape(meta[key])

    return meta


# =============================================================================
# HTML PREPROCESSING
# =============================================================================

# Elements to remove entirely
_REMOVE_SELECTORS = [
    "style", "noscript", "header", "footer", "nav",
    ".share", ".social", ".comments", ".related-posts",
    ".sidebar", ".newsletter", ".wp-block-spacer",
    ".sharedaddy", ".jp-relatedposts", ".post-navigation",
    ".breadcrumb", ".breadcrumbs", ".cookie-notice",
    "#cookie-notice", ".wp-block-separator",
    ".helpful-article", ".helpful", ".feedback-form",
    ".rating", ".post-ratings", ".star-rating",
    ".ez-toc-title", ".ez-toc-list", "#ez-toc-container",
    ".lwptoc", ".lwptoc_i", ".table-of-contents",
]

# WordPress CSS classes that indicate non-semantic wrappers
_WP_WRAPPER_CLASSES = re.compile(
    r"wp-block-(group|column|columns|cover|media-text|spacer)"
    r"|wp-container-\d+"
    r"|is-layout-(flow|flex|constrained)"
    r"|has-global-padding"
)


def preprocess_html(html: str, site_url: str) -> tuple[BeautifulSoup, list[str]]:
    """Clean WordPress HTML for markdown conversion.

    Args:
        html: Raw HTML string.
        site_url: Base URL for making image paths absolute.

    Returns:
        (soup, inline_js): Cleaned BeautifulSoup of content area,
        and list of extracted inline JS strings.
    """
    soup = BeautifulSoup(html, "lxml")

    # Capture H1 from full page before narrowing to content area
    # WordPress often puts H1 outside .entry-content
    page_h1 = soup.find("h1")
    h1_text = page_h1.get_text(strip=True) if page_h1 else None

    # Find content area: .entry-content > article > main > body
    content = (
        soup.find(class_="entry-content")
        or soup.find("article")
        or soup.find("main")
        or soup.find("body")
    )
    if content is None:
        content = soup

    # If H1 was outside content area, prepend it
    if h1_text and not content.find("h1"):
        h1_tag = soup.new_tag("h1")
        h1_tag.string = h1_text
        content.insert(0, h1_tag)

    # Extract inline JS from content area (dirty pages)
    inline_js = []
    for script in content.find_all("script"):
        js_text = script.string or ""
        if js_text.strip():
            inline_js.append(js_text.strip())
        script.decompose()
    if inline_js:
        logger.warning(f"Extracted {len(inline_js)} inline <script> blocks")

    # Remove unwanted elements
    for selector in _REMOVE_SELECTORS:
        for el in content.select(selector) if "." in selector or "#" in selector else content.find_all(selector):
            el.decompose()

    # Fix lazy loading: data-src / data-lazy-src → src
    for tag in content.find_all(["img", "iframe"]):
        for attr in ("data-src", "data-lazy-src", "data-original"):
            if tag.get(attr):
                tag["src"] = tag[attr]
                break

    # Deduplicate images: WordPress renders both lazy img and noscript fallback
    _deduplicate_images(content)

    # Convert YouTube iframes → !yt[VIDEO_ID]
    for iframe in content.find_all("iframe"):
        src = iframe.get("src", "")
        yt_match = re.search(r"youtube\.com/embed/([a-zA-Z0-9_-]+)", src)
        if yt_match:
            video_id = yt_match.group(1)
            iframe.replace_with(f"\n\n!yt[{video_id}]\n\n")

    # Strip WordPress CSS artifacts
    _strip_wp_artifacts(content, site_url)

    return content, inline_js


def _deduplicate_images(soup: BeautifulSoup) -> None:
    """Remove duplicate images from WordPress lazy loading + noscript fallback."""
    seen_srcs = set()
    for img in soup.find_all("img"):
        src = img.get("src", "")
        if not src or src in seen_srcs:
            # Remove duplicate or empty img
            img.decompose()
            continue
        # Skip 1px tracking pixels
        width = img.get("width", "")
        height = img.get("height", "")
        if str(width) == "1" or str(height) == "1":
            img.decompose()
            continue
        seen_srcs.add(src)


def _strip_wp_artifacts(soup: BeautifulSoup, site_url: str) -> None:
    """Remove all WordPress CSS classes, styles, and unwrap pure wrappers."""
    # Remove class and style from ALL elements
    for tag in soup.find_all(True):
        if tag.get("class"):
            del tag["class"]
        if tag.get("style"):
            del tag["style"]
        if tag.get("id") and tag.name in ("div", "span", "section"):
            del tag["id"]

    # Unwrap figure.wp-block-image → keep inner img
    for figure in soup.find_all("figure"):
        figure.unwrap()

    # Unwrap pure wrapper divs/spans/sections
    for tag_name in ("div", "span", "section"):
        for tag in soup.find_all(tag_name):
            # If it has no attributes and only contains other elements, unwrap
            if not tag.attrs:
                tag.unwrap()

    # Make image URLs absolute
    for img in soup.find_all("img"):
        src = img.get("src", "")
        if src and not src.startswith(("http://", "https://", "data:")):
            img["src"] = urljoin(site_url, src)


# =============================================================================
# MARKDOWN CONVERSION
# =============================================================================

def to_markdown(soup: BeautifulSoup, site_url: str, topic: str,
                slug: str = "") -> str:
    """Convert cleaned HTML soup to pure markdown.

    Args:
        soup: Preprocessed BeautifulSoup content.
        site_url: Site URL for rewriting internal links.
        topic: Topic directory name for relative link paths.
        slug: Page slug (empty string for topic root/homepage).

    Returns:
        Clean markdown string with no HTML residue.
    """
    md = markdownify.markdownify(
        str(soup),
        heading_style="ATX",
        code_language="python",
        strip=["button", "input", "form", "select", "textarea"],
    )

    # Rewrite internal links: {site_url}/{topic}/{slug}/ → ../{slug}/
    parsed = urlparse(site_url)
    base_domain = parsed.netloc

    # Match markdown links (not images!) pointing to same domain
    def _rewrite_link(m):
        prefix = m.group(1)  # empty or "!" for images
        text = m.group(2)
        href = m.group(3)
        if prefix == "!":
            return m.group(0)  # Don't rewrite image URLs
        if base_domain in href:
            # Skip wp-content/uploads (images, PDFs, etc.)
            url_path = urlparse(href).path
            if "wp-content" in url_path:
                return m.group(0)
            path = url_path.strip("/")
            parts = path.split("/")
            if len(parts) >= 2:
                # e.g., de/cv2 → ../cv2/
                target_slug = parts[-1] if parts[-1] else parts[-2] if len(parts) > 1 else ""
                if target_slug and target_slug != "post.php":
                    # Homepage (slug="") is at de/index.md → use slug/index.md
                    # Subpages are at de/page/index.md → use ../slug/index.md
                    prefix = "" if not slug else "../"
                    return f"[{text}]({prefix}{target_slug}/index.md)"
        return m.group(0)

    md = re.sub(r'(!?)\[([^\]]*)\]\(([^)]+)\)', _rewrite_link, md)

    # Keep H1 — wire convention: body starts with # Title
    # _sanitize_content() will re-insert if missing, so keep for consistency

    # Post-conversion: remove residual raw HTML tags
    md = re.sub(r'</?(?:div|span|section|figure|figcaption|aside|article|main|header|footer|nav)[^>]*>', '', md)

    # Remove empty links and images with no content
    md = re.sub(r'\[]\([^)]*\)', '', md)
    # Remove orphaned image syntax (no URL or empty)
    md = re.sub(r'^!\s*$', '', md, flags=re.MULTILINE)
    # Fix trailing slashes in image URLs: ![alt](url/) → ![alt](url)
    md = re.sub(r'(!\[[^\]]*\]\([^)]+)/\)', r'\1)', md)

    # Clean WordPress Gutenberg footnote UUIDs:
    # [1](#uuid) → [^1]  and  [︎](#uuid-link) → (backref, remove)
    md = re.sub(r'\[(\d+)\]\(#[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\)', r'[^\1]', md)
    md = re.sub(r'\s*\[[^\]]*\]\(#[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}-link\)', '', md)

    # Remove auto-generated TOC labels
    md = re.sub(r' *Inhaltsverzeichnis\n*', '\n', md)
    md = re.sub(r' *Table of Contents\n*', '\n', md)

    # Remove feedback/rating sections at end
    md = re.sub(r'###?\s*Fanden Sie.*$', '', md, flags=re.DOTALL)

    # Clean up: collapse 3+ blank lines to 2
    md = re.sub(r'\n{3,}', '\n\n', md)

    # Strip trailing whitespace per line
    md = "\n".join(line.rstrip() for line in md.split("\n"))

    # Strip leading/trailing whitespace
    md = md.strip()

    return md


# =============================================================================
# IMAGE DOWNLOADING
# =============================================================================

def download_images(markdown: str, assets_dir: Path, site_url: str) -> str:
    """Download same-domain images and rewrite paths to local.

    Args:
        markdown: Markdown string with image references.
        assets_dir: Directory to save images to.
        site_url: Site URL for determining same-domain images.

    Returns:
        Markdown with rewritten image paths.
    """
    from curl_cffi import requests

    domain = urlparse(site_url).netloc
    img_pattern = re.compile(r'!\[([^\]]*)\]\(([^)]+)\)')

    def _download_and_rewrite(m):
        alt = m.group(1)
        url = m.group(2)

        # Skip external images
        if domain not in urlparse(url).netloc:
            return m.group(0)

        # Skip data URIs
        if url.startswith("data:"):
            return m.group(0)

        # Derive filename from URL
        path = urlparse(url).path
        filename = Path(path).name
        if not filename or "." not in filename:
            return m.group(0)

        dest = assets_dir / filename
        if dest.exists():
            return f"![{alt}](assets/{filename})"

        try:
            assets_dir.mkdir(parents=True, exist_ok=True)
            resp = requests.get(url, impersonate="safari17_0", timeout=30)
            resp.raise_for_status()

            # Skip tiny files (tracking pixels)
            if len(resp.content) < 100:
                logger.warning(f"Skipping tiny image ({len(resp.content)} bytes): {url}")
                return m.group(0)

            dest.write_bytes(resp.content)
            logger.info(f"Downloaded image: {filename} ({len(resp.content)} bytes)")
            return f"![{alt}](assets/{filename})"
        except Exception as e:
            logger.warning(f"Failed to download image {url}: {e}")
            return m.group(0)

    return img_pattern.sub(_download_and_rewrite, markdown)


# =============================================================================
# PAGE DOWNLOAD ORCHESTRATOR
# =============================================================================

def download_page(slug: str, topic: str, site_url: str, docs_dir: Path = None,
                  force: bool = False) -> tuple[str, bool]:
    """Download a single WordPress page and convert to mkdocs markdown.

    Orchestrates: fetch → extract metadata → preprocess → convert → download images.
    Only processes stub pages (content < 50 chars) unless force=True.

    Args:
        slug: Page slug (e.g., "cv2").
        topic: Topic directory (e.g., "de").
        site_url: WordPress site URL (e.g., "https://konfuzio.com").
        docs_dir: Override docs directory. Defaults to tools.DOCS_DIR.
        force: Re-download even if page has content.

    Returns:
        (message, success) tuple for _run_batch() compatibility.
    """
    if docs_dir is None:
        docs_dir = tools.DOCS_DIR

    page_dir = docs_dir / topic / slug
    index_path = page_dir / "index.md"

    # Check if stub
    if index_path.exists() and not force:
        existing = index_path.read_text(encoding="utf-8")
        # Parse frontmatter to get body only
        try:
            post = frontmatter.load(index_path)
            body = post.content.strip()
        except Exception:
            body = existing.strip()

        if len(body) >= 50:
            return f"skipped (has content, {len(body)} chars)", True

    # Build URL
    url = f"{site_url.rstrip('/')}/{topic}/{slug}/"
    logger.info(f"Downloading {url}")

    # Fetch HTML
    html = fetch_html(url)
    if not html:
        return f"failed (fetch error for {url})", False

    # Extract metadata
    meta = extract_metadata(html, url)
    logger.info(f"  metadata: {list(meta.keys())}")

    # Preprocess HTML
    content_soup, inline_js = preprocess_html(html, site_url)

    # Convert to markdown
    md_body = to_markdown(content_soup, site_url, topic, slug=slug)

    if not md_body or len(md_body.strip()) < 20:
        return f"failed (empty content after conversion)", False

    # Download images
    assets_dir = page_dir / "assets"
    md_body = download_images(md_body, assets_dir, site_url)

    # Handle inline JS
    if inline_js:
        assets_dir.mkdir(parents=True, exist_ok=True)
        js_path = assets_dir / "extra.js"
        js_path.write_text("\n\n".join(inline_js), encoding="utf-8")
        meta["has_inline_js"] = True
        logger.warning(f"  Saved {len(inline_js)} inline JS blocks to {js_path}")

    # Build frontmatter
    fm = {}

    # Preserve existing frontmatter fields
    if index_path.exists():
        try:
            existing_post = frontmatter.load(index_path)
            fm.update(existing_post.metadata)
        except Exception:
            pass

    # Merge downloaded metadata — title and description always come from the
    # actual page since stubs only have slug-based placeholders
    if meta.get("title"):
        fm["title"] = meta["title"]
    if meta.get("description"):
        fm["description"] = meta["description"]
    if meta.get("created"):
        fm["created"] = meta["created"]
    if meta.get("modified"):
        fm["modified"] = meta["modified"]
    if meta.get("author"):
        fm["author"] = meta["author"]
    if meta.get("section"):
        fm["section"] = meta["section"]
    if meta.get("has_inline_js"):
        fm["has_inline_js"] = True

    # Ensure title exists
    if not fm.get("title"):
        fm["title"] = slug.replace("-", " ").title()

    # Write markdown file
    page_dir.mkdir(parents=True, exist_ok=True)
    post = frontmatter.Post(md_body, **fm)
    frontmatter.dump(post, index_path)

    # Register in database
    try:
        from wire.db import register_content, init_db
        init_db(docs_dir)
        register_content(topic, slug, created=meta.get("created"), docs_dir=docs_dir)
    except Exception as e:
        logger.warning(f"  DB registration failed: {e}")

    # Count images
    img_count = len(list(assets_dir.glob("*"))) if assets_dir.exists() else 0
    word_count = len(md_body.split())

    return f"downloaded ({word_count} words, {img_count} images)", True
